
CREATE TABLE kyc_verifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE,
  front_face_image_url TEXT,
  left_face_image_url TEXT,
  right_face_image_url TEXT,
  document_type TEXT,
  document_number TEXT,
  document_image_url TEXT,
  verification_status TEXT DEFAULT 'pending',
  verified_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_kyc_user_id ON kyc_verifications(user_id);
CREATE INDEX idx_kyc_status ON kyc_verifications(verification_status);
