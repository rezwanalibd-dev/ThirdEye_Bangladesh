
-- Reports table for storing violation reports
CREATE TABLE reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_number TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  violation_type TEXT NOT NULL, -- 'traffic' or 'social'
  vehicle_number TEXT,
  location_text TEXT NOT NULL,
  latitude REAL,
  longitude REAL,
  description TEXT,
  status TEXT DEFAULT 'pending', -- pending, under_review, verified, rejected, resolved
  fine_amount REAL,
  commission_amount REAL,
  commission_paid BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Evidence files for reports
CREATE TABLE report_evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_id INTEGER NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL, -- image/video
  file_url TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- E-challans generated for violations
CREATE TABLE e_challans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_id INTEGER NOT NULL,
  challan_number TEXT NOT NULL UNIQUE,
  violator_email TEXT,
  violator_phone TEXT,
  vehicle_number TEXT,
  fine_amount REAL NOT NULL,
  status TEXT DEFAULT 'sent', -- sent, paid, overdue
  payment_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Commission payments to citizens
CREATE TABLE commission_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  report_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  mobile_banking_type TEXT NOT NULL, -- bkash, nagad, rocket, upay
  mobile_banking_number TEXT NOT NULL,
  payment_status TEXT DEFAULT 'pending', -- pending, processing, sent, failed
  transaction_id TEXT,
  payment_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_reports_user_id ON reports(user_id);
CREATE INDEX idx_reports_case_number ON reports(case_number);
CREATE INDEX idx_reports_status ON reports(status);
CREATE INDEX idx_report_evidence_report_id ON report_evidence(report_id);
CREATE INDEX idx_e_challans_report_id ON e_challans(report_id);
CREATE INDEX idx_commission_payments_user_id ON commission_payments(user_id);
