
DROP INDEX idx_commission_payments_user_id;
DROP INDEX idx_e_challans_report_id;
DROP INDEX idx_report_evidence_report_id;
DROP INDEX idx_reports_status;
DROP INDEX idx_reports_case_number;
DROP INDEX idx_reports_user_id;

DROP TABLE commission_payments;
DROP TABLE e_challans;
DROP TABLE report_evidence;
DROP TABLE reports;
