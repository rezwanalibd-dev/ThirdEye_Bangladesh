
DROP INDEX idx_otp_expires;
DROP INDEX idx_otp_user_id;
DROP TABLE otp_verifications;
