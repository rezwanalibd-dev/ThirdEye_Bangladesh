
DROP INDEX idx_kyc_status;
DROP INDEX idx_kyc_user_id;
DROP TABLE kyc_verifications;
