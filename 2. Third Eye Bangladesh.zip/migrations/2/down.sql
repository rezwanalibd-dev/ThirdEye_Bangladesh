
DROP INDEX idx_users_email;
DROP INDEX idx_users_mobile;
DROP TABLE users;
