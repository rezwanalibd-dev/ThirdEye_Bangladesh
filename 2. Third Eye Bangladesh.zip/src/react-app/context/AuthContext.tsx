import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export type UserRole = 'citizen' | 'dmpOfficer' | 'brtaOfficial';
export type VerificationStatus = 'pending' | 'documents_uploaded' | 'biometric_complete' | 'wallet_verified' | 'complete';

export interface User {
  id: string;
  email?: string;
  fullName: string;
  mobileNumber: string;
  role: UserRole;
  verificationStatus: VerificationStatus;
  profileImage?: string;
  
  // Identity Documents
  nidNumber?: string;
  drivingLicenseNumber?: string;
  passportNumber?: string;
  
  // Document Verification Status
  documentsVerified: boolean;
  biometricVerified: boolean;
  
  // Mobile Wallet Info (for citizens)
  walletInfo?: {
    type: string;
    provider: string;
    number: string;
    accountHolder: string;
    verified: boolean;
  };
  
  // Officer-specific fields
  badgeNumber?: string;
  employeeId?: string;
  department?: string;
  rank?: string;
  postingArea?: string;
  
  // Statistics
  statistics?: {
    reportsFiled: number;
    casesResolved: number;
    rewardsEarned: number;
    pendingRewards: number;
    falseReports: number;
    successRate: number;
  };
  
  // Account Status
  accountStatus: 'active' | 'suspended' | 'deactivated';
  createdAt: string;
  lastLoginAt?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (identifier: string, password: string) => Promise<boolean>;
  signup: (userData: any, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
  updateVerificationStatus: (status: VerificationStatus) => void;
  canReport: () => boolean;
  canReportSocialCrime: () => boolean;
  getVerificationProgress: () => number;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('thirdEyeUser');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        setIsAuthenticated(true);
      } catch (err) {
        console.error('Error parsing saved user data:', err);
        localStorage.removeItem('thirdEyeUser');
      }
    }
  }, []);

  // Save user to localStorage whenever user changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('thirdEyeUser', JSON.stringify(user));
    } else {
      localStorage.removeItem('thirdEyeUser');
    }
  }, [user]);

  const login = async (identifier: string, _password: string): Promise<boolean> => {
    console.log('Authenticating user:', identifier.substring(0, 3) + '***');
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock authentication logic
      const isDemoAccount = identifier.includes('@demo.com') || identifier.includes('demo');
      const isOfficer = identifier.includes('officer') || identifier.includes('dmp');
      const isBrtaOfficial = identifier.includes('brta');
      
      const mockUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email: identifier.includes('@') ? identifier : undefined,
        mobileNumber: identifier.includes('@') ? '+8801234567890' : identifier,
        fullName: isDemoAccount ? 
          (isOfficer ? 'Demo DMP Officer' : 
           isBrtaOfficial ? 'Demo BRTA Official' : 
           'Demo Citizen') : 'Test User',
        role: isOfficer ? 'dmpOfficer' : isBrtaOfficial ? 'brtaOfficial' : 'citizen',
        verificationStatus: isDemoAccount ? 'complete' : 'pending',
        documentsVerified: isDemoAccount,
        biometricVerified: isDemoAccount,
        accountStatus: 'active',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        
        // Demo wallet info for citizens
        walletInfo: isDemoAccount && !isOfficer && !isBrtaOfficial ? {
          type: 'bKash',
          provider: 'bKash',
          number: '+8801234567890',
          accountHolder: 'Demo Citizen',
          verified: true
        } : undefined,
        
        // Demo statistics
        statistics: {
          reportsFiled: isDemoAccount ? 15 : 5,
          casesResolved: isDemoAccount ? 12 : 3,
          rewardsEarned: isDemoAccount ? 3500 : 800,
          pendingRewards: isDemoAccount ? 500 : 200,
          falseReports: 0,
          successRate: isDemoAccount ? 85.5 : 70.0
        },
        
        // Officer-specific info
        badgeNumber: isOfficer ? 'DMP-12345' : undefined,
        employeeId: isBrtaOfficial ? 'BRTA-67890' : undefined,
        department: isOfficer ? 'Traffic Division' : undefined,
        postingArea: isBrtaOfficial ? 'Dhaka Metro' : undefined
      };

      setUser(mockUser);
      setIsAuthenticated(true);
      return true;
    } catch (err) {
      console.error('Login error:', err);
      return false;
    }
  };

  const signup = async (userData: any, _password: string): Promise<boolean> => {
    console.log('Creating account for:', userData.fullName);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Determine verification status based on completed steps
      let verificationStatus: VerificationStatus = 'pending';
      let documentsVerified = false;
      let biometricVerified = false;
      
      // Check if documents are uploaded
      const hasDocuments = userData.nidNumber || userData.drivingLicenseNumber || userData.passportNumber;
      if (hasDocuments) {
        verificationStatus = 'documents_uploaded';
        documentsVerified = true;
      }
      
      // Check if biometric data is captured
      const hasBiometric = userData.frontFaceImage && userData.leftFaceImage && userData.rightFaceImage;
      if (hasBiometric) {
        verificationStatus = 'biometric_complete';
        biometricVerified = true;
      }
      
      // Check if wallet is set up (for citizens)
      const hasWallet = userData.role !== 'citizen' || (userData.walletProvider && userData.walletNumber);
      if (hasWallet && userData.role === 'citizen') {
        verificationStatus = 'wallet_verified';
      }
      
      // Complete verification for officers or fully verified citizens
      if ((userData.role !== 'citizen' && documentsVerified && biometricVerified) ||
          (userData.role === 'citizen' && documentsVerified && biometricVerified && hasWallet)) {
        verificationStatus = 'complete';
      }
      
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email: userData.email || undefined,
        mobileNumber: userData.mobileNumber,
        fullName: userData.fullName,
        role: userData.role,
        verificationStatus,
        documentsVerified,
        biometricVerified,
        accountStatus: 'active',
        createdAt: new Date().toISOString(),
        
        // Identity documents
        nidNumber: userData.nidNumber || undefined,
        drivingLicenseNumber: userData.drivingLicenseNumber || undefined,
        passportNumber: userData.passportNumber || undefined,
        
        // Mobile wallet info (citizens only)
        walletInfo: userData.role === 'citizen' && userData.walletProvider ? {
          type: userData.walletProvider,
          provider: userData.walletProvider,
          number: userData.walletNumber,
          accountHolder: userData.walletAccountHolder,
          verified: true // Assume verified after OTP
        } : undefined,
        
        // Officer-specific fields
        badgeNumber: userData.badgeNumber,
        employeeId: userData.employeeId,
        department: userData.department,
        rank: userData.rank,
        postingArea: userData.postingArea,
        
        // Initial statistics
        statistics: {
          reportsFiled: 0,
          casesResolved: 0,
          rewardsEarned: 0,
          pendingRewards: 0,
          falseReports: 0,
          successRate: 100
        }
      };

      setUser(newUser);
      setIsAuthenticated(true);
      return true;
    } catch (err) {
      console.error('Signup error:', err);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('thirdEyeUser');
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
    }
  };

  const updateVerificationStatus = (status: VerificationStatus) => {
    if (user) {
      setUser({ ...user, verificationStatus: status });
    }
  };

  const canReport = (): boolean => {
    return user?.role === 'citizen' && 
           user?.verificationStatus === 'complete' && 
           user?.accountStatus === 'active' &&
           user?.documentsVerified === true &&
           user?.biometricVerified === true &&
           (user?.walletInfo?.verified === true);
  };

  const canReportSocialCrime = (): boolean => {
    // Social crime reporting requires less verification - just basic identity
    return user !== null && 
           user?.accountStatus === 'active' &&
           (user?.documentsVerified === true || user?.biometricVerified === true);
  };

  const getVerificationProgress = (): number => {
    if (!user) return 0;
    
    let progress = 0;
    
    // Step 1: Basic info (always completed if user exists)
    progress += 20;
    
    // Step 2: Documents
    if (user.documentsVerified) progress += 20;
    
    // Step 3: Biometric
    if (user.biometricVerified) progress += 20;
    
    // Step 4: Wallet (citizens only)
    if (user.role !== 'citizen' || user.walletInfo?.verified) progress += 20;
    
    // Step 5: Complete verification
    if (user.verificationStatus === 'complete') progress += 20;
    
    return Math.min(progress, 100);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        login,
        signup,
        logout,
        updateUser,
        updateVerificationStatus,
        canReport,
        canReportSocialCrime,
        getVerificationProgress,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
