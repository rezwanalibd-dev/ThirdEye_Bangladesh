import { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'bn';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // App Title & Branding
    'appName': 'Third Eye',
    'appTagline': 'Your Vigilance Saves Lives and Earns Rewards',
    'tagline': 'Report Violations • Earn Rewards • Save Lives',
    'welcome': 'Welcome, Citizen!',
    
    // Language Labels
    'languageLabel': 'English/Bangla',
    'otherLanguageLabel': 'ইংরেজি/বাংলা',
    'skip': 'Skip',
    
    // Onboarding Content
    'onboardingTitle1': 'Welcome to Third Eye',
    'onboardingDesc1': 'Are you ready to make a difference?\nYour report can save lives.\nSeen a violation — wrong-side driving, footpath riding, illegal horns, mobile use while driving, speeding, helmetless riders, or illegal parking? Report it and help prevent accidents.\nDon\'t be a bystander - Be a public guardian.\nYour voice matters.\nReport today for safer roads.',
    'onboardingTitle2': 'Snap, Tag, Submit',
    'onboardingDesc2': 'Capture photo/video, geotag location, and select the violation type.',
    'onboardingTitle3': 'Earn Commission',
    'onboardingDesc3': 'Get 20% commission on the fine collected after official verification.',
    'onboardingTitle4': 'Stand Against Social Crimes',
    'onboardingDesc4': 'Stand against social crimes.\nYour courage saves lives.\nBreak the silence — report violence, theft, corruption, harassment, or other crimes anonymously. Protect the vulnerable, fight injustice. Identity protected; impact lasting.\nBuild a fearless Bangladesh\nAct today. Report Now.',
    'startReporting': 'Start Reporting',
    
    // Navigation
    'home': 'Home',
    'login': 'Login',
    'signup': 'Sign Up',
    'dashboard': 'Dashboard',
    'profile': 'Profile',
    'logout': 'Logout',
    
    // Authentication
    'email': 'Email Address',
    'mobileOrEmail': 'Mobile Number or Email',
    'password': 'Password',
    'confirmPassword': 'Confirm Password',
    'fullName': 'Full Name',
    'phoneNumber': 'Phone Number',
    'signIn': 'Sign In',
    'createAccount': 'Create Account',
    'forgotPassword': 'Forgot Password?',
    'alreadyHaveAccount': 'Already have an account?',
    'dontHaveAccount': "Don't have an account?",
    
    // User Roles
    'selectRole': 'Select Your Role',
    'citizen': 'Citizen',
    'dmpOfficer': 'DMP Officer',
    'brtaOfficial': 'BRTA Official',
    
    // Features
    'reportViolation': 'Report Violation',
    'reportViolationDesc': 'Capture evidence of traffic rule breaks',
    'reportInjustice': 'Report Injustice Safely',
    'reportInjusticeDesc': 'Securely report harassment, corruption, or abuse',
    
    // Report Injustice Page
    'reportInjusticeTitle': 'Report Injustice Safely',
    'yourIdentityProtected': 'Your Identity is Protected',
    'completeAnonymityGuaranteed': 'Complete anonymity guaranteed',
    'noPersonalInfoShared': 'No personal information shared with authorities',
    'secureEncryptedSubmission': 'Secure encrypted submission',
    'professionalInvestigation': 'Professional investigation without revealing source',
    'crimeCategory': 'Crime Category',
    'selectCrimeType': 'Select crime type...',
    'incidentLocation': 'Incident Location',
    'gpsLocationAutoDetected': 'GPS location will be auto-detected',
    'locationAutoDetected': 'Location is automatically detected for accuracy and cannot be manually edited',
    'evidence': 'Evidence',
    'takePhotoNow': 'Take Photo Now',
    'instantCapture': 'Instant capture',
    'recordVideoNow': 'Record Video Now',
    'instantRecording': 'Instant recording',
    'uploadEvidence': 'Upload Evidence',
    'chooseExistingFiles': 'Or choose existing photos/videos from device',
    'fileUploadLimit': 'Up to 50MB per file (max 5 files)',
    'incidentDescription': 'Incident Description (Optional)',
    'describeIncident': 'Describe the incident in detail. You can write in English or Bangla. Include time, people involved, what happened, and any other relevant information...',
    'tipProvideDetails': 'Tip: Provide as much detail as possible to help authorities investigate effectively. Your identity will remain completely protected.',
    'anonymousReporting': 'Anonymous Reporting: Your identity is fully protected by law',
    'legalProtection': 'Legal Protection: Whistleblower protection laws apply',
    'warningFalseReports': 'Warning: False reports are punishable by law',
    'submitAnonymousReport': 'Submit Anonymous Report',
    'caseStatus': 'Case Status',
    'caseStatusDesc': 'Track your filed reports and rewards',
    'trafficRules': 'Traffic Rules & Fines',
    'trafficRulesDesc': 'Stay Regularly Updated on the Road Transport Act 2018',
    'digitalWallet': 'Digital Wallet',
    'digitalWalletDesc': 'View commissions and manage finances',
    'emergencyCall': 'Emergency Call 999',
    'emergencyServices': 'Emergency Services',
    
    // Reporting
    'violationType': 'Violation Type',
    'trafficViolation': 'Traffic Violation',
    'socialCrime': 'Social Crime',
    'vehicleNumber': 'Vehicle Number',
    'location': 'Location',
    'description': 'Description',
    'submitReport': 'Submit Report',
    'takePhoto': 'Take Photo',
    'recordVideo': 'Record Video',
    
    // Statistics
    'reportsFiled': 'Reports Filed',
    'activeCitizens': 'Active Citizens',
    'casesResolved': 'Cases Resolved',
    'rewardsDistributed': 'Rewards Distributed',
    'communityImpact': 'Community Impact',
    
    // KYC & Verification
    'kycVerification': 'KYC Verification',
    'documentUpload': 'Document Upload',
    'biometricVerification': 'Biometric Verification',
    'nidNumber': 'NID Number',
    'drivingLicense': 'Driving License',
    'passport': 'Passport',
    'uploadDocument': 'Upload Document',
    'takeSelfie': 'Take Selfie',
    
    // Rewards & Penalties
    'rewardSystem': 'Reward System: 20% commission on fine recovery',
    'falseReportPenalty': 'Warning: Penalty for false reports',
    'earnedRewards': 'Earned Rewards',
    'pendingRewards': 'Pending Rewards',
    
    // General Actions
    'next': 'Next',
    'previous': 'Previous',
    'submit': 'Submit',
    'cancel': 'Cancel',
    'save': 'Save',
    'edit': 'Edit',
    'delete': 'Delete',
    'search': 'Search',
    'filter': 'Filter',
    'loading': 'Loading...',
    'success': 'Success',
    'error': 'Error',
    
    // Emergency Contacts
    'police': 'Police',
    'fireService': 'Fire Service',
    'ambulance': 'Ambulance',
    'emergencyHotline': 'Emergency Hotline',
  },
  bn: {
    // App Title & Branding
    'appName': 'তৃতীয় চোখ',
    'appTagline': 'আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার',
    'tagline': 'অনিয়ম রিপোর্ট করুন • পুরস্কার অর্জন করুন • জীবন বাঁচান',
    'welcome': 'স্বাগতম, নাগরিক!',
    
    // Language Labels
    'languageLabel': 'ইংরেজি/বাংলা',
    'otherLanguageLabel': 'English/Bangla',
    'skip': 'এড়িয়ে যান',
    
    // Onboarding Content
    'onboardingTitle1': 'তৃতীয় চোখে স্বাগতম',
    'onboardingDesc1': 'আপনি কি পরিবর্তন আনতে প্রস্তুত?\nআপনার রিপোর্ট জীবন বাঁচাতে পারে।\nভুল পাশ দিয়ে গাড়ি চালানো, ফুটপাতে গাড়ি চালানো, অবৈধ হর্ন, চালকের মোবাইল ব্যবহার, অতিরিক্ত গতি, হেলমেট ছাড়া রাইড বা অবৈধ পার্কিং — এইসব ট্রাফিক আইন লঙ্ঘন দেখলেই রিপোর্ট করুন, দুর্ঘটনা প্রতিরোধে সাহায্য করুন।\nদর্শক বনে থাকবেন না - জনসাধারণের অভিভাবক হন।\nআপনার কণ্ঠস্বর গুরুত্বপূর্ণ।\nনিরাপদ সড়কের জন্য আজই রিপোর্ট করুন।',
    'onboardingTitle2': 'ছবি তুলুন, ট্যাগ করুন, জমা দিন',
    'onboardingDesc2': 'ফটো/ভিডিও তুলুন, অবস্থান জিওট্যাগ করুন, এবং আইন লঙ্ঘনের ধরন নির্বাচন করুন।',
    'onboardingTitle3': 'কমিশন অর্জন করুন',
    'onboardingDesc3': 'সরকারি যাচাইকরণের পর আদায় হওয়া জরিমানা থেকে ২০% কমিশন পান।',
    'onboardingTitle4': 'সামাজিক অপরাধের বিরুদ্ধে দাঁড়ান',
    'onboardingDesc4': 'সামাজিক অপরাধের বিরুদ্ধে দাঁড়ান।\nআপনার সাহস জীবন বাঁচায়।\nনীরবতা ভাঙুন — সহিংসতা, চুরি, দুর্নীতি, হয়রানি বা অন্য কোনো অপরাধ বেনামে রিপোর্ট করুন।\nদুর্বলদের রক্ষা করুন, ন্যায় প্রতিষ্ঠায় ভূমিকা নিন। পরিচয় সুরক্ষিত; প্রভাব স্থায়ী।\nনির্ভীক বাংলাদেশ গড়ুন\nআজই কাজ করুন।রিপোর্ট করুন।',
    'startReporting': 'রিপোর্ট করা শুরু করুন',
    
    // Navigation
    'home': 'হোম',
    'login': 'লগইন',
    'signup': 'সাইন আপ',
    'dashboard': 'ড্যাশবোর্ড',
    'profile': 'প্রোফাইল',
    'logout': 'লগআউট',
    
    // Authentication
    'email': 'ইমেইল ঠিকানা',
    'mobileOrEmail': 'মোবাইল নম্বর বা ইমেইল',
    'password': 'পাসওয়ার্ড',
    'confirmPassword': 'পাসওয়ার্ড নিশ্চিত করুন',
    'fullName': 'পুরো নাম',
    'phoneNumber': 'ফোন নম্বর',
    'signIn': 'সাইন ইন',
    'createAccount': 'অ্যাকাউন্ট তৈরি করুন',
    'forgotPassword': 'পাসওয়ার্ড ভুলে গেছেন?',
    'alreadyHaveAccount': 'ইতিমধ্যে একটি অ্যাকাউন্ট আছে?',
    'dontHaveAccount': 'কোন অ্যাকাউন্ট নেই?',
    
    // User Roles
    'selectRole': 'আপনার ভূমিকা নির্বাচন করুন',
    'citizen': 'নাগরিক',
    'dmpOfficer': 'ডিএমপি অফিসার',
    'brtaOfficial': 'বিআরটিএ কর্মকর্তা',
    
    // Features
    'reportViolation': 'অনিয়ম রিপোর্ট করুন',
    'reportViolationDesc': 'ট্রাফিক আইন ভাঙার প্রমাণ সংগ্রহ করুন',
    'reportInjustice': 'নিরাপদে অন্যায়ের রিপোর্ট দিন',
    'reportInjusticeDesc': 'উৎপীড়ন, দুর্নীতি বা নির্যাতন নিরাপদে রিপোর্ট করুন।',
    
    // Report Injustice Page
    'reportInjusticeTitle': 'অন্যায়ের বিরুদ্ধে নিরাপদে রিপোর্ট করুন',
    'yourIdentityProtected': 'আপনার পরিচয় সুরক্ষিত',
    'completeAnonymityGuaranteed': 'সম্পূর্ণ বেনামিত্বের নিশ্চয়তা',
    'noPersonalInfoShared': 'কর্তৃপক্ষের সাথে কোনো ব্যক্তিগত তথ্য শেয়ার করা হয় না',
    'secureEncryptedSubmission': 'নিরাপদ এনক্রিপ্টেড জমাদান',
    'professionalInvestigation': 'সূত্র গোপন রেখে পেশাদার তদন্ত',
    'crimeCategory': 'অপরাধের বিভাগ',
    'selectCrimeType': 'অপরাধের ধরন নির্বাচন করুন...',
    'incidentLocation': 'ঘটনার অবস্থান',
    'gpsLocationAutoDetected': 'জিপিএস লোকেশন স্বয়ংক্রিয়ভাবে শনাক্ত করা হবে',
    'locationAutoDetected': 'সঠিকতার জন্য অবস্থান স্বয়ংক্রিয়ভাবে শনাক্ত করা হয় এবং হাতেই সম্পাদনা করা যাবে না',
    'evidence': 'প্রমাণ',
    'takePhotoNow': 'এখনই ফটো তুলুন',
    'instantCapture': 'তাৎক্ষণিক ক্যাপচার',
    'recordVideoNow': 'এখনই ভিডিও রেকর্ড করুন',
    'instantRecording': 'তাৎক্ষণিক রেকর্ডিং',
    'uploadEvidence': 'প্রমাণ আপলোড করুন',
    'chooseExistingFiles': 'অথবা ডিভাইস থেকে বিদ্যমান ছবি/ভিডিও নির্বাচন করুন',
    'fileUploadLimit': 'প্রতি ফাইলে সর্বোচ্চ ৫০এমবি (সর্বোচ্চ ৫টি ফাইল)',
    'incidentDescription': 'ঘটনার বর্ণনা (ঐচ্ছিক)',
    'describeIncident': 'ঘটনাটির বিস্তারিত বর্ণনা করুন। আপনি ইংরেজি বা বাংলায় লিখতে পারেন। সময়, সংশ্লিষ্ট ব্যক্তি, কী ঘটেছে এবং অন্য কোনো প্রাসঙ্গিক তথ্য অন্তর্ভুক্ত করুন...',
    'tipProvideDetails': 'পরামর্শ: কর্তৃপক্ষের কার্যকর তদন্তে সহায়তার জন্য যতটা সম্ভব বিস্তারিত তথ্য প্রদান করুন। আপনার পরিচয় সম্পূর্ণরূপে সুরক্ষিত থাকবে।',
    'anonymousReporting': 'বেনামি রিপোর্টিং: আইন দ্বারা আপনার পরিচয় সম্পূর্ণরূপে সুরক্ষিত',
    'legalProtection': 'আইনি সুরক্ষা: হুইসেলব্লোয়ার সুরক্ষা আইন প্রযোজ্য',
    'warningFalseReports': 'সতর্কতা: মিথ্যা রিপোর্ট আইনত দণ্ডনীয়',
    'submitAnonymousReport': 'পরিচয় গোপন রেখে রিপোর্ট করুন',
    'caseStatus': 'মামলার অবস্থা',
    'caseStatusDesc': 'আপনার রিপোর্ট এবং পুরস্কারের খোঁজ রাখুন',
    'trafficRules': 'ট্রাফিক আইন ও জরিমানা',
    'trafficRulesDesc': 'সড়ক পরিবহন আইন ২০১৮ সম্পর্কে নিয়মিত আপডেটেড থাকুন',
    'digitalWallet': 'ডিজিটাল ওয়ালেট',
    'digitalWalletDesc': 'কমিশন দেখুন এবং আর্থিক ব্যবস্থাপনা করুন',
    'emergencyCall': 'জরুরী কল ৯৯৯',
    'emergencyServices': 'জরুরি পরিষেবা',
    
    // Reporting
    'violationType': 'অনিয়মের ধরন',
    'trafficViolation': 'ট্রাফিক অনিয়ম',
    'socialCrime': 'সামাজিক অপরাধ',
    'vehicleNumber': 'গাড়ির নম্বর',
    'location': 'অবস্থান',
    'description': 'বিবরণ',
    'submitReport': 'রিপোর্ট জমা দিন',
    'takePhoto': 'ছবি তুলুন',
    'recordVideo': 'ভিডিও রেকর্ড করুন',
    
    // Statistics
    'reportsFiled': 'রিপোর্ট জমা হয়েছে',
    'activeCitizens': 'সক্রিয় নাগরিক',
    'casesResolved': 'সমাধান হওয়া মামলা',
    'rewardsDistributed': 'পুরস্কার বিতরণ করা হয়েছে',
    'communityImpact': 'কমিউনিটি প্রভাব',
    
    // KYC & Verification
    'kycVerification': 'কেওয়াইসি যাচাইকরণ',
    'documentUpload': 'নথি আপলোড',
    'biometricVerification': 'বায়োমেট্রিক যাচাইকরণ',
    'nidNumber': 'এনআইডি নম্বর',
    'drivingLicense': 'ড্রাইভিং লাইসেন্স',
    'passport': 'পাসপোর্ট',
    'uploadDocument': 'নথি আপলোড করুন',
    'takeSelfie': 'সেলফি তুলুন',
    
    // Rewards & Penalties
    'rewardSystem': 'পুরস্কার ব্যবস্থা: জরিমানা আদায়ের উপর ২০% কমিশন',
    'falseReportPenalty': 'সতর্কতা: মিথ্যা রিপোর্টের জন্য জরিমানা',
    'earnedRewards': 'অর্জিত পুরস্কার',
    'pendingRewards': 'অপেক্ষমান পুরস্কার',
    
    // General Actions
    'next': 'পরবর্তী',
    'previous': 'পূর্ববর্তী',
    'submit': 'জমা দিন',
    'cancel': 'বাতিল',
    'save': 'সংরক্ষণ',
    'edit': 'সম্পাদনা',
    'delete': 'মুছুন',
    'search': 'অনুসন্ধান',
    'filter': 'ফিল্টার',
    'loading': 'লোড হচ্ছে...',
    'success': 'সফল',
    'error': 'ত্রুটি',
    
    // Emergency Contacts
    'police': 'পুলিশ',
    'fireService': 'ফায়ার সার্ভিস',
    'ambulance': 'অ্যাম্বুলেন্স',
    'emergencyHotline': 'জরুরী হটলাইন',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'bn' : 'en');
  };

  const t = (key: string): string => {
    return (translations[language] as Record<string, string>)[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
