import { useState, useEffect } from 'react';
import { Download, X } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function PWAInstallPrompt() {
  const { language } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setShowPrompt(false);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-white rounded-lg shadow-2xl border border-gray-200 p-4 z-50 animate-slide-up">
      <button
        onClick={handleDismiss}
        className="absolute top-2 right-2 p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
      >
        <X size={16} />
      </button>
      
      <div className="flex items-start space-x-4">
        <div className="bg-sky-100 p-3 rounded-full">
          <Download className="text-sky-600" size={24} />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-gray-800 mb-1">
            {language === 'en' ? 'Install Third Eye App' : 'থার্ড আই অ্যাপ ইনস্টল করুন'}
          </h3>
          <p className="text-sm text-gray-600 mb-3">
            {language === 'en' 
              ? 'Install our app for quick access and offline features. Works on Android and iOS devices.'
              : 'দ্রুত অ্যাক্সেস এবং অফলাইন বৈশিষ্ট্যের জন্য আমাদের অ্যাপ ইনস্টল করুন। অ্যান্ড্রয়েড এবং iOS ডিভাইসে কাজ করে।'
            }
          </p>
          <button
            onClick={handleInstall}
            className="w-full bg-sky-600 text-white py-2 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium text-sm flex items-center justify-center"
          >
            <Download size={16} className="mr-2" />
            {language === 'en' ? 'Install Now' : 'এখনই ইনস্টল করুন'}
          </button>
        </div>
      </div>
    </div>
  );
}
