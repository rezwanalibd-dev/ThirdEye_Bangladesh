import React from 'react';
import { Link, useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  Camera, 
  FileText, 
  BookOpen, 
  Wallet, 
  PhoneCall, 
  Settings, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  DollarSign,
  Shield,
  Gavel,
  Trophy
} from 'lucide-react';

interface DashboardCardProps {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  title: string;
  description: string;
  onClick: () => void;
  color: string;
  disabled?: boolean;
}

function DashboardCard({ icon: Icon, title, description, onClick, color, disabled = false }: DashboardCardProps) {
  return (
    <div
      onClick={disabled ? undefined : onClick}
      className={`
        group flex flex-col p-6 rounded-xl shadow-lg transition-all duration-300 cursor-pointer h-40
        ${disabled 
          ? 'bg-gray-100 opacity-50 cursor-not-allowed' 
          : `bg-white hover:shadow-xl transform hover:-translate-y-1 hover:border-l-4 hover:border-l-${color}-500`
        }
      `}
    >
      <div className={`flex items-center justify-between mb-4 text-${color}-600`}>
        <Icon size={32} />
        <div className={`w-3 h-3 rounded-full bg-${color}-200 group-hover:bg-${color}-400 transition-colors`} />
      </div>
      <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">
        {title}
      </h3>
      <p className="text-sm text-gray-600 flex-grow line-clamp-3">
        {description}
      </p>
      {disabled && (
        <div className="mt-2 text-xs text-red-600 font-medium">
          Complete KYC verification to unlock
        </div>
      )}
    </div>
  );
}

function CitizenDashboard() {
  const { t } = useLanguage();
  const { user, canReport } = useAuth();
  const navigate = useNavigate();

  const incompleteVerification = user?.verificationStatus !== 'complete';

  const handleFeatureClick = (route: string) => {
    if (route === '/report' && !canReport()) {
      alert('Please complete KYC verification to report violations');
      return;
    }
    if (route === '/profile' && !user?.walletInfo) {
      alert('Please complete Digital Wallet setup in Profile to access all features');
      navigate('/profile');
      return;
    }
    navigate(route);
  };

  return (
    <div className="space-y-6">
      {/* Verification Warning */}
      {incompleteVerification && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="text-yellow-600 mr-3" size={24} />
            <div>
              <h3 className="font-medium text-yellow-800">Verification Required</h3>
              <p className="text-sm text-yellow-700">
                Complete your KYC verification to unlock all features and start reporting violations.
              </p>
              <button 
                onClick={() => navigate('/profile')}
                className="mt-2 text-sm bg-yellow-600 text-white px-3 py-1 rounded hover:bg-yellow-700"
              >
                Complete Verification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Welcome Card */}
      <div className="bg-gradient-to-r from-blue-50 to-sky-50 p-6 rounded-xl border border-blue-100">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-800">{t('welcome')}</h2>
            <p className="text-gray-600">{user?.fullName}</p>
            <div className="flex items-center mt-2 space-x-4 text-sm">
              <span className="flex items-center text-green-600">
                <DollarSign size={16} className="mr-1" />
                ৳{user?.statistics?.rewardsEarned || 0}
              </span>
              <span className="text-gray-500">
                {user?.statistics?.reportsFiled || 0} reports filed
              </span>
            </div>
          </div>
          <div className="text-right">
            <div className={`inline-flex px-3 py-1 rounded-full text-xs font-medium ${
              user?.verificationStatus === 'complete' 
                ? 'bg-green-100 text-green-800' 
                : 'bg-yellow-100 text-yellow-800'
            }`}>
              {user?.verificationStatus === 'complete' ? 'Verified' : 'Pending Verification'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DashboardCard
          icon={Camera}
          title={t('reportViolation')}
          description={t('reportViolationDesc')}
          onClick={() => handleFeatureClick('/report')}
          color="blue"
          disabled={!canReport()}
        />
        <DashboardCard
          icon={Shield}
          title={t('reportInjustice')}
          description={t('reportInjusticeDesc')}
          onClick={() => handleFeatureClick('/report-injustice')}
          color="red"
        />
        <DashboardCard
          icon={FileText}
          title={t('caseStatus')}
          description={t('caseStatusDesc')}
          onClick={() => handleFeatureClick('/case-status')}
          color="green"
        />
        <DashboardCard
          icon={Wallet}
          title={t('digitalWallet')}
          description={t('digitalWalletDesc')}
          onClick={() => handleFeatureClick('/profile')}
          color="yellow"
          disabled={!user?.walletInfo}
        />
      </div>

      {/* Traffic Rules Section */}
      <div className="mt-6">
        <DashboardCard
          icon={BookOpen}
          title={t('trafficRules')}
          description={t('trafficRulesDesc')}
          onClick={() => handleFeatureClick('/traffic-rules')}
          color="purple"
        />
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow text-center">
          <div className="text-2xl font-bold text-blue-600">{user?.statistics?.reportsFiled || 0}</div>
          <div className="text-sm text-gray-600">{t('reportsFiled')}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow text-center">
          <div className="text-2xl font-bold text-green-600">{user?.statistics?.casesResolved || 0}</div>
          <div className="text-sm text-gray-600">{t('casesResolved')}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow text-center">
          <div className="text-2xl font-bold text-yellow-600">৳{user?.statistics?.rewardsEarned || 0}</div>
          <div className="text-sm text-gray-600">Rewards</div>
        </div>
      </div>

      {/* History Section */}
      <div className="mt-6">
        <button
          onClick={() => navigate('/history')}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-5 rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all cursor-pointer shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Trophy className="text-white mr-3" size={28} />
              <div className="text-left">
                <h3 className="font-bold text-white text-lg">Your Contribution & Achievements</h3>
                <p className="text-sm text-purple-100">View your history, rankings, and community impact</p>
              </div>
            </div>
            <div className="text-white font-bold text-2xl">
              #{Math.floor((user?.statistics?.casesResolved || 0) * 10 / 10) + 1}
            </div>
          </div>
        </button>
      </div>

      {/* Emergency Contact */}
      <Link to="/emergency">
        <div className="bg-red-600 p-5 rounded-lg border border-red-800 hover:bg-red-700 transition-all cursor-pointer shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <PhoneCall className="text-white mr-3" size={28} />
              <div>
                <h3 className="font-bold text-white text-lg">{t('emergencyCall')}</h3>
                <p className="text-sm text-red-100">Police, Fire, Ambulance - All emergency contacts</p>
              </div>
            </div>
            <div className="text-white font-bold text-2xl">999</div>
          </div>
        </div>
      </Link>
    </div>
  );
}

function OfficerDashboard() {
  const { user } = useAuth();

  const pendingReports = [
    { id: 'TE-001', type: 'Traffic Violation', location: 'Dhanmondi, Dhaka', status: 'pending' },
    { id: 'TE-002', type: 'Social Crime', location: 'Gulshan, Dhaka', status: 'review' },
    { id: 'TE-003', type: 'Traffic Violation', location: 'Uttara, Dhaka', status: 'pending' }
  ];

  return (
    <div className="space-y-6">
      {/* Officer Welcome */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border border-green-100">
        <div className="flex items-center">
          <Shield className="text-green-600 mr-4" size={40} />
          <div>
            <h2 className="text-xl font-bold text-gray-800">Officer Dashboard</h2>
            <p className="text-gray-600">{user?.fullName}</p>
            <p className="text-sm text-green-600 font-medium">
              {user?.role === 'dmpOfficer' ? 'DMP Officer' : 'BRTA Official'}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-600">Pending Reports</h3>
              <p className="text-2xl font-bold text-orange-600">12</p>
            </div>
            <Clock className="text-orange-600" size={24} />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-600">Verified Today</h3>
              <p className="text-2xl font-bold text-green-600">8</p>
            </div>
            <CheckCircle className="text-green-600" size={24} />
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-600">Total Processed</h3>
              <p className="text-2xl font-bold text-blue-600">156</p>
            </div>
            <Gavel className="text-blue-600" size={24} />
          </div>
        </div>
      </div>

      {/* Pending Reports List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-800">Pending Verification</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {pendingReports.map((report) => (
            <div key={report.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-3 h-3 rounded-full ${
                    report.status === 'pending' ? 'bg-orange-400' : 'bg-blue-400'
                  }`} />
                  <div>
                    <h4 className="font-medium text-gray-800">{report.id}</h4>
                    <p className="text-sm text-gray-600">{report.type}</p>
                    <p className="text-sm text-gray-500">{report.location}</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="px-4 py-2 bg-green-600 text-white text-sm rounded hover:bg-green-700">
                    Approve
                  </button>
                  <button className="px-4 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                    Reject
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { language, toggleLanguage } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Redirect if not authenticated
  React.useEffect(() => {
    if (!isAuthenticated || !user) {
      navigate('/login');
    }
  }, [isAuthenticated, user, navigate]);

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sky-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src="https://mocha-cdn.com/019a7364-a032-7e48-8ef2-a113c18111ab/third-eye-logo.png" 
                alt="Third Eye Logo" 
                className="w-12 h-12 rounded-full drop-shadow-sm border border-sky-200"
              />
              <div>
                <h1 className="text-lg font-bold text-gray-800" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                  {language === 'en' ? 'Third Eye' : 'তৃতীয় চোখ'}
                </h1>
                <p className="text-xs text-gray-600" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                  {language === 'en' ? 'Your Vigilance Saves Lives and Earns Rewards' : 'আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার'}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Language Toggle */}
              <button
                onClick={toggleLanguage}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100 transition duration-150"
                title="Toggle Language"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
              
              {/* Settings */}
              <Link 
                to="/settings"
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100 transition duration-150"
                title="Settings"
              >
                <Settings size={20} />
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {user.role === 'citizen' ? <CitizenDashboard /> : <OfficerDashboard />}
      </main>
    </div>
  );
}
