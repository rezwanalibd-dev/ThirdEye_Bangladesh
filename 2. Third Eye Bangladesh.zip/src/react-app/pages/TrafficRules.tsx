import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { 
  ArrowLeft,
  Globe,
  FileText,
  DollarSign,
  Search,
  ChevronDown,
  ChevronRight,
  Scale,
  Building2,
  Phone
} from 'lucide-react';

interface TrafficRule {
  id: string;
  title: string;
  titleEn: string;
  titleBn: string;
  description: string;
  descriptionEn: string;
  descriptionBn: string;
  fine: number;
  imprisonment?: string;
  imprisonmentEn?: string;
  imprisonmentBn?: string;
  section: string;
  category: 'moving' | 'parking' | 'license' | 'vehicle' | 'serious' | 'documents';
  severity: 'minor' | 'major' | 'serious';
  points?: number;
}

interface BRTAService {
  id: string;
  service: string;
  serviceEn: string;
  serviceBn: string;
  documents: string[];
  documentsEn: string[];
  documentsBn: string[];
  fee: number;
  processingTime: string;
  processingTimeEn: string;
  processingTimeBn: string;
  category: 'registration' | 'license' | 'renewal' | 'transfer' | 'permit';
}

export default function TrafficRulesPage() {
  const { language, toggleLanguage } = useLanguage();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'rules' | 'brta' | 'fines'>('rules');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());

  const trafficRules: TrafficRule[] = [
    {
      id: 'speed-limit',
      title: 'Speed Limit Violation',
      titleEn: 'Speed Limit Violation',
      titleBn: 'গতিসীমা লঙ্ঘন',
      description: 'Exceeding prescribed speed limits on roads',
      descriptionEn: 'Exceeding prescribed speed limits on roads',
      descriptionBn: 'সড়কে নির্ধারিত গতিসীমা অতিক্রম করা',
      fine: 3000,
      section: 'Section 103',
      category: 'moving',
      severity: 'major',
      points: 6
    },
    {
      id: 'red-light',
      title: 'Red Light Violation',
      titleEn: 'Red Light Violation',
      titleBn: 'লাল বাতি লঙ্ঘন',
      description: 'Running through red traffic signal',
      descriptionEn: 'Running through red traffic signal',
      descriptionBn: 'লাল ট্রাফিক সিগন্যাল অমান্য করা',
      fine: 5000,
      imprisonment: '1 month',
      imprisonmentEn: '1 month',
      imprisonmentBn: '১ মাস',
      section: 'Section 95',
      category: 'moving',
      severity: 'major',
      points: 8
    },
    {
      id: 'wrong-side',
      title: 'Wrong Side Driving',
      titleEn: 'Wrong Side Driving',
      titleBn: 'ভুল পথে গাড়ি চালানো',
      description: 'Driving on the wrong side of the road',
      descriptionEn: 'Driving on the wrong side of the road',
      descriptionBn: 'রাস্তার ভুল দিকে গাড়ি চালানো',
      fine: 5000,
      imprisonment: '1 month',
      imprisonmentEn: '1 month',
      imprisonmentBn: '১ মাস',
      section: 'Section 96',
      category: 'moving',
      severity: 'serious',
      points: 10
    },
    {
      id: 'mobile-phone',
      title: 'Mobile Phone While Driving',
      titleEn: 'Mobile Phone While Driving',
      titleBn: 'গাড়ি চালানোর সময় মোবাইল ফোন ব্যবহার',
      description: 'Using mobile phone while driving',
      descriptionEn: 'Using mobile phone while driving',
      descriptionBn: 'গাড়ি চালানোর সময় মোবাইল ফোন ব্যবহার করা',
      fine: 5000,
      section: 'Section 98',
      category: 'moving',
      severity: 'major',
      points: 6
    },
    {
      id: 'no-helmet',
      title: 'Riding Without Helmet',
      titleEn: 'Riding Without Helmet',
      titleBn: 'হেলমেট ছাড়া বাইক চালানো',
      description: 'Motorcyclist or passenger without helmet',
      descriptionEn: 'Motorcyclist or passenger without helmet',
      descriptionBn: 'মোটরসাইকেল চালক বা যাত্রী হেলমেট ছাড়া',
      fine: 1000,
      section: 'Section 109',
      category: 'vehicle',
      severity: 'minor',
      points: 3
    },
    {
      id: 'no-license',
      title: 'Driving Without License',
      titleEn: 'Driving Without License',
      titleBn: 'লাইসেন্স ছাড়া গাড়ি চালানো',
      description: 'Driving without valid driving license',
      descriptionEn: 'Driving without valid driving license',
      descriptionBn: 'বৈধ ড্রাইভিং লাইসেন্স ছাড়া গাড়ি চালানো',
      fine: 25000,
      imprisonment: '3 months',
      imprisonmentEn: '3 months',
      imprisonmentBn: '৩ মাস',
      section: 'Section 85',
      category: 'license',
      severity: 'serious',
      points: 15
    },
    {
      id: 'illegal-parking',
      title: 'Illegal Parking',
      titleEn: 'Illegal Parking',
      titleBn: 'অবৈধ পার্কিং',
      description: 'Parking in prohibited areas',
      descriptionEn: 'Parking in prohibited areas',
      descriptionBn: 'নিষিদ্ধ এলাকায় পার্কিং',
      fine: 2000,
      section: 'Section 104',
      category: 'parking',
      severity: 'minor',
      points: 2
    },
    {
      id: 'drink-driving',
      title: 'Drink and Drive',
      titleEn: 'Drink and Drive',
      titleBn: 'মদ খেয়ে গাড়ি চালানো',
      description: 'Driving under influence of alcohol',
      descriptionEn: 'Driving under influence of alcohol',
      descriptionBn: 'মদের প্রভাবে গাড়ি চালানো',
      fine: 50000,
      imprisonment: '6 months',
      imprisonmentEn: '6 months',
      imprisonmentBn: '৬ মাস',
      section: 'Section 112',
      category: 'serious',
      severity: 'serious',
      points: 20
    }
  ];

  const brtaServices: BRTAService[] = [
    {
      id: 'new-car-registration',
      service: 'New Car Registration',
      serviceEn: 'New Car Registration',
      serviceBn: 'নতুন গাড়ি নিবন্ধন',
      documents: [
        'Invoice/Bill of Sale',
        'Import Permit (if imported)',
        'Insurance Certificate',
        'Tax Token',
        'Applicant\'s NID',
        'Passport Size Photo'
      ],
      documentsEn: [
        'Invoice/Bill of Sale',
        'Import Permit (if imported)',
        'Insurance Certificate',
        'Tax Token',
        'Applicant\'s NID',
        'Passport Size Photo'
      ],
      documentsBn: [
        'ইনভয়েস/বিক্রয় দলিল',
        'আমদানি অনুমতিপত্র (আমদানিকৃত হলে)',
        'বীমা সার্টিফিকেট',
        'ট্যাক্স টোকেন',
        'আবেদনকারীর এনআইডি',
        'পাসপোর্ট সাইজ ছবি'
      ],
      fee: 25000,
      processingTime: '7-10 working days',
      processingTimeEn: '7-10 working days',
      processingTimeBn: '৭-১০ কর্মদিবস',
      category: 'registration'
    },
    {
      id: 'driving-license-new',
      service: 'New Driving License',
      serviceEn: 'New Driving License',
      serviceBn: 'নতুন ড্রাইভিং লাইসেন্স',
      documents: [
        'Filled Application Form',
        'Medical Certificate',
        'NID Copy',
        'Passport Size Photo (8 copies)',
        'Driving School Certificate',
        'Eye Test Report'
      ],
      documentsEn: [
        'Filled Application Form',
        'Medical Certificate',
        'NID Copy',
        'Passport Size Photo (8 copies)',
        'Driving School Certificate',
        'Eye Test Report'
      ],
      documentsBn: [
        'পূরণকৃত আবেদনপত্র',
        'মেডিকেল সার্টিফিকেট',
        'এনআইডি কপি',
        'পাসপোর্ট সাইজ ছবি (৮ কপি)',
        'ড্রাইভিং স্কুল সার্টিফিকেট',
        'চোখের পরীক্ষার রিপোর্ট'
      ],
      fee: 3200,
      processingTime: '15-20 working days',
      processingTimeEn: '15-20 working days',
      processingTimeBn: '১৫-২০ কর্মদিবস',
      category: 'license'
    },
    {
      id: 'license-renewal',
      service: 'Driving License Renewal',
      serviceEn: 'Driving License Renewal',
      serviceBn: 'ড্রাইভিং লাইসেন্স নবায়ন',
      documents: [
        'Original License',
        'Medical Certificate',
        'NID Copy',
        'Passport Size Photo (4 copies)',
        'Renewal Application'
      ],
      documentsEn: [
        'Original License',
        'Medical Certificate',
        'NID Copy',
        'Passport Size Photo (4 copies)',
        'Renewal Application'
      ],
      documentsBn: [
        'মূল লাইসেন্স',
        'মেডিকেল সার্টিফিকেট',
        'এনআইডি কপি',
        'পাসপোর্ট সাইজ ছবি (৪ কপি)',
        'নবায়ন আবেদন'
      ],
      fee: 1600,
      processingTime: '7-10 working days',
      processingTimeEn: '7-10 working days',
      processingTimeBn: '৭-১০ কর্মদিবস',
      category: 'renewal'
    },
    {
      id: 'vehicle-transfer',
      service: 'Vehicle Ownership Transfer',
      serviceEn: 'Vehicle Ownership Transfer',
      serviceBn: 'গাড়ির মালিকানা হস্তান্তর',
      documents: [
        'Original Registration Book',
        'Transfer Application',
        'Seller\'s NID',
        'Buyer\'s NID',
        'Tax Clearance',
        'NOC from Traffic Police'
      ],
      documentsEn: [
        'Original Registration Book',
        'Transfer Application',
        'Seller\'s NID',
        'Buyer\'s NID',
        'Tax Clearance',
        'NOC from Traffic Police'
      ],
      documentsBn: [
        'মূল রেজিস্ট্রেশন বই',
        'হস্তান্তর আবেদন',
        'বিক্রেতার এনআইডি',
        'ক্রেতার এনআইডি',
        'ট্যাক্স ক্লিয়ারেন্স',
        'ট্রাফিক পুলিশের অনাপত্তিপত্র'
      ],
      fee: 15000,
      processingTime: '10-15 working days',
      processingTimeEn: '10-15 working days',
      processingTimeBn: '১০-১৫ কর্মদিবস',
      category: 'transfer'
    },
    {
      id: 'route-permit',
      service: 'Route Permit',
      serviceEn: 'Route Permit',
      serviceBn: 'রুট পারমিট',
      documents: [
        'Registration Certificate',
        'Route Application',
        'Fitness Certificate',
        'Insurance Copy',
        'Tax Token',
        'Driver\'s License'
      ],
      documentsEn: [
        'Registration Certificate',
        'Route Application',
        'Fitness Certificate',
        'Insurance Copy',
        'Tax Token',
        'Driver\'s License'
      ],
      documentsBn: [
        'রেজিস্ট্রেশন সার্টিফিকেট',
        'রুট আবেদন',
        'ফিটনেস সার্টিফিকেট',
        'বীমার কপি',
        'ট্যাক্স টোকেন',
        'ড্রাইভারের লাইসেন্স'
      ],
      fee: 5000,
      processingTime: '30-45 working days',
      processingTimeEn: '30-45 working days',
      processingTimeBn: '৩০-৪৫ কর্মদিবস',
      category: 'permit'
    }
  ];

  const categories = [
    { value: 'all', label: language === 'en' ? 'All Rules' : 'সব নিয়ম' },
    { value: 'moving', label: language === 'en' ? 'Moving Violations' : 'চলাচল লঙ্ঘন' },
    { value: 'parking', label: language === 'en' ? 'Parking' : 'পার্কিং' },
    { value: 'license', label: language === 'en' ? 'License' : 'লাইসেন্স' },
    { value: 'vehicle', label: language === 'en' ? 'Vehicle' : 'যানবাহন' },
    { value: 'serious', label: language === 'en' ? 'Serious Offenses' : 'গুরুতর অপরাধ' },
    { value: 'documents', label: language === 'en' ? 'Documents' : 'কাগজপত্র' }
  ];

  const filteredRules = trafficRules.filter(rule => {
    const matchesCategory = selectedCategory === 'all' || rule.category === selectedCategory;
    const matchesSearch = searchTerm === '' || 
      (language === 'en' ? rule.titleEn : rule.titleBn).toLowerCase().includes(searchTerm.toLowerCase()) ||
      (language === 'en' ? rule.descriptionEn : rule.descriptionBn).toLowerCase().includes(searchTerm.toLowerCase()) ||
      rule.section.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        newSet.add(sectionId);
      }
      return newSet;
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'serious': return 'border-red-500 bg-red-50 text-red-700';
      case 'major': return 'border-orange-500 bg-orange-50 text-orange-700';
      case 'minor': return 'border-yellow-500 bg-yellow-50 text-yellow-700';
      default: return 'border-gray-500 bg-gray-50 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition duration-150"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  {language === 'en' ? '📚 Traffic Rules & BRTA Services' : '📚 ট্রাফিক নিয়ম ও বিআরটিএ সেবা'}
                </h1>
                <p className="text-blue-100 text-sm">
                  {language === 'en' ? 
                    'Complete guide to Bangladesh Road Transport Act 2018 & BRTA services' :
                    'বাংলাদেশ সড়ক পরিবহন আইন ২০১৮ ও বিআরটিএ সেবার সম্পূর্ণ গাইড'
                  }
                </p>
              </div>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-white bg-opacity-20 text-white rounded-full text-sm font-medium hover:bg-opacity-30 transition duration-150"
            >
              <Globe size={16} />
              <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex space-x-8">
            {[
              { key: 'rules', label: language === 'en' ? 'Traffic Rules & Fines' : 'ট্রাফিক নিয়ম ও জরিমানা', icon: Scale },
              { key: 'brta', label: language === 'en' ? 'BRTA Services' : 'বিআরটিএ সেবা', icon: Building2 },
              { key: 'fines', label: language === 'en' ? 'Fine Calculator' : 'জরিমানা ক্যালকুলেটর', icon: DollarSign }
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors flex items-center ${
                  activeTab === key
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-800'
                }`}
              >
                <Icon size={18} className="mr-2" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Traffic Rules Tab */}
        {activeTab === 'rules' && (
          <div className="space-y-6">
            {/* Search and Filter */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="text"
                      placeholder={language === 'en' ? 
                        'Search traffic rules, sections, or fines...' :
                        'ট্রাফিক নিয়ম, ধারা বা জরিমানা অনুসন্ধান করুন...'
                      }
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category.value}
                    onClick={() => setSelectedCategory(category.value)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition duration-150 ${
                      selectedCategory === category.value
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Traffic Rules List */}
            <div className="space-y-4">
              {filteredRules.map((rule) => (
                <div key={rule.id} className="bg-white rounded-lg shadow border-l-4 border-l-blue-500 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">
                        {language === 'en' ? rule.titleEn : rule.titleBn}
                      </h3>
                      <p className="text-gray-600 mb-3">
                        {language === 'en' ? rule.descriptionEn : rule.descriptionBn}
                      </p>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="bg-gray-100 px-2 py-1 rounded font-mono text-gray-700">
                          {rule.section}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${getSeverityColor(rule.severity)}`}>
                          {language === 'en' ? 
                            rule.severity.charAt(0).toUpperCase() + rule.severity.slice(1) :
                            rule.severity === 'serious' ? 'গুরুতর' :
                            rule.severity === 'major' ? 'প্রধান' : 'সাধারণ'
                          }
                        </span>
                        {rule.points && (
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                            {rule.points} {language === 'en' ? 'points' : 'পয়েন্ট'}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right ml-6">
                      <div className="text-2xl font-bold text-red-600">
                        ৳{rule.fine.toLocaleString()}
                      </div>
                      {rule.imprisonment && (
                        <div className="text-sm text-gray-600 mt-1">
                          {language === 'en' ? 
                            `or ${rule.imprisonmentEn}` : 
                            `অথবা ${rule.imprisonmentBn}`
                          }
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* BRTA Services Tab */}
        {activeTab === 'brta' && (
          <div className="space-y-6">
            {/* BRTA Contact Info */}
            <div className="bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-lg p-6">
              <div className="flex items-start space-x-4">
                <Building2 className="text-green-600 mt-1" size={24} />
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-green-800 mb-2">
                    {language === 'en' ? 'Bangladesh Road Transport Authority (BRTA)' : 'বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ)'}
                  </h3>
                  <p className="text-green-700 text-sm mb-3">
                    {language === 'en' ? 
                      'Official authority for vehicle registration, driving licenses, and transport permits' :
                      'যানবাহন নিবন্ধন, ড্রাইভিং লাইসেন্স এবং পরিবহন পারমিটের জন্য সরকারি কর্তৃপক্ষ'
                    }
                  </p>
                  <div className="flex items-center space-x-4 text-sm text-green-600">
                    <div className="flex items-center">
                      <Phone size={16} className="mr-1" />
                      <span>16107</span>
                    </div>
                    <div className="flex items-center">
                      <Globe size={16} className="mr-1" />
                      <span>brta.gov.bd</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* BRTA Services List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {brtaServices.map((service) => (
                <div key={service.id} className="bg-white rounded-lg shadow border border-gray-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-800 flex-1">
                      {language === 'en' ? service.serviceEn : service.serviceBn}
                    </h3>
                    <div className="text-right ml-4">
                      <div className="text-xl font-bold text-blue-600">
                        ৳{service.fee.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' ? service.processingTimeEn : service.processingTimeBn}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <button
                      onClick={() => toggleSection(service.id)}
                      className="flex items-center w-full text-left text-sm font-medium text-blue-600 hover:text-blue-700"
                    >
                      {expandedSections.has(service.id) ? (
                        <ChevronDown size={16} className="mr-1" />
                      ) : (
                        <ChevronRight size={16} className="mr-1" />
                      )}
                      {language === 'en' ? 'Required Documents' : 'প্রয়োজনীয় কাগজপত্র'}
                    </button>
                  </div>
                  
                  {expandedSections.has(service.id) && (
                    <div className="bg-gray-50 rounded-lg p-4">
                      <ul className="space-y-2">
                        {(language === 'en' ? service.documentsEn : service.documentsBn).map((doc, index) => (
                          <li key={index} className="flex items-center text-sm text-gray-700">
                            <FileText size={14} className="mr-2 text-blue-500" />
                            {doc}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="mt-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      service.category === 'registration' ? 'bg-blue-100 text-blue-800' :
                      service.category === 'license' ? 'bg-green-100 text-green-800' :
                      service.category === 'renewal' ? 'bg-yellow-100 text-yellow-800' :
                      service.category === 'transfer' ? 'bg-purple-100 text-purple-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {language === 'en' ? 
                        service.category.charAt(0).toUpperCase() + service.category.slice(1) :
                        service.category === 'registration' ? 'নিবন্ধন' :
                        service.category === 'license' ? 'লাইসেন্স' :
                        service.category === 'renewal' ? 'নবায়ন' :
                        service.category === 'transfer' ? 'হস্তান্তর' : 'পারমিট'
                      }
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Fine Calculator Tab */}
        {activeTab === 'fines' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                {language === 'en' ? 'Traffic Fine Calculator' : 'ট্রাফিক জরিমানা ক্যালকুলেটর'}
              </h3>
              <p className="text-gray-600 mb-6">
                {language === 'en' ? 
                  'Calculate total fines based on traffic violations. Select violations to see the total penalty.' :
                  'ট্রাফিক লঙ্ঘনের উপর ভিত্তি করে মোট জরিমানা গণনা করুন। লঙ্ঘন নির্বাচন করে মোট জরিমানা দেখুন।'
                }
              </p>
              
              {/* Fine Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-red-600">
                    ৳{trafficRules.filter(r => r.severity === 'serious').reduce((sum, r) => sum + r.fine, 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-red-700">
                    {language === 'en' ? 'Serious Offenses' : 'গুরুতর অপরাধ'}
                  </div>
                </div>
                
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    ৳{trafficRules.filter(r => r.severity === 'major').reduce((sum, r) => sum + r.fine, 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-orange-700">
                    {language === 'en' ? 'Major Violations' : 'প্রধান লঙ্ঘন'}
                  </div>
                </div>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-600">
                    ৳{trafficRules.filter(r => r.severity === 'minor').reduce((sum, r) => sum + r.fine, 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-yellow-700">
                    {language === 'en' ? 'Minor Violations' : 'সাধারণ লঙ্ঘন'}
                  </div>
                </div>
              </div>

              {/* Most Common Violations */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-blue-800 mb-4">
                  {language === 'en' ? 'Most Common Violations & Fines' : 'সর্বাধিক সাধারণ লঙ্ঘন ও জরিমানা'}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trafficRules.slice(0, 6).map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between bg-white p-3 rounded">
                      <span className="text-sm text-gray-700">
                        {language === 'en' ? rule.titleEn : rule.titleBn}
                      </span>
                      <span className="font-bold text-red-600">
                        ৳{rule.fine.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer Information */}
        <div className="mt-8 bg-gradient-to-r from-blue-50 to-green-50 border border-blue-200 rounded-lg p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-blue-800 mb-3">
                {language === 'en' ? 'Road Transport Act 2018' : 'সড়ক পরিবহন আইন ২০১৮'}
              </h3>
              <p className="text-blue-700 text-sm mb-4">
                {language === 'en' ? 
                  'This information is based on Bangladesh Road Transport Act 2018. All fines and penalties are as per government regulations.' :
                  'এই তথ্য বাংলাদেশ সড়ক পরিবহন আইন ২০১৮ এর উপর ভিত্তি করে। সমস্ত জরিমানা ও শাস্তি সরকারি নিয়মানুসারে।'
                }
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-green-800 mb-3">
                {language === 'en' ? 'Important Contacts' : 'গুরুত্বপূর্ণ যোগাযোগ'}
              </h3>
              <div className="space-y-2 text-sm text-green-700">
                <div className="flex items-center">
                  <Phone size={14} className="mr-2" />
                  <span>BRTA: 16107</span>
                </div>
                <div className="flex items-center">
                  <Phone size={14} className="mr-2" />
                  <span>{language === 'en' ? 'Traffic Police: 999' : 'ট্রাফিক পুলিশ: ৯৯৯'}</span>
                </div>
                <div className="flex items-center">
                  <Globe size={14} className="mr-2" />
                  <span>brta.gov.bd</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-blue-200 text-xs text-blue-600">
            <p>📅 {language === 'en' ? 'Last Updated: November 2025' : 'সর্বশেষ আপডেট: নভেম্বর ২০২৫'}</p>
            <p>⚖️ {language === 'en' ? 'Source: Bangladesh Road Transport Act 2018' : 'সূত্র: বাংলাদেশ সড়ক পরিবহন আইন ২০১৮'}</p>
            <p>✅ {language === 'en' ? 'All information verified with BRTA & relevant authorities' : 'সব তথ্য বিআরটিএ ও সংশ্লিষ্ট কর্তৃপক্ষের সাথে যাচাইকৃত'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
