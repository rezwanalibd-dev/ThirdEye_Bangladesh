import { useState, useEffect } from 'react';
import { Camera, Globe, Eye, DollarSign, Zap, Shield } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

const onboardingSteps = [
  { icon: Eye, titleKey: 'onboardingTitle1', descKey: 'onboardingDesc1' },
  { icon: Shield, titleKey: 'onboardingTitle4', descKey: 'onboardingDesc4' },
  { icon: Camera, titleKey: 'onboardingTitle2', descKey: 'onboardingDesc2' },
  { icon: DollarSign, titleKey: 'onboardingTitle3', descKey: 'onboardingDesc3' },
];

interface OnboardingScreenProps {
  lang: 'en' | 'bn';
  t: (key: string) => string;
  toggleLanguage: () => void;
  onComplete: () => void;
}

function OnboardingScreen({ lang, t, toggleLanguage, onComplete }: OnboardingScreenProps) {
  const [step, setStep] = useState(0);
  const currentStep = onboardingSteps[step];
  const isLastStep = step === onboardingSteps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      onComplete();
    } else {
      setStep(step + 1);
    }
  };
  
  const handleSkip = () => {
    onComplete();
  };

  const formatDescription = (desc: string) => {
    return desc.split('\n').map((line, index) => {
      // Make specific phrases bold
      let formattedLine: React.ReactNode = line;
      
      if (line.includes('Are you ready to make a difference?')) {
        formattedLine = <strong>{line}</strong>;
      } else if (line.includes('আপনি কি পরিবর্তন আনতে প্রস্তুত?')) {
        formattedLine = <strong>{line}</strong>;
      } else if (line.includes('Your voice matters.')) {
        formattedLine = <strong>{line}</strong>;
      } else if (line.includes('আপনার কণ্ঠস্বর গুরুত্বপূর্ণ।')) {
        formattedLine = <strong>{line}</strong>;
      }
      
      return (
        <span key={index}>
          {formattedLine}
          {index < desc.split('\n').length - 1 && <br />}
        </span>
      );
    });
  };

  return (
    <div 
      className="flex flex-col h-full w-full justify-between p-6 sm:p-8 text-white" 
      style={{ 
        minHeight: '80vh', 
        backgroundImage: 'linear-gradient(135deg, #06B6D4 0%, #155E75 100%)',
        fontFamily: lang === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif'
      }}
    >
      <div className="flex justify-between items-center">
        <button
          onClick={toggleLanguage}
          className="flex items-center space-x-1 p-2 bg-white/20 backdrop-blur-sm text-white rounded-full text-sm font-medium hover:bg-white/30 transition duration-150 shadow-lg"
        >
          <Globe size={16} />
          <span style={{ fontFamily: lang === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {t('languageLabel')}
          </span>
        </button>
        
        <button 
          onClick={handleSkip}
          className="text-sm font-medium text-sky-200 hover:text-white transition duration-150 p-2 rounded-lg"
        >
          {t('skip')}
        </button>
      </div>

      <div className="flex flex-col items-center text-center px-4 py-8 rounded-3xl backdrop-blur-md bg-white/10 shadow-2xl transition-all duration-500">
        <div className="mb-6 p-3 bg-white/20 rounded-full shadow-lg border-2 border-sky-100/50">
          <currentStep.icon 
            size={80} 
            strokeWidth={1.5} 
            className="text-white drop-shadow-lg" 
            style={{ filter: 'drop-shadow(0 0 10px rgba(255, 255, 255, 0.7))' }}
          />
        </div>
        
        <h2 className="text-3xl font-extrabold mb-3 leading-tight" style={{ color: '#E0F7FA' }}>
          {t(currentStep.titleKey)}
        </h2>
        
        <div className="text-base text-sky-100 max-w-xs font-light leading-relaxed">
          {formatDescription(t(currentStep.descKey))}
        </div>
      </div>

      <div className="flex flex-col items-center space-y-5">
        <div className="flex space-x-2 mb-4">
          {onboardingSteps.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === step ? 'w-10 bg-white shadow-md' : 'w-2 bg-sky-300/50'
              }`}
            ></div>
          ))}
        </div>
        
        <button
          onClick={handleNext}
          className={`w-full py-4 rounded-xl font-bold text-lg text-teal-900 transition-all duration-300 transform active:scale-[0.98]
            ${isLastStep 
              ? 'bg-amber-300 hover:bg-amber-200 shadow-xl shadow-amber-300/50' 
              : 'bg-white hover:bg-gray-100 shadow-xl shadow-sky-400/50'
            }`}
        >
          {isLastStep ? t('startReporting') : t('next')} <Zap size={18} className="inline ml-1" />
        </button>
      </div>
    </div>
  );
}

export default function HomePage() {
  const { language, toggleLanguage, t } = useLanguage();
  const { isAuthenticated, user } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState(true);

  useEffect(() => {
    // Check if user has already seen onboarding
    const hasSeenOnboarding = localStorage.getItem('thirdEyeHasSeenOnboarding');
    
    if (hasSeenOnboarding === 'true') {
      // If they've seen it before, skip to appropriate page
      if (isAuthenticated && user) {
        window.location.href = '/dashboard';
      } else {
        window.location.href = '/login';
      }
    }
  }, [isAuthenticated, user]);

  const handleOnboardingComplete = () => {
    // Mark onboarding as seen
    localStorage.setItem('thirdEyeHasSeenOnboarding', 'true');
    setShowOnboarding(false);
    
    // Navigate to appropriate page
    if (isAuthenticated && user) {
      window.location.href = '/dashboard';
    } else {
      window.location.href = '/login';
    }
  };

  if (!showOnboarding) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-2 sm:p-4" style={{ fontFamily: 'Inter, sans-serif' }}>
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200" style={{ minHeight: '80vh' }}>
        {/* Third Eye Logo and Branding at top */}
        <div className="bg-white p-6 text-center border-b border-gray-100">
          <img 
            src="https://mocha-cdn.com/019a7364-a032-7e48-8ef2-a113c18111ab/third-eye-logo.png" 
            alt="Third Eye Logo" 
            className="w-16 h-16 mx-auto rounded-full drop-shadow-lg border-2 border-sky-200"
          />
          <h1 className="text-2xl font-bold text-gray-800 mt-3" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Third Eye' : 'তৃতীয় চোখ'}
          </h1>
          <p className="text-sm text-gray-600 mt-1" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Your Vigilance Saves Lives and Earns Rewards' : 'আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার'}
          </p>
        </div>
        <OnboardingScreen lang={language} t={t} toggleLanguage={toggleLanguage} onComplete={handleOnboardingComplete} />
      </div>
    </div>
  );
}
