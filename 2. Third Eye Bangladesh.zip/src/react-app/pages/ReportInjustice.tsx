import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  Camera, 
  MapPin, 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  FileText,
  Globe,
  Upload,
  Video,
  Shield
} from 'lucide-react';

interface ReportFormData {
  crimeCategory: string;
  location: string;
  description: string;
  evidence: File[];
  coordinates?: {
    lat: number;
    lng: number;
  };
}

const crimeCategoriesEn = {
  'violent-crimes': {
    title: 'Violent Crimes',
    items: [
      'Murder/Homicide',
      'Assault (physical/sexual)',
      'Robbery',
      'Kidnapping/Abduction',
      'Domestic violence',
      'Human trafficking',
      'Child abuse',
      'Elder abuse',
      'Hate crimes',
      'Gang violence'
    ]
  },
  'property-crimes': {
    title: 'Property Crimes',
    items: [
      'Theft/Burglary',
      'Shoplifting',
      'Vehicle theft',
      'Arson',
      'Vandalism',
      'Trespassing',
      'Identity theft'
    ]
  },
  'financial-crimes': {
    title: 'Financial & Economic Crimes',
    items: [
      'Fraud',
      'Corruption/Bribery',
      'Embezzlement',
      'Money laundering',
      'Tax evasion',
      'Counterfeiting',
      'Cybercrime',
      'Insider trading',
      'Ponzi schemes',
      'Insurance fraud'
    ]
  },
  'public-order': {
    title: 'Public Order Crimes',
    items: [
      'Drug trafficking',
      'Drug abuse',
      'Prostitution',
      'Illegal gambling',
      'Public intoxication',
      'Disorderly conduct',
      'Rioting'
    ]
  },
  'other-crimes': {
    title: 'Other Serious Crimes',
    items: [
      'Terrorism',
      'Extortion',
      'Blackmail',
      'Perjury',
      'Witness intimidation',
      'Stalking',
      'Harassment',
      'Cyberbullying',
      'Child pornography',
      'Illegal weapons trafficking',
      'Environmental crimes',
      'Animal cruelty',
      'Organized crime',
      'Human smuggling',
      'Hate speech',
      'Voter fraud'
    ]
  }
};

const crimeCategoriesBn = {
  'violent-crimes': {
    title: 'সহিংস অপরাধ',
    items: [
      'খুন/হত্যা',
      'শারীরিক/যৌন নিপীড়ন',
      'ডাকাতি',
      'অপহরণ',
      'গার্হস্থ্য সহিংসতা',
      'মানব পাচার',
      'শিশু নির্যাতন',
      'বয়োজ্যেষ্ঠ নির্যাতন',
      'ঘৃণাজনিত অপরাধ',
      'গ্যাং সংঘর্ষ'
    ]
  },
  'property-crimes': {
    title: 'সম্পত্তিগত অপরাধ',
    items: [
      'চুরি/সন্ত্রাস',
      'দোকান থেকে চুরি',
      'যানবাহন চুরি',
      'অগ্নিসংযোগ',
      'সম্পত্তি নষ্ট করা',
      'অননুমোদিত প্রবেশ',
      'পরিচয় চুরি'
    ]
  },
  'financial-crimes': {
    title: 'আর্থিক অপরাধ',
    items: [
      'জালিয়াতি',
      'দুর্নীতি/ঘুষ',
      'তহবিল তসরুফ',
      'মুনাফা পাচার',
      'ট্যাক্স ফাঁকি',
      'জাল নোট',
      'সাইবার অপরাধ'
    ]
  },
  'public-order': {
    title: 'সামাজিক অপরাধ',
    items: [
      'মাদক পাচার',
      'মাদকাসক্তি',
      'পতিতাবৃত্তি',
      'অবৈধ জুয়া',
      'প্রকাশ্যে মাদকসেবন',
      'অশান্তি সৃষ্টি',
      'দাঙ্গা'
    ]
  },
  'other-crimes': {
    title: 'অন্যান্য গুরুতর অপরাধ',
    items: [
      'সন্ত্রাসবাদ',
      'চাঁদাবাজি',
      'ব্ল্যাকমেইল',
      'মিথ্যা সাক্ষ্য',
      'সাক্ষীকে হুমকি',
      'স্টকিং',
      'হয়রানি',
      'সাইবার হয়রানি',
      'শিশু পর্নোগ্রাফি',
      'অবৈধ অস্ত্র পাচার',
      'পরিবেশ দূষণ',
      'প্রাণী নিপীড়ন',
      'সংগঠিত অপরাধ',
      'অবৈধ অভিবাসন',
      'ঘৃণামূলক বক্তব্য',
      'ভোটার জালিয়াতি'
    ]
  }
};

export default function ReportInjusticePage() {
  const { language, toggleLanguage, t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<ReportFormData>({
    crimeCategory: '',
    location: '',
    description: '',
    evidence: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);

  const crimeCategories = language === 'bn' ? crimeCategoriesBn : crimeCategoriesEn;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const getCurrentLocation = () => {
    setLocationLoading(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setFormData(prev => ({
            ...prev,
            location: `Lat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}`,
            coordinates: { lat: latitude, lng: longitude }
          }));
          setLocationLoading(false);
        },
        (error) => {
          console.error('Geolocation error:', error);
          alert('GPS location is required for report submission. Please enable location access and try again.');
          setLocationLoading(false);
        }
      );
    } else {
      alert('GPS location is required but not supported by your device.');
      setLocationLoading(false);
    }
  };

  // Auto-get location on component mount
  useEffect(() => {
    getCurrentLocation();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');
      const isValidSize = file.size <= 50 * 1024 * 1024; // 50MB limit
      return (isImage || isVideo) && isValidSize;
    });

    setFormData(prev => ({
      ...prev,
      evidence: [...prev.evidence, ...validFiles].slice(0, 5) // Max 5 files
    }));
  };

  const handleCameraCapture = (type: 'photo' | 'video') => {
    if (type === 'photo') {
      photoInputRef.current?.click();
    } else {
      videoInputRef.current?.click();
    }
  };

  const removeFile = (index: number) => {
    setFormData(prev => ({
      ...prev,
      evidence: prev.evidence.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    if (!formData.crimeCategory.trim()) return 'Please select a crime category';
    if (!formData.location.trim()) return 'Location is required';
    if (formData.evidence.length === 0) return 'Evidence (photo/video) is mandatory for all reports';
    if (!formData.coordinates) return 'GPS location is required - please enable location access';
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      alert(validationError);
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate case number with date, time and sequence
      const now = new Date();
      const dateStr = now.getFullYear().toString().slice(-2) + 
                      (now.getMonth() + 1).toString().padStart(2, '0') + 
                      now.getDate().toString().padStart(2, '0');
      const timeStr = now.getHours().toString().padStart(2, '0') + 
                      now.getMinutes().toString().padStart(2, '0') + 
                      now.getSeconds().toString().padStart(2, '0');
      const sequenceNumber = Math.floor(Math.random() * 999) + 1;
      const caseNumber = `TI-${dateStr}-${timeStr}-${sequenceNumber.toString().padStart(3, '0')}`;
      
      // Simulate successful submission
      alert(`Social Crime Report submitted successfully!\n\nCase Number: ${caseNumber}\nGPS Location: ${formData.coordinates?.lat.toFixed(6)}, ${formData.coordinates?.lng.toFixed(6)}\n\n🔒 Your identity is completely protected and anonymous\n📱 Authorities will investigate without revealing your information\n🛡️ Report will be forwarded to appropriate law enforcement agencies`);
      navigate('/dashboard');
    } catch (err) {
      console.error('Report submission error:', err);
      alert('Failed to submit report. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <AlertTriangle className="mx-auto text-yellow-600 mb-4" size={48} />
          <h2 className="text-xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Please log in to report social crimes</p>
          <button 
            onClick={() => navigate('/login')}
            className="inline-block bg-sky-600 text-white px-6 py-2 rounded-lg hover:bg-sky-700"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">{t('reportInjusticeTitle')}</h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'English/Bangla' : 'ইংরেজি/বাংলা'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Privacy Notice */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <div className="flex items-start space-x-3">
              <Shield className="text-green-600 mt-1" size={24} />
              <div>
                <h3 className="text-lg font-bold text-green-900 mb-2">{t('yourIdentityProtected')}</h3>
                <ul className="text-green-800 text-sm space-y-1">
                  <li>• {t('completeAnonymityGuaranteed')}</li>
                  <li>• {t('noPersonalInfoShared')}</li>
                  <li>• {t('secureEncryptedSubmission')}</li>
                  <li>• {t('professionalInvestigation')}</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Crime Category Selection */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('crimeCategory')} *</h2>
            <select
              name="crimeCategory"
              value={formData.crimeCategory}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}
              required
            >
              <option value="">{t('selectCrimeType')}</option>
              {Object.entries(crimeCategories).map(([categoryKey, category]) => (
                <optgroup key={categoryKey} label={category.title}>
                  {category.items.map((crime, index) => (
                    <option key={`${categoryKey}-${index}`} value={crime}>
                      {crime}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          {/* Location */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('location')} *</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                  {t('incidentLocation')}
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder={t('gpsLocationAutoDetected')}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    required
                    readOnly
                  />
                  <button
                    type="button"
                    onClick={getCurrentLocation}
                    disabled={locationLoading}
                    className="px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    {locationLoading ? (
                      <Clock className="animate-spin" size={20} />
                    ) : (
                      <MapPin size={20} />
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {t('locationAutoDetected')}
                </p>
              </div>
            </div>
          </div>

          {/* Evidence Upload */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('evidence')} *</h2>
            
            <div className="space-y-4">
              {/* Instant Capture Buttons */}
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => handleCameraCapture('photo')}
                  className="flex flex-col items-center p-4 border-2 border-dashed border-red-300 rounded-lg hover:border-red-400 hover:bg-red-50 transition-colors"
                >
                  <Camera className="text-red-500 mb-2" size={32} />
                  <span className="text-sm font-medium text-gray-800">{t('takePhotoNow')}</span>
                  <span className="text-xs text-gray-600">{t('instantCapture')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleCameraCapture('video')}
                  className="flex flex-col items-center p-4 border-2 border-dashed border-red-300 rounded-lg hover:border-red-400 hover:bg-red-50 transition-colors"
                >
                  <Video className="text-red-500 mb-2" size={32} />
                  <span className="text-sm font-medium text-gray-800">{t('recordVideoNow')}</span>
                  <span className="text-xs text-gray-600">{t('instantRecording')}</span>
                </button>
              </div>

              {/* Upload Later Option */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-red-300 rounded-lg p-6 text-center hover:border-red-400 hover:bg-red-50 transition-colors cursor-pointer"
              >
                <Upload className="mx-auto text-red-500 mb-2" size={32} />
                <p className="text-gray-800 mb-1 font-medium">📸 {t('uploadEvidence')}</p>
                <p className="text-sm text-gray-600">{t('chooseExistingFiles')}</p>
                <p className="text-xs text-gray-500 mt-1">{t('fileUploadLimit')}</p>
              </div>

              {/* File Input Elements */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
              <input
                ref={photoInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Uploaded Files */}
              {formData.evidence.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-medium text-gray-800">Uploaded Evidence:</h3>
                  {formData.evidence.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded">
                      <div className="flex items-center space-x-3">
                        {file.type.startsWith('video/') ? (
                          <Video className="text-gray-500" size={20} />
                        ) : (
                          <FileText className="text-gray-500" size={20} />
                        )}
                        <span className="text-sm text-gray-700 truncate">{file.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('incidentDescription')}</h2>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder={t('describeIncident')}
              rows={6}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
              style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}
            />
            <p className="text-sm text-gray-600 mt-2">
              💡 <strong>{t('tipProvideDetails')}</strong>
            </p>
          </div>

          {/* Safety & Legal Info */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="text-sm space-y-2">
              <div className="flex items-start">
                <CheckCircle className="text-amber-600 mr-2 mt-0.5" size={16} />
                <p className="text-amber-800">
                  <strong>{t('anonymousReporting')}</strong>
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-amber-600 mr-2 mt-0.5" size={16} />
                <p className="text-amber-800">
                  <strong>{t('legalProtection')}</strong>
                </p>
              </div>
              <div className="flex items-start">
                <AlertTriangle className="text-red-600 mr-2 mt-0.5" size={16} />
                <p className="text-red-800">
                  <strong>{t('warningFalseReports')}</strong>
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition duration-150 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isSubmitting ? (
              <>
                <Clock className="animate-spin mr-2" size={20} />
                Submitting Report Anonymously...
              </>
            ) : (
              <>
                <Shield className="mr-2" size={20} />
                {t('submitAnonymousReport')}
              </>
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
