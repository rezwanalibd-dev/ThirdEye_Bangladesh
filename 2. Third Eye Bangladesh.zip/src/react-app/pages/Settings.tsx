import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  ArrowLeft,
  User,
  Lock,
  Bell,
  Shield,
  LogOut,
  Camera,
  Loader2,
  AlertTriangle,
  Globe,
  Trash2,
  UserX,
  Eye,
  EyeOff
} from 'lucide-react';

type TabType = 'profile' | 'password' | 'notifications' | 'privacy' | 'account';

export default function SettingsPage() {
  const { language, toggleLanguage } = useLanguage();
  const { user, updateUser, logout } = useAuth();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<TabType>('profile');
  const [isLoading, setIsLoading] = useState(false);
  
  // Profile state
  const [profileImagePreview, setProfileImagePreview] = useState<string>(user?.profileImage || '');
  const [fullName, setFullName] = useState(user?.fullName || '');
  const profileImageRef = useRef<HTMLInputElement>(null);
  
  // Password state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    otp: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  
  // Notifications state
  const [notificationSettings, setNotificationSettings] = useState({
    reportUpdates: true,
    commissionAlerts: true,
    systemMessages: true,
    emailNotifications: user?.email ? true : false,
    smsNotifications: true,
    pushNotifications: true
  });
  
  // Privacy state
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'public',
    showStatistics: true,
    showInLeaderboard: true
  });
  
  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileImagePreview(URL.createObjectURL(file));
    }
  };
  
  const handleSaveProfile = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser({ 
        fullName,
        profileImage: profileImagePreview 
      });
      
      alert(language === 'en' ? 'Profile updated successfully!' : 'প্রোফাইল সফলভাবে আপডেট হয়েছে!');
    } catch (error) {
      console.error('Profile update error:', error);
      alert(language === 'en' ? 'Failed to update profile' : 'প্রোফাইল আপডেট ব্যর্থ হয়েছে');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSendPasswordOTP = async () => {
    if (!passwordData.currentPassword) {
      alert(language === 'en' ? 'Please enter your current password' : 'আপনার বর্তমান পাসওয়ার্ড লিখুন');
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setOtpSent(true);
      setOtpTimer(120);
      
      const interval = setInterval(() => {
        setOtpTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      const contact = user?.email || user?.mobileNumber;
      alert(language === 'en' 
        ? `OTP sent to ${contact}` 
        : `OTP পাঠানো হয়েছে ${contact} এ`);
    } catch (error) {
      console.error('OTP send error:', error);
      alert(language === 'en' ? 'Failed to send OTP' : 'OTP পাঠাতে ব্যর্থ');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleChangePassword = async () => {
    if (passwordData.otp.length !== 6) {
      alert(language === 'en' ? 'Please enter a valid 6-digit OTP' : 'অনুগ্রহ করে একটি বৈধ ৬ ডিজিটের OTP লিখুন');
      return;
    }
    
    if (passwordData.newPassword.length < 8) {
      alert(language === 'en' ? 'Password must be at least 8 characters' : 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে');
      return;
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert(language === 'en' ? 'Passwords do not match' : 'পাসওয়ার্ড মিলছে না');
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      alert(language === 'en' ? 'Password changed successfully!' : 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '', otp: '' });
      setOtpSent(false);
    } catch (error) {
      console.error('Password change error:', error);
      alert(language === 'en' ? 'Failed to change password' : 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSaveNotifications = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert(language === 'en' ? 'Notification settings saved!' : 'বিজ্ঞপ্তি সেটিংস সংরক্ষিত হয়েছে!');
    } catch (error) {
      console.error('Save notifications error:', error);
      alert(language === 'en' ? 'Failed to save settings' : 'সেটিংস সংরক্ষণ ব্যর্থ হয়েছে');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSavePrivacy = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert(language === 'en' ? 'Privacy settings saved!' : 'গোপনীয়তা সেটিংস সংরক্ষিত হয়েছে!');
    } catch (error) {
      console.error('Save privacy error:', error);
      alert(language === 'en' ? 'Failed to save settings' : 'সেটিংস সংরক্ষণ ব্যর্থ হয়েছে');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDeactivateAccount = async () => {
    const confirmed = window.confirm(
      language === 'en' 
        ? 'Are you sure you want to deactivate your account? You can reactivate it later by logging in.' 
        : 'আপনি কি নিশ্চিত যে আপনি আপনার অ্যাকাউন্ট নিষ্ক্রিয় করতে চান? আপনি পরে লগ ইন করে এটি পুনরায় সক্রিয় করতে পারবেন।'
    );
    
    if (!confirmed) return;
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser({ accountStatus: 'deactivated' });
      alert(language === 'en' ? 'Account deactivated successfully' : 'অ্যাকাউন্ট সফলভাবে নিষ্ক্রিয় হয়েছে');
      logout();
      navigate('/');
    } catch (error) {
      console.error('Deactivate error:', error);
      alert(language === 'en' ? 'Failed to deactivate account' : 'অ্যাকাউন্ট নিষ্ক্রিয় করতে ব্যর্থ');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDeleteAccount = async () => {
    const password = window.prompt(
      language === 'en' 
        ? 'This action is permanent and cannot be undone. Enter your password to delete your account:' 
        : 'এই কাজটি স্থায়ী এবং পূর্বাবস্থায় ফিরিয়ে আনা যাবে না। আপনার অ্যাকাউন্ট মুছে ফেলতে আপনার পাসওয়ার্ড লিখুন:'
    );
    
    if (!password) return;
    
    const confirmed = window.confirm(
      language === 'en' 
        ? 'Are you absolutely sure? All your data, reports, and rewards will be permanently deleted.' 
        : 'আপনি কি সম্পূর্ণ নিশ্চিত? আপনার সমস্ত ডেটা, রিপোর্ট এবং পুরস্কার স্থায়ীভাবে মুছে ফেলা হবে।'
    );
    
    if (!confirmed) return;
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      alert(language === 'en' ? 'Account deleted successfully' : 'অ্যাকাউন্ট সফলভাবে মুছে ফেলা হয়েছে');
      logout();
      navigate('/');
    } catch (error) {
      console.error('Delete error:', error);
      alert(language === 'en' ? 'Failed to delete account' : 'অ্যাকাউন্ট মুছে ফেলতে ব্যর্থ');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleLogout = () => {
    const confirmed = window.confirm(
      language === 'en' ? 'Are you sure you want to logout?' : 'আপনি কি লগআউট করতে চান?'
    );
    
    if (confirmed) {
      logout();
      navigate('/');
    }
  };
  
  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">
                {language === 'en' ? 'Settings' : 'সেটিংস'}
              </h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'বাংলা' : 'English'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex overflow-x-auto space-x-4 md:space-x-8">
            {[
              { key: 'profile', icon: User, label: language === 'en' ? 'Edit Profile' : 'প্রোফাইল সম্পাদনা' },
              { key: 'password', icon: Lock, label: language === 'en' ? 'Change Password' : 'পাসওয়ার্ড পরিবর্তন' },
              { key: 'notifications', icon: Bell, label: language === 'en' ? 'Notifications' : 'বিজ্ঞপ্তি' },
              { key: 'privacy', icon: Shield, label: language === 'en' ? 'Privacy & Security' : 'গোপনীয়তা ও নিরাপত্তা' },
              { key: 'account', icon: UserX, label: language === 'en' ? 'Account Management' : 'অ্যাকাউন্ট ব্যবস্থাপনা' }
            ].map(({ key, icon: Icon, label }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as TabType)}
                className={`py-4 border-b-2 font-medium text-sm whitespace-nowrap transition-colors flex items-center ${
                  activeTab === key
                    ? 'border-sky-600 text-sky-600'
                    : 'border-transparent text-gray-600 hover:text-gray-800'
                }`}
              >
                <Icon size={16} className="mr-2" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {/* Edit Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Profile Picture' : 'প্রোফাইল ছবি'}
              </h3>
              <div className="flex items-center space-x-6">
                <div className="relative">
                  {profileImagePreview ? (
                    <img 
                      src={profileImagePreview} 
                      alt="Profile" 
                      className="w-24 h-24 rounded-full object-cover border-4 border-sky-200"
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center">
                      <User size={40} className="text-gray-400" />
                    </div>
                  )}
                  <button
                    onClick={() => profileImageRef.current?.click()}
                    className="absolute bottom-0 right-0 bg-sky-600 text-white p-2 rounded-full hover:bg-sky-700 shadow-lg"
                  >
                    <Camera size={16} />
                  </button>
                  <input
                    ref={profileImageRef}
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageChange}
                    className="hidden"
                  />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">{user.fullName}</h4>
                  <p className="text-sm text-gray-600">{user.email || user.mobileNumber}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Personal Information' : 'ব্যক্তিগত তথ্য'}
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === 'en' ? 'Full Name' : 'পুরো নাম'}
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveProfile}
              disabled={isLoading}
              className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
              {language === 'en' ? 'Save Changes' : 'পরিবর্তনগুলো সংরক্ষণ করুন'}
            </button>
          </div>
        )}

        {/* Change Password Tab */}
        {activeTab === 'password' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Change Password' : 'পাসওয়ার্ড পরিবর্তন করুন'}
              </h3>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-800">
                  {language === 'en' 
                    ? 'For security, we will send an OTP to your verified mobile number/email to confirm password change.'
                    : 'নিরাপত্তার জন্য, পাসওয়ার্ড পরিবর্তন নিশ্চিত করতে আমরা আপনার যাচাইকৃত মোবাইল নম্বর/ইমেইলে একটি OTP পাঠাব।'}
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === 'en' ? 'Current Password' : 'বর্তমান পাসওয়ার্ড'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPasswords.current ? 'text' : 'password'}
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent pr-12"
                      placeholder="••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswords(prev => ({ ...prev, current: !prev.current }))}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                    >
                      {showPasswords.current ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>

                {!otpSent ? (
                  <button
                    onClick={handleSendPasswordOTP}
                    disabled={isLoading || !passwordData.currentPassword}
                    className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
                  >
                    {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
                    {language === 'en' ? 'Send OTP' : 'OTP পাঠান'}
                  </button>
                ) : (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {language === 'en' ? 'Enter OTP' : 'OTP লিখুন'}
                      </label>
                      <input
                        type="text"
                        value={passwordData.otp}
                        onChange={(e) => setPasswordData(prev => ({ ...prev, otp: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent text-center text-2xl tracking-widest"
                        placeholder="000000"
                        maxLength={6}
                      />
                      {otpTimer > 0 && (
                        <p className="text-xs text-gray-500 text-center mt-2">
                          {language === 'en' 
                            ? `OTP expires in ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')}`
                            : `OTP ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')} মিনিটে শেষ হবে`
                          }
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {language === 'en' ? 'New Password' : 'নতুন পাসওয়ার্ড'}
                      </label>
                      <div className="relative">
                        <input
                          type={showPasswords.new ? 'text' : 'password'}
                          value={passwordData.newPassword}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent pr-12"
                          placeholder="••••••••"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPasswords(prev => ({ ...prev, new: !prev.new }))}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                        >
                          {showPasswords.new ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {language === 'en' ? 'Confirm New Password' : 'নতুন পাসওয়ার্ড নিশ্চিত করুন'}
                      </label>
                      <div className="relative">
                        <input
                          type={showPasswords.confirm ? 'text' : 'password'}
                          value={passwordData.confirmPassword}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent pr-12"
                          placeholder="••••••••"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPasswords(prev => ({ ...prev, confirm: !prev.confirm }))}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                        >
                          {showPasswords.confirm ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={handleChangePassword}
                      disabled={isLoading || passwordData.otp.length !== 6}
                      className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition duration-150 font-medium disabled:opacity-50"
                    >
                      {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
                      {language === 'en' ? 'Change Password' : 'পাসওয়ার্ড পরিবর্তন করুন'}
                    </button>

                    {otpTimer === 0 && (
                      <button
                        onClick={handleSendPasswordOTP}
                        className="w-full text-sky-600 hover:text-sky-700 text-sm font-medium"
                      >
                        {language === 'en' ? 'Resend OTP' : 'পুনরায় OTP পাঠান'}
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Notification Preferences' : 'বিজ্ঞপ্তি পছন্দসমূহ'}
              </h3>
              
              <div className="space-y-4">
                {[
                  { key: 'reportUpdates', label: language === 'en' ? 'Report Status Updates' : 'রিপোর্ট স্ট্যাটাস আপডেট' },
                  { key: 'commissionAlerts', label: language === 'en' ? 'Commission Payment Alerts' : 'কমিশন পেমেন্ট সতর্কতা' },
                  { key: 'systemMessages', label: language === 'en' ? 'System Messages' : 'সিস্টেম বার্তা' },
                  { key: 'emailNotifications', label: language === 'en' ? 'Email Notifications' : 'ইমেইল বিজ্ঞপ্তি', disabled: !user.email },
                  { key: 'smsNotifications', label: language === 'en' ? 'SMS Notifications' : 'এসএমএস বিজ্ঞপ্তি' },
                  { key: 'pushNotifications', label: language === 'en' ? 'Push Notifications' : 'পুশ বিজ্ঞপ্তি' }
                ].map(({ key, label, disabled }) => (
                  <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className={`text-gray-700 ${disabled ? 'opacity-50' : ''}`}>{label}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={notificationSettings[key as keyof typeof notificationSettings]}
                        onChange={(e) => setNotificationSettings(prev => ({ ...prev, [key]: e.target.checked }))}
                        disabled={disabled}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-600 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}></div>
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleSaveNotifications}
              disabled={isLoading}
              className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
              {language === 'en' ? 'Save Settings' : 'সেটিংস সংরক্ষণ করুন'}
            </button>
          </div>
        )}

        {/* Privacy & Security Tab */}
        {activeTab === 'privacy' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Privacy Settings' : 'গোপনীয়তা সেটিংস'}
              </h3>
              
              <div className="space-y-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === 'en' ? 'Profile Visibility' : 'প্রোফাইল দৃশ্যমানতা'}
                  </label>
                  <select
                    value={privacySettings.profileVisibility}
                    onChange={(e) => setPrivacySettings(prev => ({ ...prev, profileVisibility: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                  >
                    <option value="public">{language === 'en' ? 'Public' : 'সর্বজনীন'}</option>
                    <option value="private">{language === 'en' ? 'Private' : 'ব্যক্তিগত'}</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-700">
                    {language === 'en' ? 'Show Statistics on Profile' : 'প্রোফাইলে পরিসংখ্যান দেখান'}
                  </span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={privacySettings.showStatistics}
                      onChange={(e) => setPrivacySettings(prev => ({ ...prev, showStatistics: e.target.checked }))}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-700">
                    {language === 'en' ? 'Show in Leaderboard' : 'লিডারবোর্ডে দেখান'}
                  </span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={privacySettings.showInLeaderboard}
                      onChange={(e) => setPrivacySettings(prev => ({ ...prev, showInLeaderboard: e.target.checked }))}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-600"></div>
                  </label>
                </div>
              </div>
            </div>

            <button
              onClick={handleSavePrivacy}
              disabled={isLoading}
              className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
              {language === 'en' ? 'Save Settings' : 'সেটিংস সংরক্ষণ করুন'}
            </button>
          </div>
        )}

        {/* Account Management Tab */}
        {activeTab === 'account' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                {language === 'en' ? 'Account Actions' : 'অ্যাকাউন্ট কার্যক্রম'}
              </h3>
              
              <div className="space-y-4">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center space-x-2 bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 transition duration-150 font-medium"
                >
                  <LogOut size={20} />
                  <span>{language === 'en' ? 'Logout' : 'লগআউট'}</span>
                </button>

                <button
                  onClick={handleDeactivateAccount}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center space-x-2 bg-orange-600 text-white py-3 px-4 rounded-lg hover:bg-orange-700 transition duration-150 font-medium disabled:opacity-50"
                >
                  <UserX size={20} />
                  <span>{language === 'en' ? 'Deactivate Account' : 'অ্যাকাউন্ট নিষ্ক্রিয় করুন'}</span>
                </button>

                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3 mb-3">
                    <AlertTriangle className="text-red-600 mt-0.5" size={20} />
                    <div className="text-sm text-red-800">
                      <p className="font-medium mb-1">
                        {language === 'en' ? 'Danger Zone' : 'বিপদ অঞ্চল'}
                      </p>
                      <p>
                        {language === 'en' 
                          ? 'Deleting your account is permanent and cannot be undone. All your data, reports, and rewards will be lost forever.'
                          : 'আপনার অ্যাকাউন্ট মুছে ফেলা স্থায়ী এবং পূর্বাবস্থায় ফিরিয়ে আনা যাবে না। আপনার সমস্ত ডেটা, রিপোর্ট এবং পুরস্কার চিরতরে হারিয়ে যাবে।'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center space-x-2 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition duration-150 font-medium disabled:opacity-50"
                  >
                    <Trash2 size={20} />
                    <span>{language === 'en' ? 'Delete Account Permanently' : 'অ্যাকাউন্ট স্থায়ীভাবে মুছুন'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
