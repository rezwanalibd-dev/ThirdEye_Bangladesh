import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  ArrowLeft,
  Globe,
  Trophy,
  Star,
  DollarSign,
  Target,
  Award,
  TrendingUp,
  
  CheckCircle,
  Clock,
  FileText,
  Medal,
  Crown,
  Users,
  BarChart3,
  Shield
} from 'lucide-react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  earned: boolean;
  earnedDate?: string;
  progress?: number;
  maxProgress?: number;
}

interface RankInfo {
  currentRank: string;
  nextRank: string;
  currentPoints: number;
  nextRankPoints: number;
  rankIcon: React.ComponentType<{ size?: number; className?: string }>;
  rankColor: string;
  benefits: string[];
}

interface ContributionStats {
  totalReports: number;
  verifiedReports: number;
  resolvedCases: number;
  totalEarnings: number;
  pendingCommission: number;
  successRate: number;
  averageResponseTime: string;
  communityImpact: number;
  monthlyGrowth: number;
}

export default function HistoryPage() {
  const { language, toggleLanguage } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [stats, setStats] = useState<ContributionStats>({
    totalReports: 0,
    verifiedReports: 0,
    resolvedCases: 0,
    totalEarnings: 0,
    pendingCommission: 0,
    successRate: 0,
    averageResponseTime: '0h',
    communityImpact: 0,
    monthlyGrowth: 0
  });
  
  const [rankInfo, setRankInfo] = useState<RankInfo>({
    currentRank: 'Civic Guardian',
    nextRank: 'Traffic Sentinel',
    currentPoints: 0,
    nextRankPoints: 100,
    rankIcon: Shield,
    rankColor: 'text-blue-600',
    benefits: []
  });
  
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  // Mock data - in real app, this would come from API
  useEffect(() => {
    const mockStats: ContributionStats = {
      totalReports: user?.statistics?.reportsFiled || 15,
      verifiedReports: user?.statistics?.casesResolved || 12,
      resolvedCases: user?.statistics?.casesResolved || 12,
      totalEarnings: user?.statistics?.rewardsEarned || 3500,
      pendingCommission: 800,
      successRate: 85.5,
      averageResponseTime: '2.4h',
      communityImpact: 47, // Lives potentially saved
      monthlyGrowth: 23.5
    };

    const mockAchievements: Achievement[] = [
      {
        id: '1',
        title: 'First Report',
        description: 'Submit your first violation report',
        icon: FileText,
        earned: true,
        earnedDate: '2024-10-15T10:30:00Z'
      },
      {
        id: '2', 
        title: 'Traffic Guardian',
        description: 'Report 10 traffic violations',
        icon: Shield,
        earned: true,
        earnedDate: '2024-11-05T14:20:00Z',
        progress: 15,
        maxProgress: 10
      },
      {
        id: '3',
        title: 'Eagle Eye',
        description: 'Maintain 80%+ verification success rate',
        icon: Target,
        earned: true,
        earnedDate: '2024-11-08T09:15:00Z'
      },
      {
        id: '4',
        title: 'Community Hero',
        description: 'Help resolve 25 cases',
        icon: Users,
        earned: false,
        progress: 12,
        maxProgress: 25
      },
      {
        id: '5',
        title: 'Top Contributor',
        description: 'Earn ৳5,000 in commissions',
        icon: Trophy,
        earned: false,
        progress: 3500,
        maxProgress: 5000
      },
      {
        id: '6',
        title: 'Speed Demon',
        description: 'Report 5 cases within 24 hours',
        icon: TrendingUp,
        earned: false,
        progress: 2,
        maxProgress: 5
      }
    ];

    // Calculate rank based on points (verified reports * 10 + other factors)
    const points = mockStats.verifiedReports * 10 + Math.floor(mockStats.totalEarnings / 100);
    let currentRank = 'Civic Guardian';
    let nextRank = 'Traffic Sentinel';
    let nextRankPoints = 100;
    let rankIcon = Shield;
    let rankColor = 'text-blue-600';
    let benefits = ['Basic reporting features', 'Commission eligibility', 'Community recognition'];

    if (points >= 500) {
      currentRank = 'Traffic Marshal';
      nextRank = 'Safety Champion';
      nextRankPoints = 1000;
      rankIcon = Crown;
      rankColor = 'text-purple-600';
      benefits = ['Priority case review', 'Exclusive rewards', 'Government recognition', 'Premium support'];
    } else if (points >= 250) {
      currentRank = 'Safety Advocate';
      nextRank = 'Traffic Marshal';
      nextRankPoints = 500;
      rankIcon = Award;
      rankColor = 'text-gold-600';
      benefits = ['Enhanced commission rates', 'Special badges', 'Priority support'];
    } else if (points >= 100) {
      currentRank = 'Traffic Sentinel';
      nextRank = 'Safety Advocate';
      nextRankPoints = 250;
      rankIcon = Medal;
      rankColor = 'text-green-600';
      benefits = ['Advanced reporting tools', 'Higher commission rates', 'Monthly rewards'];
    }

    setTimeout(() => {
      setStats(mockStats);
      setRankInfo({
        currentRank,
        nextRank,
        currentPoints: points,
        nextRankPoints,
        rankIcon,
        rankColor,
        benefits
      });
      setAchievements(mockAchievements);
      setLoading(false);
    }, 1000);
  }, [user]);

  if (!user) {
    navigate('/login');
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="animate-pulse mx-auto text-sky-600 mb-4" size={32} />
          <p className="text-gray-600">Loading your achievements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">
                {language === 'en' ? 'Your Contribution & Achievements' : 'আপনার অবদান ও অর্জন'}
              </h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'বাংলা' : 'English'}
              </span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Rank & Progress Card */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-white bg-opacity-20 p-4 rounded-full">
                <rankInfo.rankIcon size={32} className="text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{rankInfo.currentRank}</h2>
                <p className="text-blue-100">
                  {rankInfo.currentPoints} points • Next: {rankInfo.nextRank}
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">#{Math.floor(rankInfo.currentPoints / 10) + 1}</div>
              <p className="text-sm text-blue-100">Community Rank</p>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm">Progress to {rankInfo.nextRank}</span>
              <span className="text-sm">{rankInfo.currentPoints}/{rankInfo.nextRankPoints}</span>
            </div>
            <div className="w-full bg-white bg-opacity-20 rounded-full h-3">
              <div 
                className="bg-white rounded-full h-3 transition-all duration-500"
                style={{ width: `${Math.min((rankInfo.currentPoints / rankInfo.nextRankPoints) * 100, 100)}%` }}
              />
            </div>
          </div>

          {/* Benefits */}
          <div className="mt-4">
            <p className="text-sm text-blue-100 mb-2">Current Benefits:</p>
            <div className="flex flex-wrap gap-2">
              {rankInfo.benefits.map((benefit, index) => (
                <span key={index} className="bg-white bg-opacity-20 px-2 py-1 rounded text-xs">
                  {benefit}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Reports</p>
                <p className="text-2xl font-bold text-gray-800">{stats.totalReports}</p>
                <p className="text-xs text-green-600">+{stats.monthlyGrowth}% this month</p>
              </div>
              <FileText className="text-blue-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-l-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-gray-800">{stats.successRate}%</p>
                <p className="text-xs text-gray-500">{stats.verifiedReports}/{stats.totalReports} verified</p>
              </div>
              <Target className="text-green-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-l-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Earnings</p>
                <p className="text-2xl font-bold text-gray-800">৳{stats.totalEarnings}</p>
                <p className="text-xs text-yellow-600">৳{stats.pendingCommission} pending</p>
              </div>
              <DollarSign className="text-purple-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-l-red-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Community Impact</p>
                <p className="text-2xl font-bold text-gray-800">{stats.communityImpact}</p>
                <p className="text-xs text-gray-500">Lives potentially saved</p>
              </div>
              <Users className="text-red-500" size={24} />
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Performance Metrics</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <Clock className="text-blue-600" size={24} />
              </div>
              <h4 className="font-semibold text-gray-800">Response Time</h4>
              <p className="text-2xl font-bold text-blue-600">{stats.averageResponseTime}</p>
              <p className="text-sm text-gray-600">Average time to report</p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <CheckCircle className="text-green-600" size={24} />
              </div>
              <h4 className="font-semibold text-gray-800">Resolution Rate</h4>
              <p className="text-2xl font-bold text-green-600">{Math.round((stats.resolvedCases / stats.totalReports) * 100)}%</p>
              <p className="text-sm text-gray-600">Cases resolved successfully</p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="text-purple-600" size={24} />
              </div>
              <h4 className="font-semibold text-gray-800">Growth Rate</h4>
              <p className="text-2xl font-bold text-purple-600">+{stats.monthlyGrowth}%</p>
              <p className="text-sm text-gray-600">Monthly improvement</p>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <Trophy className="mr-2 text-yellow-600" size={24} />
            Achievements
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => (
              <div 
                key={achievement.id} 
                className={`p-4 rounded-lg border-2 transition-all ${
                  achievement.earned 
                    ? 'border-green-200 bg-green-50' 
                    : 'border-gray-200 bg-gray-50'
                }`}
              >
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-full ${
                    achievement.earned 
                      ? 'bg-green-100 text-green-600' 
                      : 'bg-gray-100 text-gray-400'
                  }`}>
                    <achievement.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <h4 className={`font-semibold ${
                      achievement.earned ? 'text-gray-800' : 'text-gray-500'
                    }`}>
                      {achievement.title}
                    </h4>
                    <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                    
                    {achievement.earned ? (
                      <p className="text-xs text-green-600">
                        Earned on {new Date(achievement.earnedDate!).toLocaleDateString()}
                      </p>
                    ) : achievement.progress !== undefined && achievement.maxProgress ? (
                      <div>
                        <div className="flex justify-between text-xs text-gray-600 mb-1">
                          <span>Progress</span>
                          <span>{achievement.progress}/{achievement.maxProgress}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-gray-500">Not yet earned</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recognition & Future Goals */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <Star className="mr-2 text-yellow-600" size={24} />
            Recognition & Goals
          </h3>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
            <div className="flex items-center space-x-3">
              <Award className="text-yellow-600" size={24} />
              <div>
                <h4 className="font-semibold text-yellow-800">Government Recognition Eligible</h4>
                <p className="text-sm text-yellow-700">
                  Your contributions may qualify for official recognition by DMP/BRTA and the Government of Bangladesh.
                  Continue reporting to unlock special honors and certificates.
                </p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Upcoming Milestones</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <Target className="mr-2 text-blue-500" size={16} />
                  Reach {rankInfo.nextRank} rank
                </li>
                <li className="flex items-center">
                  <DollarSign className="mr-2 text-green-500" size={16} />
                  Earn ৳5,000 total commission
                </li>
                <li className="flex items-center">
                  <Users className="mr-2 text-purple-500" size={16} />
                  Help resolve 25 total cases
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Community Impact</h4>
              <div className="space-y-2 text-sm">
                <p className="text-gray-600">
                  Your reports have potentially prevented <span className="font-semibold text-blue-600">{stats.communityImpact} accidents</span> and saved lives.
                </p>
                <p className="text-gray-600">
                  You're ranked in the <span className="font-semibold text-green-600">top {Math.floor((1 - (rankInfo.currentPoints / 1000)) * 100)}%</span> of active citizens.
                </p>
                <p className="text-gray-600">
                  Your contribution helps make Bangladesh roads <span className="font-semibold text-purple-600">safer for everyone</span>.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
