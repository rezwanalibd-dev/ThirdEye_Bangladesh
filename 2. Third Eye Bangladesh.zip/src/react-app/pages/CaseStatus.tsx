import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  ArrowLeft,
  Globe,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  MapPin,
  Calendar,
  DollarSign,
  FileText,
  Eye,
  Filter,
  Search,
  RefreshCw
} from 'lucide-react';

interface Report {
  id: string;
  caseNumber: string;
  type: 'traffic' | 'social';
  status: 'pending' | 'under_review' | 'verified' | 'rejected' | 'resolved';
  location: string;
  vehicleNumber?: string;
  submittedDate: string;
  lastUpdated: string;
  fineAmount?: number;
  commissionAmount?: number;
  commissionPaid: boolean;
  officerNotes?: string;
}

export default function CaseStatusPage() {
  const { language, toggleLanguage } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [reports, setReports] = useState<Report[]>([]);
  const [filteredReports, setFilteredReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'verified' | 'resolved' | 'rejected'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data - in real app, this would come from API
  useEffect(() => {
    const mockReports: Report[] = [
      {
        id: '1',
        caseNumber: 'TE-241110-192545-001',
        type: 'traffic',
        status: 'verified',
        location: 'Dhanmondi 27, Dhaka',
        vehicleNumber: 'Dhaka Metro-Gha-12-3456',
        submittedDate: '2024-11-10T14:25:45Z',
        lastUpdated: '2024-11-10T16:30:00Z',
        fineAmount: 5000,
        commissionAmount: 1000,
        commissionPaid: true,
        officerNotes: 'Verified by DMP Officer. Fine collected successfully.'
      },
      {
        id: '2', 
        caseNumber: 'TE-241110-183042-002',
        type: 'traffic',
        status: 'under_review',
        location: 'Gulshan 2 Circle, Dhaka',
        submittedDate: '2024-11-10T13:30:42Z',
        lastUpdated: '2024-11-10T15:45:00Z',
        commissionPaid: false,
        officerNotes: 'Under review by BRTA. Evidence verification in progress.'
      },
      {
        id: '3',
        caseNumber: 'TI-241109-205318-001',
        type: 'social',
        status: 'resolved',
        location: 'Uttara Sector 7, Dhaka',
        submittedDate: '2024-11-09T15:53:18Z',
        lastUpdated: '2024-11-10T09:20:00Z',
        commissionPaid: false,
        officerNotes: 'Investigation completed. Appropriate action taken by authorities.'
      },
      {
        id: '4',
        caseNumber: 'TE-241109-143025-003',
        type: 'traffic',
        status: 'pending',
        location: 'Mirpur 10, Dhaka',
        vehicleNumber: 'Dhaka Metro-Ka-15-7890',
        submittedDate: '2024-11-09T09:30:25Z',
        lastUpdated: '2024-11-09T09:30:25Z',
        commissionPaid: false,
        officerNotes: 'Awaiting initial review by DMP Officer.'
      },
      {
        id: '5',
        caseNumber: 'TE-241108-112847-004',
        type: 'traffic',
        status: 'rejected',
        location: 'Banani, Dhaka',
        submittedDate: '2024-11-08T06:28:47Z',
        lastUpdated: '2024-11-08T18:45:00Z',
        commissionPaid: false,
        officerNotes: 'Insufficient evidence. Please provide clearer photos/videos in future reports.'
      }
    ];

    setTimeout(() => {
      setReports(mockReports);
      setFilteredReports(mockReports);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = reports;

    // Apply status filter
    if (filter !== 'all') {
      filtered = filtered.filter(report => report.status === filter);
    }

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(report => 
        report.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (report.vehicleNumber && report.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    setFilteredReports(filtered);
  }, [filter, searchTerm, reports]);

  const getStatusColor = (status: Report['status']) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'under_review': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'verified': return 'bg-green-100 text-green-800 border-green-200';
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: Report['status']) => {
    switch (status) {
      case 'pending': return <Clock size={16} />;
      case 'under_review': return <Eye size={16} />;
      case 'verified': 
      case 'resolved': return <CheckCircle size={16} />;
      case 'rejected': return <XCircle size={16} />;
      default: return <AlertTriangle size={16} />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const totalEarnings = reports
    .filter(r => r.commissionPaid)
    .reduce((sum, r) => sum + (r.commissionAmount || 0), 0);

  if (!user) {
    navigate('/login');
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="animate-spin mx-auto text-sky-600 mb-4" size={32} />
          <p className="text-gray-600">Loading your reports...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">
                {language === 'en' ? 'Case Status & Reports' : 'কেস স্ট্যাটাস ও রিপোর্ট'}
              </h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'বাংলা' : 'English'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Stats Summary */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Reports</p>
                <p className="text-2xl font-bold text-gray-800">{reports.length}</p>
              </div>
              <FileText className="text-blue-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow border-l-4 border-l-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Verified</p>
                <p className="text-2xl font-bold text-gray-800">
                  {reports.filter(r => r.status === 'verified' || r.status === 'resolved').length}
                </p>
              </div>
              <CheckCircle className="text-green-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow border-l-4 border-l-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-gray-800">
                  {reports.filter(r => r.status === 'pending' || r.status === 'under_review').length}
                </p>
              </div>
              <Clock className="text-yellow-500" size={24} />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow border-l-4 border-l-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Earnings</p>
                <p className="text-2xl font-bold text-gray-800">৳{totalEarnings}</p>
              </div>
              <DollarSign className="text-purple-500" size={24} />
            </div>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search by case number, location, or vehicle number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="text-gray-600" size={20} />
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
              >
                <option value="all">All Reports</option>
                <option value="pending">Pending</option>
                <option value="under_review">Under Review</option>
                <option value="verified">Verified</option>
                <option value="resolved">Resolved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </div>

        {/* Reports List */}
        <div className="space-y-4">
          {filteredReports.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <FileText className="mx-auto text-gray-400 mb-4" size={48} />
              <h3 className="text-lg font-medium text-gray-800 mb-2">No reports found</h3>
              <p className="text-gray-600">No reports match your current search and filter criteria.</p>
            </div>
          ) : (
            filteredReports.map((report) => (
              <div key={report.id} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-800 mb-1">
                          {report.caseNumber}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span className="flex items-center">
                            <Calendar size={16} className="mr-1" />
                            {formatDate(report.submittedDate)}
                          </span>
                          <span className="flex items-center">
                            <MapPin size={16} className="mr-1" />
                            {report.location}
                          </span>
                          {report.vehicleNumber && (
                            <span className="bg-gray-100 px-2 py-1 rounded text-xs font-mono">
                              {report.vehicleNumber}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(report.status)}`}>
                        {getStatusIcon(report.status)}
                        <span className="ml-1 capitalize">{report.status.replace('_', ' ')}</span>
                      </div>
                    </div>
                    
                    {report.officerNotes && (
                      <div className="bg-blue-50 border-l-4 border-blue-400 p-3 mb-3">
                        <p className="text-sm text-blue-800">
                          <strong>Officer Notes:</strong> {report.officerNotes}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {/* Earnings Info */}
                  {(report.fineAmount || report.commissionAmount) && (
                    <div className="border-t lg:border-t-0 lg:border-l border-gray-200 pt-4 lg:pt-0 lg:pl-6 lg:ml-6">
                      <div className="text-center lg:text-right space-y-2">
                        {report.fineAmount && (
                          <div>
                            <p className="text-sm text-gray-600">Fine Amount</p>
                            <p className="text-lg font-semibold text-gray-800">৳{report.fineAmount}</p>
                          </div>
                        )}
                        {report.commissionAmount && (
                          <div>
                            <p className="text-sm text-gray-600">Your Commission</p>
                            <p className={`text-lg font-semibold ${report.commissionPaid ? 'text-green-600' : 'text-yellow-600'}`}>
                              ৳{report.commissionAmount}
                            </p>
                            <p className={`text-xs ${report.commissionPaid ? 'text-green-600' : 'text-yellow-600'}`}>
                              {report.commissionPaid ? '✓ Paid' : 'Pending Payment'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between items-center text-xs text-gray-500">
                  <span>Last updated: {formatDate(report.lastUpdated)}</span>
                  <span className="bg-gray-100 px-2 py-1 rounded">
                    {report.type === 'traffic' ? 'Traffic Violation' : 'Social Crime'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
