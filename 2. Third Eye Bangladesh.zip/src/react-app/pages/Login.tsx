import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Eye, EyeOff, Lock, Loader2, Globe, Phone } from 'lucide-react';

export default function LoginPage() {
  const { t, language, toggleLanguage } = useLanguage();
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    mobileOrEmail: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const success = await login(formData.mobileOrEmail, formData.password);
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Invalid mobile number/email or password');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError('Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-sky-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8">
        {/* Language Toggle */}
        <div className="flex justify-end mb-4">
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
          >
            <Globe size={16} />
            <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
              {t('languageLabel')}
            </span>
          </button>
        </div>
        
        {/* Logo */}
        <div className="text-center mb-8">
          <img 
            src="https://mocha-cdn.com/019a7364-a032-7e48-8ef2-a113c18111ab/third-eye-logo.png" 
            alt="Third Eye Logo" 
            className="w-20 h-20 mx-auto rounded-full drop-shadow-lg border-2 border-sky-200"
          />
          <h1 className="text-2xl font-bold text-gray-800 mt-3" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Third Eye' : 'তৃতীয় চোখ'}
          </h1>
          <p className="text-sm text-gray-600 mt-1" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Your Vigilance Saves Lives and Earns Rewards' : 'আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="mobileOrEmail" className="block text-sm font-medium text-gray-700 mb-2">
              {t('mobileOrEmail')}
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                id="mobileOrEmail"
                name="mobileOrEmail"
                value={formData.mobileOrEmail}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                placeholder="+8801XXXXXXXXX or email@example.com"
                autoComplete="tel"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
              {t('password')}
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition duration-150 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? (
              <Loader2 className="animate-spin mr-2" size={20} />
            ) : null}
            {isLoading ? 'Signing in...' : t('signIn')}
          </button>

          <div className="text-center">
            <Link 
              to="/forgot-password" 
              className="text-sm text-sky-600 hover:text-sky-700 hover:underline"
            >
              {t('forgotPassword')}
            </Link>
          </div>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">
              {t('dontHaveAccount')}
            </p>
            <Link 
              to="/signup" 
              className="w-full inline-block bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition duration-150 font-medium text-center"
            >
              {t('createAccount')}
            </Link>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link 
            to="/" 
            className="text-sm text-gray-600 hover:text-gray-800 hover:underline"
          >
            ← Back to Home
          </Link>
        </div>

        {/* Demo Login Credentials */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Demo Credentials:</h3>
          <div className="text-xs text-gray-600 space-y-2">
            <button 
              onClick={() => {
                setFormData({ mobileOrEmail: 'citizen@demo.com', password: 'password' });
              }}
              className="block w-full text-left p-2 hover:bg-gray-100 rounded"
            >
              <div className="font-medium">Citizen: citizen@demo.com / password</div>
              <div className="text-gray-500">Click to fill credentials</div>
            </button>
            <button 
              onClick={() => {
                setFormData({ mobileOrEmail: 'officer@demo.com', password: 'password' });
              }}
              className="block w-full text-left p-2 hover:bg-gray-100 rounded"
            >
              <div className="font-medium">DMP Officer: officer@demo.com / password</div>
            </button>
            <button 
              onClick={() => {
                setFormData({ mobileOrEmail: 'brta@demo.com', password: 'password' });
              }}
              className="block w-full text-left p-2 hover:bg-gray-100 rounded"
            >
              <div className="font-medium">BRTA Official: brta@demo.com / password</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
