import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  ArrowLeft,
  User,
  Phone,
  Mail,
  Camera,
  Wallet,
  Shield,
  CheckCircle,
  Upload,
  Loader2,
  AlertCircle,
  Globe
} from 'lucide-react';

type TabType = 'profile' | 'banking' | 'kyc';
type KYCStep = 'selfie' | 'document';

export default function ProfilePage() {
  const { language, toggleLanguage } = useLanguage();
  const { user, updateUser, updateVerificationStatus } = useAuth();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<TabType>('profile');
  const [kycStep, setKycStep] = useState<KYCStep>('selfie');
  const [isLoading, setIsLoading] = useState(false);
  
  // Profile state
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string>(user?.profileImage || '');
  const profileImageRef = useRef<HTMLInputElement>(null);
  
  // Banking state
  const [bankingData, setBankingData] = useState({
    type: user?.walletInfo?.provider || 'bKash',
    number: user?.walletInfo?.number || '',
    otp: ''
  });
  const [bankingVerified, setBankingVerified] = useState(!!user?.walletInfo);
  const [otpSent, setOtpSent] = useState(false);
  
  // KYC state
  const [selfieImages, setSelfieImages] = useState<{
    front: File | null;
    left: File | null;
    right: File | null;
  }>({ front: null, left: null, right: null });
  const [selfiePreviews, setSelfiePreviews] = useState<{
    front: string;
    left: string;
    right: string;
  }>({ front: '', left: '', right: '' });
  
  const [documentData, setDocumentData] = useState({
    type: 'nid',
    number: '',
    image: null as File | null,
    imagePreview: ''
  });

  React.useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileImage(file);
      setProfileImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSaveProfile = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (profileImage) {
        // Simulate upload
        updateUser({ profileImage: profileImagePreview });
      }
      
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Profile update error:', error);
      alert('Failed to update profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendBankingOTP = async () => {
    if (!bankingData.number || bankingData.number.length < 11) {
      alert('Please enter a valid mobile banking number');
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setOtpSent(true);
      alert(`OTP sent to ${bankingData.number}`);
    } catch (error) {
      console.error('OTP send error:', error);
      alert('Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyBanking = async () => {
    if (bankingData.otp.length !== 6) {
      alert('Please enter a valid 6-digit OTP');
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser({
        walletInfo: {
          type: bankingData.type,
          provider: bankingData.type,
          number: bankingData.number,
          accountHolder: user?.fullName || '',
          verified: true
        }
      });
      
      setBankingVerified(true);
      alert('Mobile banking account verified successfully!');
    } catch (error) {
      console.error('OTP verification error:', error);
      alert('Invalid OTP. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelfieCapture = (position: 'front' | 'left' | 'right', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelfieImages(prev => ({ ...prev, [position]: file }));
      setSelfiePreviews(prev => ({ ...prev, [position]: URL.createObjectURL(file) }));
    }
  };

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDocumentData(prev => ({
        ...prev,
        image: file,
        imagePreview: URL.createObjectURL(file)
      }));
    }
  };

  const handleSubmitKYC = async () => {
    // Validate selfies
    if (!selfieImages.front || !selfieImages.left || !selfieImages.right) {
      alert('Please capture all three selfie photos');
      return;
    }
    
    // Validate document
    if (!documentData.number || !documentData.image) {
      alert('Please provide document number and upload document photo');
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      updateVerificationStatus('complete');
      alert('KYC verification submitted successfully! Your account will be verified within 24-48 hours.');
      navigate('/dashboard');
    } catch (error) {
      console.error('KYC submission error:', error);
      alert('Failed to submit KYC verification');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  const ProfileTab = () => (
    <div className="space-y-6">
      {/* Profile Image */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Profile Picture</h3>
        <div className="flex items-center space-x-6">
          <div className="relative">
            {profileImagePreview ? (
              <img 
                src={profileImagePreview} 
                alt="Profile" 
                className="w-24 h-24 rounded-full object-cover border-4 border-sky-200"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center">
                <User size={40} className="text-gray-400" />
              </div>
            )}
            <button
              onClick={() => profileImageRef.current?.click()}
              className="absolute bottom-0 right-0 bg-sky-600 text-white p-2 rounded-full hover:bg-sky-700 shadow-lg"
            >
              <Camera size={16} />
            </button>
            <input
              ref={profileImageRef}
              type="file"
              accept="image/*"
              onChange={handleProfileImageChange}
              className="hidden"
            />
          </div>
          <div>
            <h4 className="font-medium text-gray-800">{user.fullName}</h4>
            <p className="text-sm text-gray-600">{user.email || 'No email provided'}</p>
            <p className="text-sm text-gray-600">{user.mobileNumber}</p>
          </div>
        </div>
      </div>

      {/* Account Information */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Account Information</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <User className="text-gray-600" size={20} />
              <div>
                <p className="text-sm text-gray-600">Full Name</p>
                <p className="font-medium text-gray-800">{user.fullName}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Phone className="text-gray-600" size={20} />
              <div>
                <p className="text-sm text-gray-600">Mobile Number</p>
                <p className="font-medium text-gray-800">{user.mobileNumber}</p>
              </div>
            </div>
            <CheckCircle className="text-green-600" size={20} />
          </div>
          
          {user.email && (
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Mail className="text-gray-600" size={20} />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium text-gray-800">{user.email}</p>
                </div>
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Shield className="text-gray-600" size={20} />
              <div>
                <p className="text-sm text-gray-600">Verification Status</p>
                <p className={`font-medium ${
                  user.verificationStatus === 'complete' ? 'text-green-600' : 'text-yellow-600'
                }`}>
                  {user.verificationStatus === 'complete' ? 'Verified' : 'Pending Verification'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={handleSaveProfile}
        disabled={isLoading}
        className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
      >
        {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
        Save Changes
      </button>
    </div>
  );

  const BankingTab = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Digital Mobile Banking *</h3>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-yellow-800">
            <strong>Required:</strong> You must complete Digital Wallet setup with your full name and verified mobile banking account to receive commission payments and access all features.
          </p>
        </div>

        {!bankingVerified ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name * (as per mobile banking account)
              </label>
              <input
                type="text"
                value={user?.fullName || ''}
                readOnly
                className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                placeholder="Your full name from profile"
              />
              <p className="text-xs text-gray-500 mt-1">This must match your mobile banking account name</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mobile Banking Type *
              </label>
              <select
                value={bankingData.type}
                onChange={(e) => setBankingData(prev => ({ ...prev, type: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
              >
                <option value="bKash">bKash</option>
                <option value="Nagad">Nagad</option>
                <option value="Rocket">Rocket</option>
                <option value="Upay">Upay</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mobile Banking Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="tel"
                  value={bankingData.number}
                  onChange={(e) => setBankingData(prev => ({ ...prev, number: e.target.value }))}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                  placeholder="+880 1234 567890"
                />
              </div>
            </div>

            {!otpSent ? (
              <button
                onClick={handleSendBankingOTP}
                disabled={isLoading}
                className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
                Send OTP
              </button>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Enter OTP
                  </label>
                  <input
                    type="text"
                    value={bankingData.otp}
                    onChange={(e) => setBankingData(prev => ({ ...prev, otp: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent text-center text-2xl tracking-widest"
                    placeholder="000000"
                    maxLength={6}
                  />
                  <p className="text-xs text-gray-500 text-center mt-2">
                    OTP sent to {bankingData.number}
                  </p>
                </div>

                <button
                  onClick={handleVerifyBanking}
                  disabled={isLoading || bankingData.otp.length !== 6}
                  className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition duration-150 font-medium disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
                  Verify & Link Account
                </button>

                <button
                  onClick={handleSendBankingOTP}
                  className="w-full text-sky-600 hover:text-sky-700 text-sm font-medium"
                >
                  Resend OTP
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center">
              <CheckCircle className="text-green-600 mr-3" size={24} />
              <div>
                <h4 className="font-medium text-green-800">Account Verified</h4>
                <p className="text-sm text-green-700">
                  {bankingData.type}: {bankingData.number}
                </p>
                <p className="text-xs text-green-600 mt-1">
                  Commissions will be sent to this account
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const KYCTab = () => (
    <div className="space-y-6">
      {user.verificationStatus === 'complete' ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-center">
            <CheckCircle className="text-green-600 mr-4" size={48} />
            <div>
              <h3 className="text-xl font-bold text-green-800">KYC Verified</h3>
              <p className="text-green-700">Your account has been fully verified</p>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Step Indicator */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex-1">
                <div className={`h-2 rounded-full ${kycStep === 'selfie' ? 'bg-sky-600' : 'bg-green-600'}`} />
              </div>
              <div className="px-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  kycStep === 'document' ? 'bg-sky-600 text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  {kycStep === 'document' ? '2' : '1'}
                </div>
              </div>
            </div>
            <p className="text-center text-sm text-gray-600">
              {kycStep === 'selfie' ? 'Step 1: Biometric Verification' : 'Step 2: Document Verification'}
            </p>
          </div>

          {kycStep === 'selfie' && (
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-2">Biometric Verification</h3>
              <p className="text-sm text-gray-600 mb-6">
                Take three selfie photos: front face, left side, and right side
              </p>

              <div className="grid grid-cols-3 gap-4 mb-6">
                {(['front', 'left', 'right'] as const).map((position) => (
                  <div key={position}>
                    <label className="block">
                      <div className="relative cursor-pointer">
                        {selfiePreviews[position] ? (
                          <img 
                            src={selfiePreviews[position]} 
                            alt={`${position} face`}
                            className="w-full h-32 object-cover rounded-lg border-2 border-sky-200"
                          />
                        ) : (
                          <div className="w-full h-32 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center">
                            <Camera className="text-gray-400 mb-1" size={24} />
                            <span className="text-xs text-gray-600 capitalize">{position}</span>
                          </div>
                        )}
                        <input
                          type="file"
                          accept="image/*"
                          capture="user"
                          onChange={(e) => handleSelfieCapture(position, e)}
                          className="hidden"
                        />
                      </div>
                    </label>
                    <p className="text-xs text-center text-gray-600 mt-2 capitalize">{position} Face</p>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  if (selfieImages.front && selfieImages.left && selfieImages.right) {
                    setKycStep('document');
                  } else {
                    alert('Please capture all three selfie photos');
                  }
                }}
                className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium"
              >
                Continue to Document Upload
              </button>
            </div>
          )}

          {kycStep === 'document' && (
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-2">Document Verification</h3>
              <p className="text-sm text-gray-600 mb-6">
                Upload your NID, Driving License, or Passport
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Document Type
                  </label>
                  <select
                    value={documentData.type}
                    onChange={(e) => setDocumentData(prev => ({ ...prev, type: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                  >
                    <option value="nid">National ID (NID)</option>
                    <option value="driving_license">Driving License</option>
                    <option value="passport">Passport</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Document Number
                  </label>
                  <input
                    type="text"
                    value={documentData.number}
                    onChange={(e) => setDocumentData(prev => ({ ...prev, number: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    placeholder="Enter document number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Upload Document Photo
                  </label>
                  <label className="block cursor-pointer">
                    {documentData.imagePreview ? (
                      <img 
                        src={documentData.imagePreview} 
                        alt="Document"
                        className="w-full h-48 object-cover rounded-lg border-2 border-sky-200"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center">
                        <Upload className="text-gray-400 mb-2" size={32} />
                        <span className="text-sm text-gray-600">Click to upload document</span>
                        <span className="text-xs text-gray-500 mt-1">Clear photo of the document</span>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleDocumentChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="flex space-x-4 mt-6">
                <button
                  onClick={() => setKycStep('selfie')}
                  className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-150 font-medium"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmitKYC}
                  disabled={isLoading}
                  className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition duration-150 font-medium disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="animate-spin inline mr-2" size={20} /> : null}
                  Submit KYC
                </button>
              </div>
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertCircle className="text-blue-600 mr-3 mt-0.5" size={20} />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1">Verification Requirements:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>All selfie photos must show your face clearly</li>
                  <li>Document photo must be clear and readable</li>
                  <li>Document number must match the uploaded photo</li>
                  <li>Verification typically takes 24-48 hours</li>
                </ul>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">Profile & Settings</h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'বাংলা' : 'English'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('profile')}
              className={`py-4 border-b-2 font-medium transition-colors ${
                activeTab === 'profile'
                  ? 'border-sky-600 text-sky-600'
                  : 'border-transparent text-gray-600 hover:text-gray-800'
              }`}
            >
              <User className="inline mr-2" size={20} />
              Profile
            </button>
            <button
              onClick={() => setActiveTab('banking')}
              className={`py-4 border-b-2 font-medium transition-colors ${
                activeTab === 'banking'
                  ? 'border-sky-600 text-sky-600'
                  : 'border-transparent text-gray-600 hover:text-gray-800'
              }`}
            >
              <Wallet className="inline mr-2" size={20} />
              Banking
            </button>
            <button
              onClick={() => setActiveTab('kyc')}
              className={`py-4 border-b-2 font-medium transition-colors ${
                activeTab === 'kyc'
                  ? 'border-sky-600 text-sky-600'
                  : 'border-transparent text-gray-600 hover:text-gray-800'
              }`}
            >
              <Shield className="inline mr-2" size={20} />
              KYC Verification
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {activeTab === 'profile' && <ProfileTab />}
        {activeTab === 'banking' && <BankingTab />}
        {activeTab === 'kyc' && <KYCTab />}
      </main>
    </div>
  );
}
