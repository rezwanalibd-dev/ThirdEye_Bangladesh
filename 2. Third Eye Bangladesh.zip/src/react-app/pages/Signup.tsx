import { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth, UserRole } from '../context/AuthContext';
import { 
  Eye, 
  EyeOff, 
  User, 
  Phone, 
  Mail,
  Loader2, 
  ArrowRight, 
  ArrowLeft, 
  Globe, 
  CheckCircle,
  Camera,
  Upload,
  Shield,
  CreditCard,
  FileText
} from 'lucide-react';

interface FormErrors {
  [key: string]: string;
}

interface SignupFormData {
  // Basic Info
  fullName: string;
  mobileNumber: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: UserRole;
  
  // Identity Documents
  nidNumber: string;
  drivingLicenseNumber: string;
  passportNumber: string;
  
  // Document Images
  nidFrontImage: File | null;
  nidBackImage: File | null;
  licenseFrontImage: File | null;
  licenseBackImage: File | null;
  passportImage: File | null;
  
  // Selfie Images
  frontFaceImage: File | null;
  leftFaceImage: File | null;
  rightFaceImage: File | null;
  
  // Mobile Wallet Info
  walletProvider: string;
  walletNumber: string;
  walletAccountHolder: string;
  
  // Officer Info (for DMP/BRTA)
  badgeNumber?: string;
  employeeId?: string;
  department?: string;
  rank?: string;
  postingArea?: string;
}

export default function SignupPage() {
  const { language, toggleLanguage } = useLanguage();
  const { signup } = useAuth();
  const navigate = useNavigate();
  
  const [step, setStep] = useState(1); // 1: Role & Basic Info, 2: Identity Documents, 3: Biometric Verification, 4: Mobile Wallet, 5: OTP Verification
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpTimer, setOtpTimer] = useState(0);

  // Form data
  const [formData, setFormData] = useState<SignupFormData>({
    fullName: '',
    mobileNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'citizen',
    nidNumber: '',
    drivingLicenseNumber: '',
    passportNumber: '',
    nidFrontImage: null,
    nidBackImage: null,
    licenseFrontImage: null,
    licenseBackImage: null,
    passportImage: null,
    frontFaceImage: null,
    leftFaceImage: null,
    rightFaceImage: null,
    walletProvider: 'bKash',
    walletNumber: '',
    walletAccountHolder: '',
  });

  // File input refs
  const nidFrontRef = useRef<HTMLInputElement>(null);
  const nidBackRef = useRef<HTMLInputElement>(null);
  const licenseFrontRef = useRef<HTMLInputElement>(null);
  const licenseBackRef = useRef<HTMLInputElement>(null);
  const passportRef = useRef<HTMLInputElement>(null);
  const frontFaceRef = useRef<HTMLInputElement>(null);
  const leftFaceRef = useRef<HTMLInputElement>(null);
  const rightFaceRef = useRef<HTMLInputElement>(null);

  const validatePassword = (pwd: string): string | null => {
    if (pwd.length < 8) return language === 'en' ? 'Password must be at least 8 characters' : 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে';
    if (!/[A-Z]/.test(pwd)) return language === 'en' ? 'Password must contain uppercase letter' : 'পাসওয়ার্ডে বড় হাতের অক্ষর থাকতে হবে';
    if (!/[a-z]/.test(pwd)) return language === 'en' ? 'Password must contain lowercase letter' : 'পাসওয়ার্ডে ছোট হাতের অক্ষর থাকতে হবে';
    if (!/[0-9]/.test(pwd)) return language === 'en' ? 'Password must contain number' : 'পাসওয়ার্ডে সংখ্যা থাকতে হবে';
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(pwd)) return language === 'en' ? 'Password must contain symbol' : 'পাসওয়ার্ডে বিশেষ চিহ্ন থাকতে হবে';
    return null;
  };

  const validateStep = (): boolean => {
    const newErrors: FormErrors = {};

    if (step === 1) {
      if (!formData.fullName.trim()) newErrors.fullName = language === 'en' ? 'Full name is required' : 'পুরো নাম আবশ্যক';
      if (!formData.mobileNumber.trim()) newErrors.mobileNumber = language === 'en' ? 'Mobile number is required' : 'মোবাইল নম্বর আবশ্যক';
      if (formData.mobileNumber && !/^(\+880|880)?[0-9]{10,11}$/.test(formData.mobileNumber.replace(/\s/g, ''))) {
        newErrors.mobileNumber = language === 'en' ? 'Invalid mobile number format' : 'অবৈধ মোবাইল নম্বর ফরম্যাট';
      }
      if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        newErrors.email = language === 'en' ? 'Invalid email format' : 'অবৈধ ইমেইল ফরম্যাট';
      }
      const passwordError = validatePassword(formData.password);
      if (passwordError) newErrors.password = passwordError;
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = language === 'en' ? 'Passwords do not match' : 'পাসওয়ার্ড মিলছে না';
      }

      // Officer-specific validation
      if (formData.role === 'dmpOfficer') {
        if (!formData.badgeNumber) newErrors.badgeNumber = language === 'en' ? 'Badge number is required' : 'ব্যাজ নম্বর আবশ্যক';
        if (!formData.department) newErrors.department = language === 'en' ? 'Department is required' : 'বিভাগ আবশ্যক';
      }
      if (formData.role === 'brtaOfficial') {
        if (!formData.employeeId) newErrors.employeeId = language === 'en' ? 'Employee ID is required' : 'কর্মচারী আইডি আবশ্যক';
        if (!formData.postingArea) newErrors.postingArea = language === 'en' ? 'Posting area is required' : 'পোস্টিং এলাকা আবশ্যক';
      }
    }

    if (step === 2) {
      // At least one identity document is required
      const hasNid = formData.nidNumber && (formData.nidFrontImage || formData.nidBackImage);
      const hasLicense = formData.drivingLicenseNumber && (formData.licenseFrontImage || formData.licenseBackImage);
      const hasPassport = formData.passportNumber && formData.passportImage;
      
      if (!hasNid && !hasLicense && !hasPassport) {
        newErrors.documents = language === 'en' ? 'At least one identity document is required' : 'কমপক্ষে একটি পরিচয়পত্র আবশ্যক';
      }
    }

    if (step === 3) {
      if (!formData.frontFaceImage) newErrors.frontFace = language === 'en' ? 'Front face selfie is required' : 'সামনের মুখের সেলফি আবশ্যক';
      if (!formData.leftFaceImage) newErrors.leftFace = language === 'en' ? 'Left face selfie is required' : 'বাম দিকের মুখের সেলফি আবশ্যক';
      if (!formData.rightFaceImage) newErrors.rightFace = language === 'en' ? 'Right face selfie is required' : 'ডান দিকের মুখের সেলফি আবশ্যক';
    }

    if (step === 4 && formData.role === 'citizen') {
      if (!formData.walletNumber) newErrors.walletNumber = language === 'en' ? 'Mobile wallet number is required' : 'মোবাইল ওয়ালেট নম্বর আবশ্যক';
      if (!formData.walletAccountHolder) newErrors.walletAccountHolder = language === 'en' ? 'Account holder name is required' : 'অ্যাকাউন্ট হোল্ডারের নাম আবশ্যক';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      if (step === 4 && formData.role === 'citizen') {
        handleSendOTP();
      } else if (step === 3 && formData.role !== 'citizen') {
        handleSendOTP(); // Officers skip wallet step
      } else {
        setStep(step + 1);
      }
    }
  };

  const handleSendOTP = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setOtpTimer(120); // 2 minutes
      const interval = setInterval(() => {
        setOtpTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      alert(language === 'en' ? 
        `OTP sent to ${formData.mobileNumber}` : 
        `OTP পাঠানো হয়েছে ${formData.mobileNumber} এ`);
      setStep(5);
    } catch (error) {
      console.error('OTP send error:', error);
      alert(language === 'en' ? 'Failed to send OTP. Please try again.' : 'OTP পাঠাতে ব্যর্থ। আবার চেষ্টা করুন।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      alert(language === 'en' ? 'Please enter a valid 6-digit OTP' : 'অনুগ্রহ করে একটি বৈধ ৬ ডিজিটের OTP লিখুন');
      return;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const success = await signup(formData as any, formData.password);
      if (success) {
        alert(language === 'en' ? 
          'Account created successfully! Please complete your profile verification.' :
          'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! অনুগ্রহ করে আপনার প্রোফাইল যাচাইকরণ সম্পূর্ণ করুন।');
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('OTP verification error:', error);
      alert(language === 'en' ? 'Invalid OTP. Please try again.' : 'অবৈধ OTP। আবার চেষ্টা করুন।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (type: keyof SignupFormData, file: File | null) => {
    setFormData(prev => ({ ...prev, [type]: file }));
  };

  const capturePhoto = (inputRef: React.RefObject<HTMLInputElement | null>) => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  // Step 1: Role Selection & Basic Information
  const Step1Component = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {language === 'en' ? 'Create Account & Start Reporting' : 'অ্যাকাউন্ট তৈরি করুন এবং রিপোর্টিং শুরু করুন'}
        </h2>
        <p className="text-gray-600">
          {language === 'en' ? 'Step 1 of 5' : 'ধাপ ১/৫'}
        </p>
      </div>

      {/* Role Selection */}
      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700">
          {language === 'en' ? 'Select Your Role *' : 'আপনার ভূমিকা নির্বাচন করুন *'}
        </label>
        {[
          { value: 'citizen', label: language === 'en' ? 'Citizen' : 'নাগরিক', color: 'bg-blue-50 border-blue-200 text-blue-800' },
          { value: 'dmpOfficer', label: language === 'en' ? 'DMP Officer' : 'ডিএমপি অফিসার', color: 'bg-green-50 border-green-200 text-green-800' },
          { value: 'brtaOfficial', label: language === 'en' ? 'BRTA Official' : 'বিআরটিএ কর্মকর্তা', color: 'bg-red-50 border-red-200 text-red-800' }
        ].map((roleOption) => (
          <label key={roleOption.value} className="block cursor-pointer">
            <input
              type="radio"
              name="role"
              value={roleOption.value}
              checked={formData.role === roleOption.value}
              onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as UserRole }))}
              className="sr-only"
            />
            <div className={`p-4 rounded-lg border-2 transition-all ${
              formData.role === roleOption.value ? roleOption.color : 'bg-white border-gray-200 hover:border-gray-300'
            }`}>
              <div className="flex items-center justify-between">
                <span className="font-medium">{roleOption.label}</span>
                <div className={`w-4 h-4 rounded-full border-2 ${
                  formData.role === roleOption.value ? 'bg-current border-current' : 'border-gray-300'
                }`} />
              </div>
            </div>
          </label>
        ))}
      </div>

      {/* Basic Information */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Full Name *' : 'পূর্ণ নাম *'}
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
              className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                errors.fullName ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder={language === 'en' ? 'Enter your full name' : 'আপনার পূর্ণ নাম লিখুন'}
            />
          </div>
          {errors.fullName && <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Mobile Number *' : 'মোবাইল নম্বর *'}
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="tel"
              value={formData.mobileNumber}
              onChange={(e) => setFormData(prev => ({ ...prev, mobileNumber: e.target.value }))}
              className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                errors.mobileNumber ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="+880 1234 567890"
            />
          </div>
          {errors.mobileNumber && <p className="mt-1 text-sm text-red-600">{errors.mobileNumber}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Email Address (Optional)' : 'ইমেইল ঠিকানা (ঐচ্ছিক)'}
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                errors.email ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="your@email.com"
            />
          </div>
          {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Create Password *' : 'পাসওয়ার্ড তৈরি করুন *'}
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent pr-12 ${
                errors.password ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
          {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
          <p className="mt-1 text-xs text-gray-600">
            {language === 'en' ? 'Must include A-Z, a-z, 0-9, and symbols' : 'ইংরেজি বড় অক্ষর, ছোট অক্ষর, সংখ্যা ও বিশেষ চিহ্ন ব্যবহার করতে হবে'}
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Confirm Password *' : 'পাসওয়ার্ড নিশ্চিত করুন *'}
          </label>
          <div className="relative">
            <input
              type={showConfirmPassword ? 'text' : 'password'}
              value={formData.confirmPassword}
              onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent pr-12 ${
                errors.confirmPassword ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            >
              {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
          {errors.confirmPassword && <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>}
        </div>

        {/* Officer-specific fields */}
        {formData.role === 'dmpOfficer' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? 'Badge Number *' : 'ব্যাজ নম্বর *'}
              </label>
              <input
                type="text"
                value={formData.badgeNumber || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, badgeNumber: e.target.value }))}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                  errors.badgeNumber ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="DMP-12345"
              />
              {errors.badgeNumber && <p className="mt-1 text-sm text-red-600">{errors.badgeNumber}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? 'Department *' : 'বিভাগ *'}
              </label>
              <select
                value={formData.department || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                  errors.department ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select Department</option>
                <option value="traffic">Traffic Division</option>
                <option value="crime">Crime Division</option>
                <option value="detective">Detective Branch</option>
                <option value="special">Special Branch</option>
              </select>
              {errors.department && <p className="mt-1 text-sm text-red-600">{errors.department}</p>}
            </div>
          </>
        )}

        {formData.role === 'brtaOfficial' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? 'Employee ID *' : 'কর্মচারী আইডি *'}
              </label>
              <input
                type="text"
                value={formData.employeeId || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, employeeId: e.target.value }))}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                  errors.employeeId ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="BRTA-67890"
              />
              {errors.employeeId && <p className="mt-1 text-sm text-red-600">{errors.employeeId}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? 'Posting Area *' : 'পোস্টিং এলাকা *'}
              </label>
              <input
                type="text"
                value={formData.postingArea || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, postingArea: e.target.value }))}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
                  errors.postingArea ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="Dhaka Metro"
              />
              {errors.postingArea && <p className="mt-1 text-sm text-red-600">{errors.postingArea}</p>}
            </div>
          </>
        )}
      </div>

      <button
        onClick={handleNext}
        className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium flex items-center justify-center"
      >
        {language === 'en' ? 'Continue' : 'পরবর্তী'} <ArrowRight className="ml-2" size={20} />
      </button>
    </div>
  );

  // Step 2: Identity Documents
  const Step2Component = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {language === 'en' ? 'Identity Documents' : 'পরিচয়পত্র'}
        </h2>
        <p className="text-gray-600">
          {language === 'en' ? 'Step 2 of 5' : 'ধাপ ২/৫'}
        </p>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p className="text-sm text-yellow-800">
          {language === 'en' ? 
            'Note: Provide at least one identification document (such as your NID, Driving License, or Passport) including its number for verification. You will be able to proceed to the next step only after verification is successful.' :
            'নোট: অন্তত একটি পরিচয় সংক্রান্ত নথি (যেমন আপনার এনআইডি, ড্রাইভিং লাইসেন্স, বা পাসপোর্ট) এর নম্বর সহ প্রদান করুন যাচাইকরণের জন্য। যাচাইকরণ সফল হওয়ার পরেই আপনি পরবর্তী ধাপে যেতে পারবেন।'
          }
        </p>
      </div>

      {errors.documents && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-sm text-red-800">{errors.documents}</p>
        </div>
      )}

      {/* NID Section */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-4 flex items-center">
          <FileText className="mr-2" size={20} />
          {language === 'en' ? 'Click to upload NID front & back photo' : 'এনআইডি সামনে ও পেছনের ছবি আপলোড করতে ক্লিক করুন'}
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {language === 'en' ? 'NID Number' : 'এনআইডি নম্বর'}
            </label>
            <input
              type="text"
              value={formData.nidNumber}
              onChange={(e) => setFormData(prev => ({ ...prev, nidNumber: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="1234567890123"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <button
                type="button"
                onClick={() => capturePhoto(nidFrontRef)}
                className="w-full h-32 border-2 border-dashed border-blue-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-400 transition-colors"
              >
                {formData.nidFrontImage ? (
                  <CheckCircle className="text-green-600" size={24} />
                ) : (
                  <Upload className="text-blue-500" size={24} />
                )}
                <span className="text-sm text-gray-600 mt-2">
                  {language === 'en' ? 'NID Front' : 'এনআইডি সামনে'}
                </span>
              </button>
              <input
                ref={nidFrontRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange('nidFrontImage', e.target.files?.[0] || null)}
                className="hidden"
              />
            </div>
            
            <div>
              <button
                type="button"
                onClick={() => capturePhoto(nidBackRef)}
                className="w-full h-32 border-2 border-dashed border-blue-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-400 transition-colors"
              >
                {formData.nidBackImage ? (
                  <CheckCircle className="text-green-600" size={24} />
                ) : (
                  <Upload className="text-blue-500" size={24} />
                )}
                <span className="text-sm text-gray-600 mt-2">
                  {language === 'en' ? 'NID Back' : 'এনআইডি পেছনে'}
                </span>
              </button>
              <input
                ref={nidBackRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange('nidBackImage', e.target.files?.[0] || null)}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Driving License Section */}
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-purple-800 mb-4 flex items-center">
          <CreditCard className="mr-2" size={20} />
          {language === 'en' ? 'Click to upload Driving License front & back photo' : 'ড্রাইভিং লাইসেন্স সামনে ও পেছনের ছবি আপলোড করতে ক্লিক করুন'}
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {language === 'en' ? 'Driving License Number' : 'ড্রাইভিং লাইসেন্স নম্বর'}
            </label>
            <input
              type="text"
              value={formData.drivingLicenseNumber}
              onChange={(e) => setFormData(prev => ({ ...prev, drivingLicenseNumber: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="DL123456789"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <button
                type="button"
                onClick={() => capturePhoto(licenseFrontRef)}
                className="w-full h-32 border-2 border-dashed border-purple-300 rounded-lg flex flex-col items-center justify-center hover:border-purple-400 transition-colors"
              >
                {formData.licenseFrontImage ? (
                  <CheckCircle className="text-green-600" size={24} />
                ) : (
                  <Upload className="text-purple-500" size={24} />
                )}
                <span className="text-sm text-gray-600 mt-2">
                  {language === 'en' ? 'License Front' : 'লাইসেন্স সামনে'}
                </span>
              </button>
              <input
                ref={licenseFrontRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange('licenseFrontImage', e.target.files?.[0] || null)}
                className="hidden"
              />
            </div>
            
            <div>
              <button
                type="button"
                onClick={() => capturePhoto(licenseBackRef)}
                className="w-full h-32 border-2 border-dashed border-purple-300 rounded-lg flex flex-col items-center justify-center hover:border-purple-400 transition-colors"
              >
                {formData.licenseBackImage ? (
                  <CheckCircle className="text-green-600" size={24} />
                ) : (
                  <Upload className="text-purple-500" size={24} />
                )}
                <span className="text-sm text-gray-600 mt-2">
                  {language === 'en' ? 'License Back' : 'লাইসেন্স পেছনে'}
                </span>
              </button>
              <input
                ref={licenseBackRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange('licenseBackImage', e.target.files?.[0] || null)}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Passport Section */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-green-800 mb-4 flex items-center">
          <Shield className="mr-2" size={20} />
          {language === 'en' ? 'Click to upload Passport Information Page' : 'পাসপোর্ট তথ্য পৃষ্ঠা আপলোড করতে ক্লিক করুন'}
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {language === 'en' ? 'Passport Number' : 'পাসপোর্ট নম্বর'}
            </label>
            <input
              type="text"
              value={formData.passportNumber}
              onChange={(e) => setFormData(prev => ({ ...prev, passportNumber: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="A1234567"
            />
          </div>
          
          <div>
            <button
              type="button"
              onClick={() => capturePhoto(passportRef)}
              className="w-full h-32 border-2 border-dashed border-green-300 rounded-lg flex flex-col items-center justify-center hover:border-green-400 transition-colors"
            >
              {formData.passportImage ? (
                <CheckCircle className="text-green-600" size={24} />
              ) : (
                <Upload className="text-green-500" size={24} />
              )}
              <span className="text-sm text-gray-600 mt-2">
                {language === 'en' ? 'Passport Photo' : 'পাসপোর্ট ছবি'}
              </span>
            </button>
            <input
              ref={passportRef}
              type="file"
              accept="image/*"
              onChange={(e) => handleFileChange('passportImage', e.target.files?.[0] || null)}
              className="hidden"
            />
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => setStep(1)}
          className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-150 font-medium flex items-center justify-center"
        >
          <ArrowLeft className="mr-2" size={20} /> 
          {language === 'en' ? 'Back' : 'পূর্ববর্তী'}
        </button>
        <button
          onClick={handleNext}
          className="flex-1 bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium flex items-center justify-center"
        >
          {language === 'en' ? 'Continue' : 'পরবর্তী'} <ArrowRight className="ml-2" size={20} />
        </button>
      </div>
    </div>
  );

  // Step 3: Biometric Verification (Selfie)
  const Step3Component = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {language === 'en' ? 'Biometric Verification' : 'বায়োমেট্রিক যাচাইকরণ'}
        </h2>
        <p className="text-gray-600">
          {language === 'en' ? 'Step 3 of 5' : 'ধাপ ৩/৫'}
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          {language === 'en' ? 
            'Take three selfie photos: front face, left side, and right side for identity verification.' :
            'পরিচয় যাচাইকরণের জন্য তিনটি সেলফি ছবি তুলুন: সামনের মুখ, বাম দিক এবং ডান দিক।'
          }
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Front Face */}
        <div>
          <button
            type="button"
            onClick={() => capturePhoto(frontFaceRef)}
            className="w-full h-40 border-2 border-dashed border-blue-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-400 transition-colors"
          >
            {formData.frontFaceImage ? (
              <CheckCircle className="text-green-600" size={32} />
            ) : (
              <Camera className="text-blue-500" size={32} />
            )}
            <span className="text-sm text-gray-600 mt-2 text-center">
              {language === 'en' ? 'Front Face' : 'সামনের মুখ'}
            </span>
          </button>
          <input
            ref={frontFaceRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={(e) => handleFileChange('frontFaceImage', e.target.files?.[0] || null)}
            className="hidden"
          />
          {errors.frontFace && <p className="mt-1 text-sm text-red-600">{errors.frontFace}</p>}
        </div>

        {/* Left Face */}
        <div>
          <button
            type="button"
            onClick={() => capturePhoto(leftFaceRef)}
            className="w-full h-40 border-2 border-dashed border-blue-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-400 transition-colors"
          >
            {formData.leftFaceImage ? (
              <CheckCircle className="text-green-600" size={32} />
            ) : (
              <Camera className="text-blue-500" size={32} />
            )}
            <span className="text-sm text-gray-600 mt-2 text-center">
              {language === 'en' ? 'Left Face' : 'বাম দিকের মুখ'}
            </span>
          </button>
          <input
            ref={leftFaceRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={(e) => handleFileChange('leftFaceImage', e.target.files?.[0] || null)}
            className="hidden"
          />
          {errors.leftFace && <p className="mt-1 text-sm text-red-600">{errors.leftFace}</p>}
        </div>

        {/* Right Face */}
        <div>
          <button
            type="button"
            onClick={() => capturePhoto(rightFaceRef)}
            className="w-full h-40 border-2 border-dashed border-blue-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-400 transition-colors"
          >
            {formData.rightFaceImage ? (
              <CheckCircle className="text-green-600" size={32} />
            ) : (
              <Camera className="text-blue-500" size={32} />
            )}
            <span className="text-sm text-gray-600 mt-2 text-center">
              {language === 'en' ? 'Right Face' : 'ডান দিকের মুখ'}
            </span>
          </button>
          <input
            ref={rightFaceRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={(e) => handleFileChange('rightFaceImage', e.target.files?.[0] || null)}
            className="hidden"
          />
          {errors.rightFace && <p className="mt-1 text-sm text-red-600">{errors.rightFace}</p>}
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => setStep(2)}
          className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-150 font-medium flex items-center justify-center"
        >
          <ArrowLeft className="mr-2" size={20} /> 
          {language === 'en' ? 'Back' : 'পূর্ববর্তী'}
        </button>
        <button
          onClick={handleNext}
          className="flex-1 bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium flex items-center justify-center"
        >
          {language === 'en' ? 'Continue' : 'পরবর্তী'} <ArrowRight className="ml-2" size={20} />
        </button>
      </div>
    </div>
  );

  // Step 4: Mobile Wallet (Citizens Only)
  const Step4Component = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {language === 'en' ? 'Mobile Wallet Setup' : 'মোবাইল ওয়ালেট সেটআপ'}
        </h2>
        <p className="text-gray-600">
          {language === 'en' ? 'Step 4 of 5' : 'ধাপ ৪/৫'}
        </p>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <CreditCard className="text-green-600 mt-1" size={20} />
          <div>
            <h3 className="font-medium text-green-800 mb-1">
              {language === 'en' ? 'Why add a mobile wallet?' : 'মোবাইল ওয়ালেট কেন যুক্ত করবেন?'}
            </h3>
            <p className="text-sm text-green-700">
              {language === 'en' ? 
                'When your violation reports are verified and fines are collected, you\'ll automatically receive commission payments directly to your mobile wallet.' :
                'আপনার রিপোর্টকৃত ট্রাফিক আইন লঙ্ঘন যখন ভেরিফাই হবে এবং জরিমানা আদায় হবে, তখন আপনি স্বয়ংক্রিয়ভাবে কমিশন পেমেন্ট আপনার মোবাইল ওয়ালেটে পেয়ে যাবেন।'
              }
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Select Wallet Provider *' : 'ওয়ালেট প্রোভাইডার নির্বাচন করুন *'}
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'bKash', label: '📱 bKash', color: 'border-pink-500' },
              { value: 'Nagad', label: '🔥 Nagad', color: 'border-orange-500' },
              { value: 'Rocket', label: '🚀 Rocket', color: 'border-blue-500' },
              { value: 'Upay', label: '💳 Upay', color: 'border-purple-500' }
            ].map((wallet) => (
              <label key={wallet.value} className="cursor-pointer">
                <input
                  type="radio"
                  name="walletProvider"
                  value={wallet.value}
                  checked={formData.walletProvider === wallet.value}
                  onChange={(e) => setFormData(prev => ({ ...prev, walletProvider: e.target.value }))}
                  className="sr-only"
                />
                <div className={`p-3 border-2 rounded-lg text-center transition-all ${
                  formData.walletProvider === wallet.value 
                    ? `${wallet.color} bg-opacity-10` 
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <span className="font-medium">{wallet.label}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Mobile Number *' : 'মোবাইল নম্বর *'}
          </label>
          <input
            type="tel"
            value={formData.walletNumber}
            onChange={(e) => setFormData(prev => ({ ...prev, walletNumber: e.target.value }))}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
              errors.walletNumber ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="+880 1234 567890"
          />
          {errors.walletNumber && <p className="mt-1 text-sm text-red-600">{errors.walletNumber}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {language === 'en' ? 'Account Holder Name *' : 'অ্যাকাউন্ট হোল্ডারের নাম *'}
          </label>
          <input
            type="text"
            value={formData.walletAccountHolder}
            onChange={(e) => setFormData(prev => ({ ...prev, walletAccountHolder: e.target.value }))}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent ${
              errors.walletAccountHolder ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder={language === 'en' ? 'Account holder full name' : 'অ্যাকাউন্ট হোল্ডারের পুরো নাম'}
          />
          {errors.walletAccountHolder && <p className="mt-1 text-sm text-red-600">{errors.walletAccountHolder}</p>}
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => setStep(3)}
          className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-150 font-medium flex items-center justify-center"
        >
          <ArrowLeft className="mr-2" size={20} /> 
          {language === 'en' ? 'Back' : 'পূর্ববর্তী'}
        </button>
        <button
          onClick={handleNext}
          disabled={isLoading}
          className="flex-1 bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 transition duration-150 font-medium flex items-center justify-center disabled:opacity-50"
        >
          {isLoading ? <Loader2 className="animate-spin mr-2" size={20} /> : null}
          {isLoading ? 
            (language === 'en' ? 'Sending OTP...' : 'OTP পাঠানো হচ্ছে...') : 
            (language === 'en' ? 'Send OTP' : 'OTP পাঠান')
          }
        </button>
      </div>
    </div>
  );

  // Step 5: OTP Verification
  const Step5Component = () => (
    <div className="space-y-6">
      <div className="text-center">
        <CheckCircle className="mx-auto text-green-600 mb-4" size={48} />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {language === 'en' ? 'Verify Your Account' : 'আপনার অ্যাকাউন্ট যাচাই করুন'}
        </h2>
        <p className="text-gray-600">
          {language === 'en' ? 'Step 5 of 5' : 'ধাপ ৫/৫'}
        </p>
        <p className="text-sm text-gray-600 mt-2">
          {language === 'en' ? 
            `Enter the 6-digit OTP sent to ${formData.mobileNumber}` :
            `${formData.mobileNumber} এ পাঠানো ৬ সংখ্যার OTP লিখুন`
          }
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2 text-center">
            {language === 'en' ? 'Enter OTP' : 'OTP লিখুন'}
          </label>
          <input
            type="text"
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent text-center text-2xl tracking-widest"
            placeholder="000000"
            maxLength={6}
          />
          {otpTimer > 0 && (
            <p className="text-xs text-gray-500 text-center mt-2">
              {language === 'en' ? 
                `OTP expires in ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')}` :
                `OTP ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')} মিনিটে শেষ হবে`
              }
            </p>
          )}
        </div>

        {otpTimer === 0 && (
          <button
            onClick={handleSendOTP}
            className="w-full text-sky-600 hover:text-sky-700 text-sm font-medium"
          >
            {language === 'en' ? 'Resend OTP' : 'পুনরায় OTP পাঠান'}
          </button>
        )}
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => setStep(formData.role === 'citizen' ? 4 : 3)}
          className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-150 font-medium flex items-center justify-center"
        >
          <ArrowLeft className="mr-2" size={20} /> 
          {language === 'en' ? 'Back' : 'পূর্ববর্তী'}
        </button>
        <button
          onClick={handleVerifyOTP}
          disabled={isLoading || otp.length !== 6}
          className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition duration-150 font-medium flex items-center justify-center disabled:opacity-50"
        >
          {isLoading ? <Loader2 className="animate-spin mr-2" size={20} /> : null}
          {isLoading ? 
            (language === 'en' ? 'Verifying...' : 'যাচাই করা হচ্ছে...') : 
            (language === 'en' ? 'Create Account' : 'অ্যাকাউন্ট তৈরি করুন')
          }
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-sky-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-8">
        {/* Language Toggle */}
        <div className="flex justify-end mb-4">
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
          >
            <Globe size={16} />
            <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
              {language === 'en' ? 'বাংলা' : 'English'}
            </span>
          </button>
        </div>
        
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <img 
            src="https://mocha-cdn.com/019a7364-a032-7e48-8ef2-a113c18111ab/third-eye-logo.png" 
            alt="Third Eye Logo" 
            className="w-20 h-20 mx-auto rounded-full drop-shadow-lg border-2 border-sky-200"
          />
          <h1 className="text-2xl font-bold text-gray-800 mt-3" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Third Eye' : 'তৃতীয় চোখ'}
          </h1>
          <p className="text-sm text-gray-600 mt-1" style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
            {language === 'en' ? 'Report Violations • Earn Rewards • Save Lives' : 'অনিয়ম রিপোর্ট করুন • পুরস্কার অর্জন করুন • জীবন বাঁচান'}
          </p>

          {/* Step Indicator */}
          <div className="flex justify-center mt-4 space-x-2">
            {[1, 2, 3, 4, 5].map((stepNum) => (
              <div
                key={stepNum}
                className={`w-8 h-1 rounded-full transition-all duration-300 ${
                  stepNum <= step ? 'bg-sky-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step Content */}
        {step === 1 && <Step1Component />}
        {step === 2 && <Step2Component />}
        {step === 3 && <Step3Component />}
        {step === 4 && formData.role === 'citizen' && <Step4Component />}
        {step === 5 && <Step5Component />}

        {/* Footer */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">
              {language === 'en' ? 'Already have an account?' : 'ইতিমধ্যে একটি অ্যাকাউন্ট আছে?'}
            </p>
            <Link 
              to="/login" 
              className="text-sky-600 hover:text-sky-700 font-medium hover:underline"
            >
              {language === 'en' ? 'Login' : 'লগইন'}
            </Link>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link 
            to="/" 
            className="text-sm text-gray-600 hover:text-gray-800 hover:underline"
          >
            ← {language === 'en' ? 'Back to Home' : 'হোমে ফিরে যান'}
          </Link>
        </div>
      </div>
    </div>
  );
}
