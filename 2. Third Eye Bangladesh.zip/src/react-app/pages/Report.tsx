import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  Camera, 
  MapPin, 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle,
  Car,
  Gavel,
  Clock,
  FileText,
  Globe
} from 'lucide-react';

interface ReportFormData {
  violationType: 'traffic' | 'social';
  vehicleNumber: string;
  location: string;
  description: string;
  evidence: File[];
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export default function ReportPage() {
  const { t, language, toggleLanguage } = useLanguage();
  const { user, canReport } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<ReportFormData>({
    violationType: 'traffic',
    vehicleNumber: '',
    location: '',
    description: '',
    evidence: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);

  // Redirect if user can't report
  React.useEffect(() => {
    if (!user || !canReport()) {
      navigate('/dashboard');
    }
  }, [user, canReport, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const getCurrentLocation = () => {
    setLocationLoading(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setFormData(prev => ({
            ...prev,
            location: `Lat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}`,
            coordinates: { lat: latitude, lng: longitude }
          }));
          setLocationLoading(false);
        },
        (error) => {
          console.error('Geolocation error:', error);
          alert('GPS location is required for report submission. Please enable location access and try again.');
          setLocationLoading(false);
        }
      );
    } else {
      alert('GPS location is required but not supported by your device.');
      setLocationLoading(false);
    }
  };

  // Auto-get location on component mount
  React.useEffect(() => {
    getCurrentLocation();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');
      const isValidSize = file.size <= 50 * 1024 * 1024; // 50MB limit
      return (isImage || isVideo) && isValidSize;
    });

    setFormData(prev => ({
      ...prev,
      evidence: [...prev.evidence, ...validFiles].slice(0, 3) // Max 3 files
    }));
  };

  const removeFile = (index: number) => {
    setFormData(prev => ({
      ...prev,
      evidence: prev.evidence.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    if (!formData.violationType) return 'Please select violation type';
    if (!formData.location.trim()) return 'Location is required';
    if (formData.evidence.length === 0) return 'Evidence (photo/video) is mandatory for all reports';
    if (!formData.coordinates) return 'GPS location is required - please enable location access';
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      alert(validationError);
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate case number with date, time and sequence
      const now = new Date();
      const dateStr = now.getFullYear().toString().slice(-2) + 
                      (now.getMonth() + 1).toString().padStart(2, '0') + 
                      now.getDate().toString().padStart(2, '0');
      const timeStr = now.getHours().toString().padStart(2, '0') + 
                      now.getMinutes().toString().padStart(2, '0') + 
                      now.getSeconds().toString().padStart(2, '0');
      const sequenceNumber = Math.floor(Math.random() * 999) + 1;
      const caseNumber = `TE-${dateStr}-${timeStr}-${sequenceNumber.toString().padStart(3, '0')}`;
      
      // Simulate successful submission with commission info
      alert(`Report submitted successfully!\n\nCase Number: ${caseNumber}\nGPS Location: ${formData.coordinates?.lat.toFixed(6)}, ${formData.coordinates?.lng.toFixed(6)}\n\n📱 You will receive SMS/app notifications about case progress\n💰 If violation is verified, 20% commission will be sent to your ${user?.walletInfo?.provider || 'mobile banking'} account\n📧 E-challan will be sent to the violator upon verification`);
      navigate('/dashboard');
    } catch (err) {
      console.error('Report submission error:', err);
      alert('Failed to submit report. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user || !canReport()) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <AlertTriangle className="mx-auto text-yellow-600 mb-4" size={48} />
          <h2 className="text-xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Complete KYC verification to report violations</p>
          <Link 
            to="/dashboard" 
            className="inline-block bg-sky-600 text-white px-6 py-2 rounded-lg hover:bg-sky-700"
          >
            Go to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100"
              >
                <ArrowLeft size={20} />
              </button>
              <h1 className="text-xl font-bold text-gray-800">{t('reportViolation')}</h1>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-sky-50 text-sky-600 rounded-full text-sm font-medium hover:bg-sky-100 transition duration-150"
            >
              <Globe size={16} />
              <span style={{ fontFamily: language === 'bn' ? 'SutonnyMJ, sans-serif' : 'Inter, sans-serif' }}>
                {language === 'en' ? 'বাংলা' : 'English'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Violation Type Selection */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('violationType')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="cursor-pointer">
                <input
                  type="radio"
                  name="violationType"
                  value="traffic"
                  checked={formData.violationType === 'traffic'}
                  onChange={handleInputChange}
                  className="sr-only"
                />
                <div className={`p-4 rounded-lg border-2 transition-all ${
                  formData.violationType === 'traffic'
                    ? 'border-blue-500 bg-blue-50 text-blue-800'
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <div className="flex items-center space-x-3">
                    <Car className="text-blue-600" size={24} />
                    <div>
                      <h3 className="font-medium">{t('trafficViolation')}</h3>
                      <p className="text-sm text-gray-600">Speeding, illegal parking, etc.</p>
                    </div>
                  </div>
                </div>
              </label>

              <label className="cursor-pointer">
                <input
                  type="radio"
                  name="violationType"
                  value="social"
                  checked={formData.violationType === 'social'}
                  onChange={handleInputChange}
                  className="sr-only"
                />
                <div 
                  className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                    formData.violationType === 'social'
                      ? 'border-red-500 bg-red-50 text-red-800'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => navigate('/report-injustice')}
                >
                  <div className="flex items-center space-x-3">
                    <Gavel className="text-red-600" size={24} />
                    <div>
                      <h3 className="font-medium">{t('socialCrime')}</h3>
                      <p className="text-sm text-gray-600">Harassment, public disturbance</p>
                    </div>
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Vehicle Information */}
          {formData.violationType === 'traffic' && (
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Vehicle Information</h2>
              <div>
                <label htmlFor="vehicleNumber" className="block text-sm font-medium text-gray-700 mb-2">
                  {t('vehicleNumber')} (Optional)
                </label>
                <input
                  type="text"
                  id="vehicleNumber"
                  name="vehicleNumber"
                  value={formData.vehicleNumber}
                  onChange={handleInputChange}
                  placeholder="e.g., Dhaka Metro-Gha-12-3456 (if visible/known)"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-sm text-gray-600 mt-1">Vehicle number is optional. Evidence and location are sufficient for verification.</p>
              </div>
            </div>
          )}

          {/* Location */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('location')}</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                  Location Address *
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="Enter location or use GPS"
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <button
                    type="button"
                    onClick={getCurrentLocation}
                    disabled={locationLoading}
                    className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    {locationLoading ? (
                      <Clock className="animate-spin" size={20} />
                    ) : (
                      <MapPin size={20} />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Evidence Upload */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('uploadEvidence')}</h2>
            
            <div className="space-y-4">
              {/* Instant Capture Buttons */}
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'image/*';
                    input.capture = 'environment';
                    input.onchange = (e) => {
                      const files = Array.from((e.target as HTMLInputElement).files || []);
                      const validFiles = files.filter(file => {
                        const isImage = file.type.startsWith('image/');
                        const isValidSize = file.size <= 50 * 1024 * 1024;
                        return isImage && isValidSize;
                      });
                      setFormData(prev => ({
                        ...prev,
                        evidence: [...prev.evidence, ...validFiles].slice(0, 3)
                      }));
                    };
                    input.click();
                  }}
                  className="flex flex-col items-center p-4 border-2 border-dashed border-blue-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-colors"
                >
                  <Camera className="text-blue-500 mb-2" size={32} />
                  <span className="text-sm font-medium text-gray-800">Take Photo Now</span>
                  <span className="text-xs text-gray-600">Instant capture</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'video/*';
                    input.capture = 'environment';
                    input.onchange = (e) => {
                      const files = Array.from((e.target as HTMLInputElement).files || []);
                      const validFiles = files.filter(file => {
                        const isVideo = file.type.startsWith('video/');
                        const isValidSize = file.size <= 50 * 1024 * 1024;
                        return isVideo && isValidSize;
                      });
                      setFormData(prev => ({
                        ...prev,
                        evidence: [...prev.evidence, ...validFiles].slice(0, 3)
                      }));
                    };
                    input.click();
                  }}
                  className="flex flex-col items-center p-4 border-2 border-dashed border-blue-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-colors"
                >
                  <FileText className="text-blue-500 mb-2" size={32} />
                  <span className="text-sm font-medium text-gray-800">Record Video Now</span>
                  <span className="text-xs text-gray-600">Instant recording</span>
                </button>
              </div>

              {/* Upload Later Option */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-red-300 rounded-lg p-6 text-center hover:border-red-400 hover:bg-red-50 transition-colors cursor-pointer"
              >
                <Camera className="mx-auto text-red-500 mb-2" size={32} />
                <p className="text-gray-800 mb-1 font-medium">📸 Or Upload Later</p>
                <p className="text-sm text-gray-600">Choose existing photos/videos from device</p>
                <p className="text-xs text-gray-500 mt-1">Up to 50MB per file (max 3 files)</p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Uploaded Files */}
              {formData.evidence.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-medium text-gray-800">Uploaded Evidence:</h3>
                  {formData.evidence.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded">
                      <div className="flex items-center space-x-3">
                        <FileText className="text-gray-500" size={20} />
                        <span className="text-sm text-gray-700 truncate">{file.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('description')}</h2>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Describe the violation details, exact location, time, or any additional information that can help DMP/BRTA officers during verification and case resolution..."
              rows={6}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
            <p className="text-sm text-gray-600 mt-2">
              💡 <strong>Tip:</strong> Include specific details like violation type, time of incident, landmark references, 
              or any other information that can help officials verify and process your report faster.
            </p>
          </div>

          {/* Warning and Reward Info */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="text-sm space-y-2">
              <div className="flex items-start">
                <CheckCircle className="text-green-600 mr-2 mt-0.5" size={16} />
                <p className="text-green-800">
                  <strong>Commission System:</strong> Earn 20% commission on verified fines paid by violators
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-green-600 mr-2 mt-0.5" size={16} />
                <p className="text-green-800">
                  <strong>Auto Payment:</strong> Commission will be sent directly to your verified mobile banking account
                </p>
              </div>
              <div className="flex items-start">
                <AlertTriangle className="text-yellow-600 mr-2 mt-0.5" size={16} />
                <p className="text-yellow-800">
                  <strong>Warning:</strong> False reports result in penalties and account suspension
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-150 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isSubmitting ? (
              <>
                <Clock className="animate-spin mr-2" size={20} />
                Submitting Report...
              </>
            ) : (
              <>
                <CheckCircle className="mr-2" size={20} />
                {t('submitReport')}
              </>
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
