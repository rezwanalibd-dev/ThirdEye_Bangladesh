import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { 
  ArrowLeft,
  Phone,
  PhoneCall,
  Shield,
  Flame,
  Heart,
  AlertTriangle,
  Building2,
  Zap,
  Droplets,
  Car,
  Users,
  Globe,
  Search,
  Clock
} from 'lucide-react';

interface EmergencyContact {
  id: string;
  name: string;
  nameEn: string;
  nameBn: string;
  description: string;
  descriptionEn: string;
  descriptionBn: string;
  number: string;
  category: 'emergency' | 'police' | 'medical' | 'fire' | 'utility' | 'support' | 'banking' | 'transport' | 'telecom' | 'land';
  icon: React.ComponentType<{ size?: number; className?: string }>;
  priority: 'urgent' | 'high' | 'medium' | 'low';
  available24x7: boolean;
}

export default function EmergencyPage() {
  const { language, toggleLanguage } = useLanguage();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const emergencyContacts: EmergencyContact[] = [
    // Emergency Services
    {
      id: '999',
      name: 'National Emergency Service',
      nameEn: 'National Emergency Service',
      nameBn: 'জাতীয় জরুরি সেবা',
      description: 'Police, Fire Service, Ambulance (24/7)',
      descriptionEn: 'Police, Fire Service, Ambulance (24/7)',
      descriptionBn: 'পুলিশ, ফায়ার সার্ভিস, অ্যাম্বুলেন্স (২৪/৭)',
      number: '999',
      category: 'emergency',
      icon: AlertTriangle,
      priority: 'urgent',
      available24x7: true
    },
    {
      id: '16163',
      name: 'Fire & Rescue Service',
      nameEn: 'Fire & Rescue Service',
      nameBn: 'ফায়ার ও রেসকিউ সার্ভিস',
      description: 'Fire incidents, rescue operations',
      descriptionEn: 'Fire incidents, rescue operations',
      descriptionBn: 'অগ্নিকাণ্ড, উদ্ধার অভিযান',
      number: '16163',
      category: 'fire',
      icon: Flame,
      priority: 'urgent',
      available24x7: true
    },
    {
      id: '199',
      name: 'Medical Emergency Service',
      nameEn: 'Medical Emergency Service',
      nameBn: 'চিকিৎসা জরুরি সেবা',
      description: 'Ambulance & medical emergency assistance',
      descriptionEn: 'Ambulance & medical emergency assistance',
      descriptionBn: 'অ্যাম্বুলেন্স ও চিকিৎসা জরুরি সহায়তা',
      number: '199',
      category: 'medical',
      icon: Heart,
      priority: 'urgent',
      available24x7: true
    },

    // Police Services
    {
      id: '01777720050',
      name: 'RAB (Rapid Action Battalion)',
      nameEn: 'RAB (Rapid Action Battalion)',
      nameBn: 'র‍্যাব (দ্রুত অ্যাকশন ব্যাটালিয়ন)',
      description: 'Crime, terrorism, drugs',
      descriptionEn: 'Crime, terrorism, drugs',
      descriptionBn: 'অপরাধ, সন্ত্রাসবাদ, মাদক',
      number: '01777720050',
      category: 'police',
      icon: Shield,
      priority: 'high',
      available24x7: true
    },
    {
      id: '02-9514400',
      name: 'Dhaka Metropolitan Police',
      nameEn: 'Dhaka Metropolitan Police',
      nameBn: 'ঢাকা মহানগর পুলিশ',
      description: 'City security and law enforcement',
      descriptionEn: 'City security and law enforcement',
      descriptionBn: 'শহর নিরাপত্তা ও আইন প্রয়োগ',
      number: '02-9514400',
      category: 'police',
      icon: Shield,
      priority: 'high',
      available24x7: true
    },

    // Medical Services
    {
      id: '02-55165088',
      name: 'Dhaka Medical College Hospital',
      nameEn: 'Dhaka Medical College Hospital',
      nameBn: 'ঢাকা মেডিকেল কলেজ হাসপাতাল',
      description: 'Emergency medical services',
      descriptionEn: 'Emergency medical services',
      descriptionBn: 'জরুরি চিকিৎসা সেবা',
      number: '02-55165088',
      category: 'medical',
      icon: Heart,
      priority: 'high',
      available24x7: true
    },
    {
      id: '10678',
      name: 'Apollo Hospital',
      nameEn: 'Apollo Hospital',
      nameBn: 'অ্যাপোলো হাসপাতাল',
      description: 'Private hospital emergency services',
      descriptionEn: 'Private hospital emergency services',
      descriptionBn: 'বেসরকারি হাসপাতাল জরুরি সেবা',
      number: '10678',
      category: 'medical',
      icon: Heart,
      priority: 'high',
      available24x7: true
    },

    // Support Services
    {
      id: '333',
      name: 'National Information Service',
      nameEn: 'National Information Service',
      nameBn: 'জাতীয় তথ্য সেবা',
      description: 'Government information, social assistance',
      descriptionEn: 'Government information, social assistance',
      descriptionBn: 'সরকারি তথ্য, সামাজিক সহায়তা',
      number: '333',
      category: 'support',
      icon: Building2,
      priority: 'medium',
      available24x7: true
    },
    {
      id: '109',
      name: 'Women & Child Abuse Prevention Helpline',
      nameEn: 'Women & Child Abuse Prevention Helpline',
      nameBn: 'নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন',
      description: 'Legal aid, shelter, counseling',
      descriptionEn: 'Legal aid, shelter, counseling',
      descriptionBn: 'আইনি সহায়তা, আশ্রয়, পরামর্শ',
      number: '109',
      category: 'support',
      icon: Users,
      priority: 'high',
      available24x7: true
    },

    // Utility Services
    {
      id: '16120',
      name: 'DESCO (Dhaka Electric)',
      nameEn: 'DESCO (Dhaka Electric)',
      nameBn: 'ডেসকো (ঢাকা ইলেকট্রিক)',
      description: 'Electricity issues - Mirpur, Gulshan, Uttara',
      descriptionEn: 'Electricity issues - Mirpur, Gulshan, Uttara',
      descriptionBn: 'বিদ্যুৎ সমস্যা - মিরপুর, গুলশান, উত্তরা',
      number: '16120',
      category: 'utility',
      icon: Zap,
      priority: 'medium',
      available24x7: true
    },
    {
      id: '16162',
      name: 'WASA (Dhaka Water & Sewerage)',
      nameEn: 'WASA (Dhaka Water & Sewerage)',
      nameBn: 'ওয়াসা (ঢাকা পানি ও পয়ঃনিষ্কাশন)',
      description: 'Water & sewerage services',
      descriptionEn: 'Water & sewerage services',
      descriptionBn: 'পানি ও পয়ঃনিষ্কাশন সেবা',
      number: '16162',
      category: 'utility',
      icon: Droplets,
      priority: 'medium',
      available24x7: true
    },

    // Banking Services
    {
      id: '16247',
      name: 'bKash',
      nameEn: 'bKash',
      nameBn: 'বিকাশ',
      description: 'Mobile wallet customer service',
      descriptionEn: 'Mobile wallet customer service',
      descriptionBn: 'মোবাইল ওয়ালেট গ্রাহক সেবা',
      number: '16247',
      category: 'banking',
      icon: Phone,
      priority: 'medium',
      available24x7: true
    },
    {
      id: '16167',
      name: 'Nagad',
      nameEn: 'Nagad',
      nameBn: 'নগদ',
      description: 'Mobile wallet customer service',
      descriptionEn: 'Mobile wallet customer service',
      descriptionBn: 'মোবাইল ওয়ালেট গ্রাহক সেবা',
      number: '16167',
      category: 'banking',
      icon: Phone,
      priority: 'medium',
      available24x7: true
    },

    // Transport Services
    {
      id: '16107',
      name: 'Road Transport Authority (BRTA)',
      nameEn: 'Road Transport Authority (BRTA)',
      nameBn: 'সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ)',
      description: 'Vehicle or traffic-related complaints',
      descriptionEn: 'Vehicle or traffic-related complaints',
      descriptionBn: 'যানবাহন বা ট্রাফিক সংক্রান্ত অভিযোগ',
      number: '16107',
      category: 'transport',
      icon: Car,
      priority: 'medium',
      available24x7: false
    },
    {
      id: '02-8901904',
      name: 'Hazrat Shahjalal International Airport',
      nameEn: 'Hazrat Shahjalal International Airport',
      nameBn: 'হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দর',
      description: 'Flight information and services',
      descriptionEn: 'Flight information and services',
      descriptionBn: 'ফ্লাইট তথ্য ও সেবা',
      number: '02-8901904',
      category: 'transport',
      icon: Car,
      priority: 'medium',
      available24x7: true
    }
  ];

  const categories = [
    { value: 'all', label: language === 'en' ? 'All Services' : 'সব সেবা', count: emergencyContacts.length },
    { value: 'emergency', label: language === 'en' ? 'Emergency' : 'জরুরি', count: emergencyContacts.filter(c => c.category === 'emergency').length },
    { value: 'police', label: language === 'en' ? 'Police' : 'পুলিশ', count: emergencyContacts.filter(c => c.category === 'police').length },
    { value: 'medical', label: language === 'en' ? 'Medical' : 'চিকিৎসা', count: emergencyContacts.filter(c => c.category === 'medical').length },
    { value: 'fire', label: language === 'en' ? 'Fire Service' : 'ফায়ার সার্ভিস', count: emergencyContacts.filter(c => c.category === 'fire').length },
    { value: 'utility', label: language === 'en' ? 'Utility' : 'জনসেবা', count: emergencyContacts.filter(c => c.category === 'utility').length },
    { value: 'support', label: language === 'en' ? 'Support' : 'সহায়তা', count: emergencyContacts.filter(c => c.category === 'support').length },
    { value: 'banking', label: language === 'en' ? 'Banking' : 'ব্যাংকিং', count: emergencyContacts.filter(c => c.category === 'banking').length },
    { value: 'transport', label: language === 'en' ? 'Transport' : 'পরিবহন', count: emergencyContacts.filter(c => c.category === 'transport').length }
  ];

  const filteredContacts = emergencyContacts.filter(contact => {
    const matchesCategory = selectedCategory === 'all' || contact.category === selectedCategory;
    const matchesSearch = searchTerm === '' || 
      (language === 'en' ? contact.nameEn : contact.nameBn).toLowerCase().includes(searchTerm.toLowerCase()) ||
      (language === 'en' ? contact.descriptionEn : contact.descriptionBn).toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.number.includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  const handleCall = (number: string, name: string) => {
    // Clean the number for calling
    const cleanNumber = number.replace(/[^0-9+]/g, '');
    
    // Confirm before calling
    const confirmation = window.confirm(
      language === 'en' 
        ? `Call ${name} at ${number}?`
        : `${name} এ ${number} নম্বরে কল করবেন?`
    );
    
    if (confirmation) {
      window.location.href = `tel:${cleanNumber}`;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'border-red-500 bg-red-50';
      case 'high': return 'border-orange-500 bg-orange-50';
      case 'medium': return 'border-blue-500 bg-blue-50';
      default: return 'border-gray-500 bg-gray-50';
    }
  };

  const getPriorityTextColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-700';
      case 'high': return 'text-orange-700';
      case 'medium': return 'text-blue-700';
      default: return 'text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-red-600 to-red-700 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => navigate(-1)}
                className="p-2 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition duration-150"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  {language === 'en' ? '🚨 Emergency Services' : '🚨 জরুরি পরিষেবা'}
                </h1>
                <p className="text-red-100 text-sm">
                  {language === 'en' ? 
                    'Complete Bangladesh emergency & government contact directory (2025)' :
                    'সম্পূর্ণ বাংলাদেশ জরুরি ও সরকারি যোগাযোগ ডিরেক্টরি (২০২৫)'
                  }
                </p>
              </div>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 p-2 bg-white bg-opacity-20 text-white rounded-full text-sm font-medium hover:bg-opacity-30 transition duration-150"
            >
              <Globe size={16} />
              <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Emergency Call 999 Banner */}
      <div className="bg-red-600 text-white py-4">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center">
            <h2 className="text-xl font-bold mb-2">
              {language === 'en' ? 'EMERGENCY: CALL 999' : 'জরুরি অবস্থায়: ৯৯৯ ডায়াল করুন'}
            </h2>
            <p className="text-red-100 mb-4">
              {language === 'en' ? 
                'For immediate police, fire, or medical emergency' :
                'তাৎক্ষণিক পুলিশ, ফায়ার বা চিকিৎসা জরুরি অবস্থার জন্য'
              }
            </p>
            <button 
              onClick={() => handleCall('999', 'Emergency Service')}
              className="bg-white text-red-600 px-8 py-3 rounded-lg font-bold hover:bg-red-50 transition duration-150 flex items-center mx-auto"
            >
              <PhoneCall className="mr-2" size={20} />
              {language === 'en' ? '📞 CALL 999 NOW' : '📞 এখনই ৯৯৯ ডায়াল করুন'}
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          {/* Search */}
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder={language === 'en' ? 
                    'Search services, numbers, or keywords...' :
                    'সেবা, নম্বর বা কীওয়ার্ড অনুসন্ধান করুন...'
                  }
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition duration-150 ${
                  selectedCategory === category.value
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.label} ({category.count})
              </button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4 text-gray-600 text-sm">
          {language === 'en' ? 
            `Showing ${filteredContacts.length} of ${emergencyContacts.length} services` :
            `${emergencyContacts.length} টির মধ্যে ${filteredContacts.length} টি সেবা প্রদর্শিত`
          }
        </div>

        {/* Emergency Contacts List */}
        <div className="space-y-4">
          {filteredContacts.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <AlertTriangle className="mx-auto text-gray-400 mb-4" size={48} />
              <h3 className="text-lg font-medium text-gray-800 mb-2">
                {language === 'en' ? 'No services found' : 'কোনো সেবা পাওয়া যায়নি'}
              </h3>
              <p className="text-gray-600">
                {language === 'en' ? 
                  'Try adjusting your search terms or category filter.' :
                  'আপনার অনুসন্ধান বা ক্যাটেগরি ফিল্টার পরিবর্তন করে দেখুন।'
                }
              </p>
            </div>
          ) : (
            filteredContacts
              .sort((a, b) => {
                // Sort by priority first, then alphabetically
                const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
                if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
                  return priorityOrder[a.priority] - priorityOrder[b.priority];
                }
                return (language === 'en' ? a.nameEn : a.nameBn).localeCompare(
                  language === 'en' ? b.nameEn : b.nameBn
                );
              })
              .map((contact) => {
                const IconComponent = contact.icon;
                return (
                  <div 
                    key={contact.id}
                    className={`bg-white rounded-lg shadow border-l-4 p-6 hover:shadow-md transition-shadow ${getPriorityColor(contact.priority)}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-start space-x-4 flex-1">
                        <div className={`p-3 rounded-full ${getPriorityTextColor(contact.priority)} bg-white`}>
                          <IconComponent size={24} />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className={`text-lg font-semibold ${getPriorityTextColor(contact.priority)}`}>
                                {language === 'en' ? contact.nameEn : contact.nameBn}
                              </h3>
                              <p className="text-gray-600 text-sm">
                                {language === 'en' ? contact.descriptionEn : contact.descriptionBn}
                              </p>
                            </div>
                            
                            <div className="text-right ml-4">
                              <div className={`text-2xl font-bold ${getPriorityTextColor(contact.priority)}`}>
                                {contact.number}
                              </div>
                              {contact.available24x7 && (
                                <div className="flex items-center text-xs text-green-600 mt-1">
                                  <Clock size={12} className="mr-1" />
                                  {language === 'en' ? '24/7 Available' : '২৪/৭ সেবা'}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                contact.priority === 'urgent' ? 'bg-red-100 text-red-800' :
                                contact.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                contact.priority === 'medium' ? 'bg-blue-100 text-blue-800' :
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {language === 'en' ? 
                                  contact.priority.charAt(0).toUpperCase() + contact.priority.slice(1) :
                                  contact.priority === 'urgent' ? 'জরুরি' :
                                  contact.priority === 'high' ? 'গুরুত্বপূর্ণ' :
                                  contact.priority === 'medium' ? 'মাধ্যম' : 'কম'
                                }
                              </span>
                            </div>
                            
                            <button
                              onClick={() => handleCall(contact.number, language === 'en' ? contact.nameEn : contact.nameBn)}
                              className={`flex items-center px-4 py-2 rounded-lg font-medium transition duration-150 ${
                                contact.priority === 'urgent' ? 'bg-red-600 hover:bg-red-700 text-white' :
                                contact.priority === 'high' ? 'bg-orange-600 hover:bg-orange-700 text-white' :
                                'bg-blue-600 hover:bg-blue-700 text-white'
                              }`}
                            >
                              <PhoneCall size={16} className="mr-2" />
                              {language === 'en' ? 'Call Now' : 'কল করুন'}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
          )}
        </div>

        {/* Footer Information */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-800 mb-3">
            {language === 'en' ? '24/7 Emergency Services Available' : '২৪/৭ জরুরি সেবা উপলব্ধ'}
          </h3>
          <p className="text-blue-700 text-sm mb-4">
            {language === 'en' ? 
              'All emergency services are available around the clock for your safety' :
              'আপনার নিরাপত্তার জন্য সব জরুরি সেবা দিন-রাত উপলব্ধ'
            }
          </p>
          <div className="text-xs text-blue-600 space-y-1">
            <p>📅 {language === 'en' ? 'Last Updated: November 2025' : 'সর্বশেষ আপডেট: নভেম্বর ২০২৫'}</p>
            <p>🏛️ {language === 'en' ? 'Source: Bangladesh Government Official Directory' : 'সূত্র: বাংলাদেশ সরকারের অফিসিয়াল ডিরেক্টরি'}</p>
            <p>✅ {language === 'en' ? 'Status: All numbers verified & active' : 'অবস্থা: সব নম্বর যাচাইকৃত ও সক্রিয়'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
