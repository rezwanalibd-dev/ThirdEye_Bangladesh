import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import LoginPage from "@/react-app/pages/Login";
import SignupPage from "@/react-app/pages/Signup";
import DashboardPage from "@/react-app/pages/Dashboard";
import ReportPage from "@/react-app/pages/Report";
import EmergencyPage from "@/react-app/pages/Emergency";
import TrafficRulesPage from "@/react-app/pages/TrafficRules";
import ProfilePage from "@/react-app/pages/Profile";
import SettingsPage from "@/react-app/pages/Settings";
import ReportInjusticePage from "@/react-app/pages/ReportInjustice";
import CaseStatusPage from "@/react-app/pages/CaseStatus";
import HistoryPage from "@/react-app/pages/History";
import { LanguageProvider } from "@/react-app/context/LanguageContext";
import { AuthProvider } from "@/react-app/context/AuthContext";
import PWAInstallPrompt from "@/react-app/components/PWAInstallPrompt";

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/report" element={<ReportPage />} />
              <Route path="/emergency" element={<EmergencyPage />} />
              <Route path="/traffic-rules" element={<TrafficRulesPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/report-injustice" element={<ReportInjusticePage />} />
              <Route path="/case-status" element={<CaseStatusPage />} />
              <Route path="/history" element={<HistoryPage />} />
            </Routes>
            <PWAInstallPrompt />
          </div>
        </Router>
      </AuthProvider>
    </LanguageProvider>
  );
}
