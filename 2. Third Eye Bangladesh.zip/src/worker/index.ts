import { Hono } from 'hono';
import { cors } from 'hono/cors';

type Bindings = {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_KEY: string;
  MOCHA_USERS_SERVICE_API_URL: string;
};

const app = new Hono<{ Bindings: Bindings }>();

app.use('*', cors());

// Health check endpoint
app.get('/api/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API endpoints for the Third Eye app
app.get('/api/users/:id', async (c) => {
  try {
    const userId = c.req.param('id');
    const user = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(userId).first();
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    return c.json(user);
  } catch (error) {
    console.error('Error fetching user:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.post('/api/reports', async (c) => {
  try {
    const body = await c.req.json();
    const { userId, violationType, vehicleNumber, location, latitude, longitude, description } = body;
    
    // Generate case number
    const caseNumber = `TE-${Date.now().toString().slice(-6)}`;
    
    // Insert report
    const result = await c.env.DB.prepare(`
      INSERT INTO reports (case_number, user_id, violation_type, vehicle_number, location_text, latitude, longitude, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(caseNumber, userId, violationType, vehicleNumber, location, latitude, longitude, description).run();
    
    return c.json({ success: true, caseNumber, reportId: result.meta.last_row_id });
  } catch (error) {
    console.error('Error creating report:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.get('/api/reports/user/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const reports = await c.env.DB.prepare('SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC').bind(userId).all();
    
    return c.json(reports.results);
  } catch (error) {
    console.error('Error fetching user reports:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Enhanced case number generation endpoint
app.post('/api/generate-case-number', async (c) => {
  try {
    const { type } = await c.req.json();
    
    // Generate case number with date, time and sequence
    const now = new Date();
    const dateStr = now.getFullYear().toString().slice(-2) + 
                    (now.getMonth() + 1).toString().padStart(2, '0') + 
                    now.getDate().toString().padStart(2, '0');
    const timeStr = now.getHours().toString().padStart(2, '0') + 
                    now.getMinutes().toString().padStart(2, '0') + 
                    now.getSeconds().toString().padStart(2, '0');
    
    // Get sequence number from database
    const result = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM reports 
      WHERE DATE(created_at) = DATE('now')
    `).first();
    
    const sequenceNumber = (result?.count as number || 0) + 1;
    const prefix = type === 'social' ? 'TI' : 'TE';
    const caseNumber = `${prefix}-${dateStr}-${timeStr}-${sequenceNumber.toString().padStart(3, '0')}`;
    
    return c.json({ caseNumber });
  } catch (error) {
    console.error('Error generating case number:', error);
    return c.json({ error: 'Failed to generate case number' }, 500);
  }
});

// Digital wallet verification endpoint
app.post('/api/verify-wallet', async (c) => {
  try {
    const { userId, walletType, walletNumber } = await c.req.json();
    
    // In real implementation, this would verify OTP with mobile banking provider
    // For demo purposes, we simulate verification
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Update user's wallet information
    await c.env.DB.prepare(`
      UPDATE users SET 
        mobile_banking_type = ?,
        mobile_banking_number = ?,
        is_banking_verified = TRUE,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(walletType, walletNumber, userId).run();
    
    return c.json({ success: true, message: 'Wallet verified successfully' });
  } catch (error) {
    console.error('Wallet verification error:', error);
    return c.json({ error: 'Wallet verification failed' }, 500);
  }
});

// Commission payment processing endpoint
app.post('/api/process-commission', async (c) => {
  try {
    const { reportId, userId, amount } = await c.req.json();
    
    // Get user's wallet information
    const user = await c.env.DB.prepare(`
      SELECT mobile_banking_type, mobile_banking_number, full_name 
      FROM users WHERE id = ?
    `).bind(userId).first();
    
    if (!user || !user.mobile_banking_number) {
      return c.json({ error: 'User wallet not found or not verified' }, 400);
    }
    
    // Insert commission payment record
    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    
    await c.env.DB.prepare(`
      INSERT INTO commission_payments (
        user_id, report_id, amount, mobile_banking_type, 
        mobile_banking_number, transaction_id, payment_status
      ) VALUES (?, ?, ?, ?, ?, ?, 'processing')
    `).bind(userId, reportId, amount, user.mobile_banking_type, user.mobile_banking_number, transactionId).run();
    
    // In real implementation, this would integrate with mobile banking APIs
    // For demo purposes, we simulate successful payment
    setTimeout(async () => {
      await c.env.DB.prepare(`
        UPDATE commission_payments 
        SET payment_status = 'sent', payment_date = CURRENT_TIMESTAMP 
        WHERE transaction_id = ?
      `).bind(transactionId).run();
      
      await c.env.DB.prepare(`
        UPDATE reports 
        SET commission_paid = TRUE 
        WHERE id = ?
      `).bind(reportId).run();
    }, 5000);
    
    return c.json({ 
      success: true, 
      transactionId, 
      message: 'Commission payment initiated' 
    });
  } catch (error) {
    console.error('Commission processing error:', error);
    return c.json({ error: 'Commission processing failed' }, 500);
  }
});

// User statistics endpoint
app.get('/api/users/:userId/statistics', async (c) => {
  try {
    const userId = c.req.param('userId');
    
    const stats = await c.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_reports,
        COUNT(CASE WHEN status IN ('verified', 'resolved') THEN 1 END) as verified_reports,
        SUM(CASE WHEN commission_paid = TRUE THEN commission_amount ELSE 0 END) as total_earnings,
        SUM(CASE WHEN commission_paid = FALSE AND status = 'verified' THEN commission_amount ELSE 0 END) as pending_earnings
      FROM reports 
      WHERE user_id = ?
    `).bind(userId).first();
    
    return c.json(stats);
  } catch (error) {
    console.error('Error fetching user statistics:', error);
    return c.json({ error: 'Failed to fetch statistics' }, 500);
  }
});

// Catch all for client-side routing
app.get('*', (c) => {
  return c.text('Third Eye Bangladesh API', 200);
});

export default app;
