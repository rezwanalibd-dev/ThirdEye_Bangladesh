# Third Eye Mobile App Setup Guide

## 📱 Android Setup

### Prerequisites
- Android Studio Arctic Fox or later
- Android SDK 24 or higher
- Java 8 or higher

### Setup Steps

1. **Open Android Studio**
   - Import the `android/` folder as an existing Android project
   - Wait for Gradle sync to complete

2. **Configure App URL**
   - Open `android/app/src/main/java/com/thirdeye/app/MainActivity.java`
   - Replace `"https://your-domain.com"` with your actual app URL

3. **Update Package Name (Optional)**
   - Change `com.thirdeye.app` to your preferred package name
   - Update in `build.gradle`, `AndroidManifest.xml`, and Java files

4. **Generate Signed APK**
   - Go to Build > Generate Signed Bundle/APK
   - Create a new keystore or use existing one
   - Follow the wizard to generate release APK

5. **Test Installation**
   - Install APK on device: `adb install app-release.apk`
   - Ensure camera, location, and file access work properly

### Publishing to Google Play Store

1. **Create Developer Account**
   - Register at https://play.google.com/console/
   - Pay $25 one-time registration fee

2. **Prepare App Bundle**
   - Generate signed App Bundle (.aab file)
   - This is preferred over APK for Play Store

3. **Upload and Configure**
   - Create new app in Play Console
   - Upload App Bundle
   - Fill out store listing details
   - Submit for review

## 🍎 iOS Setup

### Prerequisites
- Xcode 14 or later
- macOS Monterey or later
- Apple Developer Account ($99/year)

### Setup Steps

1. **Open Xcode**
   - Open `ios/ThirdEye.xcodeproj`
   - Select your development team in project settings

2. **Configure App URL**
   - Open `ios/ThirdEye/ViewController.swift`
   - Replace `"https://your-domain.com"` with your actual app URL

3. **Update Bundle Identifier**
   - Change bundle identifier to match your Apple Developer account
   - Format: `com.yourcompany.thirdeye`

4. **Configure Permissions**
   - Review `Info.plist` permission descriptions
   - Customize messages to match your app's purpose

5. **Test on Device**
   - Connect iOS device
   - Build and run project
   - Test camera, location, and web functionality

### Publishing to App Store

1. **App Store Connect**
   - Create new app at https://appstoreconnect.apple.com/
   - Configure app information and metadata

2. **Archive and Upload**
   - Product > Archive in Xcode
   - Use Organizer to upload to App Store Connect
   - Submit for review

## 🔧 Configuration Requirements

### SSL Certificate
- Your web app MUST use HTTPS
- Camera and location APIs require secure context
- Consider using Cloudflare for SSL

### PWA Manifest
- Ensure `manifest.json` is properly configured
- Icons should be high-resolution and properly sized
- Service worker should be functional

### API Endpoints
- All API calls should use absolute URLs
- Consider implementing offline functionality
- Handle network errors gracefully

## 📋 Pre-Launch Checklist

### Android
- [ ] App runs on various screen sizes
- [ ] Camera capture works properly
- [ ] Location permission granted and functional
- [ ] File upload/download works
- [ ] Back button behavior is correct
- [ ] App icon and splash screen display correctly

### iOS
- [ ] App runs on iPhone and iPad
- [ ] Camera integration works
- [ ] Location services functional
- [ ] File picker and upload work
- [ ] Navigation is smooth
- [ ] App follows iOS design guidelines

### Both Platforms
- [ ] App loads your web URL correctly
- [ ] All features work offline (if applicable)
- [ ] Performance is acceptable
- [ ] No crashes or critical bugs
- [ ] Privacy policy implemented
- [ ] Terms of service available

## 🚀 Distribution

### Beta Testing
- **Android**: Use Google Play Console Internal Testing
- **iOS**: Use TestFlight for beta distribution

### Production Release
- Follow platform-specific guidelines
- Monitor crash reports and user feedback
- Prepare for regular updates

## 📞 Support

For technical issues:
1. Check device logs and crash reports
2. Test on multiple devices and OS versions
3. Ensure web app is mobile-optimized
4. Consider implementing app-specific error reporting

Remember to update your web app URL in both platforms before building for production!
