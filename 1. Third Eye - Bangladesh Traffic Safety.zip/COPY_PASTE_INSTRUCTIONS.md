# Third Eye Bangladesh - Copy & Paste Publishing Instructions

## 📋 HOW TO DOWNLOAD ALL FILES

### Option 1: Web Interface Download
1. **Right-click** in the file explorer area
2. **Select "Download All Files"** or **"Export Project"**
3. **Choose ZIP format** for easy extraction
4. **Save** to your computer (will be named `third-eye-bangladesh.zip`)

### Option 2: Git Clone (If Available)
```bash
git clone [repository-url]
cd third-eye-bangladesh
```

### Option 3: Manual Copy-Paste Process

#### Step 1: Create Project Folder
```bash
mkdir third-eye-bangladesh
cd third-eye-bangladesh
```

#### Step 2: Copy These Essential Files

**1. Package Configuration**
- Copy `package.json` (locked file - download from interface)
- Copy `package-lock.json` (locked file)
- Copy `tsconfig.json` (locked file)
- Copy `vite.config.ts` (locked file)
- Copy `tailwind.config.js`

**2. Source Code Files**
```
src/
├── react-app/
│   ├── App.tsx
│   ├── main.tsx
│   ├── index.css
│   ├── components/
│   ├── pages/
│   └── hooks/
├── worker/
│   └── index.ts
└── shared/
    └── types.ts
```

**3. Public Assets**
```
public/
├── manifest.json
└── sw.js
```

**4. Root Files**
```
index.html
eslint.config.js
```

## 🌐 WEB BROWSER TESTING

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

### Step 3: Test in Browser
1. **Open**: http://localhost:5173
2. **Test Features**:
   - ✅ Homepage loads correctly
   - ✅ Registration/Login works
   - ✅ Emergency buttons make calls
   - ✅ Report system functions
   - ✅ Language switching works
   - ✅ PWA install prompt appears

### Step 4: Production Build Test
```bash
npm run build
npm run preview
```

## 📱 MOBILE APP PUBLISHING SETUP

### Prerequisites Installation
```bash
# Install Node.js dependencies
npm install

# Install Capacitor CLI globally
npm install -g @capacitor/cli @capacitor/core

# Install Ionic CLI (optional but recommended)
npm install -g @ionic/cli
```

### Initialize Mobile App
```bash
# Initialize Capacitor
npx cap init "Third Eye Bangladesh" "com.thirdeyebangladesh.app"

# Add mobile platforms
npx cap add android
npx cap add ios
```

### Build and Sync
```bash
# Build web app
npm run build

# Sync with mobile platforms
npx cap sync
```

## 🤖 ANDROID PUBLISHING

### Step 1: Install Android Studio
1. **Download**: [Android Studio](https://developer.android.com/studio)
2. **Install**: Follow installation wizard
3. **Setup**: Android SDK and emulator

### Step 2: Configure Android Project
```bash
# Open Android project
npx cap open android
```

### Step 3: Update App Configuration
**File**: `android/app/src/main/AndroidManifest.xml`
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.thirdeyebd.app">
    
    <application
        android:name=".MainApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Third Eye Bangladesh"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:theme="@style/AppTheme.NoActionBarLaunch">
            
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
    
    <!-- Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
</manifest>
```

### Step 4: Build APK
```bash
# Debug build
./gradlew assembleDebug

# Release build (for Play Store)
./gradlew assembleRelease
```

### Step 5: Google Play Store Upload
1. **Create**: [Google Play Console Account](https://play.google.com/console)
2. **Upload**: Built APK/AAB file
3. **Fill**: Store listing details
4. **Submit**: For review

## 🍎 iOS PUBLISHING

### Step 1: Install Xcode (macOS Required)
1. **Download**: Xcode from Mac App Store
2. **Install**: Complete installation
3. **Setup**: iOS Simulator

### Step 2: Configure iOS Project
```bash
# Open iOS project
npx cap open ios
```

### Step 3: Update iOS Configuration
**File**: `ios/ThirdEye/Info.plist`
```xml
<key>CFBundleDisplayName</key>
<string>Third Eye Bangladesh</string>
<key>CFBundleIdentifier</key>
<string>com.thirdeyebd.app</string>
<key>CFBundleVersion</key>
<string>1.0.0</string>
<key>NSCameraUsageDescription</key>
<string>This app needs camera access to capture evidence photos</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>This app needs location access to record incident locations</string>
```

### Step 4: Build iOS App
1. **Open**: Project in Xcode
2. **Select**: iOS device or simulator
3. **Build**: Product → Archive
4. **Export**: For App Store distribution

### Step 5: App Store Upload
1. **Create**: [Apple Developer Account](https://developer.apple.com)
2. **Use**: Xcode or Application Loader
3. **Upload**: Built .ipa file
4. **Submit**: For review

## 🔧 CAPACITOR CONFIGURATION

**File**: `capacitor.config.ts`
```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thirdeyebd.app',
  appName: 'Third Eye Bangladesh',
  webDir: 'dist/client',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Camera: {
      permissions: ['camera', 'photos']
    },
    Geolocation: {
      permissions: ['location']
    },
    Device: {
      permissions: ['device-info']
    }
  }
};

export default config;
```

## 📦 COMPLETE FILE STRUCTURE

```
third-eye-bangladesh/
├── android/                 # Android app files
├── ios/                     # iOS app files
├── src/
│   ├── react-app/          # Frontend React code
│   ├── worker/             # Backend API code
│   └── shared/             # Shared types
├── public/                 # Static assets
├── dist/                   # Built files
├── package.json            # Dependencies
├── capacitor.config.ts     # Mobile app config
├── tailwind.config.js      # Styling config
└── README.md              # Documentation
```

## ✅ PUBLISHING CHECKLIST

### Before Publishing
- [ ] All features tested and working
- [ ] App icons and splash screens created
- [ ] Store descriptions written
- [ ] Screenshots taken for store listings
- [ ] Privacy policy created
- [ ] Terms of service written
- [ ] App signed with release certificate

### Store Requirements
- [ ] App title: "Third Eye Bangladesh"
- [ ] Package ID: com.thirdeyebangladesh.app
- [ ] Version: 1.0.0
- [ ] Minimum Android: API 21 (Android 5.0)
- [ ] Minimum iOS: iOS 13.0
- [ ] Permissions clearly explained
- [ ] Content rating appropriate

## 🚀 QUICK START SUMMARY

```bash
# 1. Setup project
npm install
npx cap init "Third Eye Bangladesh" "com.thirdeyebangladesh.app"

# 2. Add platforms
npx cap add android ios

# 3. Build and sync
npm run build
npx cap sync

# 4. Open in IDEs
npx cap open android  # For Android Studio
npx cap open ios      # For Xcode (macOS only)

# 5. Build for stores
# Android: Use Android Studio → Build → Generate Signed Bundle/APK
# iOS: Use Xcode → Product → Archive → Distribute App
```

Your app is now ready for publishing! 🎉
