# Third Eye - App Store Asset Creation Guide

This guide will help you create all the necessary images and graphics for publishing to Google Play Store and Apple App Store.

---

## 🎨 Design Tools You Can Use (Free)

1. **Canva** (Recommended - Easiest)
   - Website: https://www.canva.com
   - Has templates for app screenshots
   - Drag and drop interface
   - Free version is sufficient

2. **Figma**
   - Website: https://www.figma.com
   - Professional design tool
   - Free for individuals
   - More control

3. **GIMP**
   - Website: https://www.gimp.org
   - Free Photoshop alternative
   - Desktop software

---

## 📱 Required Assets

### 1. App Icon (Most Important!)

#### For Google Play Store
**Size:** 512x512 pixels
**Format:** PNG with transparency
**File name:** `icon-512.png`

**Design Guidelines:**
- Use the blue eye logo from your app
- Background: Blue (#3b82f6)
- Icon: White eye symbol
- Rounded corners (optional, Android adds automatically)
- No text on icon

**How to Create in Canva:**
1. Create custom size: 512x512
2. Add rectangle, fill with #3b82f6
3. Add eye emoji or icon from elements
4. Make it white
5. Center it
6. Export as PNG

#### For Apple App Store
**Sizes Needed:**
- 1024x1024 (App Store listing)
- 180x180 (iPhone app icon)
- 167x167 (iPad Pro)
- 152x152 (iPad, iPad mini)
- 120x120 (iPhone, iPod touch)
- 87x87 (iPhone, iPod touch)
- 80x80 (iPad, iPad mini)
- 76x76 (iPad, iPad mini)
- 58x58 (iPhone, iPod touch)
- 40x40 (iPhone, iPod touch, iPad, iPad mini)
- 29x29 (iPhone, iPod touch, iPad, iPad mini)

**Quick Tip:** Create at 1024x1024 first, then resize using online tools like https://appicon.co

---

### 2. Feature Graphic (Google Play Only)

**Size:** 1024 x 500 pixels
**Format:** PNG or JPEG
**File name:** `feature-graphic.png`

**What to Include:**
- App name: "Third Eye"
- Tagline: "Report Violations • Earn Rewards • Save Lives"
- Logo/icon
- Background: Gradient from blue to purple
- Icons representing: camera, shield, money

**Canva Template Search:** "App Feature Graphic" or "Play Store Banner"

**Content Ideas:**
```
[Left Side]
Third Eye Logo (large)

[Center]
"Bangladesh Traffic Safety"
Report Violations • Earn Rewards

[Right Side]
- 📸 Photo Evidence
- 🛡️ Official Partnership
- 💰 Earn Rewards
```

---

### 3. Screenshots

#### For Google Play Store

**Phone Screenshots:**
- Minimum: 2 screenshots
- Maximum: 8 screenshots
- Size: 1080 x 1920 pixels (portrait) or 1920 x 1080 (landscape)
- Format: PNG or JPEG

**Tablet Screenshots (Optional but Recommended):**
- Size: 1920 x 1200 or 2560 x 1800 pixels
- Same content as phone but different layout

#### For Apple App Store

**iPhone Screenshots:**
- 6.5" Display: 1284 x 2778 pixels (required)
- 5.5" Display: 1242 x 2208 pixels (required)

**iPad Screenshots:**
- 12.9" iPad Pro: 2048 x 2732 pixels (required)

---

### 4. Screenshot Content (What to Capture)

**Screenshot 1: Home/Welcome Screen**
- Shows the welcome page
- Login and signup buttons
- DMP/BRTA portal options
- Language toggle
- Eye logo prominently displayed

**Screenshot 2: Dashboard**
- User stats (reports, rewards, success rate)
- Quick action buttons
- Recent reports list
- Clean, organized layout

**Screenshot 3: Report Submission**
- Camera interface
- Location capture
- Violation type selection
- Vehicle number input
- Shows "Your Reward: ৳XXX" message

**Screenshot 4: Report Success**
- Success confirmation screen
- Case number displayed
- "You're the First Reporter!" message
- Reward information

**Screenshot 5: Search Function**
- Search bar
- Search by case number or vehicle
- Results display
- Status indicators (Pending, Approved, Rejected)

**Screenshot 6: Emergency Contacts**
- Quick dial buttons
- Police: 999
- Ambulance: 199
- Fire Service: 101
- Other emergency services

**Screenshot 7: KYC Verification**
- Document upload interface
- Selfie capture
- Verification status
- Security badges

**Screenshot 8: Rewards/Stats**
- Total earnings
- Approved reports
- Success rate
- Payment method setup

---

## 📸 How to Take Screenshots

### Method 1: From Live App (Best Quality)
1. Deploy your app online
2. Open in browser on phone
3. Take screenshots using phone's screenshot function
4. Transfer to computer via email/USB

### Method 2: Browser Developer Tools
1. Open app in Chrome browser
2. Press F12 to open Developer Tools
3. Click "Toggle Device Toolbar" (phone icon)
4. Select device: iPhone 12 Pro or Pixel 5
5. Use browser's screenshot tool or press PrtScn
6. Crop to exact dimensions needed

### Method 3: Using Emulators
**Android:**
1. Download Android Studio
2. Open AVD Manager
3. Create Pixel 5 emulator
4. Run your app
5. Take screenshots

**iOS:**
1. Use Xcode Simulator (Mac only)
2. Run your app
3. Take screenshots with Cmd+S

---

## 🎨 Screenshot Enhancement (Optional)

Make your screenshots look professional:

### Option 1: Use Screenshot Frames
Websites like https://screenshots.pro add device frames around your screenshots.

### Option 2: Add Annotations in Canva
1. Upload screenshot to Canva
2. Add text overlays explaining features
3. Add arrows or circles highlighting key elements
4. Keep it simple and readable

**Example Annotations:**
- "📸 Capture Evidence" (arrow to camera button)
- "💰 Earn ৳100 Reward" (circle around reward amount)
- "🗺️ Auto Location" (arrow to map pin)

---

## 🚀 Quick Asset Checklist

### Google Play Store
- [ ] App icon 512x512 PNG
- [ ] Feature graphic 1024x500 PNG
- [ ] At least 2 phone screenshots (1080x1920)
- [ ] Optional: 2 tablet screenshots (1920x1200)

### Apple App Store
- [ ] App icon 1024x1024 PNG
- [ ] All required icon sizes (use appicon.co)
- [ ] 2-5 iPhone 6.5" screenshots (1284x2778)
- [ ] 2-5 iPhone 5.5" screenshots (1242x2208)
- [ ] 2-5 iPad Pro screenshots (2048x2732)

---

## 💡 Pro Tips

1. **Keep it Simple:** Don't overcrowd graphics with text
2. **Stay On Brand:** Use your app's blue color (#3b82f6) consistently
3. **Show Real Content:** Use actual app screenshots, not mockups
4. **Highlight Features:** Make key benefits obvious
5. **Test on Devices:** View graphics on actual phones before uploading
6. **High Quality:** Always export at highest quality
7. **Consistent Style:** All screenshots should look like they're from the same app
8. **Add Context:** Small text explaining what user is seeing is helpful

---

## 📏 Exact Dimensions Reference

### Google Play Store
```
App Icon: 512 x 512
Feature Graphic: 1024 x 500
Phone Screenshot (Portrait): 1080 x 1920
Phone Screenshot (Landscape): 1920 x 1080
Tablet Screenshot (Portrait): 1200 x 1920
Tablet Screenshot (Landscape): 1920 x 1200
```

### Apple App Store
```
App Store Icon: 1024 x 1024
iPhone 6.7" (14 Pro Max): 1290 x 2796
iPhone 6.5" (11 Pro Max): 1284 x 2778
iPhone 5.5" (8 Plus): 1242 x 2208
iPad Pro 12.9" (6th gen): 2048 x 2732
iPad Pro 12.9" (2nd gen): 2048 x 2732
```

---

## 🎯 Final Checklist Before Upload

- [ ] All images are correct size
- [ ] All images are PNG or JPEG format
- [ ] No text is cut off or too small to read
- [ ] Colors match your app's branding
- [ ] Screenshots show actual app content
- [ ] No placeholder text or Lorem Ipsum
- [ ] Graphics look good on both light and dark backgrounds
- [ ] File names are descriptive
- [ ] You have backups of all assets
- [ ] Graphics pass the "5-second test" (clear at a glance)

---

## 🆘 Common Mistakes to Avoid

1. ❌ Using low resolution images
2. ❌ Screenshots from different app versions
3. ❌ Text too small to read on phone
4. ❌ Wrong aspect ratios
5. ❌ Copyrighted images or icons
6. ❌ Inconsistent branding
7. ❌ Missing required sizes
8. ❌ Blurry or pixelated graphics
9. ❌ Too much text on images
10. ❌ Screenshots with fake/demo data

---

## 📞 Need Help?

If you're stuck creating assets:
- Hire a designer on Fiverr (search "app store assets")
- Use Canva templates (search "app store screenshots")
- Ask in design communities (r/design_critiques on Reddit)
- Use screenshot generator tools online

Good luck creating your assets! Take your time and make them look professional. 🎨📱
