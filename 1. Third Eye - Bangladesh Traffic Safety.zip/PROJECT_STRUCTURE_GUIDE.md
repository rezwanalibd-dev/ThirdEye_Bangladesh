# Third Eye Bangladesh - Complete Project Structure Guide

## 📁 File Organization & Code Structure

This guide explains every file and folder in your Third Eye Bangladesh app, making it easy to understand and maintain.

---

## 🗂️ Root Directory Structure

```
third-eye-bangladesh/
├── 📄 README.md                          # Project overview and setup instructions
├── 📄 package.json                       # Dependencies and build scripts
├── 📄 vite.config.ts                     # Build configuration
├── 📄 tailwind.config.js                # CSS framework configuration
├── 📄 tsconfig.json                      # TypeScript configuration
├── 📄 wrangler.json                      # Cloudflare Workers deployment config
├── 📄 index.html                         # Main HTML entry point
├── 📁 public/                            # Static assets
├── 📁 src/                               # Source code
└── 📁 docs/                              # Documentation files
```

---

## 📱 Source Code Structure (`src/`)

### Main Directories

```
src/
├── 📁 react-app/                         # Frontend React application
├── 📁 worker/                            # Backend Cloudflare Worker
└── 📁 shared/                            # Shared types and utilities
```

---

## ⚛️ React App Structure (`src/react-app/`)

### Complete File Breakdown

```
src/react-app/
├── 📄 main.tsx                           # React app entry point
├── 📄 App.tsx                            # Main app component with routing
├── 📄 index.css                          # Global styles and Tailwind imports
├── 📄 vite-env.d.ts                      # TypeScript environment definitions
│
├── 📁 components/                        # Reusable UI components
│   ├── 📄 InstallPrompt.tsx             # PWA installation prompt
│   ├── 📄 MobileHeader.tsx              # Mobile page header with back button
│   └── 📄 MobileLayout.tsx              # Mobile layout with navigation
│
├── 📁 hooks/                             # Custom React hooks
│   ├── 📄 useLanguage.tsx               # Language switching (English/Bengali)
│   └── 📄 usePWA.ts                     # Progressive Web App functionality
│
└── 📁 pages/                             # Page components (screens)
    ├── 📄 Home.tsx                       # Landing page with language toggle
    ├── 📄 Dashboard.tsx                  # User dashboard after login
    ├── 📄 Report.tsx                     # Traffic violation reporting form
    ├── 📄 Search.tsx                     # Case and vehicle search
    ├── 📄 KYC.tsx                        # Identity verification page
    ├── 📄 Emergency.tsx                  # Emergency contacts page
    ├── 📄 Penalties.tsx                  # User penalties management
    ├── 📄 LoginPortals.tsx               # Login portal selection
    ├── 📄 SignUpPortals.tsx              # Registration portal selection
    ├── 📄 DMPDashboard.tsx               # Police officer dashboard
    ├── 📄 AuthCallback.tsx               # OAuth authentication callback
    ├── 📄 OnboardingFlow.tsx             # New user onboarding
    ├── 📄 Registration.tsx               # User registration form
    └── 📄 UserTypeSelection.tsx          # User type selection
```

---

## 🔧 Backend Structure (`src/worker/`)

```
src/worker/
└── 📄 index.ts                           # Cloudflare Worker API endpoints
```

**Key API Endpoints**:
- `GET /api/users/me` - Get current user info
- `POST /api/reports` - Submit violation report
- `GET /api/reports` - Get user's reports
- `POST /api/kyc` - Submit KYC documents
- `GET /api/search/case/:id` - Search by case number
- `GET /api/search/vehicle/:number` - Search by vehicle
- `POST /api/dmp/reports/verify` - Officer verification
- `GET /api/penalties` - Get user penalties

---

## 🔗 Shared Resources (`src/shared/`)

```
src/shared/
└── 📄 types.ts                           # TypeScript type definitions
```

**Key Types**:
- `User` - User account information
- `Report` - Traffic violation report
- `Penalty` - User penalty information
- `VIOLATION_TYPES` - List of traffic violations
- `VIOLATION_FINES` - Fine amounts for each violation

---

## 🎨 Component Details

### 🏠 Home.tsx - Landing Page
**Purpose**: First screen users see with language toggle and portal selection

**Key Features**:
- Language switcher (English ↔ Bengali)
- Citizen registration/login buttons
- DMP officer portal access
- BRTA officer portal access
- Clean, professional design

**Used By**: First-time visitors and returning users

---

### 📊 Dashboard.tsx - User Dashboard
**Purpose**: Main screen after login showing user stats and quick actions

**Key Features**:
- User welcome message with name
- Statistics (reports, approvals, earnings, success rate)
- KYC verification alerts
- Penalty warnings
- Quick action buttons (Report, Search)
- Recent reports list
- Links to DMP portal and Emergency contacts

**Used By**: Logged-in citizens and officers

---

### 📷 Report.tsx - Violation Reporting
**Purpose**: Form to report traffic violations with photo evidence

**Key Features**:
- Camera interface for evidence photos
- Violation type dropdown with fine amounts
- Vehicle number input
- Description text area
- GPS location capture
- Reward calculation display
- Form validation and submission

**Used By**: Verified citizens reporting violations

---

### 🔍 Search.tsx - Case Search
**Purpose**: Search for existing cases by case number or vehicle number

**Key Features**:
- Toggle between case number and vehicle search
- Search input with placeholders
- Results display with case details
- Evidence photo loading
- Officer notes and rejection reasons

**Used By**: Citizens and officers checking case status

---

### 🆔 KYC.tsx - Identity Verification
**Purpose**: Document upload and verification for new users

**Key Features**:
- Document type selection (NID/Passport/License)
- Document number input
- Phone number verification
- Document photo capture
- Selfie with document capture
- Submission with progress feedback

**Used By**: New users completing registration

---

### 🚨 Emergency.tsx - Emergency Contacts
**Purpose**: Quick access to emergency services

**Key Features**:
- Categorized emergency contacts
- One-tap calling functionality
- Urgent vs. regular services
- Police, fire, ambulance, gas, electricity services
- Emergency instructions and notes

**Used By**: All users needing emergency assistance

---

### 🔐 Authentication Pages

#### LoginPortals.tsx & SignUpPortals.tsx
**Purpose**: Portal selection and Google OAuth integration

**Key Features**:
- Beautiful portal selection cards
- Citizen vs. Officer differentiation
- Google OAuth integration
- Role-based redirection
- Professional styling

**Used By**: Users accessing the app for first time or returning

---

### 👮 DMPDashboard.tsx - Officer Dashboard
**Purpose**: Police officer interface for verifying reports

**Key Features**:
- Pending reports list
- Report details viewer
- Evidence photo display
- Approval/rejection functionality
- Officer notes input
- False report penalty system

**Used By**: Verified DMP officers

---

## 🌍 Language System

### useLanguage.tsx Hook
**Purpose**: Manages app-wide language switching

**Features**:
- English ↔ Bengali translation
- localStorage persistence
- Comprehensive translation dictionary
- Easy-to-use `t()` function

**Translation Coverage**:
- 100+ translated strings
- All UI elements
- Form labels and buttons
- Error messages
- Success notifications

**Example Usage**:
```typescript
const { t, language, setLanguage } = useLanguage();
return <button>{t('submit')}</button>; // "Submit" or "জমা দিন"
```

---

## 📱 Mobile Components

### MobileHeader.tsx
**Purpose**: Consistent header with back button for all pages

**Features**:
- Back button navigation
- Page title display
- Optional right-side actions
- Consistent styling
- Touch-friendly design

### MobileLayout.tsx
**Purpose**: Mobile app shell with bottom navigation

**Features**:
- Status bar spacing
- Bottom navigation bar
- Page content area
- Navigation highlighting
- Safe area handling

---

## 🎯 PWA Features

### usePWA.ts Hook
**Purpose**: Progressive Web App functionality

**Features**:
- Install prompt detection
- Installation status tracking
- Offline capability preparation
- App-like experience

### InstallPrompt.tsx
**Purpose**: Native app installation prompt

**Features**:
- Dismissible install banner
- Professional styling
- User preference saving
- Cross-platform compatibility

---

## 🗄️ Database Schema

The app uses Cloudflare D1 (SQLite) with these main tables:

### Users Table
```sql
users (
  id, mocha_user_id, phone_number, kyc_status,
  total_reports, approved_reports, total_rewards,
  created_at, updated_at
)
```

### Reports Table
```sql
reports (
  id, user_id, case_number, violation_type,
  vehicle_number, description, image_key,
  latitude, longitude, address, status,
  fine_amount, reward_amount, created_at
)
```

### Additional Tables
- `penalties` - User penalty tracking
- `dmp_officers` - Police officer accounts
- `brta_officers` - Transport authority officers
- `payment_methods` - User payment preferences

---

## 🔧 Build Configuration

### package.json Scripts
```json
{
  "dev": "vite",                          // Development server
  "build": "vite build",                  // Production build
  "preview": "vite preview",              // Preview production build
  "deploy": "wrangler deploy"             // Deploy to Cloudflare
}
```

### Key Dependencies
- **React 18** - Modern React framework
- **React Router** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Beautiful icons
- **TypeScript** - Type safety
- **Vite** - Fast build tool
- **Cloudflare Workers** - Serverless backend

---

## 🎨 Design System

### Colors
- **Primary**: Blue (#3b82f6) - Main brand color
- **Secondary**: Green (#10b981) - Success and DMP
- **Accent**: Purple (#8b5cf6) - BRTA and highlights
- **Warning**: Orange (#f59e0b) - Alerts and pending
- **Danger**: Red (#ef4444) - Errors and emergencies

### Typography
- **Headings**: Bold, clear hierarchy
- **Body**: Readable, accessible sizes
- **Buttons**: Medium weight, proper contrast
- **Captions**: Subtle, informative

### Spacing
- **Components**: Consistent 4px grid system
- **Layouts**: Generous whitespace
- **Touch Targets**: Minimum 44px for mobile
- **Safe Areas**: Mobile-optimized padding

---

## 🚀 Deployment

### Cloudflare Workers
- **API**: Deployed as Cloudflare Worker
- **Database**: Cloudflare D1 (SQLite)
- **Storage**: Cloudflare R2 for images
- **CDN**: Global edge network

### Frontend Hosting
- **Static Site**: Built with Vite
- **CDN**: Cloudflare Pages
- **PWA**: Service worker enabled
- **Caching**: Optimized asset caching

---

## 📋 Maintenance Guide

### Regular Tasks
1. **Dependencies**: Update monthly
2. **Security**: Monitor vulnerability reports
3. **Performance**: Check Core Web Vitals
4. **Translations**: Review Bengali accuracy
5. **Database**: Monitor query performance

### Scaling Considerations
- **Users**: Current setup handles 10K+ users
- **Reports**: Indexed for fast searching
- **Images**: R2 storage auto-scales
- **API**: Workers scale automatically

---

## 🎯 Next Steps for Enhancement

### Phase 2 Features
1. **Push Notifications**: Real-time alerts
2. **Offline Mode**: Cached data access
3. **Advanced Analytics**: User behavior tracking
4. **Admin Panel**: System administration
5. **API Improvements**: Performance optimization

### Technical Debt
1. **Testing**: Add unit and integration tests
2. **Documentation**: API documentation
3. **Monitoring**: Error tracking and alerts
4. **Performance**: Bundle size optimization
5. **Accessibility**: WCAG compliance

---

**This structure provides a solid foundation for a production-ready mobile application that can scale to thousands of users while maintaining code quality and developer productivity.** 🏗️
