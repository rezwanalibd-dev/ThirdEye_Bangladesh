import { useState, useEffect } from 'react';

interface TestUser {
  id: string;
  userType: 'citizen' | 'dmp' | 'brta';
  sessionToken: string;
  isAuthenticated: boolean;
}

export function useTestAuth() {
  const [testUser, setTestUser] = useState<TestUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing test session
    const sessionToken = localStorage.getItem('test_session_token');
    const userType = localStorage.getItem('test_user_type') as 'citizen' | 'dmp' | 'brta';
    const userId = localStorage.getItem('test_user_id');

    if (sessionToken && userType && userId) {
      setTestUser({
        id: userId,
        userType,
        sessionToken,
        isAuthenticated: true
      });
    }
    
    setIsLoading(false);
  }, []);

  const logout = () => {
    localStorage.removeItem('test_session_token');
    localStorage.removeItem('test_user_type');
    localStorage.removeItem('test_user_id');
    setTestUser(null);
  };

  const isTestMode = !!testUser;

  return {
    testUser,
    isTestMode,
    isLoading,
    logout
  };
}
