import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'bn';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Home Page
    appTitle: "Third Eye Bangladesh",
    tagline: "Your Vigilance Saves Lives and Earns Rewards",
    startReporting: "Start Reporting & Earn Rewards",
    alreadyHaveAccount: "Already have an account?",
    dmpOfficers: "DMP Officers",
    brtaOfficers: "BRTA Officers",
    dhakaPolice: "Dhaka Metropolitan Police",
    roadAuthority: "Road Transport Authority",
    register: "Register",
    login: "Login",
    language: "Language",
    
    // Motivational & Trust
    motivationalText: "Ready to Make a Difference? Every report you make helps save lives. When you witness a traffic violation, you have the power to prevent accidents and protect your community.",
    trustedPlatform: "Trusted & Verified Platform",
    officialCollaboration: "Official collaboration with Bangladesh government agencies",
    dmpVerified: "DMP Verified",
    officialPolicePartnership: "Official police partnership",
    securePlatform: "Secure Platform",
    endToEndEncryption: "End-to-end encryption",
    communityDriven: "Community Driven",
    citizenEmpowerment: "Citizen empowerment",
    
    // Dashboard
    welcomeBack: "Welcome back,",
    reports: "Reports",
    approved: "Approved",
    earned: "Earned",
    success: "Success",
    identityVerification: "Identity Verification Required",
    completeKyc: "Complete KYC verification to start reporting violations",
    verifyNow: "Verify Now",
    accountRestricted: "Account Restricted",
    pendingPenalties: "You have pending penalties. Clear them to continue reporting.",
    viewPenalties: "View Penalties",
    quickActions: "Quick Actions",
    report: "Report",
    captureViolation: "Capture violation",
    search: "Search",
    findCases: "Find cases",
    recentReports: "Recent Reports",
    noReports: "No reports yet",
    startReporting2: "Start by reporting your first violation!",
    createReport: "Create Report",
    dmpPortal: "DMP Portal",
    officerAccess: "Officer access",
    emergency: "Emergency",
    quickContacts: "Quick contacts",
    
    // Report Page
    reportViolation: "Report Violation",
    photoEvidence: "Photo Evidence",
    takePhoto: "Take Photo",
    remove: "Remove",
    violationType: "Violation Type",
    selectViolationType: "Select violation type",
    yourReward: "Your Reward",
    ifApproved: "if approved",
    vehicleNumber: "Vehicle Number",
    description: "Description",
    provideDetails: "Provide additional details...",
    location: "Location",
    getCurrentLocation: "Get Current Location",
    submitReport: "Submit Report",
    submitting: "Submitting...",
    reportSubmitted: "Report Submitted!",
    caseNumber: "Case Number",
    firstReporter: "🎉 You're the First Reporter!",
    rewardMessage: "You will receive the reward when this report is verified by DMP officers.",
    similarIncident: "Similar Incident Already Reported",
    onlyFirstReporter: "Only the first reporter receives the reward. Thank you for your vigilance!",
    backToDashboard: "Back to Dashboard",
    
    // Search Page
    searchCases: "Search Cases",
    caseNumberSearch: "Case Number",
    vehicleNumberSearch: "Vehicle Number",
    enterCaseNumber: "Enter case number (e.g., TE-2024-01-15-00001)",
    enterVehicleNumber: "Enter vehicle number (e.g., Dhaka Metro-G-11-1234)",
    noCaseFound: "No case found with this number",
    noReportsFound: "No reports found for this vehicle",
    loadEvidencePhoto: "Load Evidence Photo",
    officerNotes: "Officer Notes",
    rejectionReason: "Rejection Reason",
    
    // KYC Page
    identityVerificationTitle: "Identity Verification",
    requiredToSubmit: "Required to submit violation reports",
    documentType: "Document Type",
    selectDocumentType: "Select document type",
    nid: "National ID Card",
    passport: "Passport",
    drivingLicense: "Driving License",
    documentNumber: "Document Number",
    enterDocumentNumber: "Enter document number",
    phoneNumber: "Phone Number",
    documentPhoto: "Document Photo",
    selfieWithDocument: "Selfie with Document",
    holdDocument: "Hold your document next to your face",
    takeSelfie: "Take Selfie",
    submitForVerification: "Submit for Verification",
    kycSubmitted: "KYC Submitted!",
    documentsUnderReview: "Your documents are under review. You'll be notified once verified.",
    redirectingToDashboard: "Redirecting to dashboard...",
    
    // Emergency Page
    emergencyContacts: "Emergency Contacts",
    tapToCall: "Tap any number to call instantly",
    emergencyNumbers: "Emergency Numbers",
    lifeThreatening: "For life-threatening emergencies, call 999 immediately. All calls to emergency services are free.",
    urgentEmergency: "Urgent Emergency Services",
    governmentServices: "Other Government Services",
    tollFree: "Emergency numbers are toll-free from all networks in Bangladesh.",
    trafficEmergency: "If you're reporting a traffic violation emergency, use Third Eye app alongside calling relevant authorities.",
    callNow: "Call Now",
    
    // Navigation
    home: "Home",
    profile: "Profile",
    back: "Back",
    dmpOfficerAccess: "DMP Officer Access",
    
    // Traffic Rules & Fines
    trafficRules: "Traffic Rules & Fines",
    lawsRegulations: "Laws & regulations",
    
    // Common
    loading: "Loading...",
    submit: "Submit",
    cancel: "Cancel",
    continue: "Continue",
    close: "Close",
    pending: "Pending",
    approved2: "Approved",
    rejected: "Rejected",
    fine: "Fine",
    reward: "Reward"
  },
  bn: {
    // Home Page
    appTitle: "তৃতীয় চোখ বাংলাদেশ",
    tagline: "আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার", 
    startReporting: "রিপোর্ট করুন ও পুরস্কার জিতুন",
    alreadyHaveAccount: "ইতিমধ্যে একটি অ্যাকাউন্ট আছে?",
    dmpOfficers: "ডিএমপি অফিসার",
    brtaOfficers: "বিআরটিএ অফিসার",
    dhakaPolice: "ঢাকা মেট্রোপলিটন পুলিশ",
    roadAuthority: "সড়ক পরিবহন কর্তৃপক্ষ",
    register: "নিবন্ধন",
    login: "লগইন",
    language: "ভাষা",
    
    // Motivational & Trust
    motivationalText: "প্রস্তুত কি ইতিবাচক পরিবর্তনের অংশ হতে? আপনার একটি রিপোর্টই অনেকগুলো জীবন বাঁচাতে পারে। ট্রাফিক আইন লঙ্ঘন দেখামাত্রই আপনার রিপোর্ট হতে পারে দুর্ঘটনা প্রতিরোধের প্রথম ধাপ, আপনার সচেতনতাই হয়ে উঠতে পারে সম্প্রদায়ের নিরাপত্তার রক্ষাকবচ।",
    trustedPlatform: "বিশ্বস্ত প্ল্যাটফর্ম",
    officialCollaboration: "সরকারি সংস্থার সহযোগিতায়",
    dmpVerified: "ডিএমপি অনুমোদিত",
    officialPolicePartnership: "প্রাতিষ্ঠানিক পুলিশ অংশীদারিত্ব",
    securePlatform: "সুরক্ষিত সিস্টেম",
    endToEndEncryption: "পূর্ণাঙ্গ এনক্রিপশন",
    communityDriven: "নাগরিক পরিচালিত",
    citizenEmpowerment: "সাধারণ মানুষের ক্ষমতায়ন",
    
    // Dashboard
    welcomeBack: "আবার স্বাগতম,",
    reports: "রিপোর্ট",
    approved: "অনুমোদিত",
    earned: "অর্জিত",
    success: "সফলতা",
    identityVerification: "পরিচয় যাচাইয়ের প্রয়োজন",
    completeKyc: "লঙ্ঘন রিপোর্ট করা শুরু করতে KYC যাচাইকরণ সম্পূর্ণ করুন",
    verifyNow: "এখনই যাচাই করুন",
    accountRestricted: "অ্যাকাউন্ট সীমাবদ্ধ",
    pendingPenalties: "আপনার বকেয়া জরিমানা রয়েছে। রিপোর্ট করা চালিয়ে যেতে সেগুলো পরিশোধ করুন।",
    viewPenalties: "জরিমানা দেখুন",
    quickActions: "দ্রুত কার্যক্রম",
    report: "রিপোর্ট",
    captureViolation: "লঙ্ঘন ক্যাপচার করুন",
    search: "অনুসন্ধান",
    findCases: "মামলা খুঁজুন",
    recentReports: "সাম্প্রতিক রিপোর্ট",
    noReports: "এখনও কোনো রিপোর্ট নেই",
    startReporting2: "আপনার প্রথম লঙ্ঘন রিপোর্ট করে শুরু করুন!",
    createReport: "রিপোর্ট তৈরি করুন",
    dmpPortal: "ডিএমপি পোর্টাল",
    officerAccess: "অফিসার অ্যাক্সেস",
    emergency: "জরুরি",
    quickContacts: "দ্রুত যোগাযোগ",
    
    // Report Page
    reportViolation: "লঙ্ঘন রিপোর্ট করুন",
    photoEvidence: "ছবির প্রমাণ",
    takePhoto: "ছবি তুলুন",
    remove: "সরান",
    violationType: "লঙ্ঘনের ধরন",
    selectViolationType: "লঙ্ঘনের ধরন নির্বাচন করুন",
    yourReward: "আপনার পুরস্কার",
    ifApproved: "অনুমোদিত হলে",
    vehicleNumber: "যানবাহনের নম্বর",
    description: "বিবরণ",
    provideDetails: "অতিরিক্ত বিবরণ প্রদান করুন...",
    location: "অবস্থান",
    getCurrentLocation: "বর্তমান অবস্থান পান",
    submitReport: "রিপোর্ট জমা দিন",
    submitting: "জমা দেওয়া হচ্ছে...",
    reportSubmitted: "রিপোর্ট জমা দেওয়া হয়েছে!",
    caseNumber: "মামলা নম্বর",
    firstReporter: "🎉 আপনি প্রথম রিপোর্টকারী!",
    rewardMessage: "ডিএমপি অফিসারদের দ্বারা এই রিপোর্ট যাচাই হলে আপনি পুরস্কার পাবেন।",
    similarIncident: "অনুরূপ ঘটনা ইতিমধ্যে রিপোর্ট করা হয়েছে",
    onlyFirstReporter: "শুধুমাত্র প্রথম রিপোর্টকারী পুরস্কার পায়। আপনার সতর্কতার জন্য ধন্যবাদ!",
    backToDashboard: "ড্যাশবোর্ডে ফিরে যান",
    
    // Search Page
    searchCases: "মামলা অনুসন্ধান করুন",
    caseNumberSearch: "মামলা নম্বর",
    vehicleNumberSearch: "যানবাহনের নম্বর",
    enterCaseNumber: "মামলা নম্বর প্রবেশ করান (যেমন, TE-2024-01-15-00001)",
    enterVehicleNumber: "যানবাহনের নম্বর প্রবেশ করান (যেমন, ঢাকা মেট্রো-গ-১১-১২৩৪)",
    noCaseFound: "এই নম্বরের কোনো মামলা পাওয়া যায়নি",
    noReportsFound: "এই যানবাহনের জন্য কোনো রিপোর্ট পাওয়া যায়নি",
    loadEvidencePhoto: "প্রমাণের ছবি লোড করুন",
    officerNotes: "অফিসারের নোট",
    rejectionReason: "প্রত্যাখ্যানের কারণ",
    
    // KYC Page
    identityVerificationTitle: "পরিচয় যাচাইকরণ",
    requiredToSubmit: "লঙ্ঘন রিপোর্ট জমা দিতে প্রয়োজনীয়",
    documentType: "নথির ধরন",
    selectDocumentType: "নথির ধরন নির্বাচন করুন",
    nid: "জাতীয় পরিচয়পত্র",
    passport: "পাসপোর্ট",
    drivingLicense: "ড্রাইভিং লাইসেন্স",
    documentNumber: "নথির নম্বর",
    enterDocumentNumber: "নথির নম্বর প্রবেশ করান",
    phoneNumber: "ফোন নম্বর",
    documentPhoto: "নথির ছবি",
    selfieWithDocument: "নথির সাথে সেলফি",
    holdDocument: "আপনার মুখের পাশে নথি ধরুন",
    takeSelfie: "সেলফি তুলুন",
    submitForVerification: "যাচাইয়ের জন্য জমা দিন",
    kycSubmitted: "KYC জমা দেওয়া হয়েছে!",
    documentsUnderReview: "আপনার নথি পর্যালোচনাধীন। যাচাই হয়ে গেলে আপনাকে জানানো হবে।",
    redirectingToDashboard: "ড্যাশবোর্ডে পুনঃনির্দেশ করা হচ্ছে...",
    
    // Emergency Page
    emergencyContacts: "জরুরি যোগাযোগ",
    tapToCall: "তাৎক্ষণিক কল করতে যেকোনো নম্বরে ট্যাপ করুন",
    emergencyNumbers: "জরুরি নম্বর",
    lifeThreatening: "জীবনের জন্য হুমকিস্বরূপ জরুরি অবস্থায় অবিলম্বে ৯৯৯ নম্বরে কল করুন। জরুরি সেবায় সব কল বিনামূল্যে।",
    urgentEmergency: "জরুরি জরুরি সেবা",
    governmentServices: "অন্যান্য সরকারি সেবা",
    tollFree: "বাংলাদেশের সব নেটওয়ার্ক থেকে জরুরি নম্বরগুলো বিনামূল্যে।",
    trafficEmergency: "যদি আপনি ট্রাফিক লঙ্ঘনের জরুরি অবস্থা রিপোর্ট করেন, তাহলে সংশ্লিষ্ট কর্তৃপক্ষকে কল করার পাশাপাশি থার্ড আই অ্যাপ ব্যবহার করুন।",
    callNow: "এখনই কল করুন",
    
    // Navigation
    home: "হোম",
    profile: "প্রোফাইল",
    back: "ফিরে যান",
    dmpOfficerAccess: "ডিএমপি অফিসার অ্যাক্সেস",
    
    // Traffic Rules & Fines
    trafficRules: "ট্রাফিক নিয়ম ও জরিমানা",
    lawsRegulations: "আইন ও বিধিমালা",
    
    // Common
    loading: "লোড হচ্ছে...",
    submit: "জমা দিন",
    cancel: "বাতিল",
    continue: "চালিয়ে যান",
    close: "বন্ধ",
    pending: "মুলতুবি",
    approved2: "অনুমোদিত",
    rejected: "প্রত্যাখ্যাত",
    fine: "জরিমানা",
    reward: "পুরস্কার"
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'bn')) {
      setLanguage(savedLanguage);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    const translationKey = key as keyof typeof translations['en'];
    return translations[language][translationKey] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}
