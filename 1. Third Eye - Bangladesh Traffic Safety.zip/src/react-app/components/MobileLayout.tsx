import { ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { Home, Camera, Search, User } from 'lucide-react';
import { useLanguage } from '@/react-app/hooks/useLanguage';

interface MobileLayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
}

export default function MobileLayout({ children, showBottomNav = true }: MobileLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLanguage();

  const navItems = [
    { icon: Home, label: t('home'), path: '/dashboard' },
    { icon: Camera, label: t('report'), path: '/report' },
    { icon: Search, label: t('search'), path: '/search' },
    { icon: User, label: t('profile'), path: '/profile' },
  ];

  return (
    <div className="mobile-vh bg-white flex flex-col max-w-md mx-auto relative">
      {/* Status Bar - iOS safe area */}
      <div className="safe-top bg-white"></div>
      
      {/* Main Content */}
      <div className="flex-1 pb-20 mobile-scroll">
        {children}
      </div>

      {/* Bottom Navigation */}
      {showBottomNav && (
        <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 px-4 py-2 safe-bottom">
          <div className="flex justify-around items-center">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex flex-col items-center p-2 rounded-lg transition-colors ${
                    isActive 
                      ? 'text-blue-600 bg-blue-50' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <item.icon className="w-6 h-6 mb-1" />
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
