import { ReactNode } from 'react';
import { ArrowLeft, Bell } from 'lucide-react';
import { useNavigate } from 'react-router';

interface MobileHeaderProps {
  title?: string;
  showBack?: boolean;
  rightAction?: ReactNode;
  onBack?: () => void;
}

export default function MobileHeader({ 
  title, 
  showBack = false, 
  rightAction,
  onBack 
}: MobileHeaderProps) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <div className="bg-white px-4 py-4 border-b border-gray-100 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-3">
        {showBack && (
          <button
            onClick={handleBack}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
        )}
        {title && (
          <h1 className="text-lg font-semibold text-gray-900">{title}</h1>
        )}
      </div>
      
      <div className="flex items-center gap-2">
        {rightAction || (
          <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <Bell className="w-5 h-5 text-gray-700" />
          </button>
        )}
      </div>
    </div>
  );
}
