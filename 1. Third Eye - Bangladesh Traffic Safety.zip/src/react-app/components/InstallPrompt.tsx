import React from 'react';
import { Download, X } from 'lucide-react';
import { usePWA } from '@/react-app/hooks/usePWA';

interface InstallPromptProps {
  onDismiss: () => void;
}

export const InstallPrompt: React.FC<InstallPromptProps> = ({ onDismiss }) => {
  const { installApp } = usePWA();

  const handleInstall = async () => {
    const installed = await installApp();
    if (installed) {
      onDismiss();
    }
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-2xl shadow-2xl z-50 backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="text-2xl">👁️</div>
          <div>
            <h3 className="font-semibold text-sm">Install Third Eye</h3>
            <p className="text-xs opacity-90">Get quick access to report violations</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleInstall}
            className="bg-white bg-opacity-20 hover:bg-opacity-30 px-3 py-2 rounded-xl flex items-center space-x-1 text-xs font-medium transition-all duration-200"
          >
            <Download className="w-4 h-4" />
            <span>Install</span>
          </button>
          <button
            onClick={onDismiss}
            className="bg-white bg-opacity-10 hover:bg-opacity-20 p-2 rounded-xl transition-all duration-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
