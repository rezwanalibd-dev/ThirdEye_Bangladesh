import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router";
import { AuthProvider, useAuth } from "@getmocha/users-service/react";
import { useState, useEffect } from "react";
import { useTestAuth } from "@/react-app/hooks/useTestAuth";
import HomePage from "@/react-app/pages/Home";
import DashboardPage from "@/react-app/pages/Dashboard";
import ReportPage from "@/react-app/pages/Report";
import SearchPage from "@/react-app/pages/Search";
import KYCPage from "@/react-app/pages/KYC";
import PenaltiesPage from "@/react-app/pages/Penalties";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DMPDashboardPage from "@/react-app/pages/DMPDashboard";
import EmergencyPage from "@/react-app/pages/Emergency";
import SocialCrimePage from "@/react-app/pages/SocialCrime";
import OnboardingFlow from "@/react-app/pages/OnboardingFlow";
import LoginPortals from "@/react-app/pages/LoginPortals";
import SignUpPortals from "@/react-app/pages/SignUpPortals";
import LoginOptions from "@/react-app/pages/LoginOptions";
import SignUpOptions from "@/react-app/pages/SignUpOptions";
import TestingDashboard from "@/react-app/pages/TestingDashboard";
import TrafficRulesPage from "@/react-app/pages/TrafficRules";
import ProfilePage from "@/react-app/pages/Profile";
import { InstallPrompt } from "@/react-app/components/InstallPrompt";
import { usePWA } from "@/react-app/hooks/usePWA";
import { LanguageProvider } from "@/react-app/hooks/useLanguage";
import { Loader2 } from "lucide-react";

function ProtectedRoute({ 
  children, 
  requiresOnboarding = false 
}: { 
  children: React.ReactNode;
  requiresOnboarding?: boolean;
}) {
  const { user, isPending } = useAuth();
  const { isTestMode, isLoading: testLoading } = useTestAuth();
  const [userInfo, setUserInfo] = useState<{ needsOnboarding?: boolean } | null>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [tempSessionToken] = useState(() => localStorage.getItem('temp_session_token'));

  useEffect(() => {
    if (user && !userInfo && !isTestMode) {
      fetch('/api/users/me')
        .then(res => res.json())
        .then(data => {
          setUserInfo(data || {});
          setIsLoadingUser(false);
        })
        .catch(() => {
          setUserInfo({});
          setIsLoadingUser(false);
        });
    } else if (!user && !isTestMode) {
      setIsLoadingUser(false);
    } else if (isTestMode) {
      // For test mode, skip user info loading
      setIsLoadingUser(false);
    }
  }, [user, userInfo, isTestMode]);

  if (isPending || isLoadingUser || testLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  // Allow access for test mode, Google OAuth, or temp session from OTP
  const hasAccess = user || tempSessionToken || isTestMode;
  
  if (!hasAccess) {
    return <Navigate to="/" replace />;
  }

  // Skip onboarding checks for test mode
  if (isTestMode) {
    return <>{children}</>;
  }

  // If requires onboarding but user needs onboarding, redirect to onboarding
  if (requiresOnboarding && userInfo?.needsOnboarding) {
    return <Navigate to="/onboarding" replace />;
  }

  // If doesn't require onboarding but user needs onboarding, redirect to onboarding
  if (!requiresOnboarding && userInfo?.needsOnboarding) {
    return <Navigate to="/onboarding" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPortals />} />
      <Route path="/signup" element={<SignUpPortals />} />
      <Route path="/login-options" element={<LoginOptions />} />
      <Route path="/signup-options" element={<SignUpOptions />} />
      <Route path="/auth/callback" element={<AuthCallbackPage />} />
      <Route
        path="/onboarding"
        element={
          <ProtectedRoute requiresOnboarding={true}>
            <OnboardingFlow />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/report"
        element={
          <ProtectedRoute>
            <ReportPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/search"
        element={
          <ProtectedRoute>
            <SearchPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/kyc"
        element={
          <ProtectedRoute>
            <KYCPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/penalties"
        element={
          <ProtectedRoute>
            <PenaltiesPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dmp"
        element={
          <ProtectedRoute>
            <DMPDashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/emergency"
        element={
          <ProtectedRoute>
            <EmergencyPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/social-crime"
        element={
          <ProtectedRoute>
            <SocialCrimePage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/traffic-rules"
        element={
          <ProtectedRoute>
            <TrafficRulesPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <ProfilePage />
          </ProtectedRoute>
        }
      />
      <Route path="/testing" element={<TestingDashboard />} />
    </Routes>
  );
}

export default function App() {
  const { isInstallable, isInstalled } = usePWA();
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);

  useEffect(() => {
    // Show install prompt after a delay if app is installable and not installed
    if (isInstallable && !isInstalled) {
      const timer = setTimeout(() => {
        const dismissed = localStorage.getItem('install-prompt-dismissed');
        if (!dismissed) {
          setShowInstallPrompt(true);
        }
      }, 3000); // Show after 3 seconds

      return () => clearTimeout(timer);
    }
  }, [isInstallable, isInstalled]);

  const handleDismissInstallPrompt = () => {
    setShowInstallPrompt(false);
    localStorage.setItem('install-prompt-dismissed', 'true');
  };

  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <AppRoutes />
          {showInstallPrompt && (
            <InstallPrompt onDismiss={handleDismissInstallPrompt} />
          )}
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}
