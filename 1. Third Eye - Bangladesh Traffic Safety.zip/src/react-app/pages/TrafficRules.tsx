import { Car, Shield, AlertTriangle, Scale, FileText, CreditCard, Building2 } from "lucide-react";
import { useNavigate } from "react-router";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import { useState } from "react";
import MobileHeader from "@/react-app/components/MobileHeader";

interface VehicleRule {
  vehicle: string;
  vehicleBn: string;
  icon: any;
  color: string;
  rules: string[];
  rulesBn: string[];
  speedLimits: {
    city: string;
    highway: string;
  };
  commonViolations: Array<{
    violation: string;
    violationBn: string;
    fine: string;
    points: string;
  }>;
}

interface TrafficSign {
  category: string;
  categoryBn: string;
  color: string;
  signs: Array<{
    symbol: string;
    meaning: string;
    meaningBn: string;
    action: string;
    actionBn: string;
  }>;
}

interface DocumentRequirement {
  document: string;
  documentBn: string;
  fine: string;
  description: string;
  descriptionBn: string;
}

interface LicenseProcess {
  step: string;
  stepBn: string;
  description: string;
  descriptionBn: string;
  fee: string;
  duration: string;
}

interface RegistrationFee {
  vehicle: string;
  vehicleBn: string;
  registrationFee: string;
  annualTax: string;
  renewalFee: string;
}

interface SeriousOffense {
  offense: string;
  offenseBn: string;
  penalty: string;
  points: string;
  section: string;
}

const VEHICLE_RULES: VehicleRule[] = [
  {
    vehicle: "Motorcycles",
    vehicleBn: "মোটরসাইকেল",
    icon: Car,
    color: "blue",
    rules: [
      "Helmet mandatory for rider & pillion",
      "Maximum 2 persons allowed", 
      "Must use rightmost lane",
      "No highway without permit",
      "Registration within 30 days"
    ],
    rulesBn: [
      "চালক ও পিছনের যাত্রীর জন্য হেলমেট বাধ্যতামূলক",
      "সর্বোচ্চ ২ জন অনুমোদিত",
      "ডানদিকের লেন ব্যবহার করতে হবে",
      "পারমিট ছাড়া হাইওয়ে নিষিদ্ধ",
      "৩০ দিনের মধ্যে রেজিস্ট্রেশন"
    ],
    speedLimits: {
      city: "40 km/h",
      highway: "60 km/h"
    },
    commonViolations: [
      {
        violation: "No Helmet",
        violationBn: "হেলমেট না পরা",
        fine: "৳1,000-10,000",
        points: "1-2"
      },
      {
        violation: "Overloading (3+ persons)",
        violationBn: "ওভারলোডিং (৩+ জন)",
        fine: "৳500-5,000",
        points: "1"
      },
      {
        violation: "Speeding",
        violationBn: "গতিসীমা লঙ্ঘন",
        fine: "৳5,000-50,000",
        points: "1-2"
      }
    ]
  },
  {
    vehicle: "Cars",
    vehicleBn: "গাড়ি",
    icon: Car,
    color: "green",
    rules: [
      "Seatbelts mandatory for front seats",
      "No illegal parking",
      "No phone use while driving",
      "Modifications require BRTA approval",
      "Third-party insurance mandatory"
    ],
    rulesBn: [
      "সামনের সিটে সিটবেল্ট বাধ্যতামূলক",
      "অবৈধ পার্কিং নিষিদ্ধ",
      "চালানোর সময় ফোন ব্যবহার নয়",
      "মডিফিকেশনের জন্য BRTA অনুমোদন",
      "থার্ড-পার্টি বীমা বাধ্যতামূলক"
    ],
    speedLimits: {
      city: "50 km/h",
      highway: "80 km/h"
    },
    commonViolations: [
      {
        violation: "No Seatbelt",
        violationBn: "সিটবেল্ট না বাঁধা",
        fine: "৳500-1,000",
        points: "1"
      },
      {
        violation: "Illegal Parking",
        violationBn: "অবৈধ পার্কিং",
        fine: "৳5,000",
        points: "1"
      },
      {
        violation: "Mobile Phone Use",
        violationBn: "মোবাইল ফোন ব্যবহার",
        fine: "৳5,000",
        points: "1"
      }
    ]
  },
  {
    vehicle: "Buses",
    vehicleBn: "বাস",
    icon: Car,
    color: "orange",
    rules: [
      "No overloading passengers",
      "Conductor required",
      "Use designated stops only",
      "Speed governor mandatory",
      "Annual fitness certificate"
    ],
    rulesBn: [
      "যাত্রী ওভারলোডিং নিষিদ্ধ",
      "কন্ডাক্টর আবশ্যক",
      "শুধুমাত্র নির্ধারিত স্টপে থামা",
      "স্পিড গভর্নর বাধ্যতামূলক",
      "বার্ষিক ফিটনেস সার্টিফিকেট"
    ],
    speedLimits: {
      city: "40 km/h",
      highway: "60 km/h"
    },
    commonViolations: [
      {
        violation: "Passenger Overloading",
        violationBn: "যাত্রী ওভারলোডিং",
        fine: "৳10,000-25,000",
        points: "2"
      },
      {
        violation: "No Conductor",
        violationBn: "কন্ডাক্টর না থাকা",
        fine: "৳5,000",
        points: "1"
      },
      {
        violation: "Expired Fitness/Permit",
        violationBn: "মেয়াদোত্তীর্ণ ফিটনেস/পারমিট",
        fine: "৳25,000",
        points: "N/A"
      }
    ]
  }
];

const TRAFFIC_SIGNS: TrafficSign[] = [
  {
    category: "Mandatory Signs",
    categoryBn: "বাধ্যতামূলক সাইন",
    color: "blue",
    signs: [
      {
        symbol: "↑",
        meaning: "Move Straight Ahead",
        meaningBn: "সোজা এগিয়ে যান",
        action: "You must proceed straight",
        actionBn: "আপনাকে সোজা এগিয়ে যেতে হবে"
      },
      {
        symbol: "→",
        meaning: "Turn Right",
        meaningBn: "ডানে ঘুরুন",
        action: "You must turn right",
        actionBn: "আপনাকে ডানে ঘুরতে হবে"
      },
      {
        symbol: "🚲",
        meaning: "Cycle Track",
        meaningBn: "সাইকেল ট্র্যাক",
        action: "Compulsory for cyclists",
        actionBn: "সাইকেল চালকদের জন্য বাধ্যতামূলক"
      }
    ]
  },
  {
    category: "Prohibitory Signs",
    categoryBn: "নিষেধাজ্ঞা সাইন",
    color: "red",
    signs: [
      {
        symbol: "🚫",
        meaning: "No Entry",
        meaningBn: "প্রবেশ নিষেধ",
        action: "All vehicles prohibited",
        actionBn: "সকল যানবাহন নিষিদ্ধ"
      },
      {
        symbol: "⛔",
        meaning: "No Parking",
        meaningBn: "পার্কিং নিষেধ",
        action: "Parking prohibited",
        actionBn: "পার্কিং নিষিদ্ধ"
      },
      {
        symbol: "📢",
        meaning: "No Horn",
        meaningBn: "হর্ন নিষেধ",
        action: "Horn use prohibited",
        actionBn: "হর্ন ব্যবহার নিষিদ্ধ"
      }
    ]
  },
  {
    category: "Warning Signs",
    categoryBn: "সতর্কতা সাইন",
    color: "orange",
    signs: [
      {
        symbol: "🚧",
        meaning: "Road Work",
        meaningBn: "রাস্তার কাজ",
        action: "Proceed with caution",
        actionBn: "সাবধানে এগিয়ে যান"
      },
      {
        symbol: "🚸",
        meaning: "Pedestrian Crossing",
        meaningBn: "পথচারী ক্রসিং",
        action: "Yield to pedestrians",
        actionBn: "পথচারীদের অগ্রাধিকার দিন"
      },
      {
        symbol: "⚠️",
        meaning: "General Warning",
        meaningBn: "সাধারণ সতর্কতা",
        action: "Be cautious ahead",
        actionBn: "সামনে সাবধান"
      }
    ]
  }
];

const DOCUMENT_REQUIREMENTS: DocumentRequirement[] = [
  {
    document: "Valid Driving License",
    documentBn: "বৈধ ড্রাইভিং লাইসেন্স",
    fine: "Up to ৳25,000",
    description: "Must be for correct vehicle class",
    descriptionBn: "সঠিক যানবাহনের শ্রেণীর জন্য হতে হবে"
  },
  {
    document: "Registration Certificate",
    documentBn: "রেজিস্ট্রেশন সার্টিফিকেট",
    fine: "Up to ৳50,000",
    description: "Proof of vehicle registration",
    descriptionBn: "যানবাহন রেজিস্ট্রেশনের প্রমাণ"
  },
  {
    document: "Fitness Certificate",
    documentBn: "ফিটনেস সার্টিফিকেট",
    fine: "Up to ৳25,000",
    description: "Vehicle roadworthiness proof",
    descriptionBn: "যানবাহনের সড়কযোগ্যতার প্রমাণ"
  },
  {
    document: "Insurance Certificate",
    documentBn: "বীমা সার্টিফিকেট",
    fine: "Up to ৳10,000",
    description: "Third-party liability coverage",
    descriptionBn: "তৃতীয় পক্ষের দায়বদ্ধতা কভারেজ"
  },
  {
    document: "Tax Token",
    documentBn: "ট্যাক্স টোকেন",
    fine: "Up to ৳15,000",
    description: "Annual road tax payment proof",
    descriptionBn: "বার্ষিক সড়ক কর পরিশোধের প্রমাণ"
  }
];

const LICENSE_PROCESS_STEPS: LicenseProcess[] = [
  {
    step: "Step 1: Learner's Permit",
    stepBn: "ধাপ ১: লার্নার্স পারমিট",
    description: "Apply online, pay fee (৳205.25), pass preliminary trial",
    descriptionBn: "অনলাইনে আবেদন, ফি পরিশোধ (৳২০৫.২৫), প্রাথমিক পরীক্ষায় উত্তীর্ণ",
    fee: "৳205.25",
    duration: "6 months validity"
  },
  {
    step: "Step 2: Training Period",
    stepBn: "ধাপ ২: প্রশিক্ষণ কাল",
    description: "Mandatory training at BRTA-recognized driving school",
    descriptionBn: "BRTA স্বীকৃত ড্রাইভিং স্কুলে বাধ্যতামূলক প্রশিক্ষণ",
    fee: "Varies by school",
    duration: "1-3 months"
  },
  {
    step: "Step 3: Final Driving Test",
    stepBn: "ধাপ ৩: চূড়ান্ত ড্রাইভিং পরীক্ষা",
    description: "Practical test: vehicle control, parking, sign recognition",
    descriptionBn: "ব্যবহারিক পরীক্ষা: যান নিয়ন্ত্রণ, পার্কিং, সাইন চিহ্নিতকরণ",
    fee: "৳1,085.25",
    duration: "1-2 hours"
  },
  {
    step: "Step 4: License Issuance",
    stepBn: "ধাপ ৪: লাইসেন্স প্রদান",
    description: "Biometric enrollment, smart card delivery",
    descriptionBn: "বায়োমেত্রিক নথিভুক্তি, স্মার্ট কার্ড বিতরণ",
    fee: "Included",
    duration: "15-21 days"
  }
];

const REGISTRATION_FEES_DATA: RegistrationFee[] = [
  {
    vehicle: "Motorcycle (up to 150cc)",
    vehicleBn: "মোটরসাইকেল (১৫০সিসি পর্যন্ত)",
    registrationFee: "৳1,000-1,500",
    annualTax: "৳1,000-2,500",
    renewalFee: "৳5,000 (2 years)"
  },
  {
    vehicle: "Car (up to 1500cc)",
    vehicleBn: "গাড়ি (১৫০০সিসি পর্যন্ত)",
    registrationFee: "৳5,000-10,000",
    annualTax: "৳10,000-25,000",
    renewalFee: "Varies"
  },
  {
    vehicle: "Bus/Truck",
    vehicleBn: "বাস/ট্রাক",
    registrationFee: "৳25,000+",
    annualTax: "৳5,000-15,000",
    renewalFee: "Annual"
  }
];

const SERIOUS_OFFENSES_DATA: SeriousOffense[] = [
  {
    offense: "Drunk Driving",
    offenseBn: "মদ্যপ অবস্থায় গাড়ি চালানো",
    penalty: "৳10,000 + 3 months jail",
    points: "5",
    section: "Section 76"
  },
  {
    offense: "Hit and Run",
    offenseBn: "হিট অ্যান্ড রান",
    penalty: "৳500,000 + 3 years jail",
    points: "License Revocation",
    section: "Section 86-91"
  },
  {
    offense: "Reckless Driving",
    offenseBn: "বেপরোয়া গাড়ি চালানো",
    penalty: "৳300,000 + 3 years jail",
    points: "4-6",
    section: "Section 75"
  },
  {
    offense: "Driving Without License",
    offenseBn: "লাইসেন্স ছাড়া গাড়ি চালানো",
    penalty: "৳25,000 + 6 months jail",
    points: "License Required",
    section: "Section 66"
  }
];

export default function TrafficRulesPage() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'rules' | 'signs' | 'documents' | 'licenses' | 'registration' | 'offenses'>('rules');

  const tabs = [
    { id: 'rules', label: language === 'en' ? 'Vehicle Rules' : 'যানবাহনের নিয়ম', icon: Car },
    { id: 'signs', label: language === 'en' ? 'Traffic Signs' : 'ট্রাফিক সাইন', icon: AlertTriangle },
    { id: 'documents', label: language === 'en' ? 'Documents' : 'কাগজপত্র', icon: FileText },
    { id: 'licenses', label: language === 'en' ? 'License Process' : 'লাইসেন্স প্রক্রিয়া', icon: CreditCard },
    { id: 'registration', label: language === 'en' ? 'Registration' : 'রেজিস্ট্রেশন', icon: Building2 },
    { id: 'offenses', label: language === 'en' ? 'Serious Offenses' : 'গুরুতর অপরাধ', icon: Shield }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={language === 'en' ? "Traffic Rules & Fines" : "ট্রাফিক নিয়ম ও জরিমানা"}
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      
      <div className="px-4 py-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-2xl mb-6 shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Scale className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">
                {language === 'en' ? 'Bangladesh Traffic Laws 2025' : 'বাংলাদেশ ট্রাফিক আইন ২০২৫'}
              </h1>
              <p className="text-white/80 text-sm">
                {language === 'en' ? 'Complete guide to traffic rules & fines' : 'ট্রাফিক নিয়ম ও জরিমানার সম্পূর্ণ গাইড'}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`p-3 rounded-xl border-2 transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-600 border-blue-600 text-white shadow-lg'
                    : 'bg-white border-gray-200 text-gray-700 hover:border-blue-300 shadow-sm'
                }`}
              >
                <Icon className="w-4 h-4 mx-auto mb-1" />
                <div className="text-xs font-medium">{tab.label}</div>
              </button>
            );
          })}
        </div>

        {/* Content */}
        {activeTab === 'rules' && (
          <div className="space-y-6">
            {VEHICLE_RULES.map((vehicleRule, index) => {
              const Icon = vehicleRule.icon;
              return (
                <div key={index} className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                  <div className={`bg-${vehicleRule.color}-500 text-white p-4`}>
                    <div className="flex items-center gap-3">
                      <Icon className="w-6 h-6" />
                      <div>
                        <h3 className="font-bold text-lg">
                          {language === 'en' ? vehicleRule.vehicle : vehicleRule.vehicleBn}
                        </h3>
                        <p className="text-white/80 text-sm">
                          {language === 'en' 
                            ? `City: ${vehicleRule.speedLimits.city} | Highway: ${vehicleRule.speedLimits.highway}`
                            : `শহর: ${vehicleRule.speedLimits.city} | হাইওয়ে: ${vehicleRule.speedLimits.highway}`
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <h4 className="font-semibold text-gray-900 mb-3">
                      {language === 'en' ? 'Key Rules:' : 'মূল নিয়ম:'}
                    </h4>
                    <ul className="space-y-2 mb-4">
                      {(language === 'en' ? vehicleRule.rules : vehicleRule.rulesBn).map((rule, ruleIndex) => (
                        <li key={ruleIndex} className="flex items-start gap-2">
                          <span className="text-green-500 mt-1">✓</span>
                          <span className="text-gray-700 text-sm">{rule}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <h4 className="font-semibold text-gray-900 mb-3">
                      {language === 'en' ? 'Common Violations:' : 'সাধারণ লঙ্ঘন:'}
                    </h4>
                    <div className="space-y-2">
                      {vehicleRule.commonViolations.map((violation, vIndex) => (
                        <div key={vIndex} className="bg-gray-50 p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="font-medium text-gray-900">
                              {language === 'en' ? violation.violation : violation.violationBn}
                            </span>
                            <div className="text-right">
                              <div className="text-red-600 font-bold">{violation.fine}</div>
                              <div className="text-xs text-gray-500">{violation.points} points</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'signs' && (
          <div className="space-y-6">
            {TRAFFIC_SIGNS.map((signCategory, index) => (
              <div key={index} className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <div className={`bg-${signCategory.color}-500 text-white p-4`}>
                  <h3 className="font-bold text-lg">
                    {language === 'en' ? signCategory.category : signCategory.categoryBn}
                  </h3>
                </div>
                
                <div className="p-4">
                  <div className="grid gap-4">
                    {signCategory.signs.map((sign, signIndex) => (
                      <div key={signIndex} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                        <div className={`w-16 h-16 bg-white border-2 border-${signCategory.color}-500 rounded-lg flex items-center justify-center text-2xl`}>
                          {sign.symbol}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">
                            {language === 'en' ? sign.meaning : sign.meaningBn}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {language === 'en' ? sign.action : sign.actionBn}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'documents' && (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <h3 className="font-bold text-blue-900 mb-2">
                {language === 'en' ? 'Required Documents (Always Carry)' : 'প্রয়োজনীয় কাগজপত্র (সর্বদা বহন করুন)'}
              </h3>
              <p className="text-blue-700 text-sm">
                {language === 'en' 
                  ? 'All drivers must carry these documents while driving'
                  : 'সকল চালকদের গাড়ি চালানোর সময় এই কাগজপত্র বহন করতে হবে'}
              </p>
            </div>
            
            {DOCUMENT_REQUIREMENTS.map((doc, index) => (
              <div key={index} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">
                      {language === 'en' ? doc.document : doc.documentBn}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {language === 'en' ? doc.description : doc.descriptionBn}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-red-600 font-bold">{doc.fine}</div>
                    <div className="text-xs text-gray-500">
                      {language === 'en' ? 'Fine if missing' : 'অনুপস্থিত থাকলে জরিমানা'}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'licenses' && (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <h3 className="font-bold text-green-900 mb-2">
                {language === 'en' ? 'BRTA Driving License Application Process' : 'BRTA ড্রাইভিং লাইসেন্স আবেদন প্রক্রিয়া'}
              </h3>
              <p className="text-green-700 text-sm">
                {language === 'en' 
                  ? 'Complete guide to obtaining your driving license in Bangladesh'
                  : 'বাংলাদেশে আপনার ড্রাইভিং লাইসেন্স পাওয়ার সম্পূর্ণ গাইড'}
              </p>
            </div>
            
            {LICENSE_PROCESS_STEPS.map((step, index) => (
              <div key={index} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-bold text-sm">{index + 1}</span>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900 mb-1">
                      {language === 'en' ? step.step : step.stepBn}
                    </h4>
                    <p className="text-sm text-gray-600 mb-2">
                      {language === 'en' ? step.description : step.descriptionBn}
                    </p>
                    <div className="flex gap-4 text-xs">
                      <div className="bg-blue-50 px-2 py-1 rounded">
                        <span className="text-blue-600 font-medium">Fee: {step.fee}</span>
                      </div>
                      <div className="bg-gray-50 px-2 py-1 rounded">
                        <span className="text-gray-600 font-medium">Duration: {step.duration}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'registration' && (
          <div className="space-y-4">
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
              <h3 className="font-bold text-purple-900 mb-2">
                {language === 'en' ? 'Vehicle Registration Fees & Process' : 'যানবাহন রেজিস্ট্রেশন ফি ও প্রক্রিয়া'}
              </h3>
              <p className="text-purple-700 text-sm">
                {language === 'en' 
                  ? 'Complete breakdown of registration costs and procedures'
                  : 'রেজিস্ট্রেশন খরচ ও পদ্ধতির সম্পূর্ণ বিবরণ'}
              </p>
            </div>
            
            {REGISTRATION_FEES_DATA.map((reg, index) => (
              <div key={index} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <h4 className="font-bold text-gray-900 mb-3">
                  {language === 'en' ? reg.vehicle : reg.vehicleBn}
                </h4>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="bg-blue-50 p-2 rounded">
                    <div className="text-xs text-blue-600 font-medium">Registration</div>
                    <div className="font-bold text-blue-900">{reg.registrationFee}</div>
                  </div>
                  <div className="bg-orange-50 p-2 rounded">
                    <div className="text-xs text-orange-600 font-medium">Annual Tax</div>
                    <div className="font-bold text-orange-900">{reg.annualTax}</div>
                  </div>
                  <div className="bg-green-50 p-2 rounded">
                    <div className="text-xs text-green-600 font-medium">Renewal</div>
                    <div className="font-bold text-green-900">{reg.renewalFee}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'offenses' && (
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <h3 className="font-bold text-red-900 mb-2">
                {language === 'en' ? 'Serious Traffic Offenses' : 'গুরুতর ট্রাফিক অপরাধ'}
              </h3>
              <p className="text-red-700 text-sm">
                {language === 'en' 
                  ? 'These offenses can lead to imprisonment, not just fines'
                  : 'এই অপরাধগুলো শুধু জরিমানা নয়, কারাদণ্ডেরও কারণ হতে পারে'}
              </p>
            </div>
            
            {SERIOUS_OFFENSES_DATA.map((offense, index) => (
              <div key={index} className="bg-white rounded-xl border-2 border-red-200 p-4 shadow-sm">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">
                      {language === 'en' ? offense.offense : offense.offenseBn}
                    </h4>
                    <div className="text-red-600 font-bold mb-1">{offense.penalty}</div>
                    <div className="text-xs text-gray-500">{offense.section}</div>
                  </div>
                  <div className="text-right">
                    <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-medium">
                      {offense.points}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Important Notice */}
        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800">
              <p className="font-semibold mb-1">
                {language === 'en' ? 'Legal Disclaimer:' : 'আইনি দাবিত্যাগ:'}
              </p>
              <p>
                {language === 'en' 
                  ? 'This guide is for informational purposes only. Laws and fines are subject to change. Always verify with official BRTA (brta.gov.bd) sources for current legal information.'
                  : 'এই গাইড শুধুমাত্র তথ্যগত উদ্দেশ্যে। আইন ও জরিমানা পরিবর্তনশীল। বর্তমান আইনি তথ্যের জন্য সর্বদা সরকারি BRTA (brta.gov.bd) উৎস যাচাই করুন।'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
