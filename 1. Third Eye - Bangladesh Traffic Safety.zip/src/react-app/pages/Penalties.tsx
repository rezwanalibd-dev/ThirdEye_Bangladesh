import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { AlertCircle, CheckCircle } from "lucide-react";
import type { Penalty } from "@/shared/types";
import MobileHeader from "@/react-app/components/MobileHeader";

export default function PenaltiesPage() {
  const navigate = useNavigate();
  const [penalties, setPenalties] = useState<Penalty[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadPenalties() {
      try {
        const response = await fetch("/api/penalties");
        const data = await response.json();
        setPenalties(data);
      } catch (error) {
        console.error("Failed to load penalties:", error);
      } finally {
        setLoading(false);
      }
    }

    loadPenalties();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  const pendingPenalties = penalties.filter((p) => p.status === "pending");
  const hasPending = pendingPenalties.length > 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title="Penalties"
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      <div className="container mx-auto px-4 py-8 max-w-4xl">

        {hasPending && (
          <div className="mb-6 bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-orange-800">Reporting Suspended</div>
              <div className="text-sm text-orange-700">
                Clear pending penalties to continue reporting violations
              </div>
            </div>
          </div>
        )}

        {penalties.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-500" />
            <p className="text-gray-600">No penalties. Keep up the good reporting!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {penalties.map((penalty) => (
              <PenaltyCard key={penalty.id} penalty={penalty} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PenaltyCard({ penalty }: { penalty: Penalty }) {
  const statusColors = {
    pending: "bg-orange-100 text-orange-700 border-orange-200",
    paid: "bg-green-100 text-green-700 border-green-200",
    overdue: "bg-red-100 text-red-700 border-red-200",
  };

  const isOverdue =
    penalty.status === "pending" && new Date(penalty.due_date) < new Date();

  return (
    <div
      className={`bg-white rounded-xl shadow-sm p-6 border-2 ${
        isOverdue ? "border-red-300" : "border-gray-200"
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="text-sm text-gray-600 mb-1">Penalty Amount</div>
          <div className="text-3xl font-bold text-red-600">৳{penalty.amount.toFixed(0)}</div>
        </div>
        <div
          className={`px-3 py-1 rounded-full text-sm font-medium border ${
            statusColors[penalty.status]
          }`}
        >
          {penalty.status.charAt(0).toUpperCase() + penalty.status.slice(1)}
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div>
          <div className="text-sm text-gray-600">Reason</div>
          <div className="font-semibold">
            {penalty.reason === "false_report" && "False Report"}
            {penalty.reason === "intentional_misreporting" && "Intentional Misreporting"}
            {penalty.reason === "evidence_fabrication" && "Evidence Fabrication"}
          </div>
        </div>
        <div>
          <div className="text-sm text-gray-600">Due Date</div>
          <div className={`font-semibold ${isOverdue ? "text-red-600" : ""}`}>
            {new Date(penalty.due_date).toLocaleDateString()}
            {isOverdue && " (Overdue)"}
          </div>
        </div>
      </div>

      {penalty.status === "pending" && (
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="text-sm text-gray-700 mb-3">
            Pay via bKash, Nagad, or Rocket to restore reporting access
          </div>
          <button className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium">
            Pay Now
          </button>
        </div>
      )}

      {penalty.status === "paid" && penalty.paid_at && (
        <div className="bg-green-50 rounded-lg p-4">
          <div className="text-sm text-green-700">
            Paid on {new Date(penalty.paid_at).toLocaleDateString()}
          </div>
        </div>
      )}
    </div>
  );
}
