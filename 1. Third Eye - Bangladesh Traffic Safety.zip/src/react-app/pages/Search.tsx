import { useState } from "react";
import { Search, FileText, Car } from "lucide-react";
import type { Report } from "@/shared/types";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import MobileHeader from "@/react-app/components/MobileHeader";
import { useNavigate } from "react-router";

export default function SearchPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [searchType, setSearchType] = useState<"case" | "vehicle">("case");
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<Report | Report[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSearched(true);

    try {
      const endpoint =
        searchType === "case"
          ? `/api/search/case/${encodeURIComponent(searchQuery.toUpperCase())}`
          : `/api/search/vehicle/${encodeURIComponent(searchQuery.toUpperCase())}`;

      const response = await fetch(endpoint);
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Search error:", error);
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={t('searchCases')} 
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8 mb-6">

          {/* Search Type Selector */}
          <div className="flex gap-4 mb-6">
            <button
              onClick={() => setSearchType("case")}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-colors ${
                searchType === "case"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <FileText className="w-5 h-5 inline-block mr-2" />
              {t('caseNumberSearch')}
            </button>
            <button
              onClick={() => setSearchType("vehicle")}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-colors ${
                searchType === "vehicle"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Car className="w-5 h-5 inline-block mr-2" />
              {t('vehicleNumberSearch')}
            </button>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-3">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                searchType === "case"
                  ? t('enterCaseNumber')
                  : t('enterVehicleNumber')
              }
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors font-medium"
            >
              <Search className="w-5 h-5" />
            </button>
          </form>
        </div>

        {/* Results */}
        {loading && (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
          </div>
        )}

        {!loading && searched && (
          <div className="space-y-4">
            {searchType === "case" ? (
              results && !Array.isArray(results) ? (
                <ReportCard report={results} />
              ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                  <Search className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p className="text-gray-600">{t('noCaseFound')}</p>
                </div>
              )
            ) : Array.isArray(results) && results.length > 0 ? (
              results.map((report) => <ReportCard key={report.id} report={report} />)
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                <Search className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-gray-600">{t('noReportsFound')}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ReportCard({ report }: { report: Report }) {
  const { t } = useLanguage();
  const statusColors = {
    pending: "bg-orange-100 text-orange-700 border-orange-200",
    approved: "bg-green-100 text-green-700 border-green-200",
    rejected: "bg-red-100 text-red-700 border-red-200",
  };

  const [imageUrl, setImageUrl] = useState<string>("");

  const loadImage = async () => {
    try {
      const response = await fetch(`/api/reports/${report.id}/image`);
      const blob = await response.blob();
      setImageUrl(URL.createObjectURL(blob));
    } catch (error) {
      console.error("Failed to load image:", error);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="font-mono text-lg font-bold text-blue-600 mb-1">{report.case_number}</div>
          <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium border ${statusColors[report.status]}`}>
            {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
          </div>
        </div>
        {report.status === "approved" && (
          <div className="text-right">
            <div className="text-sm text-gray-600">Reward</div>
            <div className="text-2xl font-bold text-green-600">৳{report.reward_amount.toFixed(0)}</div>
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <div>
          <div className="text-sm text-gray-600">Violation Type</div>
          <div className="font-semibold">{report.violation_type}</div>
        </div>
        <div>
          <div className="text-sm text-gray-600">Vehicle Number</div>
          <div className="font-semibold">{report.vehicle_number}</div>
        </div>
        <div>
          <div className="text-sm text-gray-600">Location</div>
          <div className="font-semibold">{report.address}</div>
        </div>
        <div>
          <div className="text-sm text-gray-600">Date</div>
          <div className="font-semibold">
            {new Date(report.created_at).toLocaleDateString()}
          </div>
        </div>
      </div>

      {report.description && (
        <div className="mb-4">
          <div className="text-sm text-gray-600 mb-1">Description</div>
          <div className="text-gray-800">{report.description}</div>
        </div>
      )}

      {!imageUrl ? (
        <button
          onClick={loadImage}
          className="w-full px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors font-medium"
        >
          {t('loadEvidencePhoto')}
        </button>
      ) : (
        <img src={imageUrl} alt="Evidence" className="w-full rounded-lg" />
      )}

      {report.officer_notes && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="text-sm text-gray-600 mb-1">{t('officerNotes')}</div>
          <div className="text-gray-800">{report.officer_notes}</div>
        </div>
      )}

      {report.rejection_reason && (
        <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
          <div className="text-sm text-red-600 mb-1">{t('rejectionReason')}</div>
          <div className="text-red-800">{report.rejection_reason}</div>
        </div>
      )}
    </div>
  );
}
