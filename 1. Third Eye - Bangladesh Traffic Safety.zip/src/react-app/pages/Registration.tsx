import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { Camera, Upload, CreditCard, ArrowLeft, CheckCircle, AlertCircle } from "lucide-react";

interface RegistrationProps {
  userType: 'citizen' | 'dmp' | 'brta';
}

export default function Registration({ userType }: RegistrationProps) {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    phoneNumber: '',
    documentType: userType === 'citizen' ? 'nid' : (userType === 'dmp' ? 'badge' : 'employee_id'),
    documentNumber: '',
    employeeId: '',
    badgeNumber: '',
    rank: '',
    division: '',
    region: '',
    paymentMethod: '',
    accountNumber: '',
    accountName: ''
  });
  const [documents, setDocuments] = useState({
    selfie: null as File | null,
    document: null as File | null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const selfieInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);

  const steps = userType === 'citizen' 
    ? [
        { id: 1, title: 'Personal Info', description: 'Mobile number verification' },
        { id: 2, title: 'Identity Verification', description: 'Selfie & NID/License' },
        { id: 3, title: 'Payment Setup', description: 'bKash/Nagad/Rocket account' }
      ]
    : [
        { id: 1, title: 'Personal Info', description: 'Mobile number & official details' },
        { id: 2, title: 'Official Verification', description: 'Badge/ID & selfie verification' }
      ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileUpload = (type: 'selfie' | 'document', file: File) => {
    setDocuments(prev => ({ ...prev, [type]: file }));
    if (errors[type]) {
      setErrors(prev => ({ ...prev, [type]: '' }));
    }
  };

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.phoneNumber.match(/^(\+880|880|0)?1[3-9]\d{8}$/)) {
        newErrors.phoneNumber = 'Please enter a valid Bangladeshi mobile number';
      }
      
      if (userType === 'dmp') {
        if (!formData.badgeNumber) newErrors.badgeNumber = 'Badge number is required';
        if (!formData.rank) newErrors.rank = 'Rank is required';
        if (!formData.division) newErrors.division = 'Division is required';
      }
      
      if (userType === 'brta') {
        if (!formData.employeeId) newErrors.employeeId = 'Employee ID is required';
        if (!formData.rank) newErrors.rank = 'Rank is required';
        if (!formData.division) newErrors.division = 'Division is required';
        if (!formData.region) newErrors.region = 'Region is required';
      }
    }

    if (step === 2) {
      if (!documents.selfie) newErrors.selfie = 'Selfie photo is required';
      if (!documents.document) newErrors.document = 'Document photo is required';
      if (!formData.documentNumber) newErrors.documentNumber = 'Document number is required';
    }

    if (step === 3 && userType === 'citizen') {
      if (!formData.paymentMethod) newErrors.paymentMethod = 'Payment method is required';
      if (!formData.accountNumber) newErrors.accountNumber = 'Account number is required';
      if (!formData.accountName) newErrors.accountName = 'Account name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(currentStep)) return;

    setIsSubmitting(true);
    try {
      const submitFormData = new FormData();
      submitFormData.append('userType', userType);
      submitFormData.append('phoneNumber', formData.phoneNumber);
      submitFormData.append('documentType', formData.documentType);
      submitFormData.append('documentNumber', formData.documentNumber);
      
      if (documents.selfie) submitFormData.append('selfieImage', documents.selfie);
      if (documents.document) submitFormData.append('documentImage', documents.document);
      
      if (userType === 'dmp') {
        submitFormData.append('badgeNumber', formData.badgeNumber);
        submitFormData.append('rank', formData.rank);
        submitFormData.append('division', formData.division);
      }
      
      if (userType === 'brta') {
        submitFormData.append('employeeId', formData.employeeId);
        submitFormData.append('rank', formData.rank);
        submitFormData.append('division', formData.division);
        submitFormData.append('region', formData.region);
      }
      
      if (userType === 'citizen') {
        submitFormData.append('paymentMethod', formData.paymentMethod);
        submitFormData.append('accountNumber', formData.accountNumber);
        submitFormData.append('accountName', formData.accountName);
      }

      // Include temp session token if using OTP auth
      const tempSessionToken = localStorage.getItem('temp_session_token');
      const headers: HeadersInit = {};
      if (tempSessionToken) {
        headers['X-Session-Token'] = tempSessionToken;
      }

      const response = await fetch('/api/registration', {
        method: 'POST',
        headers,
        body: submitFormData
      });

      if (response.ok) {
        // Clear temp auth data
        localStorage.removeItem('temp_session_token');
        localStorage.removeItem('auth_identifier');
        localStorage.removeItem('auth_type');
        navigate('/dashboard');
      } else {
        const error = await response.json();
        setErrors({ general: error.error || 'Registration failed' });
      }
    } catch (error) {
      setErrors({ general: 'Network error. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-white mb-6 hover:text-blue-300 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step.id <= currentStep ? 'bg-blue-500 text-white' : 'bg-white/20 text-blue-300'
                }`}>
                  {step.id < currentStep ? <CheckCircle className="w-6 h-6" /> : step.id}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-20 h-1 mx-2 ${
                    step.id < currentStep ? 'bg-blue-500' : 'bg-white/20'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2">{steps[currentStep - 1].title}</h2>
            <p className="text-blue-200">{steps[currentStep - 1].description}</p>
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
          {currentStep === 1 && (
            <Step1
              userType={userType}
              formData={formData}
              errors={errors}
              onInputChange={handleInputChange}
            />
          )}

          {currentStep === 2 && (
            <Step2
              userType={userType}
              formData={formData}
              documents={documents}
              errors={errors}
              onInputChange={handleInputChange}
              onFileUpload={handleFileUpload}
              selfieInputRef={selfieInputRef}
              documentInputRef={documentInputRef}
            />
          )}

          {currentStep === 3 && userType === 'citizen' && (
            <Step3
              formData={formData}
              errors={errors}
              onInputChange={handleInputChange}
            />
          )}

          {errors.general && (
            <div className="flex items-center gap-2 text-red-400 bg-red-400/10 p-3 rounded-lg mb-6">
              <AlertCircle className="w-5 h-5" />
              {errors.general}
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between pt-6">
            <button
              onClick={() => setCurrentStep(prev => prev - 1)}
              disabled={currentStep === 1}
              className="px-6 py-2 text-white border border-white/20 rounded-lg hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            
            {currentStep < steps.length ? (
              <button
                onClick={handleNext}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isSubmitting ? 'Submitting...' : 'Complete Registration'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Step1({ userType, formData, errors, onInputChange }: any) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-white font-medium mb-2">Mobile Number</label>
        <input
          type="tel"
          placeholder="+880 1XXX-XXXXXX"
          value={formData.phoneNumber}
          onChange={(e) => onInputChange('phoneNumber', e.target.value)}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
        />
        {errors.phoneNumber && <p className="text-red-400 text-sm mt-1">{errors.phoneNumber}</p>}
      </div>

      {userType === 'dmp' && (
        <>
          <div>
            <label className="block text-white font-medium mb-2">Badge Number</label>
            <input
              type="text"
              placeholder="DMP-XXXX"
              value={formData.badgeNumber}
              onChange={(e) => onInputChange('badgeNumber', e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
            />
            {errors.badgeNumber && <p className="text-red-400 text-sm mt-1">{errors.badgeNumber}</p>}
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-white font-medium mb-2">Rank</label>
              <select
                value={formData.rank}
                onChange={(e) => onInputChange('rank', e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Rank</option>
                <option value="constable">Constable</option>
                <option value="sergeant">Sergeant</option>
                <option value="inspector">Inspector</option>
                <option value="additional_sp">Additional SP</option>
                <option value="sp">SP</option>
              </select>
              {errors.rank && <p className="text-red-400 text-sm mt-1">{errors.rank}</p>}
            </div>
            
            <div>
              <label className="block text-white font-medium mb-2">Division</label>
              <select
                value={formData.division}
                onChange={(e) => onInputChange('division', e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Division</option>
                <option value="traffic">Traffic</option>
                <option value="crime">Crime</option>
                <option value="detective">Detective</option>
                <option value="special_branch">Special Branch</option>
              </select>
              {errors.division && <p className="text-red-400 text-sm mt-1">{errors.division}</p>}
            </div>
          </div>
        </>
      )}

      {userType === 'brta' && (
        <>
          <div>
            <label className="block text-white font-medium mb-2">Employee ID</label>
            <input
              type="text"
              placeholder="BRTA-XXXX"
              value={formData.employeeId}
              onChange={(e) => onInputChange('employeeId', e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
            />
            {errors.employeeId && <p className="text-red-400 text-sm mt-1">{errors.employeeId}</p>}
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-white font-medium mb-2">Rank</label>
              <select
                value={formData.rank}
                onChange={(e) => onInputChange('rank', e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Rank</option>
                <option value="assistant">Assistant</option>
                <option value="officer">Officer</option>
                <option value="senior_officer">Senior Officer</option>
                <option value="deputy_director">Deputy Director</option>
                <option value="director">Director</option>
              </select>
              {errors.rank && <p className="text-red-400 text-sm mt-1">{errors.rank}</p>}
            </div>
            
            <div>
              <label className="block text-white font-medium mb-2">Division</label>
              <select
                value={formData.division}
                onChange={(e) => onInputChange('division', e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Division</option>
                <option value="registration">Vehicle Registration</option>
                <option value="licensing">Driving License</option>
                <option value="enforcement">Enforcement</option>
                <option value="technical">Technical</option>
              </select>
              {errors.division && <p className="text-red-400 text-sm mt-1">{errors.division}</p>}
            </div>
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Region</label>
            <select
              value={formData.region}
              onChange={(e) => onInputChange('region', e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
            >
              <option value="">Select Region</option>
              <option value="dhaka">Dhaka</option>
              <option value="chittagong">Chittagong</option>
              <option value="rajshahi">Rajshahi</option>
              <option value="khulna">Khulna</option>
              <option value="barisal">Barisal</option>
              <option value="sylhet">Sylhet</option>
              <option value="rangpur">Rangpur</option>
              <option value="mymensingh">Mymensingh</option>
            </select>
            {errors.region && <p className="text-red-400 text-sm mt-1">{errors.region}</p>}
          </div>
        </>
      )}
    </div>
  );
}

function Step2({ userType, formData, documents, errors, onInputChange, onFileUpload, selfieInputRef, documentInputRef }: any) {
  const documentTypes: Record<string, Array<{value: string, label: string}>> = {
    citizen: [
      { value: 'nid', label: 'National ID Card' },
      { value: 'driving_license', label: 'Driving License' },
      { value: 'passport', label: 'Passport' }
    ],
    dmp: [
      { value: 'badge', label: 'DMP Badge/ID' }
    ],
    brta: [
      { value: 'employee_id', label: 'BRTA Employee ID' }
    ]
  };

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-white font-medium mb-2">Document Type</label>
        <select
          value={formData.documentType}
          onChange={(e) => onInputChange('documentType', e.target.value)}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
        >
          {documentTypes[userType].map((type: any) => (
            <option key={type.value} value={type.value}>{type.label}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-white font-medium mb-2">Document Number</label>
        <input
          type="text"
          placeholder="Enter document number"
          value={formData.documentNumber}
          onChange={(e) => onInputChange('documentNumber', e.target.value)}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
        />
        {errors.documentNumber && <p className="text-red-400 text-sm mt-1">{errors.documentNumber}</p>}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="block text-white font-medium mb-2">Selfie Photo</label>
          <div 
            onClick={() => selfieInputRef.current?.click()}
            className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center cursor-pointer hover:border-white/40 transition-colors"
          >
            {documents.selfie ? (
              <div className="flex flex-col items-center gap-2">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <span className="text-white">Selfie uploaded</span>
                <span className="text-blue-200 text-sm">{documents.selfie.name}</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Camera className="w-8 h-8 text-white/50" />
                <span className="text-white/70">Take a clear selfie</span>
                <span className="text-white/50 text-sm">Click to upload</span>
              </div>
            )}
          </div>
          <input
            ref={selfieInputRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={(e) => e.target.files?.[0] && onFileUpload('selfie', e.target.files[0])}
            className="hidden"
          />
          {errors.selfie && <p className="text-red-400 text-sm mt-1">{errors.selfie}</p>}
        </div>

        <div>
          <label className="block text-white font-medium mb-2">Document Photo</label>
          <div 
            onClick={() => documentInputRef.current?.click()}
            className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center cursor-pointer hover:border-white/40 transition-colors"
          >
            {documents.document ? (
              <div className="flex flex-col items-center gap-2">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <span className="text-white">Document uploaded</span>
                <span className="text-blue-200 text-sm">{documents.document.name}</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-white/50" />
                <span className="text-white/70">Upload document photo</span>
                <span className="text-white/50 text-sm">Clear, readable image</span>
              </div>
            )}
          </div>
          <input
            ref={documentInputRef}
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files?.[0] && onFileUpload('document', e.target.files[0])}
            className="hidden"
          />
          {errors.document && <p className="text-red-400 text-sm mt-1">{errors.document}</p>}
        </div>
      </div>
    </div>
  );
}

function Step3({ formData, errors, onInputChange }: any) {
  const paymentMethods = [
    { value: 'bkash', label: 'bKash', color: 'from-pink-500 to-pink-600' },
    { value: 'nagad', label: 'Nagad', color: 'from-orange-500 to-orange-600' },
    { value: 'rocket', label: 'Rocket', color: 'from-purple-500 to-purple-600' },
    { value: 'upay', label: 'Upay', color: 'from-blue-500 to-blue-600' },
    { value: 'sure_cash', label: 'SureCash', color: 'from-green-500 to-green-600' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-white font-medium mb-4">Payment Method</label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {paymentMethods.map((method) => (
            <button
              key={method.value}
              type="button"
              onClick={() => onInputChange('paymentMethod', method.value)}
              className={`p-4 rounded-lg border-2 transition-all ${
                formData.paymentMethod === method.value
                  ? `border-white bg-gradient-to-r ${method.color} text-white`
                  : 'border-white/20 bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              <CreditCard className="w-6 h-6 mx-auto mb-2" />
              <span className="font-medium">{method.label}</span>
            </button>
          ))}
        </div>
        {errors.paymentMethod && <p className="text-red-400 text-sm mt-1">{errors.paymentMethod}</p>}
      </div>

      <div>
        <label className="block text-white font-medium mb-2">Account Number</label>
        <input
          type="text"
          placeholder="01XXXXXXXXX"
          value={formData.accountNumber}
          onChange={(e) => onInputChange('accountNumber', e.target.value)}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
        />
        {errors.accountNumber && <p className="text-red-400 text-sm mt-1">{errors.accountNumber}</p>}
      </div>

      <div>
        <label className="block text-white font-medium mb-2">Account Holder Name</label>
        <input
          type="text"
          placeholder="As registered with payment provider"
          value={formData.accountName}
          onChange={(e) => onInputChange('accountName', e.target.value)}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-blue-400"
        />
        {errors.accountName && <p className="text-red-400 text-sm mt-1">{errors.accountName}</p>}
      </div>

      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-sm font-bold">!</span>
          </div>
          <div>
            <h4 className="text-white font-medium mb-1">Payment Information</h4>
            <p className="text-blue-200 text-sm">
              Rewards from verified reports (20% of fines) will be sent directly to this account. 
              Ensure the account number and name are correct as they cannot be changed easily later.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
