import { useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import UserTypeSelection from "./UserTypeSelection";
import Registration from "./Registration";

export default function OnboardingFlow() {
  const { user } = useAuth();
  const [userType, setUserType] = useState<'citizen' | 'dmp' | 'brta' | null>(null);

  // Check for OTP-based auth session
  const tempSessionToken = localStorage.getItem('temp_session_token');
  
  // For OTP auth, allow access without Google OAuth user
  if (!user && !tempSessionToken) {
    return null; // This should be handled by protected route
  }

  // Check if user type was pre-selected from portal buttons
  const storedPortal = localStorage.getItem('selectedPortal');
  if (storedPortal && !userType) {
    setUserType(storedPortal as 'citizen' | 'dmp' | 'brta');
    localStorage.removeItem('selectedPortal');
  }

  if (!userType) {
    return <UserTypeSelection onUserTypeSelect={setUserType} />;
  }

  return <Registration userType={userType} />;
}
