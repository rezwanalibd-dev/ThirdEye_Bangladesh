import { useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Loader2 } from "lucide-react";

export default function AuthCallbackPage() {
  const { exchangeCodeForSessionToken } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    async function handleCallback() {
      try {
        await exchangeCodeForSessionToken();
        
        // Check if user needs onboarding
        const response = await fetch('/api/users/me');
        const data = await response.json();
        
        if (data.needsOnboarding) {
          navigate("/onboarding");
        } else {
          navigate("/dashboard");
        }
      } catch (error) {
        console.error("Auth callback error:", error);
        navigate("/");
      }
    }

    handleCallback();
  }, [exchangeCodeForSessionToken, navigate]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-950 to-indigo-900">
      <Loader2 className="w-12 h-12 animate-spin text-white mb-4" />
      <p className="text-white text-lg">Completing login...</p>
    </div>
  );
}
