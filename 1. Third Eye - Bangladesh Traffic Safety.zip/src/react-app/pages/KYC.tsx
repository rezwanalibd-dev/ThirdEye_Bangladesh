import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Camera, CheckCircle, AlertCircle, Shield } from "lucide-react";
import type { User } from "@/shared/types";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import MobileHeader from "@/react-app/components/MobileHeader";

export default function KYCPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [user, setUser] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    documentType: "",
    documentNumber: "",
    phoneNumber: "",
  });
  const [documentImage, setDocumentImage] = useState<File | null>(null);
  const [documentPreview, setDocumentPreview] = useState<string>("");
  const [selfieImage, setSelfieImage] = useState<File | null>(null);
  const [selfiePreview, setSelfiePreview] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    async function loadUser() {
      try {
        const response = await fetch("/api/users/me");
        const data = await response.json();
        setUser(data.appUser);

        if (data.appUser.kyc_status === "verified") {
          navigate("/dashboard");
        }
      } catch (error) {
        console.error("Failed to load user:", error);
      }
    }

    loadUser();
  }, [navigate]);

  const handleImageChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "document" | "selfie"
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      if (type === "document") {
        setDocumentImage(file);
        const reader = new FileReader();
        reader.onloadend = () => setDocumentPreview(reader.result as string);
        reader.readAsDataURL(file);
      } else {
        setSelfieImage(file);
        const reader = new FileReader();
        reader.onloadend = () => setSelfiePreview(reader.result as string);
        reader.readAsDataURL(file);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (!documentImage || !selfieImage) {
        throw new Error("Both document and selfie images are required");
      }

      const submitData = new FormData();
      submitData.append("documentType", formData.documentType);
      submitData.append("documentNumber", formData.documentNumber);
      submitData.append("phoneNumber", formData.phoneNumber);
      submitData.append("documentImage", documentImage);
      submitData.append("selfieImage", selfieImage);

      const response = await fetch("/api/kyc", {
        method: "POST",
        body: submitData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to submit KYC");
      }

      setSuccess(true);
      setTimeout(() => navigate("/dashboard"), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{t('kycSubmitted')}</h2>
          <p className="text-gray-600 mb-4">
            {t('documentsUnderReview')}
          </p>
          <div className="text-sm text-gray-500">{t('redirectingToDashboard')}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={t('identityVerificationTitle')} 
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-gray-600 text-sm">{t('requiredToSubmit')}</p>
            </div>
          </div>

          {user?.kyc_status === "rejected" && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-red-700">
                Your previous KYC submission was rejected. Please submit again with correct documents.
              </div>
            </div>
          )}

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-red-700">{error}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Document Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('documentType')} *
              </label>
              <select
                value={formData.documentType}
                onChange={(e) => setFormData({ ...formData, documentType: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">{t('selectDocumentType')}</option>
                <option value="nid">{t('nid')}</option>
                <option value="passport">{t('passport')}</option>
                <option value="driving_license">{t('drivingLicense')}</option>
              </select>
            </div>

            {/* Document Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('documentNumber')} *
              </label>
              <input
                type="text"
                value={formData.documentNumber}
                onChange={(e) => setFormData({ ...formData, documentNumber: e.target.value })}
                placeholder={t('enterDocumentNumber')}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('phoneNumber')} *
              </label>
              <input
                type="tel"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                placeholder="+8801XXXXXXXXX"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            {/* Document Image */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('documentPhoto')} *
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                {documentPreview ? (
                  <div className="relative">
                    <img src={documentPreview} alt="Document" className="max-h-48 mx-auto rounded-lg" />
                    <button
                      type="button"
                      onClick={() => {
                        setDocumentImage(null);
                        setDocumentPreview("");
                      }}
                      className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div>
                    <Camera className="w-10 h-10 mx-auto mb-3 text-gray-400" />
                    <label className="cursor-pointer">
                      <span className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-block">
                        {t('takePhoto')}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={(e) => handleImageChange(e, "document")}
                        className="hidden"
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>

            {/* Selfie with Document */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('selfieWithDocument')} *
              </label>
              <p className="text-sm text-gray-600 mb-3">{t('holdDocument')}</p>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                {selfiePreview ? (
                  <div className="relative">
                    <img src={selfiePreview} alt="Selfie" className="max-h-48 mx-auto rounded-lg" />
                    <button
                      type="button"
                      onClick={() => {
                        setSelfieImage(null);
                        setSelfiePreview("");
                      }}
                      className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div>
                    <Camera className="w-10 h-10 mx-auto mb-3 text-gray-400" />
                    <label className="cursor-pointer">
                      <span className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-block">
                        {t('takeSelfie')}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        capture="user"
                        onChange={(e) => handleImageChange(e, "selfie")}
                        className="hidden"
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !documentImage || !selfieImage}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
            >
              {loading ? t('submitting') : t('submitForVerification')}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
