import { useState } from "react";
import { useNavigate } from "react-router";
import { Shield, Car, Users, ArrowLeft } from "lucide-react";

interface UserTypeSelectionProps {
  onUserTypeSelect: (userType: 'citizen' | 'dmp' | 'brta') => void;
}

export default function UserTypeSelection({ onUserTypeSelect }: UserTypeSelectionProps) {
  const navigate = useNavigate();

  const userTypes = [
    {
      id: 'citizen',
      title: 'Citizen Reporter',
      description: 'Report traffic violations and earn rewards for verified reports',
      icon: <Users className="w-12 h-12" />,
      features: ['Report violations', 'Earn rewards', 'Track reports', 'Emergency contacts'],
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 'dmp',
      title: 'DMP Officer',
      description: 'Dhaka Metropolitan Police officer with verification authority',
      icon: <Shield className="w-12 h-12" />,
      features: ['Verify reports', 'Issue fines', 'Officer dashboard', 'Case management'],
      color: 'from-green-500 to-green-600'
    },
    {
      id: 'brta',
      title: 'BRTA Officer',
      description: 'Bangladesh Road Transport Authority official',
      icon: <Car className="w-12 h-12" />,
      features: ['Vehicle verification', 'License checks', 'Registration data', 'Compliance monitoring'],
      color: 'from-purple-500 to-purple-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 py-12">
      <div className="container mx-auto px-4">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-white mb-8 hover:text-blue-300 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Choose Your Account Type</h1>
          <p className="text-blue-200 text-lg max-w-2xl mx-auto">
            Select the account type that best describes your role in the Third Eye traffic safety system
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {userTypes.map((type) => (
            <UserTypeCard
              key={type.id}
              type={type}
              onSelect={() => onUserTypeSelect(type.id as 'citizen' | 'dmp' | 'brta')}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function UserTypeCard({ 
  type, 
  onSelect 
}: { 
  type: any; 
  onSelect: () => void;
}) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 hover:bg-white/15 transition-all duration-300 cursor-pointer transform hover:scale-105"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onSelect}
    >
      <div className={`w-20 h-20 bg-gradient-to-r ${type.color} rounded-2xl flex items-center justify-center mx-auto mb-6 text-white transition-transform duration-300 ${isHovered ? 'scale-110' : ''}`}>
        {type.icon}
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-3 text-center">{type.title}</h3>
      <p className="text-blue-200 mb-6 text-center">{type.description}</p>
      
      <ul className="space-y-2 mb-8">
        {type.features.map((feature: string, index: number) => (
          <li key={index} className="flex items-center gap-3 text-blue-100">
            <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
            {feature}
          </li>
        ))}
      </ul>
      
      <button className={`w-full py-3 bg-gradient-to-r ${type.color} text-white rounded-lg font-semibold hover:shadow-xl transition-all`}>
        Continue as {type.title}
      </button>
    </div>
  );
}
