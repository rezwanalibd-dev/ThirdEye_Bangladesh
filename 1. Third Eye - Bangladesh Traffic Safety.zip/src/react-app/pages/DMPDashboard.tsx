import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Shield, CheckCircle, XCircle, Eye, AlertTriangle, ArrowLeft } from "lucide-react";
import type { Report } from "@/shared/types";

export default function DMPDashboardPage() {
  const navigate = useNavigate();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    try {
      const response = await fetch("/api/dmp/reports/pending");
      const data = await response.json();
      // Ensure data is an array before setting
      setReports(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to load reports:", error);
      setReports([]); // Set to empty array on error
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">DMP Verification Dashboard</h1>
                <p className="text-blue-100 text-sm">Dhaka Metropolitan Police</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Reports List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <h2 className="font-bold mb-4">
                Pending Reports ({reports.length})
              </h2>
              <div className="space-y-2 max-h-[calc(100vh-250px)] overflow-y-auto">
                {!Array.isArray(reports) || reports.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <CheckCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>All reports reviewed</p>
                  </div>
                ) : (
                  reports.map((report) => (
                    <button
                      key={report.id}
                      onClick={() => setSelectedReport(report)}
                      className={`w-full text-left p-3 rounded-lg border transition-colors ${
                        selectedReport?.id === report.id
                          ? "bg-blue-50 border-blue-300"
                          : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                      }`}
                    >
                      <div className="font-mono text-sm font-medium text-blue-600 mb-1">
                        {report.case_number}
                      </div>
                      <div className="text-sm font-semibold">{report.violation_type}</div>
                      <div className="text-xs text-gray-600">{report.vehicle_number}</div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Report Details */}
          <div className="lg:col-span-2">
            {selectedReport ? (
              <ReportDetails
                report={selectedReport}
                onVerified={() => {
                  loadReports();
                  setSelectedReport(null);
                }}
              />
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                <Eye className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-gray-600">Select a report to review</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ReportDetails({
  report,
  onVerified,
}: {
  report: Report;
  onVerified: () => void;
}) {
  const [imageUrl, setImageUrl] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [isFalseReport, setIsFalseReport] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);

  useEffect(() => {
    loadImage();
  }, [report.id]);

  const loadImage = async () => {
    try {
      const response = await fetch(`/api/reports/${report.id}/image`);
      const blob = await response.blob();
      setImageUrl(URL.createObjectURL(blob));
    } catch (error) {
      console.error("Failed to load image:", error);
    }
  };

  const handleVerify = async (action: "approve" | "reject") => {
    setLoading(true);
    try {
      const response = await fetch("/api/dmp/reports/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reportId: report.id,
          action,
          notes,
          isFalseReport: action === "reject" ? isFalseReport : false,
        }),
      });

      if (!response.ok) {
        throw new Error("Verification failed");
      }

      onVerified();
    } catch (error) {
      console.error("Verification error:", error);
    } finally {
      setLoading(false);
      setShowRejectDialog(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="mb-6">
        <div className="font-mono text-lg font-bold text-blue-600 mb-2">
          {report.case_number}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-gray-600">Violation Type</div>
            <div className="font-semibold">{report.violation_type}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Vehicle Number</div>
            <div className="font-semibold">{report.vehicle_number}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Location</div>
            <div className="font-semibold text-sm">{report.address}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Date & Time</div>
            <div className="font-semibold text-sm">
              {new Date(report.created_at).toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {report.description && (
        <div className="mb-6">
          <div className="text-sm text-gray-600 mb-1">Description</div>
          <div className="p-3 bg-gray-50 rounded-lg">{report.description}</div>
        </div>
      )}

      {/* Evidence Image */}
      <div className="mb-6">
        <div className="text-sm text-gray-600 mb-2">Evidence Photo</div>
        {imageUrl ? (
          <img src={imageUrl} alt="Evidence" className="w-full rounded-lg border border-gray-200" />
        ) : (
          <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
          </div>
        )}
      </div>

      {/* Officer Notes */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Officer Notes (Optional)
        </label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Add any notes about this report..."
          rows={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <button
          onClick={() => handleVerify("approve")}
          disabled={loading}
          className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors font-medium flex items-center justify-center gap-2"
        >
          <CheckCircle className="w-5 h-5" />
          Approve Report
        </button>
        <button
          onClick={() => setShowRejectDialog(true)}
          disabled={loading}
          className="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 transition-colors font-medium flex items-center justify-center gap-2"
        >
          <XCircle className="w-5 h-5" />
          Reject Report
        </button>
      </div>

      {/* Reject Dialog */}
      {showRejectDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Reject Report</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rejection Reason *
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g., Insufficient evidence, unclear image..."
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            <div className="mb-6">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={isFalseReport}
                  onChange={(e) => setIsFalseReport(e.target.checked)}
                  className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
                />
                <span className="text-sm font-medium">Mark as False Report (Apply Penalty)</span>
              </label>
              {isFalseReport && (
                <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-red-700">
                    User will be penalized ৳500 for intentional false reporting. Their account will be restricted until penalty is paid.
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowRejectDialog(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleVerify("reject")}
                disabled={!notes || loading}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 transition-colors"
              >
                {loading ? "Rejecting..." : "Reject Report"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
