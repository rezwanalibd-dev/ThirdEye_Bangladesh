import { useState } from "react";
import { useNavigate } from "react-router";
import { Camera, Video, Upload, MapPin, AlertCircle, CheckCircle, FileImage } from "lucide-react";
import { VEHICLE_TYPES, getViolationsForVehicle, VIOLATION_FINES } from "@/shared/types";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import MobileHeader from "@/react-app/components/MobileHeader";

export default function ReportPage() {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    vehicleType: "",
    violationType: "",
    vehicleNumber: "",
    description: "",
    latitude: 0,
    longitude: 0,
    address: "",
  });
  const [evidenceFiles, setEvidenceFiles] = useState<{
    primary?: File;
    additional: File[];
  }>({ additional: [] });
  const [previews, setPreviews] = useState<{
    primary?: string;
    additional: string[];
  }>({ additional: [] });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<{ caseNumber: string; isFirstReporter: boolean } | null>(null);

  // Get user's location
  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`
            );
            const data = await response.json();
            
            setFormData((prev) => ({
              ...prev,
              latitude: lat,
              longitude: lng,
              address: data.display_name || `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
            }));
          } catch {
            setFormData((prev) => ({
              ...prev,
              latitude: lat,
              longitude: lng,
              address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
            }));
          }
        },
        () => {
          setError(language === 'en' 
            ? "Failed to get location. Please enable location services." 
            : "অবস্থান পেতে ব্যর্থ। অনুগ্রহ করে লোকেশন সার্ভিস চালু করুন।");
        }
      );
    }
  };

  const handlePrimaryFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setEvidenceFiles(prev => ({ ...prev, primary: file }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => ({ ...prev, primary: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdditionalFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      setEvidenceFiles(prev => ({ 
        ...prev, 
        additional: [...prev.additional, ...files] 
      }));
      
      files.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPreviews(prev => ({ 
            ...prev, 
            additional: [...prev.additional, reader.result as string] 
          }));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeFile = (type: 'primary' | 'additional', index?: number) => {
    if (type === 'primary') {
      setEvidenceFiles(prev => ({ ...prev, primary: undefined }));
      setPreviews(prev => ({ ...prev, primary: undefined }));
    } else if (index !== undefined) {
      setEvidenceFiles(prev => ({
        ...prev,
        additional: prev.additional.filter((_, i) => i !== index)
      }));
      setPreviews(prev => ({
        ...prev,
        additional: prev.additional.filter((_, i) => i !== index)
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (!evidenceFiles.primary) {
        throw new Error(language === 'en' 
          ? "Please capture a photo or video of the violation"
          : "লঙ্ঘনের ছবি বা ভিডিও তুলুন");
      }

      if (!formData.latitude || !formData.longitude) {
        throw new Error(language === 'en'
          ? "Please enable location to submit report"
          : "রিপোর্ট জমা দিতে অবস্থান চালু করুন");
      }

      const submitData = new FormData();
      submitData.append("vehicleType", formData.vehicleType);
      submitData.append("violationType", formData.violationType);
      submitData.append("vehicleNumber", formData.vehicleNumber.trim().toUpperCase());
      submitData.append("description", formData.description);
      submitData.append("latitude", formData.latitude.toString());
      submitData.append("longitude", formData.longitude.toString());
      submitData.append("address", formData.address);
      
      // Add primary evidence
      if (evidenceFiles.primary) {
        submitData.append("primaryEvidence", evidenceFiles.primary);
      }
      
      // Add additional evidence
      evidenceFiles.additional.forEach((file, index) => {
        submitData.append(`additionalEvidence_${index}`, file);
      });

      const response = await fetch("/api/reports", {
        method: "POST",
        body: submitData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || (language === 'en' ? "Failed to submit report" : "রিপোর্ট জমা দিতে ব্যর্থ"));
      }

      const data = await response.json();
      setSuccess({
        caseNumber: data.caseNumber,
        isFirstReporter: data.isFirstReporter,
      });
    } catch (error) {
      setError(error instanceof Error ? error.message : (language === 'en' ? "Failed to submit report" : "রিপোর্ট জমা দিতে ব্যর্থ"));
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{t('reportSubmitted')}</h2>
          <div className="mb-4">
            <div className="text-sm text-gray-600 mb-1">{t('caseNumber')}</div>
            <div className="font-mono text-lg font-bold text-blue-600">{success.caseNumber}</div>
          </div>
          
          {success.isFirstReporter ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <div className="font-semibold text-green-800 mb-1">{t('firstReporter')}</div>
              <div className="text-sm text-green-700">
                {language === 'en' 
                  ? "Upon verification, you will receive 20% commission directly to your registered mobile banking account. E-challan will be automatically issued to the accused."
                  : "যাচাইয়ের পর, আপনি আপনার নিবন্ধিত মোবাইল ব্যাংকিং অ্যাকাউন্টে ২০% কমিশন পাবেন। অভিযুক্তের কাছে স্বয়ংক্রিয়ভাবে ই-চালান পাঠানো হবে।"}
              </div>
            </div>
          ) : (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
              <div className="font-semibold text-orange-800 mb-1">{t('similarIncident')}</div>
              <div className="text-sm text-orange-700">
                {t('onlyFirstReporter')}
              </div>
            </div>
          )}

          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="font-semibold text-red-800 mb-1">
              {language === 'en' ? "⚠️ Important Warning" : "⚠️ গুরুত্বপূর্ণ সতর্কতা"}
            </div>
            <div className="text-sm text-red-700">
              {language === 'en' 
                ? "Submitting false reports is strictly prohibited and will result in financial penalties and legal action under government laws."
                : "মিথ্যা রিপোর্ট জমা দেওয়া কঠোরভাবে নিষিদ্ধ এবং এর ফলে আর্থিক জরিমানা ও সরকারি আইন অনুযায়ী আইনি ব্যবস্থা নেওয়া হবে।"}
            </div>
          </div>

          <button
            onClick={() => navigate("/dashboard")}
            className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            {t('backToDashboard')}
          </button>
        </div>
      </div>
    );
  }

  const availableViolations = getViolationsForVehicle(formData.vehicleType, language as 'en' | 'bn');

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={language === 'en' ? "Report Traffic Violation" : "ট্রাফিক আইন লঙ্ঘন রিপোর্ট করুন"} 
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">

          {/* Prerequisite Notice */}
          <div className="mb-6 bg-orange-50 border-2 border-orange-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-orange-700">
                <div className="font-semibold mb-2">
                  {language === 'en' ? "🚨 Eligibility & Submission Requirements:" : "🚨 যোগ্যতা ও জমা দেওয়ার শর্তাবলী:"}
                </div>
                <div className="space-y-2">
                  <div className="bg-white p-3 rounded border-l-4 border-orange-400">
                    <strong>{language === 'en' ? "Prerequisite:" : "পূর্বশর্ত:"}</strong>
                    <p className="mt-1">{language === 'en' 
                      ? "To submit a violation report, you must first complete the full signup process, including the registration and verification of your digital mobile banking account."
                      : "লঙ্ঘন রিপোর্ট জমা দিতে, আপনাকে প্রথমে সম্পূর্ণ সাইনআপ প্রক্রিয়া সম্পূর্ণ করতে হবে, যার মধ্যে আপনার ডিজিটাল মোবাইল ব্যাংকিং অ্যাকাউন্টের নিবন্ধন ও যাচাইকরণ রয়েছে।"}
                    </p>
                  </div>
                  <div className="bg-white p-3 rounded border-l-4 border-green-400">
                    <strong>{language === 'en' ? "Process for Successful Report:" : "সফল রিপোর্টের প্রক্রিয়া:"}</strong>
                    <ul className="mt-1 space-y-1 text-xs">
                      <li>• {language === 'en' ? "After submission, your report is verified by an authorized person" : "জমা দেওয়ার পর, আপনার রিপোর্ট একজন অনুমোদিত ব্যক্তি দ্বারা যাচাই করা হয়"}</li>
                      <li>• {language === 'en' ? "If accused is found guilty, system automatically creates an e-challan and sends via SMS/email" : "অভিযুক্ত দোষী সাব্যস্ত হলে, সিস্টেম স্বয়ংক্রিয়ভাবে একটি ই-চালান তৈরি করে এবং SMS/ইমেইলের মাধ্যমে পাঠায়"}</li>
                      <li>• {language === 'en' ? "You receive 20% commission in your provided digital banking account (bKash/Nagad/Rocket/Upay etc.)" : "আপনি আপনার প্রদত্ত ডিজিটাল ব্যাংকিং অ্যাকাউন্টে ২০% কমিশন পান (বিকাশ/নগদ/রকেট/উপায় ইত্যাদি)"}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-red-700">{error}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Primary Evidence (Photo/Video) */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "📸 Take Photo/Video for the Violation *" : "📸 লঙ্ঘনের জন্য ছবি/ভিডিও তুলুন *"}
              </label>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <label className="cursor-pointer">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors">
                    <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <div className="text-sm text-gray-600">
                      {language === 'en' ? "Take Photo" : "ছবি তুলুন"}
                    </div>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handlePrimaryFileChange}
                    className="hidden"
                  />
                </label>
                
                <label className="cursor-pointer">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors">
                    <Video className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <div className="text-sm text-gray-600">
                      {language === 'en' ? "Record Video" : "ভিডিও রেকর্ড"}
                    </div>
                  </div>
                  <input
                    type="file"
                    accept="video/*"
                    capture="environment"
                    onChange={handlePrimaryFileChange}
                    className="hidden"
                  />
                </label>
              </div>

              {previews.primary && (
                <div className="relative mb-4">
                  {evidenceFiles.primary?.type.startsWith('image/') ? (
                    <img src={previews.primary} alt="Primary evidence" className="max-h-64 mx-auto rounded-lg" />
                  ) : (
                    <video src={previews.primary} className="max-h-64 mx-auto rounded-lg" controls />
                  )}
                  <button
                    type="button"
                    onClick={() => removeFile('primary')}
                    className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                  >
                    {t('remove')}
                  </button>
                </div>
              )}
            </div>

            {/* Additional Evidence Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "📎 Upload Document/Photo/Video (Additional Evidence - Optional)" : "📎 নথি/ছবি/ভিডিও আপলোড করুন (অতিরিক্ত প্রমাণ - ঐচ্ছিক)"}
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <label className="cursor-pointer">
                  <span className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 inline-block">
                    {language === 'en' ? "Upload Files" : "ফাইল আপলোড"}
                  </span>
                  <input
                    type="file"
                    accept="image/*,video/*,.pdf,.doc,.docx"
                    multiple
                    onChange={handleAdditionalFileChange}
                    className="hidden"
                  />
                </label>
              </div>

              {previews.additional.length > 0 && (
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {previews.additional.map((preview, index) => (
                    <div key={index} className="relative">
                      {evidenceFiles.additional[index]?.type.startsWith('image/') ? (
                        <img src={preview} alt={`Additional ${index}`} className="w-full h-24 object-cover rounded" />
                      ) : evidenceFiles.additional[index]?.type.startsWith('video/') ? (
                        <video src={preview} className="w-full h-24 object-cover rounded" />
                      ) : (
                        <div className="w-full h-24 bg-gray-100 rounded flex items-center justify-center">
                          <FileImage className="w-6 h-6 text-gray-400" />
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() => removeFile('additional', index)}
                        className="absolute top-1 right-1 w-6 h-6 bg-red-600 text-white rounded-full text-xs hover:bg-red-700"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Vehicle Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "🚗 Vehicle Type *" : "🚗 যানবাহনের ধরন *"}
              </label>
              <select
                value={formData.vehicleType}
                onChange={(e) => {
                  setFormData({ ...formData, vehicleType: e.target.value, violationType: "" });
                }}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">
                  {language === 'en' ? "Select vehicle type" : "যানবাহনের ধরন নির্বাচন করুন"}
                </option>
                {VEHICLE_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {language === 'en' ? type : 
                      type === "Private Car" ? "প্রাইভেট কার" :
                      type === "Motorcycle" ? "মোটরসাইকেল" :
                      type === "Public Transport" ? "পাবলিক ট্রান্সপোর্ট" :
                      type === "E-Rickshaw" ? "ই-রিকশা" :
                      type === "Commercial Vehicle" ? "বাণিজ্যিক যানবাহন" : type
                    }
                  </option>
                ))}
              </select>
            </div>

            {/* Traffic Violation Type (Mandatory Section) */}
            {formData.vehicleType && (
              <div className="bg-amber-50 border-2 border-amber-400 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-red-600 text-lg font-bold">*</span>
                  <span className="font-semibold text-amber-800">
                    {language === 'en' ? "🚦 Traffic Violation Type (Mandatory Section)" : "🚦 ট্রাফিক লঙ্ঘনের ধরন (বাধ্যতামূলক অংশ)"}
                  </span>
                </div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? "Select the specific traffic violation:" : "নির্দিষ্ট ট্রাফিক লঙ্ঘন নির্বাচন করুন:"}
                </label>
                <select
                  value={formData.violationType}
                  onChange={(e) => setFormData({ ...formData, violationType: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">
                    {language === 'en' ? "Select traffic violation type" : "ট্রাফিক লঙ্ঘনের ধরন নির্বাচন করুন"}
                  </option>
                  {availableViolations.map((violation, index) => (
                    <option key={index} value={violation}>
                      {violation} {VIOLATION_FINES[violation] && `(Fine: ৳${VIOLATION_FINES[violation]})`}
                    </option>
                  ))}
                </select>
                {formData.violationType && VIOLATION_FINES[formData.violationType] && (
                  <div className="mt-2 bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <div className="text-sm text-orange-800">
                      <span className="font-semibold">
                        {language === 'en' ? "Your 20% Commission:" : "আপনার ২০% কমিশন:"}
                      </span> ৳
                      {(VIOLATION_FINES[formData.violationType] * 0.2).toFixed(0)} 
                      <span className="text-xs ml-1">
                        ({language === 'en' ? "if approved & guilty found" : "অনুমোদিত ও দোষী সাব্যস্ত হলে"})
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Vehicle Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "🔢 Vehicle Number (Optional)" : "🔢 যানবাহনের নম্বর (ঐচ্ছিক)"}
              </label>
              <input
                type="text"
                value={formData.vehicleNumber}
                onChange={(e) => setFormData({ ...formData, vehicleNumber: e.target.value })}
                placeholder={language === 'en' ? "e.g., Dhaka Metro-G-11-1234 (if visible)" : "যেমন, ঢাকা মেট্রো-গ-১১-১২৩৪ (দৃশ্যমান হলে)"}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'en' 
                  ? "Leave blank if vehicle number is not visible or readable"
                  : "যানবাহনের নম্বর দৃশ্যমান বা পাঠযোগ্য না হলে খালি রাখুন"}
              </p>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "📝 Description (Optional)" : "📝 বিবরণ (ঐচ্ছিক)"}
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder={language === 'en' ? "Provide additional details if needed..." : "প্রয়োজনে অতিরিক্ত বিবরণ দিন..."}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'en' ? "📍 Traffic Violation Location *" : "📍 ট্রাফিক লঙ্ঘনের স্থান *"}
              </label>
              {formData.address ? (
                <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <MapPin className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm text-gray-900">{formData.address}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {formData.latitude.toFixed(6)}, {formData.longitude.toFixed(6)}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, address: "", latitude: 0, longitude: 0 }))}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={getLocation}
                  className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  <MapPin className="w-5 h-5 inline-block mr-2" />
                  {language === 'en' ? "Get Current Location (Auto-detect)" : "বর্তমান অবস্থান নিন (স্বয়ংক্রিয়)"}
                </button>
              )}
            </div>

            {/* Warning */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-red-700">
                  <div className="font-semibold mb-1">
                    {language === 'en' ? "⚠️ Warning Against False Reports:" : "⚠️ মিথ্যা রিপোর্টের বিরুদ্ধে সতর্কতা:"}
                  </div>
                  {language === 'en' 
                    ? "Submitting false or misleading reports is strictly prohibited and will lead to financial penalties and/or prosecution under government laws. Please verify all information carefully before submitting."
                    : "মিথ্যা বা বিভ্রান্তিকর রিপোর্ট জমা দেওয়া কঠোরভাবে নিষিদ্ধ এবং এর ফলে আর্থিক জরিমানা এবং/অথবা সরকারি আইনের অধীনে মামলা হবে। জমা দেওয়ার আগে সমস্ত তথ্য সতর্কতার সাথে যাচাই করুন।"}
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !evidenceFiles.primary || !formData.address || !formData.vehicleType || !formData.violationType}
              className="w-full px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all font-bold text-lg"
            >
              {loading ? 
                (language === 'en' ? "Submitting Report..." : "রিপোর্ট জমা দেওয়া হচ্ছে...") : 
                (language === 'en' ? "Submit Traffic Violation Report" : "ট্রাফিক লঙ্ঘন রিপোর্ট জমা দিন")
              }
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
