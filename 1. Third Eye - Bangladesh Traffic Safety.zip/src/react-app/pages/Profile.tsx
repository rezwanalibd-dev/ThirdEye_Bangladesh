import { useEffect, useState, useRef } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { 
  User, 
  Phone, 
  CreditCard, 
  Shield, 
  LogOut, 
  HelpCircle,
  Award,
  TrendingUp,
  CheckCircle,
  XCircle,
  Clock,
  Globe,
  Camera,
  Settings,
  Trash2,
  Lock,
  ArrowLeft,
  AlertCircle,
  UserX
} from "lucide-react";
import type { User as AppUser } from "@/shared/types";
import MobileLayout from "@/react-app/components/MobileLayout";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import { useTestAuth } from "@/react-app/hooks/useTestAuth";

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const { testUser, logout: testLogout } = useTestAuth();
  const navigate = useNavigate();
  const { language, setLanguage } = useLanguage();
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  
  // Modal states
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [showAccountActions, setShowAccountActions] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Password change states
  const [newContact, setNewContact] = useState('');
  const [contactType, setContactType] = useState<'email' | 'mobile'>('email');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  
  // Profile picture upload
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  useEffect(() => {
    async function loadUserData() {
      try {
        const response = await fetch("/api/users/me");
        const data = await response.json();
        setAppUser(data?.appUser || null);
        
        // Load profile picture if exists
        if (data?.appUser?.profile_image_key) {
          const imageResponse = await fetch(`/api/users/profile-image/${data.appUser.id}`);
          if (imageResponse.ok) {
            const imageBlob = await imageResponse.blob();
            const imageUrl = URL.createObjectURL(imageBlob);
            setProfileImage(imageUrl);
          }
        }
      } catch (error) {
        console.error("Failed to load user data:", error);
      } finally {
        setLoading(false);
      }
    }

    loadUserData();
  }, []);

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type and size
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      alert('Image size should be less than 5MB');
      return;
    }

    setIsUploadingImage(true);

    try {
      const formData = new FormData();
      formData.append('profileImage', file);

      const response = await fetch('/api/users/profile-image', {
        method: 'POST',
        body: formData,
        headers: user ? {} : { 'X-Session-Token': localStorage.getItem('temp_session_token') || '' }
      });

      if (response.ok) {
        // Create preview URL
        const imageUrl = URL.createObjectURL(file);
        setProfileImage(imageUrl);
      } else {
        alert('Failed to upload profile picture');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Error uploading profile picture');
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleSendPasswordOtp = async () => {
    setPasswordError('');
    setIsChangingPassword(true);

    try {
      const response = await fetch('/api/users/send-password-otp', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(user ? {} : { 'X-Session-Token': localStorage.getItem('temp_session_token') || '' })
        },
        body: JSON.stringify({
          newContact,
          contactType
        })
      });

      const data = await response.json();

      if (response.ok) {
        setIsOtpSent(true);
        setPasswordSuccess(`OTP sent to your new ${contactType === 'email' ? 'email' : 'mobile number'}`);
      } else {
        setPasswordError(data.error || 'Failed to send OTP');
      }
    } catch (error) {
      setPasswordError('Network error. Please try again.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleVerifyPasswordOtp = async () => {
    setPasswordError('');
    setIsChangingPassword(true);

    try {
      const response = await fetch('/api/users/change-contact', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(user ? {} : { 'X-Session-Token': localStorage.getItem('temp_session_token') || '' })
        },
        body: JSON.stringify({
          newContact,
          contactType,
          otp
        })
      });

      const data = await response.json();

      if (response.ok) {
        setPasswordSuccess('Contact information updated successfully!');
        setShowPasswordChange(false);
        setIsOtpSent(false);
        setOtp('');
        setNewContact('');
        // Reload user data
        window.location.reload();
      } else {
        setPasswordError(data.error || 'Invalid OTP');
      }
    } catch (error) {
      setPasswordError('Network error. Please try again.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleDeactivateAccount = async () => {
    try {
      const response = await fetch('/api/users/deactivate', {
        method: 'POST',
        headers: user ? {} : { 'X-Session-Token': localStorage.getItem('temp_session_token') || '' }
      });

      if (response.ok) {
        alert('Account deactivated successfully. You can reactivate by logging in again.');
        handleLogout();
      } else {
        alert('Failed to deactivate account');
      }
    } catch (error) {
      alert('Error deactivating account');
    }
  };

  const handleDeleteAccount = async () => {
    try {
      const response = await fetch('/api/users/delete', {
        method: 'DELETE',
        headers: user ? {} : { 'X-Session-Token': localStorage.getItem('temp_session_token') || '' }
      });

      if (response.ok) {
        alert('Account deleted permanently.');
        handleLogout();
      } else {
        alert('Failed to delete account');
      }
    } catch (error) {
      alert('Error deleting account');
    }
  };

  const handleLogout = () => {
    if (testUser) {
      testLogout();
    } else {
      logout();
    }
    localStorage.removeItem('temp_session_token');
    localStorage.removeItem('auth_identifier');
    localStorage.removeItem('auth_type');
    navigate("/");
  };

  if (loading) {
    return (
      <MobileLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </MobileLayout>
    );
  }

  const getKycStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'text-green-600 bg-green-50 border-green-200';
      case 'rejected': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-orange-600 bg-orange-50 border-orange-200';
    }
  };

  const getKycStatusText = (status: string) => {
    switch (status) {
      case 'verified': return language === 'en' ? 'Verified' : 'যাচাইকৃত';
      case 'rejected': return language === 'en' ? 'Rejected' : 'প্রত্যাখ্যাত';
      default: return language === 'en' ? 'Pending' : 'মুলতুবি';
    }
  };

  const getKycStatusIcon = (status: string) => {
    switch (status) {
      case 'verified': return <CheckCircle className="w-5 h-5" />;
      case 'rejected': return <XCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const successRate = appUser?.total_reports ? 
    ((appUser.approved_reports || 0) / appUser.total_reports * 100).toFixed(0) : '0';

  return (
    <MobileLayout>
      <div className="bg-gray-50 min-h-screen">
        {/* Header with Back Button */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h1 className="text-xl font-bold">
                {language === 'en' ? 'Profile' : 'প্রোফাইল'}
              </h1>
            </div>
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded-full text-sm"
            >
              <Globe className="w-4 h-4" />
              {language === 'en' ? 'বাংলা' : 'English'}
            </button>
          </div>

          {/* User Info with Profile Picture */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center overflow-hidden">
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-10 h-10 text-white" />
                )}
              </div>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploadingImage}
                className="absolute -bottom-1 -right-1 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors"
              >
                <Camera className="w-4 h-4 text-white" />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
            <div>
              <h2 className="text-xl font-bold">
                {user?.google_user_data?.name || testUser?.userType || 'User'}
              </h2>
              <p className="text-white/80 text-sm">
                {testUser ? 
                  `${testUser.userType.toUpperCase()} (Test Mode)` :
                  (language === 'en' ? 'Citizen Reporter' : 'নাগরিক রিপোর্টার')
                }
              </p>
            </div>
          </div>
        </div>

        <div className="px-6 py-6 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    {appUser?.total_reports || 0}
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Total Reports' : 'মোট রিপোর্ট'}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Award className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    ৳{appUser?.total_rewards?.toFixed(0) || 0}
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Total Earnings' : 'মোট আয়'}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    {appUser?.approved_reports || 0}
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Approved' : 'অনুমোদিত'}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    {successRate}%
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Success Rate' : 'সফলতার হার'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Account Status */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h3 className="font-semibold text-gray-900 mb-4">
              {language === 'en' ? 'Account Status' : 'অ্যাকাউন্ট স্ট্যাটাস'}
            </h3>
            
            <div className="space-y-3">
              {/* KYC Status */}
              <div className="flex items-center justify-between">
                <span className="text-gray-600">
                  {language === 'en' ? 'Identity Verification' : 'পরিচয় যাচাই'}
                </span>
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full border text-sm font-medium ${getKycStatusColor(appUser?.kyc_status || 'pending')}`}>
                  {getKycStatusIcon(appUser?.kyc_status || 'pending')}
                  {getKycStatusText(appUser?.kyc_status || 'pending')}
                </div>
              </div>

              {/* Account Status */}
              <div className="flex items-center justify-between">
                <span className="text-gray-600">
                  {language === 'en' ? 'Account Status' : 'অ্যাকাউন্ট স্ট্যাটাস'}
                </span>
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full border text-sm font-medium ${
                  appUser?.account_status === 'active' ? 'text-green-600 bg-green-50 border-green-200' : 'text-red-600 bg-red-50 border-red-200'
                }`}>
                  <CheckCircle className="w-4 h-4" />
                  {appUser?.account_status === 'active' ? 
                    (language === 'en' ? 'Active' : 'সক্রিয়') : 
                    (language === 'en' ? 'Restricted' : 'সীমাবদ্ধ')
                  }
                </div>
              </div>

              {/* Phone Number */}
              {appUser?.phone_number && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">
                    {language === 'en' ? 'Phone Number' : 'ফোন নম্বর'}
                  </span>
                  <span className="text-gray-900 font-medium">
                    {appUser.phone_number}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Menu Items */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 divide-y divide-gray-100">
            {appUser?.kyc_status !== 'verified' && (
              <button
                onClick={() => navigate('/kyc')}
                className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <Shield className="w-5 h-5 text-orange-600" />
                </div>
                <div className="flex-1 text-left">
                  <div className="font-medium text-gray-900">
                    {language === 'en' ? 'Complete Verification' : 'যাচাইকরণ সম্পূর্ণ করুন'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Verify your identity to start reporting' : 'রিপোর্ট করা শুরু করতে আপনার পরিচয় যাচাই করুন'}
                  </div>
                </div>
              </button>
            )}

            {appUser?.has_pending_penalties && (
              <button
                onClick={() => navigate('/penalties')}
                className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-red-600" />
                </div>
                <div className="flex-1 text-left">
                  <div className="font-medium text-gray-900">
                    {language === 'en' ? 'Pending Penalties' : 'বকেয়া জরিমানা'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {language === 'en' ? 'Clear your pending penalties' : 'আপনার বকেয়া জরিমানা পরিশোধ করুন'}
                  </div>
                </div>
              </button>
            )}

            <button
              onClick={() => navigate('/emergency')}
              className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Phone className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-medium text-gray-900">
                  {language === 'en' ? 'Emergency Contacts' : 'জরুরি যোগাযোগ'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Quick access to emergency services' : 'জরুরি সেবায় দ্রুত প্রবেশ'}
                </div>
              </div>
            </button>

            <button
              onClick={() => navigate('/traffic-rules')}
              className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <HelpCircle className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-medium text-gray-900">
                  {language === 'en' ? 'Traffic Rules & Fines' : 'ট্রাফিক নিয়ম ও জরিমানা'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Learn about traffic laws' : 'ট্রাফিক আইন সম্পর্কে জানুন'}
                </div>
              </div>
            </button>

            {/* Change Password/Contact */}
            <button
              onClick={() => setShowPasswordChange(true)}
              className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Lock className="w-5 h-5 text-purple-600" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-medium text-gray-900">
                  {language === 'en' ? 'Change Contact Info' : 'যোগাযোগের তথ্য পরিবর্তন'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Update your email or phone number' : 'আপনার ইমেইল বা ফোন নম্বর আপডেট করুন'}
                </div>
              </div>
            </button>

            {/* Account Settings */}
            <button
              onClick={() => setShowAccountActions(true)}
              className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <Settings className="w-5 h-5 text-gray-600" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-medium text-gray-900">
                  {language === 'en' ? 'Account Settings' : 'অ্যাকাউন্ট সেটিংস'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Manage your account' : 'আপনার অ্যাকাউন্ট পরিচালনা করুন'}
                </div>
              </div>
            </button>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-3 bg-red-600 text-white py-4 rounded-xl hover:bg-red-700 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            {language === 'en' ? 'Logout' : 'লগআউট'}
          </button>
        </div>
      </div>

      {/* Change Password Modal */}
      {showPasswordChange && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              {language === 'en' ? 'Change Contact Information' : 'যোগাযোগের তথ্য পরিবর্তন করুন'}
            </h3>

            {!isOtpSent ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === 'en' ? 'Contact Type' : 'যোগাযোগের ধরন'}
                  </label>
                  <select
                    value={contactType}
                    onChange={(e) => setContactType(e.target.value as 'email' | 'mobile')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="email">{language === 'en' ? 'Email Address' : 'ইমেইল ঠিকানা'}</option>
                    <option value="mobile">{language === 'en' ? 'Mobile Number' : 'মোবাইল নম্বর'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {contactType === 'email' 
                      ? (language === 'en' ? 'New Email Address' : 'নতুন ইমেইল ঠিকানা')
                      : (language === 'en' ? 'New Mobile Number' : 'নতুন মোবাইল নম্বর')
                    }
                  </label>
                  <input
                    type={contactType === 'email' ? 'email' : 'tel'}
                    value={newContact}
                    onChange={(e) => setNewContact(e.target.value)}
                    placeholder={contactType === 'email' ? 'your@newemail.com' : '+880 1XXX-XXXXXX'}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {passwordError && (
                  <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm">{passwordError}</span>
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowPasswordChange(false)}
                    className="flex-1 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    {language === 'en' ? 'Cancel' : 'বাতিল'}
                  </button>
                  <button
                    onClick={handleSendPasswordOtp}
                    disabled={isChangingPassword || !newContact}
                    className="flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300"
                  >
                    {isChangingPassword 
                      ? (language === 'en' ? 'Sending...' : 'পাঠানো হচ্ছে...') 
                      : (language === 'en' ? 'Send OTP' : 'ওটিপি পাঠান')
                    }
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {passwordSuccess && (
                  <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg">
                    <CheckCircle className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm">{passwordSuccess}</span>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === 'en' ? 'Enter OTP Code' : 'ওটিপি কোড লিখুন'}
                  </label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-center text-xl tracking-widest font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                    maxLength={6}
                  />
                </div>

                {passwordError && (
                  <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm">{passwordError}</span>
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowPasswordChange(false);
                      setIsOtpSent(false);
                      setOtp('');
                      setPasswordError('');
                      setPasswordSuccess('');
                    }}
                    className="flex-1 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    {language === 'en' ? 'Cancel' : 'বাতিল'}
                  </button>
                  <button
                    onClick={handleVerifyPasswordOtp}
                    disabled={isChangingPassword || otp.length !== 6}
                    className="flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300"
                  >
                    {isChangingPassword 
                      ? (language === 'en' ? 'Verifying...' : 'যাচাই হচ্ছে...') 
                      : (language === 'en' ? 'Verify' : 'যাচাই করুন')
                    }
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Account Actions Modal */}
      {showAccountActions && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              {language === 'en' ? 'Account Settings' : 'অ্যাকাউন্ট সেটিংস'}
            </h3>

            <div className="space-y-3">
              <button
                onClick={() => {
                  handleDeactivateAccount();
                  setShowAccountActions(false);
                }}
                className="w-full flex items-center gap-3 p-4 bg-orange-50 border border-orange-200 rounded-lg hover:bg-orange-100 transition-colors"
              >
                <UserX className="w-5 h-5 text-orange-600" />
                <div className="flex-1 text-left">
                  <div className="font-medium text-orange-900">
                    {language === 'en' ? 'Deactivate Account' : 'অ্যাকাউন্ট নিষ্ক্রিয় করুন'}
                  </div>
                  <div className="text-sm text-orange-700">
                    {language === 'en' ? 'Temporarily disable your account' : 'সাময়িকভাবে আপনার অ্যাকাউন্ট বন্ধ করুন'}
                  </div>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowAccountActions(false);
                  setShowDeleteConfirm(true);
                }}
                className="w-full flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-5 h-5 text-red-600" />
                <div className="flex-1 text-left">
                  <div className="font-medium text-red-900">
                    {language === 'en' ? 'Delete Account' : 'অ্যাকাউন্ট ডিলিট করুন'}
                  </div>
                  <div className="text-sm text-red-700">
                    {language === 'en' ? 'Permanently delete your account' : 'স্থায়ীভাবে আপনার অ্যাকাউন্ট ডিলিট করুন'}
                  </div>
                </div>
              </button>
            </div>

            <div className="mt-6">
              <button
                onClick={() => setShowAccountActions(false)}
                className="w-full py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                {language === 'en' ? 'Cancel' : 'বাতিল'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-red-600" />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {language === 'en' ? 'Delete Account' : 'অ্যাকাউন্ট ডিলিট করুন'}
              </h3>
              
              <p className="text-gray-600 mb-6">
                {language === 'en' 
                  ? 'Are you sure you want to permanently delete your account? This action cannot be undone and all your data will be lost.'
                  : 'আপনি কি নিশ্চিত যে আপনার অ্যাকাউন্ট স্থায়ীভাবে ডিলিট করতে চান? এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না এবং আপনার সমস্ত ডেটা হারিয়ে যাবে।'
                }
              </p>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  {language === 'en' ? 'Cancel' : 'বাতিল'}
                </button>
                <button
                  onClick={() => {
                    handleDeleteAccount();
                    setShowDeleteConfirm(false);
                  }}
                  className="flex-1 py-2 px-4 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  {language === 'en' ? 'Delete' : 'ডিলিট'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
