import { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw, Trash2, Phone, Mail, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router';

interface OTP {
  identifier: string;
  identifierType: string;
  code: string;
  createdAt: string;
  expiresAt: string;
  verified: boolean;
}

interface TestingStatus {
  isDevelopmentMode: boolean;
  message: string;
  availableEndpoints: string[];
}

export default function TestingDashboard() {
  const navigate = useNavigate();
  const [otps, setOtps] = useState<OTP[]>([]);
  const [status, setStatus] = useState<TestingStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [cleaning, setCleaning] = useState(false);

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/testing/status');
      const data = await response.json();
      setStatus(data);
    } catch (error) {
      console.error('Failed to fetch testing status:', error);
    }
  };

  const fetchOTPs = async () => {
    try {
      const response = await fetch('/api/testing/otps');
      if (response.ok) {
        const data = await response.json();
        setOtps(data.otps || []);
      }
    } catch (error) {
      console.error('Failed to fetch OTPs:', error);
    }
  };

  const refreshOTPs = async () => {
    setRefreshing(true);
    await fetchOTPs();
    setRefreshing(false);
  };

  const cleanupOTPs = async () => {
    setCleaning(true);
    try {
      const response = await fetch('/api/testing/cleanup-otps', {
        method: 'POST'
      });
      if (response.ok) {
        const data = await response.json();
        alert(`Cleaned up ${data.clearedCount} expired OTP codes`);
        await fetchOTPs();
      }
    } catch (error) {
      console.error('Failed to cleanup OTPs:', error);
    }
    setCleaning(false);
  };

  const cleanupTestData = async () => {
    setCleaning(true);
    try {
      const response = await fetch('/api/testing/cleanup-test-data', {
        method: 'POST'
      });
      if (response.ok) {
        const data = await response.json();
        alert(`Cleaned up ${data.clearedCount} test records`);
      }
    } catch (error) {
      console.error('Failed to cleanup test data:', error);
    }
    setCleaning(false);
  };

  useEffect(() => {
    const initialize = async () => {
      await fetchStatus();
      await fetchOTPs();
      setLoading(false);
    };
    initialize();
  }, []);

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleString();
  };

  const isExpired = (expiresAt: string) => {
    return new Date(expiresAt) < new Date();
  };

  const testAsUserType = async (userType: 'citizen' | 'dmp' | 'brta') => {
    try {
      const response = await fetch('/api/testing/create-test-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userType }),
      });

      if (response.ok) {
        const data = await response.json();
        
        // Store the test session data
        localStorage.setItem('test_session_token', data.sessionToken);
        localStorage.setItem('test_user_type', userType);
        localStorage.setItem('test_user_id', data.userId);
        
        // Navigate based on user type
        if (userType === 'citizen') {
          navigate('/dashboard');
        } else {
          navigate('/dmp-dashboard');
        }
      } else {
        alert('Failed to create test session');
      }
    } catch (error) {
      console.error('Error creating test session:', error);
      alert('Error creating test session');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading testing dashboard...</p>
        </div>
      </div>
    );
  }

  if (!status?.isDevelopmentMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100 flex items-center justify-center">
        <div className="text-center p-8">
          <XCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-red-700 mb-2">Production Mode</h1>
          <p className="text-red-600 mb-4">Testing dashboard is not available in production mode</p>
          <button
            onClick={() => navigate('/')}
            className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => navigate('/')}
              className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Home
            </button>
            <div className="flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
              <CheckCircle className="h-4 w-4 mr-1" />
              Development Mode
            </div>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Testing Dashboard
          </h1>
          <p className="text-gray-600">
            Test OTP authentication flows before publishing
          </p>
        </div>

        {/* Testing Options */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Quick Testing Access */}
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl shadow-lg p-6 text-white">
            <h2 className="text-xl font-bold mb-4">
              🚀 Quick Testing Access (No OTP)
            </h2>
            <p className="text-green-100 mb-4">
              Skip authentication and directly test all app features
            </p>
            <div className="space-y-3">
              <button
                onClick={() => testAsUserType('citizen')}
                className="w-full bg-white text-green-600 px-4 py-2 rounded-lg font-medium hover:bg-green-50 transition-colors"
              >
                Test as Citizen
              </button>
              <button
                onClick={() => testAsUserType('dmp')}
                className="w-full bg-white text-green-600 px-4 py-2 rounded-lg font-medium hover:bg-green-50 transition-colors"
              >
                Test as DMP Officer
              </button>
              <button
                onClick={() => testAsUserType('brta')}
                className="w-full bg-white text-green-600 px-4 py-2 rounded-lg font-medium hover:bg-green-50 transition-colors"
              >
                Test as BRTA Officer
              </button>
            </div>
          </div>

          {/* OTP Testing */}
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg p-6 text-white">
            <h2 className="text-xl font-bold mb-4">
              🔐 OTP Authentication Testing
            </h2>
            <div className="space-y-3 text-blue-100">
              <div className="flex items-start">
                <div className="bg-blue-400 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">1</div>
                <p>Go to Sign Up and choose Mobile or Email option</p>
              </div>
              <div className="flex items-start">
                <div className="bg-blue-400 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">2</div>
                <p>Enter any valid mobile number or email</p>
              </div>
              <div className="flex items-start">
                <div className="bg-blue-400 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">3</div>
                <p>Check OTP codes below when prompted</p>
              </div>
            </div>
          </div>
        </div>

        {/* OTP List */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">
              Recent OTP Codes
            </h2>
            <div className="flex space-x-3">
              <button
                onClick={refreshOTPs}
                disabled={refreshing}
                className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </button>
              <button
                onClick={cleanupOTPs}
                disabled={cleaning}
                className="flex items-center bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Cleanup Expired
              </button>
              <button
                onClick={cleanupTestData}
                disabled={cleaning}
                className="flex items-center bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Cleanup Test Data
              </button>
            </div>
          </div>

          {otps.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">
                No OTP codes generated yet
              </p>
              <p className="text-sm text-gray-400">
                Try signing up with mobile or email to generate test OTPs
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {otps.map((otp, index) => (
                <div
                  key={index}
                  className={`border-2 rounded-lg p-4 transition-all ${
                    isExpired(otp.expiresAt)
                      ? 'border-red-200 bg-red-50'
                      : otp.verified
                      ? 'border-green-200 bg-green-50'
                      : 'border-blue-200 bg-blue-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        {otp.identifierType === 'mobile' ? (
                          <Phone className="h-5 w-5 text-blue-600 mr-2" />
                        ) : (
                          <Mail className="h-5 w-5 text-blue-600 mr-2" />
                        )}
                        <span className="font-medium text-gray-800">{otp.identifier}</span>
                      </div>
                      <div className="text-2xl font-mono font-bold text-blue-600 bg-white px-3 py-1 rounded border">
                        {otp.code}
                      </div>
                    </div>
                    <div className="text-right text-sm">
                      <div className={`font-medium ${
                        isExpired(otp.expiresAt)
                          ? 'text-red-600'
                          : otp.verified
                          ? 'text-green-600'
                          : 'text-blue-600'
                      }`}>
                        {isExpired(otp.expiresAt)
                          ? 'Expired'
                          : otp.verified
                          ? 'Used'
                          : 'Active'
                        }
                      </div>
                      <div className="text-gray-500">
                        Expires: {formatTime(otp.expiresAt)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Note */}
        <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800 text-sm">
            <strong>Note:</strong> This testing dashboard is only available in development mode and will be automatically disabled in production.
          </p>
        </div>
      </div>
    </div>
  );
}
