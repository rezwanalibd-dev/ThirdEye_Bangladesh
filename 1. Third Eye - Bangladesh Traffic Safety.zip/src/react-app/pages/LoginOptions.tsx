import { useState } from "react";
import { useNavigate } from "react-router";
import { Mail, Phone, ArrowLeft, Chrome, AlertCircle, CheckCircle } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import { useLanguage } from "@/react-app/hooks/useLanguage";

export default function LoginOptions() {
  const navigate = useNavigate();
  const { redirectToLogin } = useAuth();
  const { language } = useLanguage();
  const [authMethod, setAuthMethod] = useState<'email' | 'mobile' | null>(null);
  const [identifier, setIdentifier] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [timeLeft, setTimeLeft] = useState(120);

  const handleSendOtp = async () => {
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier,
          identifierType: authMethod,
          isLogin: true
        })
      });

      const data = await response.json();

      if (response.ok) {
        setIsOtpSent(true);
        setSuccess(`OTP sent to your ${authMethod === 'email' ? 'email' : 'mobile number'}`);
        startTimer();
      } else {
        setError(data.error || 'Failed to send OTP');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier,
          identifierType: authMethod,
          code: otp,
          isLogin: true
        })
      });

      const data = await response.json();

      if (response.ok) {
        // Store session token in localStorage
        localStorage.setItem('temp_session_token', data.sessionToken);
        localStorage.setItem('auth_identifier', identifier);
        localStorage.setItem('auth_type', authMethod!);
        
        // Check if user needs onboarding
        if (data.needsOnboarding) {
          navigate('/onboarding');
        } else {
          navigate('/dashboard');
        }
      } else {
        setError(data.error || 'Invalid OTP');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const startTimer = () => {
    setTimeLeft(120);
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleGoogleLogin = () => {
    redirectToLogin();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-white flex flex-col px-6 py-8">
      <button
        onClick={() => authMethod ? setAuthMethod(null) : navigate("/")}
        className="flex items-center gap-2 text-gray-700 mb-8 hover:text-gray-900"
      >
        <ArrowLeft className="w-5 h-5" />
        {language === 'en' ? 'Back' : 'ফিরে যান'}
      </button>

      <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === 'en' ? 'Welcome Back' : 'স্বাগতম'}
          </h1>
          <p className="text-gray-600">
            {language === 'en' 
              ? 'Choose your preferred login method' 
              : 'আপনার পছন্দের লগইন পদ্ধতি চয়ন করুন'}
          </p>
        </div>

        {!authMethod ? (
          // Method Selection
          <div className="space-y-4">
            <button
              onClick={() => setAuthMethod('email')}
              className="w-full flex items-center gap-4 p-5 bg-gray-50 border-2 border-gray-200 rounded-2xl hover:bg-gray-100 hover:border-gray-300 transition-all"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Mail className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-left flex-1">
                <div className="font-semibold text-gray-900">
                  {language === 'en' ? 'Email Address' : 'ইমেইল ঠিকানা'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Login with email & OTP' : 'ইমেইল এবং ওটিপি দিয়ে লগইন করুন'}
                </div>
              </div>
            </button>

            <button
              onClick={() => setAuthMethod('mobile')}
              className="w-full flex items-center gap-4 p-5 bg-gray-50 border-2 border-gray-200 rounded-2xl hover:bg-gray-100 hover:border-gray-300 transition-all"
            >
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Phone className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-left flex-1">
                <div className="font-semibold text-gray-900">
                  {language === 'en' ? 'Mobile Number' : 'মোবাইল নম্বর'}
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? 'Login with mobile & OTP' : 'মোবাইল এবং ওটিপি দিয়ে লগইন করুন'}
                </div>
              </div>
            </button>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white text-gray-500">
                  {language === 'en' ? 'or continue with' : 'অথবা চালিয়ে যান'}
                </span>
              </div>
            </div>

            <button
              onClick={handleGoogleLogin}
              className="w-full flex items-center justify-center gap-3 p-5 bg-white border-2 border-gray-300 rounded-2xl hover:bg-gray-50 transition-all"
            >
              <Chrome className="w-6 h-6 text-gray-700" />
              <span className="font-semibold text-gray-900">
                {language === 'en' ? 'Google Account' : 'গুগল অ্যাকাউন্ট'}
              </span>
            </button>

            <div className="text-center mt-6">
              <p className="text-gray-600 text-sm">
                {language === 'en' ? "Don't have an account?" : 'অ্যাকাউন্ট নেই?'}{' '}
                <button
                  onClick={() => navigate('/signup')}
                  className="text-blue-600 font-semibold hover:underline"
                >
                  {language === 'en' ? 'Sign up' : 'সাইনআপ করুন'}
                </button>
              </p>
            </div>
          </div>
        ) : !isOtpSent ? (
          // Enter Email/Mobile
          <div className="space-y-6">
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                {authMethod === 'email' 
                  ? (language === 'en' ? 'Email Address' : 'ইমেইল ঠিকানা')
                  : (language === 'en' ? 'Mobile Number' : 'মোবাইল নম্বর')}
              </label>
              <input
                type={authMethod === 'email' ? 'email' : 'tel'}
                placeholder={authMethod === 'email' ? 'your@email.com' : '+880 1XXX-XXXXXX'}
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">{error}</span>
              </div>
            )}

            <button
              onClick={handleSendOtp}
              disabled={isLoading || !identifier}
              className="w-full py-4 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading 
                ? (language === 'en' ? 'Sending...' : 'পাঠানো হচ্ছে...') 
                : (language === 'en' ? 'Send OTP' : 'ওটিপি পাঠান')}
            </button>
          </div>
        ) : (
          // Enter OTP
          <div className="space-y-6">
            {success && (
              <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg">
                <CheckCircle className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">{success}</span>
              </div>
            )}

            <div>
              <label className="block text-gray-700 font-medium mb-2">
                {language === 'en' ? 'Enter OTP Code' : 'ওটিপি কোড লিখুন'}
              </label>
              <input
                type="text"
                placeholder="000000"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                className="w-full px-4 py-4 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 text-center text-2xl tracking-widest font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                maxLength={6}
              />
              <p className="text-center text-sm text-gray-600 mt-2">
                {language === 'en' ? 'Sent to' : 'পাঠানো হয়েছে'} {identifier}
              </p>
            </div>

            {timeLeft > 0 ? (
              <div className="text-center">
                <p className="text-gray-600 text-sm">
                  {language === 'en' ? 'Time remaining:' : 'অবশিষ্ট সময়:'}{' '}
                  <span className="font-mono font-bold text-blue-600">{formatTime(timeLeft)}</span>
                </p>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-red-600 text-sm mb-2">
                  {language === 'en' ? 'OTP expired' : 'ওটিপি মেয়াদ শেষ'}
                </p>
                <button
                  onClick={() => {
                    setIsOtpSent(false);
                    setOtp('');
                    setSuccess('');
                    setError('');
                  }}
                  className="text-blue-600 font-semibold hover:underline"
                >
                  {language === 'en' ? 'Send new OTP' : 'নতুন ওটিপি পাঠান'}
                </button>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">{error}</span>
              </div>
            )}

            <button
              onClick={handleVerifyOtp}
              disabled={isLoading || otp.length !== 6 || timeLeft === 0}
              className="w-full py-4 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading 
                ? (language === 'en' ? 'Verifying...' : 'যাচাই হচ্ছে...') 
                : (language === 'en' ? 'Verify & Login' : 'যাচাই করুন এবং লগইন করুন')}
            </button>

            <button
              onClick={() => {
                setIsOtpSent(false);
                setOtp('');
                setSuccess('');
                setError('');
              }}
              className="w-full text-gray-600 hover:text-gray-900 text-sm"
            >
              {language === 'en' ? 'Change email/mobile' : 'ইমেইল/মোবাইল পরিবর্তন করুন'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
