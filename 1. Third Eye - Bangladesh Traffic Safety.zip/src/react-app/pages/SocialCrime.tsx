import { useState } from "react";
import { useNavigate } from "react-router";
import { Camera, Video, Upload, MapPin, AlertCircle, CheckCircle, UserX, User, FileImage, BookOpen, ChevronDown, ChevronUp } from "lucide-react";
import { getSocialCrimeCategories } from "@/shared/types";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import MobileHeader from "@/react-app/components/MobileHeader";

// Educational content with punishments & penalties
const SOCIAL_CRIME_EDUCATION = {
  en: {
    "Crimes of Violence / Person-centric": {
      definition: "Offences that cause physical harm, serious bodily injury, sexual violence, or death",
      punishments: [
        "Murder (Section 302, Penal Code): Death penalty or life imprisonment + fine",
        "Rape (Section 376, Penal Code): 10 years to life imprisonment + fine", 
        "Assault (Section 325, Penal Code): Up to 7 years imprisonment + fine",
        "Kidnapping (Section 363, Penal Code): Up to 10 years imprisonment + fine"
      ]
    },
    "Property Crimes": {
      definition: "Theft, burglary, robbery, motor-vehicle theft, arson and land-grab offences",
      punishments: [
        "Robbery/Dacoity (Section 392, Penal Code): Up to 10 years imprisonment + fine",
        "Theft (Section 379, Penal Code): Up to 3 years imprisonment + fine",
        "Arson (Section 435, Penal Code): Up to 10 years imprisonment + fine"
      ]
    },
    "Economic / White-collar Crimes": {
      definition: "Corruption, bribery, financial fraud, money laundering, tax evasion",
      punishments: [
        "Corruption (ACC Act): 7-14 years imprisonment + fine",
        "Money Laundering (Money Laundering Prevention Act): 4-12 years imprisonment",
        "Tax Evasion (Income Tax Ordinance): Up to 5 years imprisonment + 500% penalty"
      ]
    },
    "Crimes against Social / Moral Legislation": {
      definition: "Sexual harassment, dowry harassment, child marriage, domestic violence",
      punishments: [
        "Child Marriage (Child Marriage Restraint Act): 2 years imprisonment + fine",
        "Dowry Harassment (Dowry Prohibition Act): 1-5 years imprisonment + fine",
        "Sexual Harassment (Nari O Shishu Nirjatan Act): 5-10 years imprisonment"
      ]
    },
    "Organised & High-Tech Crimes": {
      definition: "Organised drug trafficking, cybercrime, trafficking networks",
      punishments: [
        "Cybercrime (Digital Security Act): 5-14 years imprisonment + fine",
        "Drug Trafficking (Narcotics Control Act): 2 years to death penalty",
        "Human Trafficking (Human Trafficking Act): 5 years to life imprisonment"
      ]
    },
    "Crimes against Public Order / State / Society": {
      definition: "Terrorism, communal violence, political violence, election offences",
      punishments: [
        "Terrorism (Anti-Terrorism Act): 5 years to death penalty",
        "Election Violence (Representation of People Order): 2-7 years imprisonment"
      ]
    }
  },
  bn: {
    "Crimes of Violence / Person-centric": {
      definition: "শারীরিক আঘাত, গুরুতর আহত করা, যৌন নির্যাতন বা মানব মৃত্যুর মতো অপরাধ",
      punishments: [
        "হত্যা (দণ্ডবিধি ৩০২): মৃত্যুদণ্ড বা যাবজ্জীবন কারাদণ্ড + জরিমানা",
        "ধর্ষণ (দণ্ডবিধি ৩৭৬): ১০ বছর থেকে যাবজ্জীবন কারাদণ্ড + জরিমানা",
        "মারপিট (দণ্ডবিধি ৩২৫): সর্বোচ্চ ৭ বছর কারাদণ্ড + জরিমানা",
        "অপহরণ (দণ্ডবিধি ৩৬৩): সর্বোচ্চ ১০ বছর কারাদণ্ড + জরিমানা"
      ]
    },
    "Property Crimes": {
      definition: "চুরি, ডাকাতি, মোটরযান-চুরি, অগ্নিসংযোগ, জমি দখল ইত্যাদি সম্পত্তি বিষয়ক অপরাধ",
      punishments: [
        "ডাকাতি (দণ্ডবিধি ৩৯২): সর্বোচ্চ ১০ বছর কারাদণ্ড + জরিমানা",
        "চুরি (দণ্ডবিধি ৩৭৯): সর্বোচ্চ ৩ বছর কারাদণ্ড + জরিমানা",
        "অগ্নিসংযোগ (দণ্ডবিধি ৪৩৫): সর্বোচ্চ ১০ বছর কারাদণ্ড + জরিমানা"
      ]
    },
    "Economic / White-collar Crimes": {
      definition: "দুর্নীতি, ঘুষ, তহবিল দুর্নীতি, আর্থিক প্রতারণা, টাকা পাচার, কর ফাঁকি",
      punishments: [
        "দুর্নীতি (দুর্নীতি দমন কমিশন আইন): ৭-১৪ বছর কারাদণ্ড + জরিমানা",
        "টাকা পাচার (টাকা পাচার প্রতিরোধ আইন): ৪-১২ বছর কারাদণ্ড",
        "কর ফাঁকি (আয়কর অধ্যাদেশ): সর্বোচ্চ ৫ বছর কারাদণ্ড + ৫০০% জরিমানা"
      ]
    },
    "Crimes against Social / Moral Legislation": {
      definition: "যৌন হয়রানি, যৌতুক নির্যাতন, বাল্যবিয়ে, গৃহহিংসা",
      punishments: [
        "বাল্যবিয়ে (বাল্যবিয়ে নিরোধ আইন): ২ বছর কারাদণ্ড + জরিমানা",
        "যৌতুক নির্যাতন (যৌতুক নিরোধ আইন): ১-৫ বছর কারাদণ্ড + জরিমানা",
        "যৌন হয়রানি (নারী ও শিশু নির্যাতন আইন): ৫-১০ বছর কারাদণ্ড"
      ]
    },
    "Organised & High-Tech Crimes": {
      definition: "সংগঠিত মাদক পাচার, সাইবার অপরাধ, পাচার নেটওয়ার্ক",
      punishments: [
        "সাইবার অপরাধ (ডিজিটাল নিরাপত্তা আইন): ৫-১৪ বছর কারাদণ্ড + জরিমানা",
        "মাদক পাচার (মাদকদ্রব্য নিয়ন্ত্রণ আইন): ২ বছর থেকে মৃত্যুদণ্ড",
        "মানব পাচার (মানব পাচার প্রতিরোধ আইন): ৫ বছর থেকে যাবজ্জীবন কারাদণ্ড"
      ]
    },
    "Crimes against Public Order / State / Society": {
      definition: "সন্ত্রাসবাদ, সাম্প্রদায়িক হিংসা, রাজনৈতিক হিংসা, নির্বাচনী অপরাধ",
      punishments: [
        "সন্ত্রাসবাদ (সন্ত্রাসবাদ বিরোধী আইন): ৫ বছর থেকে মৃত্যুদণ্ড",
        "নির্বাচনী সহিংসতা (জনপ্রতিনিধিত্ব আদেশ): ২-৭ বছর কারাদণ্ড"
      ]
    }
  }
};

export default function SocialCrimePage() {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'report' | 'education'>('report');
  const [formData, setFormData] = useState({
    category: "",
    subcategory: "",
    description: "",
    latitude: 0,
    longitude: 0,
    address: "",
    isAnonymous: false,
  });
  const [evidenceFiles, setEvidenceFiles] = useState<{
    primary?: File;
    additional: File[];
  }>({ additional: [] });
  const [previews, setPreviews] = useState<{
    primary?: string;
    additional: string[];
  }>({ additional: [] });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<{ caseNumber: string } | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const socialCrimeCategories = getSocialCrimeCategories(language as 'en' | 'bn');

  // Get user's location
  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`
            );
            const data = await response.json();
            
            setFormData((prev) => ({
              ...prev,
              latitude: lat,
              longitude: lng,
              address: data.display_name || `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
            }));
          } catch (err) {
            setFormData((prev) => ({
              ...prev,
              latitude: lat,
              longitude: lng,
              address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
            }));
          }
        },
        () => {
          setError(language === 'en' 
            ? "Failed to get location. Please enable location services." 
            : "অবস্থান পেতে ব্যর্থ। অনুগ্রহ করে লোকেশন সার্ভিস চালু করুন।");
        }
      );
    }
  };

  const handlePrimaryFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setEvidenceFiles(prev => ({ ...prev, primary: file }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => ({ ...prev, primary: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdditionalFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      setEvidenceFiles(prev => ({ 
        ...prev, 
        additional: [...prev.additional, ...files] 
      }));
      
      files.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPreviews(prev => ({ 
            ...prev, 
            additional: [...prev.additional, reader.result as string] 
          }));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeFile = (type: 'primary' | 'additional', index?: number) => {
    if (type === 'primary') {
      setEvidenceFiles(prev => ({ ...prev, primary: undefined }));
      setPreviews(prev => ({ ...prev, primary: undefined }));
    } else if (index !== undefined) {
      setEvidenceFiles(prev => ({
        ...prev,
        additional: prev.additional.filter((_, i) => i !== index)
      }));
      setPreviews(prev => ({
        ...prev,
        additional: prev.additional.filter((_, i) => i !== index)
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (!formData.latitude || !formData.longitude) {
        throw new Error(language === 'en' 
          ? "Please enable location to submit report"
          : "রিপোর্ট জমা দিতে অবস্থান চালু করুন");
      }

      const submitData = new FormData();
      submitData.append("category", formData.category);
      submitData.append("subcategory", formData.subcategory);
      submitData.append("description", formData.description);
      submitData.append("latitude", formData.latitude.toString());
      submitData.append("longitude", formData.longitude.toString());
      submitData.append("address", formData.address);
      submitData.append("isAnonymous", formData.isAnonymous.toString());
      
      if (evidenceFiles.primary) {
        submitData.append("primaryEvidence", evidenceFiles.primary);
      }
      
      evidenceFiles.additional.forEach((file, index) => {
        submitData.append(`additionalEvidence_${index}`, file);
      });

      const response = await fetch("/api/social-crime", {
        method: "POST",
        body: submitData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || (language === 'en' ? "Failed to submit report" : "রিপোর্ট জমা দিতে ব্যর্থ"));
      }

      const data = await response.json();
      setSuccess({ caseNumber: data.caseNumber });
    } catch (error) {
      setError(error instanceof Error ? error.message : (language === 'en' ? "Failed to submit report" : "রিপোর্ট জমা দিতে ব্যর্থ"));
    } finally {
      setLoading(false);
    }
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{t('reportSubmitted')}</h2>
          <div className="mb-4">
            <div className="text-sm text-gray-600 mb-1">{t('caseNumber')}</div>
            <div className="font-mono text-lg font-bold text-blue-600">{success.caseNumber}</div>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="text-sm text-blue-700">
              {language === 'en' 
                ? "Your report has been forwarded to the relevant authorities."
                : "আপনার রিপোর্ট সংশ্লিষ্ট কর্তৃপক্ষের কাছে পাঠানো হয়েছে।"}
              {formData.isAnonymous && (language === 'en' 
                ? " Your identity will remain confidential."
                : " আপনার পরিচয় গোপন থাকবে।")}
            </div>
          </div>

          <button
            onClick={() => navigate("/dashboard")}
            className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            {t('backToDashboard')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={language === 'en' ? "Social Crime Report" : "সামাজিক অপরাধ রিপোর্ট"} 
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      
      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex">
          <button
            onClick={() => setActiveTab('report')}
            className={`flex-1 py-3 px-4 text-center font-medium ${
              activeTab === 'report'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {language === 'en' ? "Report Crime" : "অপরাধ রিপোর্ট"}
          </button>
          <button
            onClick={() => setActiveTab('education')}
            className={`flex-1 py-3 px-4 text-center font-medium ${
              activeTab === 'education'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <BookOpen className="w-4 h-4 inline-block mr-1" />
            {language === 'en' ? "Learn About Crimes" : "অপরাধ সম্পর্কে জানুন"}
          </button>
        </div>
      </div>

      {activeTab === 'report' ? (
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
            
            <div className="mb-6 bg-orange-50 border border-orange-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-orange-700">
                  {language === 'en' 
                    ? "Report serious crimes like theft, violence, corruption, or any illegal activity. Your report helps make our community safer."
                    : "চুরি, হিংসা, দুর্নীতি বা যেকোনো অবৈধ কার্যকলাপের মতো গুরুতর অপরাধের রিপোর্ট করুন। আপনার রিপোর্ট আমাদের সম্প্রদায়কে নিরাপদ করতে সাহায্য করে।"}
                </div>
              </div>
            </div>

            {error && (
              <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-red-700">{error}</div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Anonymous Reporting Toggle */}
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-3">
                    {formData.isAnonymous ? (
                      <UserX className="w-5 h-5 text-gray-600" />
                    ) : (
                      <User className="w-5 h-5 text-gray-600" />
                    )}
                    <div>
                      <div className="font-medium text-gray-900">
                        {language === 'en' ? "Report Anonymously" : "বেনামে রিপোর্ট করুন"}
                      </div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' ? "Your identity will be kept confidential" : "আপনার পরিচয় গোপন রাখা হবে"}
                      </div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.isAnonymous}
                    onChange={(e) => setFormData({ ...formData, isAnonymous: e.target.checked })}
                    className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </label>
              </div>

              {/* Quick Photo/Video Evidence */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? "Quick Picture/Video (Optional)" : "দ্রুত ছবি/ভিডিও (ঐচ্ছিক)"}
                </label>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <label className="cursor-pointer">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors">
                      <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <div className="text-sm text-gray-600">
                        {language === 'en' ? "Take Photo" : "ছবি তুলুন"}
                      </div>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handlePrimaryFileChange}
                      className="hidden"
                    />
                  </label>
                  
                  <label className="cursor-pointer">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors">
                      <Video className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <div className="text-sm text-gray-600">
                        {language === 'en' ? "Record Video" : "ভিডিও রেকর্ড"}
                      </div>
                    </div>
                    <input
                      type="file"
                      accept="video/*"
                      capture="environment"
                      onChange={handlePrimaryFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                {previews.primary && (
                  <div className="relative mb-4">
                    {evidenceFiles.primary?.type.startsWith('image/') ? (
                      <img src={previews.primary} alt="Primary evidence" className="max-h-64 mx-auto rounded-lg" />
                    ) : (
                      <video src={previews.primary} className="max-h-64 mx-auto rounded-lg" controls />
                    )}
                    <button
                      type="button"
                      onClick={() => removeFile('primary')}
                      className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                    >
                      {t('remove')}
                    </button>
                  </div>
                )}
              </div>

              {/* Additional Evidence Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? "Upload Additional Documents/Photos/Videos (Optional)" : "অতিরিক্ত নথি/ছবি/ভিডিও আপলোড করুন (ঐচ্ছিক)"}
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                  <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <label className="cursor-pointer">
                    <span className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 inline-block">
                      {language === 'en' ? "Upload Files" : "ফাইল আপলোড"}
                    </span>
                    <input
                      type="file"
                      accept="image/*,video/*,.pdf,.doc,.docx"
                      multiple
                      onChange={handleAdditionalFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                {previews.additional.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {previews.additional.map((preview, index) => (
                      <div key={index} className="relative">
                        {evidenceFiles.additional[index]?.type.startsWith('image/') ? (
                          <img src={preview} alt={`Additional ${index}`} className="w-full h-24 object-cover rounded" />
                        ) : evidenceFiles.additional[index]?.type.startsWith('video/') ? (
                          <video src={preview} className="w-full h-24 object-cover rounded" />
                        ) : (
                          <div className="w-full h-24 bg-gray-100 rounded flex items-center justify-center">
                            <FileImage className="w-6 h-6 text-gray-400" />
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => removeFile('additional', index)}
                          className="absolute top-1 right-1 w-6 h-6 bg-red-600 text-white rounded-full text-xs hover:bg-red-700"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Social Crime Type (Mandatory Section) */}
              <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <span className="text-red-600">*</span> 
                  {language === 'en' ? "Social Crime Type (Mandatory)" : "সামাজিক অপরাধের ধরন (বাধ্যতামূলক)"}
                </label>
                
                {/* Category Selection */}
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value, subcategory: "" })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mb-4"
                  required
                >
                  <option value="">
                    {language === 'en' ? "Select crime category" : "অপরাধের বিভাগ নির্বাচন করুন"}
                  </option>
                  {Object.keys(socialCrimeCategories).map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>

                {/* Subcategory Selection */}
                {formData.category && (
                  <select
                    value={formData.subcategory}
                    onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  >
                    <option value="">
                      {language === 'en' ? "Select specific crime" : "নির্দিষ্ট অপরাধ নির্বাচন করুন"}
                    </option>
                    {socialCrimeCategories[formData.category]?.map((crime, index) => (
                      <option key={index} value={crime}>
                        {crime}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? "Detailed Description *" : "বিস্তারিত বিবরণ *"}
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder={language === 'en' 
                    ? "Provide as much detail as possible about the incident..." 
                    : "ঘটনা সম্পর্কে যথাসম্ভব বিস্তারিত তথ্য প্রদান করুন..."}
                  rows={5}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                  minLength={10}
                />
                <div className="text-sm text-gray-500 mt-1">
                  {language === 'en' ? "Minimum 10 characters required" : "কমপক্ষে ১০টি অক্ষর প্রয়োজন"}
                </div>
              </div>

              {/* Incident Location */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? "Incident Location *" : "ঘটনার স্থান *"}
                </label>
                {formData.address ? (
                  <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <MapPin className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm text-gray-900">{formData.address}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {formData.latitude.toFixed(6)}, {formData.longitude.toFixed(6)}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, address: "", latitude: 0, longitude: 0 }))}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      ×
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={getLocation}
                    className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    <MapPin className="w-5 h-5 inline-block mr-2" />
                    {language === 'en' ? "Auto-Set Current Location" : "স্বয়ংক্রিয়ভাবে বর্তমান অবস্থান সেট করুন"}
                  </button>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading || !formData.address || !formData.category || !formData.subcategory || formData.description.length < 10}
                className="w-full px-6 py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all font-bold text-lg"
              >
                {loading ? 
                  (language === 'en' ? "Submitting..." : "জমা দেওয়া হচ্ছে...") : 
                  (language === 'en' ? "Submit Social Crime Report" : "সামাজিক অপরাধ রিপোর্ট জমা দিন")}
              </button>
              
              <div className="text-center text-sm text-gray-500">
                {language === 'en' ? "Emergency? Call" : "জরুরি অবস্থা? কল করুন"} <a href="tel:999" className="text-red-600 font-bold">999</a> {language === 'en' ? "immediately" : "এখনই"}
              </div>
            </form>
          </div>
        </div>
      ) : (
        /* Educational Section */
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-2">
              {language === 'en' ? "Learn About Social Crimes" : "সামাজিক অপরাধ সম্পর্কে জানুন"}
            </h2>
            <p className="text-gray-600 text-sm">
              {language === 'en' 
                ? "Detailed information on crime categories, definitions, punishments & penalties under Bangladesh law"
                : "বাংলাদেশের আইনের অধীনে অপরাধের বিভাগ, সংজ্ঞা, শাস্তি ও জরিমানা সম্পর্কে বিস্তারিত তথ্য"}
            </p>
          </div>

          <div className="space-y-4">
            {Object.entries(SOCIAL_CRIME_EDUCATION[language as 'en' | 'bn']).map(([category, info]) => (
              <div key={category} className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
                <button
                  onClick={() => toggleCategory(category)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div>
                    <h3 className="font-semibold text-gray-900 text-lg">{category}</h3>
                    <p className="text-gray-600 text-sm mt-1">{info.definition}</p>
                  </div>
                  {expandedCategories[category] ? (
                    <ChevronUp className="w-5 h-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  )}
                </button>

                {expandedCategories[category] && (
                  <div className="px-6 pb-4 border-t border-gray-100">
                    <h4 className="font-semibold text-gray-900 mb-3 mt-4">
                      {language === 'en' ? "Punishments & Penalties:" : "শাস্তি ও জরিমানা:"}
                    </h4>
                    <div className="space-y-2">
                      {info.punishments.map((punishment, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <span className="text-red-500 mt-1">•</span>
                          <span className="text-gray-700 text-sm">{punishment}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 bg-amber-50 border border-amber-200 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-semibold mb-1">
                  {language === 'en' ? 'Legal Disclaimer:' : 'আইনি দাবিত্যাগ:'}
                </p>
                <p>
                  {language === 'en' 
                    ? 'Penalties are based on relevant Bangladeshi laws. Actual sentencing may vary based on case specifics. Consult legal experts for accurate information.'
                    : 'জরিমানা সংশ্লিষ্ট বাংলাদেশী আইনের উপর ভিত্তি করে। মামলার বিশেষত্বের উপর ভিত্তি করে প্রকৃত সাজা ভিন্ন হতে পারে। সঠিক তথ্যের জন্য আইনি বিশেষজ্ঞদের পরামর্শ নিন।'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
