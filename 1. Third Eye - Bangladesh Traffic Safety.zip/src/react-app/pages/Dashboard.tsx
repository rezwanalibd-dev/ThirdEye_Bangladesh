import { useEffect, useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { Link } from "react-router";
import { Camera, Search, AlertCircle, Shield, Eye, Bell, Phone } from "lucide-react";
import type { User } from "@/shared/types";
import MobileLayout from "@/react-app/components/MobileLayout";
import { useLanguage } from "@/react-app/hooks/useLanguage";


export default function DashboardPage() {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const [appUser, setAppUser] = useState<User | null>(null);
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const meRes = await fetch("/api/users/me");
        const meData = await meRes.json();
        // Safely set app user data
        setAppUser(meData?.appUser || null);

        
      } catch (error) {
        console.error("Failed to load data:", error);
        setAppUser(null);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  if (loading) {
    return (
      <MobileLayout showBottomNav={false}>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
        </div>
      </MobileLayout>
    );
  }

  const needsKYC = appUser?.kyc_status !== "verified";
  const hasPenalties = !!appUser?.has_pending_penalties;

  return (
    <MobileLayout>
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-50 via-white to-gray-50 text-gray-900 px-6 py-6 relative overflow-hidden border-b border-gray-100">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-4 right-4 w-20 h-20 border border-blue-200 rounded-full"></div>
          <div className="absolute bottom-4 left-4 w-16 h-16 border border-purple-200 rounded-full"></div>
        </div>
        
        <div className="relative z-10">
          {/* User Info */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 backdrop-blur-sm rounded-full flex items-center justify-center">
                <Eye className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-gray-600 text-sm">{t('welcomeBack')}</div>
                <div className="font-semibold text-lg text-gray-900">{user?.google_user_data.name?.split(' ')[0] || 'User'}</div>
              </div>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Bell className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-3">
            <div className="text-center bg-white/50 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xl font-bold text-gray-900">{appUser?.total_reports || 0}</div>
              <div className="text-gray-600 text-xs">{t('reports')}</div>
            </div>
            <div className="text-center bg-white/50 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xl font-bold text-gray-900">{appUser?.approved_reports || 0}</div>
              <div className="text-gray-600 text-xs">{t('approved')}</div>
            </div>
            <div className="text-center bg-white/50 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xl font-bold text-gray-900">{appUser?.total_rewards?.toFixed(0) || 0}</div>
              <div className="text-gray-600 text-xs">{t('earned')}</div>
            </div>
            <div className="text-center bg-white/50 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xl font-bold text-gray-900">{((appUser?.approved_reports || 0) / Math.max(appUser?.total_reports || 1, 1) * 100).toFixed(0)}%</div>
              <div className="text-gray-600 text-xs">{t('success')}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Alerts */}
        {needsKYC && (
          <div className="mb-6 bg-orange-50 border-2 border-orange-200 rounded-2xl p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-5 h-5 text-orange-600" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-orange-900 mb-1">{t('identityVerification')}</div>
                <div className="text-sm text-orange-700 mb-3">
                  {t('completeKyc')}
                </div>
                <Link
                  to="/kyc"
                  className="inline-block px-4 py-2 bg-orange-600 text-white rounded-xl font-medium hover:bg-orange-700 transition-colors text-sm"
                >
                  {t('verifyNow')}
                </Link>
              </div>
            </div>
          </div>
        )}

        {hasPenalties && (
          <div className="mb-6 bg-red-50 border-2 border-red-200 rounded-2xl p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-red-900 mb-1">{t('accountRestricted')}</div>
                <div className="text-sm text-red-700 mb-3">
                  {t('pendingPenalties')}
                </div>
                <Link
                  to="/penalties"
                  className="inline-block px-4 py-2 bg-red-600 text-white rounded-xl font-medium hover:bg-red-700 transition-colors text-sm"
                >
                  {t('viewPenalties')}
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">{t('quickActions')}</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link to="/report">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 text-gray-900 rounded-2xl p-4 relative overflow-hidden hover:bg-blue-200 transition-colors">
                <div className="absolute top-2 right-2 opacity-30">
                  <Camera className="w-8 h-8 text-blue-600" />
                </div>
                <div className="relative z-10">
                  <Camera className="w-8 h-8 mb-3 text-blue-600" />
                  <div className="font-semibold mb-1 text-blue-900">{t('report')}</div>
                  <div className="text-gray-600 text-sm">{t('captureViolation')}</div>
                </div>
              </div>
            </Link>
            
            <Link to="/search">
              <div className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 text-gray-900 rounded-2xl p-4 relative overflow-hidden hover:bg-green-200 transition-colors">
                <div className="absolute top-2 right-2 opacity-30">
                  <Search className="w-8 h-8 text-green-600" />
                </div>
                <div className="relative z-10">
                  <Search className="w-8 h-8 mb-3 text-green-600" />
                  <div className="font-semibold mb-1 text-green-900">{t('search')}</div>
                  <div className="text-gray-600 text-sm">{t('findCases')}</div>
                </div>
              </div>
            </Link>
            
            <Link to="/social-crime">
              <div className="bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 text-gray-900 rounded-2xl p-4 relative overflow-hidden hover:bg-red-200 transition-colors">
                <div className="absolute top-2 right-2 opacity-30">
                  <Shield className="w-8 h-8 text-red-600" />
                </div>
                <div className="relative z-10">
                  <Shield className="w-8 h-8 mb-3 text-red-600" />
                  <div className="font-semibold mb-1 text-red-900">
                    {language === 'en' ? 'Social Crime' : 'সামাজিক অপরাধ'}
                  </div>
                  <div className="text-gray-600 text-sm">
                    {language === 'en' ? 'Report crimes' : 'অপরাধের রিপোর্ট'}
                  </div>
                </div>
              </div>
            </Link>

            <Link to="/emergency">
              <div className="bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 text-gray-900 rounded-2xl p-4 relative overflow-hidden hover:bg-red-200 transition-colors">
                <div className="absolute top-2 right-2 opacity-30">
                  <Phone className="w-8 h-8 text-red-600" />
                </div>
                <div className="relative z-10">
                  <Phone className="w-8 h-8 mb-3 text-red-600" />
                  <div className="font-semibold mb-1 text-red-900">{t('emergency')}</div>
                  <div className="text-gray-600 text-sm">{t('quickContacts')}</div>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Additional Services */}
        <div className="space-y-4">
          <Link to="/dmp" className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center mb-3">
              <Shield className="w-5 h-5 text-indigo-600" />
            </div>
            <div className="font-semibold text-gray-900 text-sm mb-1">{t('dmpPortal')}</div>
            <div className="text-gray-500 text-xs">{t('officerAccess')}</div>
          </Link>
        </div>
      </div>
    </MobileLayout>
  );
}
