import { Phone, Shield, Flame, Ambulance, AlertTriangle, Info, Heart, Users, Building2, Zap, Search, Car } from "lucide-react";
import MobileHeader from "@/react-app/components/MobileHeader";
import { useNavigate } from "react-router";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import { useState } from "react";

interface EmergencyContact {
  name: string;
  nameBn: string;
  number: string;
  icon: any;
  color: string;
  description: string;
  descriptionBn: string;
  type: string;
  category: string;
}

// 🆘 URGENT EMERGENCY (24/7) - 1 service
const URGENT_EMERGENCY: EmergencyContact[] = [
  {
    name: "National Emergency Service",
    nameBn: "জাতীয় জরুরি সেবা",
    number: "999",
    icon: AlertTriangle,
    color: "red",
    description: "Primary emergency number for Police, Fire, Ambulance - Call this first!",
    descriptionBn: "পুলিশ, ফায়ার সার্ভিস, অ্যাম্বুলেন্স - সকল জরুরি সেবা",
    type: "Toll-Free",
    category: "emergency"
  }
];

// 👮 LAW ENFORCEMENT & SECURITY - 6 services
const LAW_ENFORCEMENT: EmergencyContact[] = [
  {
    name: "Bangladesh Police Emergency",
    nameBn: "বাংলাদেশ পুলিশ জরুরি",
    number: "999",
    icon: Shield,
    color: "blue",
    description: "All types of police-related emergencies",
    descriptionBn: "সকল ধরনের পুলিশ সংক্রান্ত জরুরি অবস্থা",
    type: "Toll-Free",
    category: "police"
  },
  {
    name: "RAB (Rapid Action Battalion)",
    nameBn: "র‍্যাব (দ্রুত অ্যাকশন ব্যাটালিয়ন)",
    number: "01777720050",
    icon: Shield,
    color: "blue",
    description: "Crime, terrorism, drugs",
    descriptionBn: "অপরাধ, সন্ত্রাস, মাদক",
    type: "Mobile",
    category: "police"
  },
  {
    name: "Dhaka Metropolitan Police",
    nameBn: "ঢাকা মেট্রোপলিটন পুলিশ",
    number: "02-9514400",
    icon: Shield,
    color: "blue",
    description: "City security and law enforcement",
    descriptionBn: "শহরের নিরাপত্তা ও আইন প্রয়োগ",
    type: "Landline",
    category: "police"
  },
  {
    name: "Traffic Police Helpline",
    nameBn: "ট্রাফিক পুলিশ হেল্পলাইন",
    number: "01320-040244",
    icon: Shield,
    color: "blue",
    description: "Traffic accidents, violations, road assistance",
    descriptionBn: "ট্রাফিক দুর্ঘটনা ও সহায়তা",
    type: "Mobile",
    category: "police"
  },
  {
    name: "Tourist Police",
    nameBn: "ট্যুরিস্ট পুলিশ",
    number: "02-8322999",
    icon: Shield,
    color: "blue",
    description: "Tourist assistance and security",
    descriptionBn: "পর্যটক সহায়তা ও নিরাপত্তা",
    type: "Landline",
    category: "police"
  },
  {
    name: "Cyber Crime Unit (CID)",
    nameBn: "সাইবার ক্রাইম ইউনিট (সিআইডি)",
    number: "01769693535",
    icon: Shield,
    color: "blue",
    description: "Online fraud or harassment",
    descriptionBn: "অনলাইন প্রতারণা ও হয়রানি",
    type: "Mobile",
    category: "police"
  }
];

// 🏥 HEALTH & MEDICAL - 15 services
const HEALTH_MEDICAL: EmergencyContact[] = [
  {
    name: "Medical Emergency Service",
    nameBn: "মেডিকেল জরুরি সেবা",
    number: "199",
    icon: Ambulance,
    color: "green",
    description: "Ambulance & medical emergency assistance",
    descriptionBn: "অ্যাম্বুলেন্স ও চিকিৎসা জরুরি সহায়তা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "Health Hotline (DGHS)",
    nameBn: "স্বাস্থ্য হটলাইন (ডিজিএইচএস)",
    number: "16263",
    icon: Ambulance,
    color: "green",
    description: "Medical advice, hospital info, COVID info",
    descriptionBn: "চিকিৎসা পরামর্শ, হাসপাতাল তথ্য, কোভিড তথ্য",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "Dhaka Medical College Hospital",
    nameBn: "ঢাকা মেডিকেল কলেজ হাসপাতাল",
    number: "02-55165088",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Landline",
    category: "medical"
  },
  {
    name: "Bangabandhu Sheikh Mujib Medical University",
    nameBn: "বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয়",
    number: "02-9661061",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Landline",
    category: "medical"
  },
  {
    name: "Apollo Hospital",
    nameBn: "অ্যাপোলো হাসপাতাল",
    number: "10678",
    icon: Ambulance,
    color: "green",
    description: "Private hospital emergency services",
    descriptionBn: "বেসরকারি হাসপাতালের জরুরি সেবা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "Square Hospital",
    nameBn: "স্কয়ার হাসপাতাল",
    number: "10616",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "Evercare Hospital",
    nameBn: "এভারকেয়ার হাসপাতাল",
    number: "10678",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "United Hospital",
    nameBn: "ইউনাইটেড হাসপাতাল",
    number: "10666",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "LabAid Hospital",
    nameBn: "ল্যাবএইড হাসপাতাল",
    number: "10606",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Toll-Free",
    category: "medical"
  },
  {
    name: "Ibn Sina Hospital",
    nameBn: "ইবনে সিনা হাসপাতাল",
    number: "02-48114040",
    icon: Ambulance,
    color: "green",
    description: "Emergency medical services",
    descriptionBn: "জরুরি চিকিৎসা সেবা",
    type: "Landline",
    category: "medical"
  },
  {
    name: "Red Crescent Ambulance",
    nameBn: "রেড ক্রিসেন্ট অ্যাম্বুলেন্স",
    number: "01811-458500",
    icon: Ambulance,
    color: "green",
    description: "24/7 ambulance service",
    descriptionBn: "২৪/৭ অ্যাম্বুলেন্স সেবা",
    type: "Mobile",
    category: "medical"
  },
  {
    name: "Anjuman Mufidul Islam Ambulance",
    nameBn: "আঞ্জুমান মুফিদুল ইসলাম অ্যাম্বুলেন্স",
    number: "02-9336611",
    icon: Ambulance,
    color: "green",
    description: "Private ambulance service",
    descriptionBn: "বেসরকারি অ্যাম্বুলেন্স সেবা",
    type: "Landline",
    category: "medical"
  },
  {
    name: "Kaan Pete Roi (Mental Health Support)",
    nameBn: "কান পেতে রই (মানসিক স্বাস্থ্য সহায়তা)",
    number: "01779554391",
    icon: Heart,
    color: "green",
    description: "24/7 confidential mental health support",
    descriptionBn: "২৪/৭ গোপনীয় মানসিক স্বাস্থ্য সহায়তা",
    type: "Mobile",
    category: "medical"
  },
  {
    name: "Moner Bondhu",
    nameBn: "মনের বন্ধু",
    number: "01779554391",
    icon: Heart,
    color: "green",
    description: "Online counseling service",
    descriptionBn: "অনলাইন কাউন্সেলিং সেবা",
    type: "Mobile",
    category: "medical"
  },
  {
    name: "Bangladesh Psychological Association",
    nameBn: "বাংলাদেশ মনোবিজ্ঞান সমিতি",
    number: "09666-787878",
    icon: Heart,
    color: "green",
    description: "Professional counseling service",
    descriptionBn: "পেশাদার কাউন্সেলিং সেবা",
    type: "Mobile",
    category: "medical"
  }
];

// 🔥 FIRE SERVICE - 1 service
const FIRE_SERVICE: EmergencyContact[] = [
  {
    name: "Fire & Rescue Service",
    nameBn: "ফায়ার ও রেসকিউ সার্ভিস",
    number: "16163",
    icon: Flame,
    color: "red",
    description: "Fire incidents, rescue operations",
    descriptionBn: "অগ্নিকাণ্ড ও উদ্ধার অভিযান",
    type: "Toll-Free",
    category: "fire"
  }
];

// 🔧 UTILITY SERVICES - 8 services
const UTILITY_SERVICES: EmergencyContact[] = [
  {
    name: "DESCO (Dhaka Electric)",
    nameBn: "ডেসকো (ঢাকা বিদ্যুৎ)",
    number: "16120",
    icon: Zap,
    color: "orange",
    description: "Mirpur, Gulshan, Uttara, Tongi electricity issues",
    descriptionBn: "মিরপুর, গুলশান, উত্তরা, টঙ্গী বিদ্যুৎ সমস্যা",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "DPDC (Dhaka Power)",
    nameBn: "ডিপিডিসি (ঢাকা পাওয়ার)",
    number: "16117",
    icon: Zap,
    color: "orange",
    description: "Dhanmondi, Motijheel, Jatrabari, Narayanganj electricity",
    descriptionBn: "ধানমন্ডি, মতিঝিল, যাত্রাবাড়ী, নারায়ণগঞ্জ বিদ্যুৎ",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "BPDB (Bangladesh Power Development Board)",
    nameBn: "বিপিডিবি (বাংলাদেশ বিদ্যুৎ উন্নয়ন বোর্ড)",
    number: "16121",
    icon: Zap,
    color: "orange",
    description: "Nationwide electricity service",
    descriptionBn: "দেশব্যাপী বিদ্যুৎ সেবা",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "Titas Gas",
    nameBn: "তিতাস গ্যাস",
    number: "16496",
    icon: Flame,
    color: "orange",
    description: "Dhaka, Narayanganj, Gazipur, Tongi gas service",
    descriptionBn: "ঢাকা, নারায়ণগঞ্জ, গাজীপুর, টঙ্গী গ্যাস সেবা",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "WASA (Dhaka Water & Sewerage)",
    nameBn: "ওয়াসা (ঢাকা পানি ও পয়ঃনিষ্কাশন)",
    number: "16162",
    icon: Building2,
    color: "blue",
    description: "Dhaka, Narayanganj water & sewerage",
    descriptionBn: "ঢাকা, নারায়ণগঞ্জ পানি ও পয়ঃনিষ্কাশন",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "Karnafuli Gas (Chittagong)",
    nameBn: "কর্ণফুলী গ্যাস (চট্টগ্রাম)",
    number: "16512",
    icon: Flame,
    color: "orange",
    description: "Chittagong gas service",
    descriptionBn: "চট্টগ্রাম গ্যাস সেবা",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "Dhaka North City Corporation",
    nameBn: "ঢাকা উত্তর সিটি কর্পোরেশন",
    number: "16106",
    icon: Building2,
    color: "blue",
    description: "City services, waste management (North Dhaka)",
    descriptionBn: "শহরের সেবা, বর্জ্য ব্যবস্থাপনা (উত্তর ঢাকা)",
    type: "Toll-Free",
    category: "utility"
  },
  {
    name: "Dhaka South City Corporation",
    nameBn: "ঢাকা দক্ষিণ সিটি কর্পোরেশন",
    number: "16104",
    icon: Building2,
    color: "blue",
    description: "City services, waste management (South Dhaka)",
    descriptionBn: "শহরের সেবা, বর্জ্য ব্যবস্থাপনা (দক্ষিণ ঢাকা)",
    type: "Toll-Free",
    category: "utility"
  }
];

// 🤝 SUPPORT SERVICES - 9 services
const SUPPORT_SERVICES: EmergencyContact[] = [
  {
    name: "National Information Service",
    nameBn: "জাতীয় তথ্য সেবা",
    number: "333",
    icon: Info,
    color: "blue",
    description: "Government information, social assistance, local administration contact",
    descriptionBn: "সরকারি তথ্য, সামাজিক সহায়তা, স্থানীয় প্রশাসনিক যোগাযোগ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "Women & Child Abuse Prevention Helpline",
    nameBn: "নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন",
    number: "109",
    icon: Users,
    color: "purple",
    description: "Legal aid, shelter, counseling",
    descriptionBn: "আইনি সহায়তা, আশ্রয়, পরামর্শ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "Child Helpline (Dept. of Social Services)",
    nameBn: "শিশু হেল্পলাইন (সমাজসেবা অধিদপ্তর)",
    number: "1098",
    icon: Heart,
    color: "purple",
    description: "Child protection, rescue, counseling",
    descriptionBn: "শিশু সুরক্ষা, উদ্ধার, পরামর্শ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "Anti-Corruption Commission (ACC)",
    nameBn: "দুর্নীতি দমন কমিশন (এসিসি)",
    number: "106",
    icon: Shield,
    color: "red",
    description: "Report corruption or abuse of power",
    descriptionBn: "দুর্নীতি বা ক্ষমতার অপব্যবহারের অভিযোগ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "Consumer Rights Protection Directorate",
    nameBn: "ভোক্তা অধিকার সংরক্ষণ অধিদপ্তর",
    number: "16121",
    icon: Shield,
    color: "blue",
    description: "Fraud, overpricing, unfair trade complaints",
    descriptionBn: "প্রতারণা, অতিরিক্ত দাম, অন্যায্য ব্যবসার অভিযোগ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "Road Transport Authority (BRTA)",
    nameBn: "সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ)",
    number: "16107",
    icon: Car,
    color: "blue",
    description: "Vehicle or traffic-related complaints",
    descriptionBn: "যানবাহন বা ট্রাফিক সংক্রান্ত অভিযোগ",
    type: "Toll-Free",
    category: "support"
  },
  {
    name: "BRAC Legal Aid Hotline",
    nameBn: "ব্র্যাক আইনি সহায়তা হটলাইন",
    number: "01730336699",
    icon: Users,
    color: "purple",
    description: "Legal aid for women & children",
    descriptionBn: "নারী ও শিশুদের জন্য আইনি সহায়তা",
    type: "Mobile",
    category: "support"
  },
  {
    name: "Acid Survivors Foundation",
    nameBn: "অ্যাসিড সারভাইভার্স ফাউন্ডেশন",
    number: "01796132524",
    icon: Users,
    color: "purple",
    description: "Emergency & legal aid for acid attacks",
    descriptionBn: "এসিড নিক্ষেপের জরুরি ও আইনি সহায়তা",
    type: "Mobile",
    category: "support"
  },
  {
    name: "Police Victim Support Center",
    nameBn: "পুলিশ ভিকটিম সাপোর্ট সেন্টার",
    number: "01713373191",
    icon: Shield,
    color: "blue",
    description: "Victim assistance services",
    descriptionBn: "ক্ষতিগ্রস্ত ব্যক্তিদের সহায়তা সেবা",
    type: "Mobile",
    category: "support"
  }
];

// 💳 BANKING & MOBILE FINANCIAL SERVICES - 6 services
const BANKING_SERVICES: EmergencyContact[] = [
  {
    name: "bKash",
    nameBn: "বিকাশ",
    number: "16247",
    icon: Phone,
    color: "purple",
    description: "Mobile wallet customer service",
    descriptionBn: "মোবাইল ওয়ালেট গ্রাহক সেবা",
    type: "Toll-Free",
    category: "banking"
  },
  {
    name: "Nagad",
    nameBn: "নগদ",
    number: "16167",
    icon: Phone,
    color: "orange",
    description: "Mobile wallet customer service",
    descriptionBn: "মোবাইল ওয়ালেট গ্রাহক সেবা",
    type: "Toll-Free",
    category: "banking"
  },
  {
    name: "Rocket (Dutch-Bangla Bank)",
    nameBn: "রকেট (ডাচ-বাংলা ব্যাংক)",
    number: "16216",
    icon: Phone,
    color: "blue",
    description: "Mobile banking service",
    descriptionBn: "মোবাইল ব্যাংকিং সেবা",
    type: "Toll-Free",
    category: "banking"
  },
  {
    name: "City Bank (Amex)",
    nameBn: "সিটি ব্যাংক (অ্যামেক্স)",
    number: "16234",
    icon: Phone,
    color: "green",
    description: "Credit card & bank support",
    descriptionBn: "ক্রেডিট কার্ড ও ব্যাংক সহায়তা",
    type: "Toll-Free",
    category: "banking"
  },
  {
    name: "Standard Chartered Bank",
    nameBn: "স্ট্যান্ডার্ড চার্টার্ড ব্যাংক",
    number: "16233",
    icon: Phone,
    color: "blue",
    description: "24/7 banking support",
    descriptionBn: "২৪/৭ ব্যাংকিং সহায়তা",
    type: "Toll-Free",
    category: "banking"
  },
  {
    name: "Sonali Bank",
    nameBn: "সোনালী ব্যাংক",
    number: "16236",
    icon: Phone,
    color: "orange",
    description: "Government bank service",
    descriptionBn: "সরকারি ব্যাংক সেবা",
    type: "Toll-Free",
    category: "banking"
  }
];

// 🚌 TRAVEL & TRANSPORT SERVICES - 5 services
const TRANSPORT_SERVICES: EmergencyContact[] = [
  {
    name: "Hazrat Shahjalal International Airport",
    nameBn: "হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দর",
    number: "02-8901904",
    icon: Building2,
    color: "blue",
    description: "Flight information and services",
    descriptionBn: "ফ্লাইট তথ্য ও সেবা",
    type: "Landline",
    category: "transport"
  },
  {
    name: "Biman Bangladesh Airlines",
    nameBn: "বিমান বাংলাদেশ এয়ারলাইন্স",
    number: "02-8901600",
    icon: Building2,
    color: "green",
    description: "National airline booking & support",
    descriptionBn: "জাতীয় এয়ারলাইন্স বুকিং ও সহায়তা",
    type: "Landline",
    category: "transport"
  },
  {
    name: "Bangladesh Railway Information",
    nameBn: "বাংলাদেশ রেলওয়ে তথ্য",
    number: "131",
    icon: Building2,
    color: "orange",
    description: "Train ticket and schedule information",
    descriptionBn: "ট্রেন টিকিট ও সময়সূচি তথ্য",
    type: "Toll-Free",
    category: "transport"
  },
  {
    name: "Launch / River Transport Control",
    nameBn: "লঞ্চ / নদী পরিবহন নিয়ন্ত্রণ",
    number: "01321168105",
    icon: Building2,
    color: "blue",
    description: "River transport safety & information",
    descriptionBn: "নদী পরিবহন নিরাপত্তা ও তথ্য",
    type: "Mobile",
    category: "transport"
  },
  {
    name: "BIWTA",
    nameBn: "বিআইডব্লিউটিএ",
    number: "02-9559774",
    icon: Building2,
    color: "green",
    description: "Inland waterway transport assistance",
    descriptionBn: "অভ্যন্তরীণ নৌপথ পরিবহন সহায়তা",
    type: "Landline",
    category: "transport"
  }
];

// 📞 INTERNET & TELECOM SERVICES - 6 services
const TELECOM_SERVICES: EmergencyContact[] = [
  {
    name: "Grameenphone",
    nameBn: "গ্রামীণফোন",
    number: "121",
    icon: Phone,
    color: "blue",
    description: "Customer care and support",
    descriptionBn: "গ্রাহক সেবা ও সহায়তা",
    type: "Toll-Free",
    category: "telecom"
  },
  {
    name: "Robi",
    nameBn: "রবি",
    number: "123",
    icon: Phone,
    color: "orange",
    description: "Customer care and support",
    descriptionBn: "গ্রাহক সেবা ও সহায়তা",
    type: "Toll-Free",
    category: "telecom"
  },
  {
    name: "Banglalink",
    nameBn: "বাংলালিংক",
    number: "121",
    icon: Phone,
    color: "green",
    description: "Customer care and support",
    descriptionBn: "গ্রাহক সেবা ও সহায়তা",
    type: "Toll-Free",
    category: "telecom"
  },
  {
    name: "Teletalk",
    nameBn: "টেলিটক",
    number: "121",
    icon: Phone,
    color: "red",
    description: "Government SIM support",
    descriptionBn: "সরকারি সিম সহায়তা",
    type: "Toll-Free",
    category: "telecom"
  },
  {
    name: "BTCL (Landline)",
    nameBn: "বিটিসিএল (ল্যান্ডলাইন)",
    number: "16402",
    icon: Phone,
    color: "blue",
    description: "Telephone line issues",
    descriptionBn: "টেলিফোন লাইনের সমস্যা",
    type: "Toll-Free",
    category: "telecom"
  },
  {
    name: "BTRC (Telecom Regulator)",
    nameBn: "বিটিআরসি (টেলিকম নিয়ন্ত্রক)",
    number: "100",
    icon: Phone,
    color: "purple",
    description: "Telecom/internet fraud complaints",
    descriptionBn: "টেলিকম/ইন্টারনেট প্রতারণার অভিযোগ",
    type: "Toll-Free",
    category: "telecom"
  }
];

// 🏡 LAND, PROPERTY & TAX SERVICES - 9 services
const LAND_TAX_SERVICES: EmergencyContact[] = [
  {
    name: "Land Service Helpline",
    nameBn: "ভূমি সেবা হেল্পলাইন",
    number: "16122",
    icon: Building2,
    color: "brown",
    description: "Land mutation, khatian, land record queries",
    descriptionBn: "ভূমি মিউটেশন, খতিয়ান, ভূমি রেকর্ড অনুসন্ধান",
    type: "Toll-Free",
    category: "LAND_TAX"
  },
  {
    name: "NBR National Tax Helpline",
    nameBn: "এনবিআর জাতীয় কর হেল্পলাইন",
    number: "16169",
    icon: Building2,
    color: "green",
    description: "Income tax, VAT, customs related questions",
    descriptionBn: "আয়কর, ভ্যাট, কাস্টমস সংক্রান্ত প্রশ্ন",
    type: "Toll-Free",
    category: "land"
  },
  {
    name: "Chittagong City Corporation",
    nameBn: "চট্টগ্রাম সিটি কর্পোরেশন",
    number: "09611000999",
    icon: Building2,
    color: "blue",
    description: "Property tax and city services",
    descriptionBn: "সম্পত্তি কর ও শহরের সেবা",
    type: "Mobile",
    category: "land"
  },
  {
    name: "Gazipur City Corporation",
    nameBn: "গাজীপুর সিটি কর্পোরেশন",
    number: "09610000333",
    icon: Building2,
    color: "orange",
    description: "Tax and property services",
    descriptionBn: "কর ও সম্পত্তি সেবা",
    type: "Mobile",
    category: "land"
  },
  {
    name: "Narayanganj City Corporation",
    nameBn: "নারায়ণগঞ্জ সিটি কর্পোরেশন",
    number: "09611-777777",
    icon: Building2,
    color: "purple",
    description: "Local property tax services",
    descriptionBn: "স্থানীয় সম্পত্তি কর সেবা",
    type: "Mobile",
    category: "land"
  },
  {
    name: "Rajshahi City Corporation",
    nameBn: "রাজশাহী সিটি কর্পোরেশন",
    number: "16138",
    icon: Building2,
    color: "red",
    description: "Property and holding information",
    descriptionBn: "সম্পত্তি ও হোল্ডিং তথ্য",
    type: "Toll-Free",
    category: "land"
  },
  {
    name: "Khulna City Corporation",
    nameBn: "খুলনা সিটি কর্পোরেশন",
    number: "16125",
    icon: Building2,
    color: "green",
    description: "Tax and valuation services",
    descriptionBn: "কর ও মূল্যায়ন সেবা",
    type: "Toll-Free",
    category: "land"
  },
  {
    name: "Sylhet City Corporation",
    nameBn: "সিলেট সিটি কর্পোরেশন",
    number: "09666-777333",
    icon: Building2,
    color: "blue",
    description: "Property tax complaints",
    descriptionBn: "সম্পত্তি কর অভিযোগ",
    type: "Mobile",
    category: "land"
  },
  {
    name: "Barishal City Corporation",
    nameBn: "বরিশাল সিটি কর্পোরেশন",
    number: "09638-777111",
    icon: Building2,
    color: "orange",
    description: "Local tax services",
    descriptionBn: "স্থানীয় কর সেবা",
    type: "Mobile",
    category: "land"
  }
];

// Combine all services
const ALL_SERVICES = [
  ...URGENT_EMERGENCY,
  ...LAW_ENFORCEMENT,
  ...HEALTH_MEDICAL,
  ...FIRE_SERVICE,
  ...UTILITY_SERVICES,
  ...SUPPORT_SERVICES,
  ...BANKING_SERVICES,
  ...TRANSPORT_SERVICES,
  ...TELECOM_SERVICES,
  ...LAND_TAX_SERVICES
];

export default function EmergencyPage() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const handleCall = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string; buttonBg: string }> = {
      red: { bg: "bg-red-50", text: "text-red-700", border: "border-red-200", buttonBg: "bg-red-500 hover:bg-red-600" },
      blue: { bg: "bg-blue-50", text: "text-blue-700", border: "border-blue-200", buttonBg: "bg-blue-500 hover:bg-blue-600" },
      orange: { bg: "bg-orange-50", text: "text-orange-700", border: "border-orange-200", buttonBg: "bg-orange-500 hover:bg-orange-600" },
      green: { bg: "bg-green-50", text: "text-green-700", border: "border-green-200", buttonBg: "bg-green-500 hover:bg-green-600" },
      purple: { bg: "bg-purple-50", text: "text-purple-700", border: "border-purple-200", buttonBg: "bg-purple-500 hover:bg-purple-600" },
      brown: { bg: "bg-amber-50", text: "text-amber-700", border: "border-amber-200", buttonBg: "bg-amber-500 hover:bg-amber-600" }
    };
    return colors[color] || colors.red;
  };

  // Filter services based on search and category
  const filteredServices = ALL_SERVICES.filter(service => {
    const matchesSearch = searchTerm === "" || 
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.number.includes(searchTerm) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || service.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  // Category counts
  const categoryCounts = {
    all: ALL_SERVICES.length,
    emergency: URGENT_EMERGENCY.length,
    police: LAW_ENFORCEMENT.length,
    medical: HEALTH_MEDICAL.length,
    fire: FIRE_SERVICE.length,
    utility: UTILITY_SERVICES.length,
    support: SUPPORT_SERVICES.length,
    banking: BANKING_SERVICES.length,
    transport: TRANSPORT_SERVICES.length,
    telecom: TELECOM_SERVICES.length,
    land: LAND_TAX_SERVICES.length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader 
        title={language === 'en' ? "🚨 Emergency Contacts" : "🚨 জরুরি যোগাযোগ"}
        showBack={true}
        onBack={() => navigate("/dashboard")}
      />
      
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Emergency Header */}
        <div className="mb-6 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl p-6 text-center shadow-lg">
          <div className="text-4xl mb-2">🆘</div>
          <div className="text-2xl font-bold mb-2">
            {language === 'en' ? 'EMERGENCY: CALL 999' : 'জরুরি: ৯৯৯ কল করুন'}
          </div>
          <div className="text-red-800 font-semibold">
            {language === 'en' 
              ? 'For immediate police, fire, or medical emergency'
              : 'তাৎক্ষণিক পুলিশ, ফায়ার বা চিকিৎসা জরুরি অবস্থার জন্য'}
          </div>
          <button
            onClick={() => handleCall('999')}
            className="mt-4 bg-white text-red-600 px-6 py-3 rounded-xl font-bold text-lg shadow-md hover:shadow-lg transition-all"
          >
            📞 {language === 'en' ? 'CALL 999 NOW' : '৯৯৯ এ এখনই কল করুন'}
          </button>
        </div>

        {/* Search Bar */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={language === 'en' ? "Search by name, number, or service..." : "নাম, নম্বর বা সেবা দিয়ে খুঁজুন..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white"
          />
        </div>

        {/* Category Filter */}
        <div className="mb-6">
          <div className="flex flex-wrap gap-2">
            {Object.entries(categoryCounts).map(([category, count]) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                {category === 'all' ? (language === 'en' ? `All Services (${count})` : `সব সেবা (${count})`) :
                 category === 'emergency' ? (language === 'en' ? `Emergency (${count})` : `জরুরি (${count})`) :
                 category === 'police' ? (language === 'en' ? `Police (${count})` : `পুলিশ (${count})`) :
                 category === 'medical' ? (language === 'en' ? `Medical (${count})` : `চিকিৎসা (${count})`) :
                 category === 'fire' ? (language === 'en' ? `Fire Service (${count})` : `ফায়ার সার্ভিস (${count})`) :
                 category === 'utility' ? (language === 'en' ? `Utility (${count})` : `ইউটিলিটি (${count})`) :
                 category === 'support' ? (language === 'en' ? `Support (${count})` : `সহায়তা (${count})`) :
                 category === 'banking' ? (language === 'en' ? `Banking (${count})` : `ব্যাংকিং (${count})`) :
                 category === 'transport' ? (language === 'en' ? `Transport (${count})` : `পরিবহন (${count})`) :
                 category === 'telecom' ? (language === 'en' ? `Telecom (${count})` : `টেলিকম (${count})`) :
                 category === 'land' ? (language === 'en' ? `Land & Tax (${count})` : `ভূমি ও কর (${count})`) :
                 `${category} (${count})`}
              </button>
            ))}
          </div>
        </div>

        {/* Emergency Services List */}
        <div className="space-y-4">
          {filteredServices.length === 0 ? (
            <div className="text-center py-12">
              <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">
                {language === 'en' ? 'No services found matching your search.' : 'আপনার অনুসন্ধানের সাথে মিল পাওয়া যায়নি।'}
              </p>
            </div>
          ) : (
            filteredServices.map((service, index) => {
              const Icon = service.icon;
              const colors = getColorClasses(service.color);
              
              return (
                <div key={index} className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center`}>
                        <Icon className={`w-6 h-6 ${colors.text}`} />
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-gray-900">
                          {language === 'en' ? service.name : service.nameBn}
                        </div>
                        <div className="text-sm text-gray-600">
                          {language === 'en' ? service.description : service.descriptionBn}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <div className={`text-lg font-bold ${service.category === 'LAND_TAX' ? 'text-black' : 'text-gray-900'}`}>{service.number}</div>
                          <span className={`text-xs px-2 py-1 rounded-full ${colors.bg} ${service.category === 'LAND_TAX' ? 'text-black' : colors.text} font-medium`}>
                            {service.type}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCall(service.number)}
                      className={`px-4 py-2 ${colors.buttonBg} ${service.category === 'LAND_TAX' ? 'text-black' : 'text-white'} rounded-xl font-medium transition-colors flex items-center gap-2 shadow-sm`}
                    >
                      <Phone className="w-4 h-4" />
                      {language === 'en' ? 'Call' : 'কল'}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Information */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="text-center text-sm text-blue-700 space-y-1">
            <div className="font-bold">
              {language === 'en' ? '24/7 Emergency Services Available' : '২৪/৭ জরুরি সেবা উপলব্ধ'}
            </div>
            <div>📅 {language === 'en' ? 'Last Updated: November 2025' : 'শেষ আপডেট: নভেম্বর ২০২৫'}</div>
            <div>🏛️ {language === 'en' ? 'Source: Bangladesh Government Official Directory' : 'সূত্র: বাংলাদেশ সরকারের অফিসিয়াল ডিরেক্টরি'}</div>
            <div>✅ {language === 'en' ? 'Status: All numbers verified & active' : 'স্ট্যাটাস: সব নম্বর যাচাইকৃত ও সক্রিয়'}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
