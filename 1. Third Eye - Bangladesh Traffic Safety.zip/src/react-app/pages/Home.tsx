import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { useState, useEffect } from "react";
import { Shield, Eye, Globe, TestTube, Phone, Scale, Download } from "lucide-react";
import { useLanguage } from "@/react-app/hooks/useLanguage";
import { usePWA } from "@/react-app/hooks/usePWA";

export default function HomePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();
  const { isInstallable, installApp } = usePWA();
  const [userInfo, setUserInfo] = useState<{ needsOnboarding?: boolean } | null>(null);
  const [showTestingButton, setShowTestingButton] = useState(false);

  useEffect(() => {
    if (user && !userInfo) {
      fetch('/api/users/me')
        .then(res => res.json())
        .then(data => {
          setUserInfo(data);
          if (data.needsOnboarding) {
            navigate("/onboarding");
          } else {
            navigate("/dashboard");
          }
        });
    }
  }, [user, navigate, userInfo]);

  // Check if we're in development mode
  useEffect(() => {
    const checkDevelopmentMode = async () => {
      try {
        const response = await fetch('/api/testing/status');
        if (response.ok) {
          const data = await response.json();
          setShowTestingButton(data.isDevelopmentMode);
        }
      } catch {
        // Ignore error, likely means testing endpoints don't exist
      }
    };
    checkDevelopmentMode();
  }, []);

  if (user && !userInfo) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (user) {
    return null; // Will redirect based on onboarding status
  }

  return (
    <div className="min-h-screen bg-white flex flex-col justify-center items-center px-6 text-gray-900 relative">
      {/* Language Selector */}
      <div className="absolute top-6 right-6">
        <button
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          className="flex items-center gap-2 bg-gray-100 border border-gray-200 px-4 py-2.5 rounded-xl text-gray-800 text-sm hover:bg-gray-200 transition-colors shadow-sm"
        >
          <Globe className="w-4 h-4" />
          {language === 'en' ? 'বাংলা' : 'English'}
        </button>
      </div>

      <div className="w-full max-w-sm space-y-8">
        {/* Logo */}
        <div className="flex justify-center">
          <div className="w-24 h-24 bg-blue-600 rounded-3xl flex items-center justify-center shadow-lg">
            <Eye className="w-12 h-12 text-white" />
          </div>
        </div>

        {/* App Title & Tagline */}
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2 text-gray-900">{t('appTitle')}</h1>
          <p className="text-gray-600 text-base">{t('tagline')}</p>
        </div>

        {/* PWA Install Button */}
        {isInstallable && (
          <div className="mb-4">
            <button
              onClick={installApp}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold py-5 rounded-2xl shadow-md hover:shadow-lg transition-all text-lg flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              {language === 'en' ? 'Install App' : 'অ্যাপ ইনস্টল করুন'}
            </button>
          </div>
        )}

        {/* Main Action Buttons */}
        <div className="space-y-4">
          <button
            onClick={() => navigate("/signup-options")}
            className="w-full bg-blue-600 text-white font-semibold py-5 rounded-2xl shadow-md hover:bg-blue-700 hover:shadow-lg transition-all text-lg flex items-center justify-center gap-2"
          >
            <Eye className="w-5 h-5" />
            {t('startReporting')}
          </button>
          
          <button
            onClick={() => navigate("/login-options")}
            className="w-full bg-white border-2 border-gray-300 text-gray-700 font-semibold py-5 rounded-2xl hover:bg-gray-50 hover:border-gray-400 transition-all shadow-sm text-lg"
          >
            {t('alreadyHaveAccount')}
          </button>

          {/* Emergency & Traffic Rules Buttons */}
          <div className="grid grid-cols-2 gap-4 mt-6">
            <button
              onClick={() => navigate("/emergency")}
              className="bg-red-600 text-white font-semibold py-4 rounded-2xl hover:bg-red-700 hover:shadow-lg transition-all flex flex-col items-center justify-center gap-1 text-sm"
            >
              <Phone className="w-5 h-5" />
              <span>Emergency</span>
            </button>
            
            <button
              onClick={() => navigate("/traffic-rules")}
              className="bg-gray-600 text-white font-semibold py-4 rounded-2xl hover:bg-gray-700 hover:shadow-lg transition-all flex flex-col items-center justify-center gap-1 text-sm"
            >
              <Scale className="w-5 h-5" />
              <span>Traffic Rules</span>
            </button>
          </div>
        </div>

        

        {/* Development Testing Button */}
        {showTestingButton && (
          <div className="fixed bottom-4 right-4 z-50">
            <button
              onClick={() => navigate('/testing')}
              className="bg-yellow-500 hover:bg-yellow-600 text-white p-3 rounded-full shadow-lg transition-all transform hover:scale-105"
              title="Testing Dashboard (Development Only)"
            >
              <TestTube className="h-6 w-6" />
            </button>
          </div>
        )}
      </div>

      {/* DMP Officer Access Button - Center Bottom */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 w-full max-w-sm px-6 z-40">
        <button
          onClick={() => {
            localStorage.setItem('selectedPortal', 'dmp');
            navigate("/login-options");
          }}
          className="w-full bg-green-600 text-white font-semibold py-5 rounded-2xl shadow-md hover:bg-green-700 hover:shadow-lg transition-all text-lg flex items-center justify-center gap-3"
        >
          <Shield className="w-6 h-6" />
          {t('dmpOfficerAccess')}
        </button>
      </div>
    </div>
  );
}
