import { useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Shield, Car, Users, ArrowLeft, LogIn } from "lucide-react";

export default function LoginPortals() {
  const { user, redirectToLogin } = useAuth();
  const navigate = useNavigate();
  const [selectedPortal, setSelectedPortal] = useState<'citizen' | 'dmp' | 'brta' | null>(null);

  if (user) {
    navigate("/dashboard");
    return null;
  }

  const portals = [
    {
      id: 'citizen',
      title: 'Citizen Login',
      description: 'For general public to report traffic violations',
      icon: <Users className="w-16 h-16" />,
      color: 'from-blue-500 to-blue-600',
      bgPattern: 'bg-gradient-to-br from-blue-50 to-indigo-100'
    },
    {
      id: 'dmp',
      title: 'DMP Officer Login',
      description: 'Dhaka Metropolitan Police officer portal',
      icon: <Shield className="w-16 h-16" />,
      color: 'from-green-500 to-green-600',
      bgPattern: 'bg-gradient-to-br from-green-50 to-emerald-100'
    },
    {
      id: 'brta',
      title: 'BRTA Officer Login',
      description: 'Bangladesh Road Transport Authority portal',
      icon: <Car className="w-16 h-16" />,
      color: 'from-purple-500 to-purple-600',
      bgPattern: 'bg-gradient-to-br from-purple-50 to-violet-100'
    }
  ];

  const handleLogin = () => {
    // Store the selected portal in localStorage to use after auth
    if (selectedPortal) {
      localStorage.setItem('selectedPortal', selectedPortal);
    }
    redirectToLogin();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      {!selectedPortal ? (
        // Portal Selection Screen
        <div className="container mx-auto px-4 py-12">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-white mb-8 hover:text-blue-300 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>

          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-white mb-4">Welcome Back</h1>
            <p className="text-blue-200 text-xl max-w-3xl mx-auto">
              Select your portal to access your Third Eye account
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {portals.map((portal) => (
              <PortalCard
                key={portal.id}
                portal={portal}
                onSelect={() => setSelectedPortal(portal.id as 'citizen' | 'dmp' | 'brta')}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-blue-300 text-lg mb-6">
              All portals use secure Google OAuth authentication
            </p>
            <div className="flex justify-center space-x-8 text-blue-200">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                <span>Secure Login</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
                <span>Role-based Access</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-purple-400 rounded-full"></div>
                <span>Official Integration</span>
              </div>
            </div>
            
            <div className="mt-8">
              <p className="text-blue-300 mb-4">Don't have an account yet?</p>
              <button
                onClick={() => navigate("/signup")}
                className="px-6 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
              >
                Sign Up Here
              </button>
            </div>
          </div>
        </div>
      ) : (
        // Login Confirmation Screen
        <div className="container mx-auto px-4 py-12">
          <button
            onClick={() => setSelectedPortal(null)}
            className="flex items-center gap-2 text-white mb-8 hover:text-blue-300 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Choose Different Portal
          </button>

          <div className="max-w-lg mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center">
              <div className={`w-24 h-24 bg-gradient-to-r ${portals.find(p => p.id === selectedPortal)?.color} rounded-2xl flex items-center justify-center mx-auto mb-6 text-white`}>
                {portals.find(p => p.id === selectedPortal)?.icon}
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-4">
                {portals.find(p => p.id === selectedPortal)?.title}
              </h2>
              
              <p className="text-blue-200 mb-8 text-lg">
                {portals.find(p => p.id === selectedPortal)?.description}
              </p>

              <button
                onClick={handleLogin}
                className={`w-full py-4 bg-gradient-to-r ${portals.find(p => p.id === selectedPortal)?.color} text-white rounded-lg font-bold text-lg hover:shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-3`}
              >
                <LogIn className="w-6 h-6" />
                Continue with Google
              </button>

              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-200 text-sm">
                  <strong>Secure Authentication:</strong> Your login is protected by Google OAuth 2.0. 
                  We never store your password and your data is encrypted.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PortalCard({ 
  portal, 
  onSelect 
}: { 
  portal: any; 
  onSelect: () => void;
}) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 hover:bg-white/15 transition-all duration-300 cursor-pointer transform hover:scale-105"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onSelect}
    >
      <div className={`w-24 h-24 bg-gradient-to-r ${portal.color} rounded-2xl flex items-center justify-center mx-auto mb-6 text-white transition-transform duration-300 ${isHovered ? 'scale-110 rotate-3' : ''}`}>
        {portal.icon}
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-3 text-center">{portal.title}</h3>
      <p className="text-blue-200 mb-6 text-center">{portal.description}</p>
      
      <button className={`w-full py-3 bg-gradient-to-r ${portal.color} text-white rounded-lg font-semibold hover:shadow-xl transition-all`}>
        Select Portal
      </button>
    </div>
  );
}
