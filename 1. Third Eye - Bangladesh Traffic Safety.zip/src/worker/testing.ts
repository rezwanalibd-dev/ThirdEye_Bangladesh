// Testing utilities for development and pre-production testing

export interface TestingOTP {
  identifier: string;
  identifierType: string;
  code: string;
  createdAt: string;
  expiresAt: string;
  verified: boolean;
}

// Get recent OTP codes for testing purposes
export async function getRecentOTPs(db: D1Database): Promise<TestingOTP[]> {
  const { results } = await db.prepare(
    `SELECT identifier, identifier_type, code, created_at, expires_at, verified 
     FROM otp_codes 
     WHERE created_at > datetime('now', '-10 minutes')
     ORDER BY created_at DESC 
     LIMIT 20`
  ).all<TestingOTP>();

  return results || [];
}

// Clear expired OTP codes (cleanup utility)
export async function clearExpiredOTPs(db: D1Database): Promise<number> {
  const result = await db.prepare(
    "DELETE FROM otp_codes WHERE expires_at < datetime('now')"
  ).run();

  return result.meta.changes || 0;
}

// Development mode checker (based on environment)
export function isDevelopmentMode(env: any): boolean {
  // In development, we don't have production secrets or the environment is clearly dev
  return !env.PRODUCTION_MODE || env.ENVIRONMENT === 'development';
}

// Create a test session for bypassing authentication
export async function createTestSession(db: D1Database, userType: 'citizen' | 'dmp' | 'brta'): Promise<{
  sessionToken: string;
  userId: string;
}> {
  const sessionToken = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const userId = `test_user_${userType}_${Date.now()}`;
  
  // Create test session in auth_sessions table
  await db.prepare(`
    INSERT INTO auth_sessions (id, identifier, identifier_type, session_token, is_verified, user_id, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(
    `test_session_${Date.now()}`,
    `test_${userType}@example.com`,
    'email',
    sessionToken,
    true,
    userId
  ).run();

  // Create test user based on type
  if (userType === 'citizen') {
    await db.prepare(`
      INSERT INTO users (id, mocha_user_id, phone_number, kyc_status, account_status, user_type, registration_completed, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      userId,
      `test_mocha_${userId}`,
      '+8801711175314',
      'verified',
      'active',
      'citizen',
      true
    ).run();
  } else if (userType === 'dmp') {
    await db.prepare(`
      INSERT INTO users (id, mocha_user_id, phone_number, kyc_status, account_status, user_type, registration_completed, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      userId,
      `test_mocha_${userId}`,
      '+8801711175314',
      'verified',
      'active',
      'dmp',
      true
    ).run();

    await db.prepare(`
      INSERT INTO dmp_officers (id, mocha_user_id, badge_number, rank, division, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      `test_dmp_${Date.now()}`,
      `test_mocha_${userId}`,
      `TEST${Date.now().toString().slice(-4)}`,
      'Inspector',
      'Traffic Division'
    ).run();
  } else if (userType === 'brta') {
    await db.prepare(`
      INSERT INTO users (id, mocha_user_id, phone_number, kyc_status, account_status, user_type, registration_completed, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      userId,
      `test_mocha_${userId}`,
      '+8801711175314',
      'verified',
      'active',
      'brta',
      true
    ).run();

    await db.prepare(`
      INSERT INTO brta_officers (id, mocha_user_id, employee_id, rank, division, region, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      `test_brta_${Date.now()}`,
      `test_mocha_${userId}`,
      `BRTA${Date.now().toString().slice(-4)}`,
      'Inspector',
      'Registration Division',
      'Dhaka'
    ).run();
  }

  return { sessionToken, userId };
}

// Clean up test data
export async function cleanupTestData(db: D1Database): Promise<number> {
  let totalCleaned = 0;

  // Clean test sessions
  const sessions = await db.prepare(
    "DELETE FROM auth_sessions WHERE identifier LIKE 'test_%'"
  ).run();
  totalCleaned += sessions.meta.changes || 0;

  // Clean test users
  const users = await db.prepare(
    "DELETE FROM users WHERE id LIKE 'test_user_%'"
  ).run();
  totalCleaned += users.meta.changes || 0;

  // Clean test officers
  const dmpOfficers = await db.prepare(
    "DELETE FROM dmp_officers WHERE id LIKE 'test_dmp_%'"
  ).run();
  totalCleaned += dmpOfficers.meta.changes || 0;

  const brtaOfficers = await db.prepare(
    "DELETE FROM brta_officers WHERE id LIKE 'test_brta_%'"
  ).run();
  totalCleaned += brtaOfficers.meta.changes || 0;

  return totalCleaned;
}
