import { Hono } from "hono";
import { cors } from "hono/cors";
import {
  authMiddleware,
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import type { MochaUser } from "@getmocha/users-service/shared";
import {
  CreateReportSchema,
  KYCSubmissionSchema,
  VerifyReportSchema,
  VIOLATION_FINES,
  type User,
  type Report,
  type Penalty,
  RegistrationSchema,
  CreateSocialCrimeReportSchema,
} from "@/shared/types";
import { getRecentOTPs, clearExpiredOTPs, isDevelopmentMode, createTestSession, cleanupTestData } from "./testing";

interface Env {
  DB: D1Database;
  R2_BUCKET: R2Bucket;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors());

// ============================================================================
// Authentication Routes
// ============================================================================

// Generate a random 6-digit OTP
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP endpoint
app.post("/api/auth/send-otp", async (c) => {
  const body = await c.req.json();
  const { identifier, identifierType, isLogin } = body;

  if (!identifier || !identifierType) {
    return c.json({ error: "Identifier and type required" }, 400);
  }

  // Validate identifier format
  if (identifierType === 'email' && !identifier.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    return c.json({ error: "Invalid email format" }, 400);
  }

  if (identifierType === 'mobile' && !identifier.match(/^(\+880|880|0)?1[3-9]\d{8}$/)) {
    return c.json({ error: "Invalid mobile number format" }, 400);
  }

  // For login, check if user exists
  if (isLogin) {
    const existingUser = await c.env.DB.prepare(
      identifierType === 'email'
        ? "SELECT id FROM users WHERE mocha_user_id LIKE ?"
        : "SELECT id FROM users WHERE phone_number = ?"
    )
      .bind(identifierType === 'email' ? `%${identifier}%` : identifier)
      .first();

    if (!existingUser) {
      return c.json({ error: "No account found with this email/mobile" }, 404);
    }
  }

  // Generate OTP
  const code = generateOTP();
  const expiresAt = new Date(Date.now() + 2 * 60 * 1000).toISOString(); // 2 minutes

  // Delete any existing OTPs for this identifier
  await c.env.DB.prepare(
    "DELETE FROM otp_codes WHERE identifier = ? AND identifier_type = ?"
  )
    .bind(identifier, identifierType)
    .run();

  // Store OTP
  const otpId = crypto.randomUUID();
  await c.env.DB.prepare(
    "INSERT INTO otp_codes (id, identifier, identifier_type, code, expires_at) VALUES (?, ?, ?, ?, ?)"
  )
    .bind(otpId, identifier, identifierType, code, expiresAt)
    .run();

  // In production, send actual SMS/Email here
  // For now, we'll log it to console (in dev, the code is returned in response)
  console.log(`OTP for ${identifier}: ${code}`);

  // Check if we're in development mode
  const devMode = isDevelopmentMode(c.env);
  
  return c.json({ 
    success: true, 
    message: `OTP sent to ${identifier}`,
    // Only include devCode in development mode
    ...(devMode && { devCode: code }),
    isDevelopmentMode: devMode
  });
});

// Verify OTP endpoint
app.post("/api/auth/verify-otp", async (c) => {
  const body = await c.req.json();
  const { identifier, identifierType, code, isLogin } = body;

  if (!identifier || !identifierType || !code) {
    return c.json({ error: "All fields required" }, 400);
  }

  // Get OTP record
  const otpRecord = await c.env.DB.prepare(
    `SELECT * FROM otp_codes 
     WHERE identifier = ? AND identifier_type = ? 
     ORDER BY created_at DESC LIMIT 1`
  )
    .bind(identifier, identifierType)
    .first<{
      id: string;
      code: string;
      expires_at: string;
      verified: boolean;
      attempts: number;
    }>();

  if (!otpRecord) {
    return c.json({ error: "No OTP found. Please request a new one." }, 404);
  }

  // Check if already verified
  if (otpRecord.verified) {
    return c.json({ error: "OTP already used. Please request a new one." }, 400);
  }

  // Check attempts
  if (otpRecord.attempts >= 3) {
    return c.json({ error: "Too many failed attempts. Please request a new OTP." }, 400);
  }

  // Check expiration
  if (new Date(otpRecord.expires_at) < new Date()) {
    return c.json({ error: "OTP expired. Please request a new one." }, 400);
  }

  // Verify code
  if (otpRecord.code !== code) {
    await c.env.DB.prepare(
      "UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?"
    )
      .bind(otpRecord.id)
      .run();
    return c.json({ error: "Invalid OTP code" }, 400);
  }

  // Mark OTP as verified
  await c.env.DB.prepare(
    "UPDATE otp_codes SET verified = 1 WHERE id = ?"
  )
    .bind(otpRecord.id)
    .run();

  // Create or get user
  let user;
  if (isLogin) {
    user = await c.env.DB.prepare(
      identifierType === 'email'
        ? "SELECT * FROM users WHERE mocha_user_id LIKE ? LIMIT 1"
        : "SELECT * FROM users WHERE phone_number = ? LIMIT 1"
    )
      .bind(identifierType === 'email' ? `%${identifier}%` : identifier)
      .first<User>();

    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }
  } else {
    // For signup, create a temporary user record
    const userId = crypto.randomUUID();
    const tempUserId = `temp_${identifierType}_${identifier}_${userId}`;
    
    await c.env.DB.prepare(
      `INSERT INTO users (id, mocha_user_id, phone_number, registration_completed) 
       VALUES (?, ?, ?, 0)`
    )
      .bind(userId, tempUserId, identifierType === 'mobile' ? identifier : null)
      .run();

    user = await c.env.DB.prepare("SELECT * FROM users WHERE id = ?")
      .bind(userId)
      .first<User>();
  }

  // Create session token
  const sessionToken = crypto.randomUUID();
  const sessionId = crypto.randomUUID();

  await c.env.DB.prepare(
    `INSERT INTO auth_sessions (id, identifier, identifier_type, session_token, is_verified, user_id)
     VALUES (?, ?, ?, ?, 1, ?)`
  )
    .bind(sessionId, identifier, identifierType, sessionToken, user!.id)
    .run();

  return c.json({
    success: true,
    sessionToken,
    needsOnboarding: !user!.registration_completed,
    userId: user!.id
  });
});

// Validate session token from OTP auth
app.get("/api/auth/validate-session", async (c) => {
  const sessionToken = c.req.query('token');

  if (!sessionToken) {
    return c.json({ error: "Session token required" }, 400);
  }

  const session = await c.env.DB.prepare(
    "SELECT * FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
  )
    .bind(sessionToken)
    .first<{
      id: string;
      user_id: string;
      identifier: string;
      identifier_type: string;
    }>();

  if (!session) {
    return c.json({ error: "Invalid session" }, 401);
  }

  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  )
    .bind(session.user_id)
    .first<User>();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  return c.json({
    user,
    needsOnboarding: !user.registration_completed
  });
});

app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

// ============================================================================
// Testing Routes (Development/Testing Only)
// ============================================================================

// Get recent OTP codes for testing purposes
app.get("/api/testing/otps", async (c) => {
  // Only allow in development mode
  if (!isDevelopmentMode(c.env)) {
    return c.json({ error: "Not available in production" }, 403);
  }

  const otps = await getRecentOTPs(c.env.DB);
  
  return c.json({
    otps,
    note: "This endpoint is only available in development mode for testing OTP flows"
  });
});

// Clear expired OTPs (cleanup utility)
app.post("/api/testing/cleanup-otps", async (c) => {
  if (!isDevelopmentMode(c.env)) {
    return c.json({ error: "Not available in production" }, 403);
  }

  const clearedCount = await clearExpiredOTPs(c.env.DB);
  
  return c.json({
    message: `Cleared ${clearedCount} expired OTP codes`,
    clearedCount
  });
});

// Development status endpoint
app.get("/api/testing/status", async (c) => {
  const devMode = isDevelopmentMode(c.env);
  
  return c.json({
    isDevelopmentMode: devMode,
    message: devMode 
      ? "Development mode active - OTP codes visible for testing" 
      : "Production mode - OTP codes hidden for security",
    availableEndpoints: devMode ? [
      "GET /api/testing/otps - View recent OTP codes",
      "POST /api/testing/cleanup-otps - Clear expired OTPs",
      "POST /api/testing/create-test-session - Create test user session",
      "POST /api/testing/cleanup-test-data - Clear test data"
    ] : []
  });
});

// Create test session (bypass OTP authentication)
app.post("/api/testing/create-test-session", async (c) => {
  if (!isDevelopmentMode(c.env)) {
    return c.json({ error: "Not available in production" }, 403);
  }

  try {
    const { userType } = await c.req.json();
    
    if (!['citizen', 'dmp', 'brta'].includes(userType)) {
      return c.json({ error: "Invalid user type" }, 400);
    }

    const session = await createTestSession(c.env.DB, userType);
    return c.json({
      success: true,
      sessionToken: session.sessionToken,
      userId: session.userId,
      userType,
      message: `Test session created for ${userType}`
    });
  } catch (error) {
    console.error('Error creating test session:', error);
    return c.json({ error: "Failed to create test session" }, 500);
  }
});

// Clean up test data
app.post("/api/testing/cleanup-test-data", async (c) => {
  if (!isDevelopmentMode(c.env)) {
    return c.json({ error: "Not available in production" }, 403);
  }

  try {
    const clearedCount = await cleanupTestData(c.env.DB);
    return c.json({ 
      success: true, 
      clearedCount,
      message: `Cleaned up ${clearedCount} test records`
    });
  } catch (error) {
    console.error('Error cleaning test data:', error);
    return c.json({ error: "Failed to cleanup test data" }, 500);
  }
});

app.get("/api/users/me", authMiddleware, async (c) => {
  try {
    const user = c.get("user") as MochaUser;

    // Get or create app user
    let appUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(user.id)
      .first<User>();

    if (!appUser) {
      const id = crypto.randomUUID();
      await c.env.DB.prepare(
        `INSERT INTO users (id, mocha_user_id) VALUES (?, ?)`
      )
        .bind(id, user.id)
        .run();

      appUser = await c.env.DB.prepare("SELECT * FROM users WHERE id = ?")
        .bind(id)
        .first<User>();
    }

    return c.json({ 
      user, 
      appUser: appUser || null,
      needsOnboarding: !appUser?.registration_completed 
    });
  } catch (error) {
    console.error("Error fetching user data:", error);
    return c.json({ 
      user: null, 
      appUser: null,
      needsOnboarding: true 
    });
  }
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// ============================================================================
// Registration Routes
// ============================================================================

app.post("/api/registration", async (c) => {
  // Check for both Google OAuth and OTP session
  const sessionTokenHeader = c.req.header('X-Session-Token');
  const oauthUser = c.get("user") as MochaUser | undefined;
  
  let user: User | null = null;

  if (oauthUser) {
    // Google OAuth user
    user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(oauthUser.id)
      .first<User>();

    if (!user) {
      const id = crypto.randomUUID();
      await c.env.DB.prepare(
        `INSERT INTO users (id, mocha_user_id) VALUES (?, ?)`
      )
        .bind(id, oauthUser.id)
        .run();

      user = await c.env.DB.prepare("SELECT * FROM users WHERE id = ?")
        .bind(id)
        .first<User>();
    }
  } else if (sessionTokenHeader) {
    // OTP session user
    const session = await c.env.DB.prepare(
      "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
    )
      .bind(sessionTokenHeader)
      .first<{ user_id: string }>();

    if (!session) {
      return c.json({ error: "Invalid session" }, 401);
    }

    user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    )
      .bind(session.user_id)
      .first<User>();
  } else {
    return c.json({ error: "Authentication required" }, 401);
  }

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  if (user.registration_completed) {
    return c.json({ error: "Registration already completed" }, 400);
  }

  const formData = await c.req.formData();
  const data = RegistrationSchema.parse({
    userType: formData.get("userType"),
    phoneNumber: formData.get("phoneNumber"),
    documentType: formData.get("documentType"),
    documentNumber: formData.get("documentNumber"),
    badgeNumber: formData.get("badgeNumber") || undefined,
    employeeId: formData.get("employeeId") || undefined,
    rank: formData.get("rank") || undefined,
    division: formData.get("division") || undefined,
    region: formData.get("region") || undefined,
    paymentMethod: formData.get("paymentMethod") || undefined,
    accountNumber: formData.get("accountNumber") || undefined,
    accountName: formData.get("accountName") || undefined,
  });

  const selfieFile = formData.get("selfieImage") as File;
  const documentFile = formData.get("documentImage") as File;

  if (!selfieFile || !documentFile) {
    return c.json({ error: "Both selfie and document images required" }, 400);
  }

  // Upload files to R2
  const selfieKey = `users/${user.id}/selfie_${Date.now()}.jpg`;
  const documentKey = `users/${user.id}/document_${Date.now()}.jpg`;

  await c.env.R2_BUCKET.put(selfieKey, selfieFile.stream(), {
    httpMetadata: { contentType: selfieFile.type },
  });

  await c.env.R2_BUCKET.put(documentKey, documentFile.stream(), {
    httpMetadata: { contentType: documentFile.type },
  });

  // Update user record
  await c.env.DB.prepare(
    `UPDATE users SET 
     phone_number = ?, 
     kyc_document_type = ?, 
     kyc_document_number = ?, 
     selfie_key = ?,
     document_image_key = ?,
     user_type = ?,
     registration_completed = 1,
     kyc_status = 'pending'
     WHERE id = ?`
  )
    .bind(
      data.phoneNumber, 
      data.documentType, 
      data.documentNumber, 
      selfieKey, 
      documentKey,
      data.userType,
      user.id
    )
    .run();

  // Get the user's oauth_user_id for officer tables
  const userOAuthId = oauthUser?.id || user.mocha_user_id;

  // Handle specific user types
  if (data.userType === 'dmp' && data.badgeNumber && data.rank && data.division) {
    const dmpId = crypto.randomUUID();
    await c.env.DB.prepare(
      `INSERT INTO dmp_officers (id, mocha_user_id, badge_number, rank, division)
       VALUES (?, ?, ?, ?, ?)`
    )
      .bind(dmpId, userOAuthId, data.badgeNumber, data.rank, data.division)
      .run();
  } else if (data.userType === 'brta' && data.employeeId && data.rank && data.division && data.region) {
    const brtaId = crypto.randomUUID();
    await c.env.DB.prepare(
      `INSERT INTO brta_officers (id, mocha_user_id, employee_id, rank, division, region)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
      .bind(brtaId, userOAuthId, data.employeeId, data.rank, data.division, data.region)
      .run();
  } else if (data.userType === 'citizen' && data.paymentMethod && data.accountNumber && data.accountName) {
    // Add payment method
    const paymentId = crypto.randomUUID();
    await c.env.DB.prepare(
      `INSERT INTO payment_methods (id, user_id, method_type, account_number, account_name, is_primary)
       VALUES (?, ?, ?, ?, ?, 1)`
    )
      .bind(paymentId, user.id, data.paymentMethod, data.accountNumber, data.accountName)
      .run();

    await c.env.DB.prepare(
      "UPDATE users SET default_payment_method = ? WHERE id = ?"
    )
      .bind(data.paymentMethod, user.id)
      .run();
  }

  return c.json({ 
    success: true, 
    message: "Registration completed successfully. Verification pending." 
  });
});

// ============================================================================
// Reports Routes
// ============================================================================

app.post("/api/reports", authMiddleware, async (c) => {
  const authUser = c.get("user") as MochaUser;
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mocha_user_id = ?"
  )
    .bind(authUser.id)
    .first<User>();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  // Allow access even without full verification for demo purposes
  // Note: In production, you may want to re-enable these checks
  /*
  if (user.account_status !== "active") {
    return c.json({ error: "Account restricted. Please clear penalties." }, 403);
  }

  if (user.kyc_status !== "verified") {
    return c.json({ error: "KYC verification required" }, 403);
  }
  */

  const formData = await c.req.formData();
  const vehicleNumberValue = formData.get("vehicleNumber") as string;
  const data = CreateReportSchema.parse({
    vehicleType: formData.get("vehicleType"),
    violationType: formData.get("violationType"),
    vehicleNumber: vehicleNumberValue?.trim() || undefined,
    description: formData.get("description") || undefined,
    latitude: parseFloat(formData.get("latitude") as string),
    longitude: parseFloat(formData.get("longitude") as string),
    address: formData.get("address"),
  });

  const imageFile = formData.get("image") as File;
  if (!imageFile) {
    return c.json({ error: "Image required" }, 400);
  }

  // Generate case number
  const today = new Date().toISOString().split("T")[0].replace(/-/g, "");
  const sequence = await c.env.DB.prepare(
    "SELECT sequence FROM case_sequences WHERE date_key = ?"
  )
    .bind(today)
    .first<{ sequence: number }>();

  const nextSeq = sequence ? sequence.sequence + 1 : 1;
  await c.env.DB.prepare(
    "INSERT OR REPLACE INTO case_sequences (date_key, sequence) VALUES (?, ?)"
  )
    .bind(today, nextSeq)
    .run();

  const year = today.substring(0, 4);
  const month = today.substring(4, 6);
  const day = today.substring(6, 8);
  const caseNumber = `TE-${year}-${month}-${day}-${String(nextSeq).padStart(5, "0")}`;

  // Upload image to R2
  const reportId = crypto.randomUUID();
  const imageKey = `reports/${reportId}/${imageFile.name}`;
  await c.env.R2_BUCKET.put(imageKey, imageFile.stream(), {
    httpMetadata: { contentType: imageFile.type },
  });

  // Use "UNKNOWN" if no vehicle number provided
  const finalVehicleNumber = data.vehicleNumber || "UNKNOWN";

  // Check for existing incident (only if vehicle number is known)
  let existingIncident = null;
  if (data.vehicleNumber) {
    existingIncident = await c.env.DB.prepare(
      `SELECT id FROM incident_races 
       WHERE vehicle_number = ? AND violation_type = ? 
       AND created_at > datetime('now', '-5 minutes')
       AND ABS(latitude - ?) < 0.001 AND ABS(longitude - ?) < 0.001
       LIMIT 1`
    )
      .bind(data.vehicleNumber, data.violationType, data.latitude, data.longitude)
      .first<{ id: string }>();
  }

  let incidentId = existingIncident?.id;
  const isFirstReporter = !existingIncident;

  if (!existingIncident) {
    // Create new incident race
    incidentId = crypto.randomUUID();
    await c.env.DB.prepare(
      `INSERT INTO incident_races (id, first_reporter_id, first_report_id, vehicle_number, violation_type, latitude, longitude)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(incidentId, user.id, reportId, finalVehicleNumber, data.violationType, data.latitude, data.longitude)
      .run();
  } else {
    // Add to duplicate reports
    const position = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM duplicate_reports WHERE incident_id = ?"
    )
      .bind(incidentId)
      .first<{ count: number }>();

    await c.env.DB.prepare(
      `INSERT INTO duplicate_reports (id, incident_id, report_id, user_id, position)
       VALUES (?, ?, ?, ?, ?)`
    )
      .bind(crypto.randomUUID(), incidentId, reportId, user.id, (position?.count || 0) + 2)
      .run();

    await c.env.DB.prepare(
      "UPDATE incident_races SET total_reports = total_reports + 1 WHERE id = ?"
    )
      .bind(incidentId)
      .run();
  }

  // Create report
  await c.env.DB.prepare(
    `INSERT INTO reports (id, user_id, case_number, violation_type, vehicle_number, description, 
     image_key, latitude, longitude, address, incident_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      reportId,
      user.id,
      caseNumber,
      data.violationType,
      finalVehicleNumber,
      data.description || null,
      imageKey,
      data.latitude,
      data.longitude,
      data.address,
      incidentId
    )
    .run();

  // Update user stats
  await c.env.DB.prepare(
    "UPDATE users SET total_reports = total_reports + 1 WHERE id = ?"
  )
    .bind(user.id)
    .run();

  return c.json({ 
    reportId, 
    caseNumber,
    isFirstReporter,
    message: isFirstReporter 
      ? "You are the first reporter for this incident!" 
      : "Similar incident already reported. Only first reporter receives reward."
  }, 201);
});

app.get("/api/reports", authMiddleware, async (c) => {
  try {
    const authUser = c.get("user") as MochaUser;
    const user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(authUser.id)
      .first<User>();

    if (!user) {
      return c.json([]);
    }

    const { results } = await c.env.DB.prepare(
      "SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC"
    )
      .bind(user.id)
      .all<Report>();

    return c.json(results || []);
  } catch (error) {
    console.error("Error fetching user reports:", error);
    return c.json([]);
  }
});

app.get("/api/reports/:id/image", async (c) => {
  const reportId = c.req.param("id");
  const report = await c.env.DB.prepare("SELECT * FROM reports WHERE id = ?")
    .bind(reportId)
    .first<Report>();

  if (!report) {
    return c.json({ error: "Report not found" }, 404);
  }

  const object = await c.env.R2_BUCKET.get(report.image_key);
  if (!object) {
    return c.json({ error: "Image not found" }, 404);
  }

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);

  return c.body(object.body, { headers });
});

// ============================================================================
// Search Routes
// ============================================================================

app.get("/api/search/case/:caseNumber", authMiddleware, async (c) => {
  const caseNumber = c.req.param("caseNumber");
  const report = await c.env.DB.prepare(
    "SELECT * FROM reports WHERE case_number = ?"
  )
    .bind(caseNumber)
    .first<Report>();

  return c.json(report || null);
});

app.get("/api/search/vehicle/:vehicleNumber", authMiddleware, async (c) => {
  const vehicleNumber = c.req.param("vehicleNumber");
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM reports WHERE vehicle_number = ? ORDER BY created_at DESC"
  )
    .bind(vehicleNumber.toUpperCase())
    .all<Report>();

  return c.json(results);
});

// ============================================================================
// Social Crime Routes
// ============================================================================

app.post("/api/social-crime", authMiddleware, async (c) => {
  const authUser = c.get("user") as MochaUser;
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mocha_user_id = ?"
  )
    .bind(authUser.id)
    .first<User>();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  // Allow access even without full verification for demo purposes
  // Note: In production, you may want to re-enable these checks
  /*
  if (user.account_status !== "active") {
    return c.json({ error: "Account restricted. Please clear penalties." }, 403);
  }

  if (user.kyc_status !== "verified") {
    return c.json({ error: "KYC verification required" }, 403);
  }
  */

  const formData = await c.req.formData();
  const data = CreateSocialCrimeReportSchema.parse({
    category: formData.get("category"),
    description: formData.get("description"),
    latitude: parseFloat(formData.get("latitude") as string),
    longitude: parseFloat(formData.get("longitude") as string),
    address: formData.get("address"),
    isAnonymous: formData.get("isAnonymous") === "true",
  });

  // Generate case number
  const today = new Date().toISOString().split("T")[0].replace(/-/g, "");
  const sequence = await c.env.DB.prepare(
    "SELECT sequence FROM case_sequences WHERE date_key = ?"
  )
    .bind(today)
    .first<{ sequence: number }>();

  const nextSeq = sequence ? sequence.sequence + 1 : 1;
  await c.env.DB.prepare(
    "INSERT OR REPLACE INTO case_sequences (date_key, sequence) VALUES (?, ?)"
  )
    .bind(today, nextSeq)
    .run();

  const year = today.substring(0, 4);
  const month = today.substring(4, 6);
  const day = today.substring(6, 8);
  const caseNumber = `SC-${year}-${month}-${day}-${String(nextSeq).padStart(5, "0")}`;

  const reportId = crypto.randomUUID();
  let imageKey: string | null = null;

  // Upload image if provided
  const imageFile = formData.get("image") as File | null;
  if (imageFile) {
    imageKey = `social-crime/${reportId}/${imageFile.name}`;
    await c.env.R2_BUCKET.put(imageKey, imageFile.stream(), {
      httpMetadata: { contentType: imageFile.type },
    });
  }

  // Create report (stored in reports table with special violation_type)
  await c.env.DB.prepare(
    `INSERT INTO reports (id, user_id, case_number, violation_type, vehicle_number, description, 
     image_key, latitude, longitude, address, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      reportId,
      data.isAnonymous ? "anonymous" : user.id,
      caseNumber,
      `SOCIAL_CRIME:${data.category}`,
      "N/A",
      data.description,
      imageKey || "",
      data.latitude,
      data.longitude,
      data.address,
      "pending"
    )
    .run();

  // Don't update user stats for anonymous reports
  if (!data.isAnonymous) {
    await c.env.DB.prepare(
      "UPDATE users SET total_reports = total_reports + 1 WHERE id = ?"
    )
      .bind(user.id)
      .run();
  }

  return c.json({ 
    reportId, 
    caseNumber,
    message: "Social crime report submitted successfully. Authorities have been notified."
  }, 201);
});

// ============================================================================
// KYC Routes
// ============================================================================

app.post("/api/kyc", authMiddleware, async (c) => {
  const authUser = c.get("user") as MochaUser;
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mocha_user_id = ?"
  )
    .bind(authUser.id)
    .first<User>();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  if (user.kyc_status === "verified") {
    return c.json({ error: "KYC already verified" }, 400);
  }

  const formData = await c.req.formData();
  const data = KYCSubmissionSchema.parse({
    documentType: formData.get("documentType"),
    documentNumber: formData.get("documentNumber"),
    phoneNumber: formData.get("phoneNumber"),
  });

  const documentImage = formData.get("documentImage") as File;
  const selfieImage = formData.get("selfieImage") as File;

  if (!documentImage || !selfieImage) {
    return c.json({ error: "Both document and selfie images required" }, 400);
  }

  // Upload KYC documents
  const docKey = `kyc/${user.id}/document_${Date.now()}.jpg`;
  const selfieKey = `kyc/${user.id}/selfie_${Date.now()}.jpg`;

  await c.env.R2_BUCKET.put(docKey, documentImage.stream(), {
    httpMetadata: { contentType: documentImage.type },
  });

  await c.env.R2_BUCKET.put(selfieKey, selfieImage.stream(), {
    httpMetadata: { contentType: selfieImage.type },
  });

  // Update user with KYC info
  await c.env.DB.prepare(
    `UPDATE users SET 
     kyc_document_type = ?, kyc_document_number = ?, 
     phone_number = ?, kyc_status = 'pending'
     WHERE id = ?`
  )
    .bind(data.documentType, data.documentNumber, data.phoneNumber, user.id)
    .run();

  return c.json({ success: true, message: "KYC submitted for verification" });
});

// ============================================================================
// Profile Management Routes
// ============================================================================

// Upload profile picture
app.post("/api/users/profile-image", async (c) => {
  let userId: string | null = null;

  // Check for both OAuth and OTP session authentication
  try {
    const authUser = c.get("user") as MochaUser;
    if (authUser) {
      const user = await c.env.DB.prepare(
        "SELECT * FROM users WHERE mocha_user_id = ?"
      )
        .bind(authUser.id)
        .first<User>();
      userId = user?.id || null;
    }
  } catch (error) {
    // Try OTP session
    const sessionToken = c.req.header('X-Session-Token');
    if (sessionToken) {
      const session = await c.env.DB.prepare(
        "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
      )
        .bind(sessionToken)
        .first<{ user_id: string }>();
      userId = session?.user_id || null;
    }
  }

  if (!userId) {
    return c.json({ error: "Authentication required" }, 401);
  }

  try {
    const formData = await c.req.formData();
    const imageFile = formData.get("profileImage") as File;

    if (!imageFile) {
      return c.json({ error: "Profile image required" }, 400);
    }

    // Validate file type and size
    if (!imageFile.type.startsWith('image/')) {
      return c.json({ error: "Invalid file type. Please upload an image." }, 400);
    }

    if (imageFile.size > 5 * 1024 * 1024) { // 5MB limit
      return c.json({ error: "File size too large. Maximum 5MB allowed." }, 400);
    }

    // Upload to R2
    const imageKey = `profile/${userId}/profile_${Date.now()}.jpg`;
    await c.env.R2_BUCKET.put(imageKey, imageFile.stream(), {
      httpMetadata: { contentType: imageFile.type },
    });

    // Update user record
    await c.env.DB.prepare(
      "UPDATE users SET profile_image_key = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    )
      .bind(imageKey, userId)
      .run();

    return c.json({ success: true, message: "Profile picture uploaded successfully" });
  } catch (error) {
    console.error("Error uploading profile image:", error);
    return c.json({ error: "Failed to upload profile image" }, 500);
  }
});

// Get profile image
app.get("/api/users/profile-image/:userId", async (c) => {
  const userId = c.req.param("userId");
  
  const user = await c.env.DB.prepare("SELECT profile_image_key FROM users WHERE id = ?")
    .bind(userId)
    .first<{ profile_image_key: string | null }>();

  if (!user?.profile_image_key) {
    return c.json({ error: "Profile image not found" }, 404);
  }

  const object = await c.env.R2_BUCKET.get(user.profile_image_key);
  if (!object) {
    return c.json({ error: "Image file not found" }, 404);
  }

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);

  return c.body(object.body, { headers });
});

// Send OTP for contact change
app.post("/api/users/send-password-otp", async (c) => {
  let userId: string | null = null;

  // Check for both OAuth and OTP session authentication
  try {
    const authUser = c.get("user") as MochaUser;
    if (authUser) {
      const user = await c.env.DB.prepare(
        "SELECT * FROM users WHERE mocha_user_id = ?"
      )
        .bind(authUser.id)
        .first<User>();
      userId = user?.id || null;
    }
  } catch (error) {
    // Try OTP session
    const sessionToken = c.req.header('X-Session-Token');
    if (sessionToken) {
      const session = await c.env.DB.prepare(
        "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
      )
        .bind(sessionToken)
        .first<{ user_id: string }>();
      userId = session?.user_id || null;
    }
  }

  if (!userId) {
    return c.json({ error: "Authentication required" }, 401);
  }

  const { newContact, contactType } = await c.req.json();

  if (!newContact || !contactType) {
    return c.json({ error: "Contact information and type required" }, 400);
  }

  // Validate format
  if (contactType === 'email' && !newContact.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    return c.json({ error: "Invalid email format" }, 400);
  }

  if (contactType === 'mobile' && !newContact.match(/^(\+880|880|0)?1[3-9]\d{8}$/)) {
    return c.json({ error: "Invalid mobile number format" }, 400);
  }

  // Check if contact already exists
  const existingUser = await c.env.DB.prepare(
    contactType === 'email'
      ? "SELECT id FROM users WHERE mocha_user_id LIKE ? AND id != ?"
      : "SELECT id FROM users WHERE phone_number = ? AND id != ?"
  )
    .bind(contactType === 'email' ? `%${newContact}%` : newContact, userId)
    .first();

  if (existingUser) {
    return c.json({ error: "This contact is already registered with another account" }, 400);
  }

  // Generate OTP
  const code = generateOTP();
  const expiresAt = new Date(Date.now() + 2 * 60 * 1000).toISOString();

  // Delete existing OTPs for this user
  await c.env.DB.prepare(
    "DELETE FROM otp_codes WHERE identifier = ? AND identifier_type = ?"
  )
    .bind(`password_change_${userId}_${newContact}`, contactType)
    .run();

  // Store OTP
  const otpId = crypto.randomUUID();
  await c.env.DB.prepare(
    "INSERT INTO otp_codes (id, identifier, identifier_type, code, expires_at) VALUES (?, ?, ?, ?, ?)"
  )
    .bind(otpId, `password_change_${userId}_${newContact}`, contactType, code, expiresAt)
    .run();

  console.log(`Contact change OTP for user ${userId} to ${newContact}: ${code}`);

  return c.json({ 
    success: true, 
    message: `OTP sent to ${newContact}`,
    ...(isDevelopmentMode(c.env) && { devCode: code })
  });
});

// Change contact information
app.post("/api/users/change-contact", async (c) => {
  let userId: string | null = null;

  // Check for both OAuth and OTP session authentication
  const sessionToken = c.req.header('X-Session-Token');
  const authUser = c.get("user") as MochaUser;
  
  if (authUser) {
    const user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(authUser.id)
      .first<User>();
    userId = user?.id || null;
  } else if (sessionToken) {
    const session = await c.env.DB.prepare(
      "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
    )
      .bind(sessionToken)
      .first<{ user_id: string }>();
    userId = session?.user_id || null;
  }

  if (!userId) {
    return c.json({ error: "Authentication required" }, 401);
  }

  const { newContact, contactType, otp } = await c.req.json();

  // Verify OTP
  const otpRecord = await c.env.DB.prepare(
    `SELECT * FROM otp_codes 
     WHERE identifier = ? AND identifier_type = ? 
     ORDER BY created_at DESC LIMIT 1`
  )
    .bind(`password_change_${userId}_${newContact}`, contactType)
    .first<{
      id: string;
      code: string;
      expires_at: string;
      verified: boolean;
      attempts: number;
    }>();

  if (!otpRecord) {
    return c.json({ error: "No OTP found. Please request a new one." }, 404);
  }

  if (otpRecord.verified) {
    return c.json({ error: "OTP already used. Please request a new one." }, 400);
  }

  if (otpRecord.attempts >= 3) {
    return c.json({ error: "Too many failed attempts. Please request a new OTP." }, 400);
  }

  if (new Date(otpRecord.expires_at) < new Date()) {
    return c.json({ error: "OTP expired. Please request a new one." }, 400);
  }

  if (otpRecord.code !== otp) {
    await c.env.DB.prepare(
      "UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?"
    )
      .bind(otpRecord.id)
      .run();
    return c.json({ error: "Invalid OTP code" }, 400);
  }

  // Mark OTP as verified
  await c.env.DB.prepare(
    "UPDATE otp_codes SET verified = 1 WHERE id = ?"
  )
    .bind(otpRecord.id)
    .run();

  // Update user contact information
  if (contactType === 'mobile') {
    await c.env.DB.prepare(
      "UPDATE users SET phone_number = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    )
      .bind(newContact, userId)
      .run();
  } else {
    // For email, we would update the OAuth user's email in the external service
    // For now, just update a field to track it
    await c.env.DB.prepare(
      "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    )
      .bind(userId)
      .run();
  }

  return c.json({ success: true, message: "Contact information updated successfully" });
});

// Deactivate account
app.post("/api/users/deactivate", async (c) => {
  let userId: string | null = null;

  // Check for both OAuth and OTP session authentication
  const sessionToken = c.req.header('X-Session-Token');
  const authUser = c.get("user") as MochaUser;
  
  if (authUser) {
    const user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(authUser.id)
      .first<User>();
    userId = user?.id || null;
  } else if (sessionToken) {
    const session = await c.env.DB.prepare(
      "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
    )
      .bind(sessionToken)
      .first<{ user_id: string }>();
    userId = session?.user_id || null;
  }

  if (!userId) {
    return c.json({ error: "Authentication required" }, 401);
  }

  // Update account status to deactivated
  await c.env.DB.prepare(
    "UPDATE users SET account_status = 'deactivated', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(userId)
    .run();

  return c.json({ success: true, message: "Account deactivated successfully" });
});

// Delete account permanently
app.delete("/api/users/delete", async (c) => {
  let userId: string | null = null;

  // Check for both OAuth and OTP session authentication
  const sessionToken = c.req.header('X-Session-Token');
  const authUser = c.get("user") as MochaUser;
  
  if (authUser) {
    const user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    )
      .bind(authUser.id)
      .first<User>();
    userId = user?.id || null;
  } else if (sessionToken) {
    const session = await c.env.DB.prepare(
      "SELECT user_id FROM auth_sessions WHERE session_token = ? AND is_verified = 1"
    )
      .bind(sessionToken)
      .first<{ user_id: string }>();
    userId = session?.user_id || null;
  }

  if (!userId) {
    return c.json({ error: "Authentication required" }, 401);
  }

  try {
    // Delete all user-related data (in order due to foreign key constraints)
    await c.env.DB.prepare("DELETE FROM duplicate_reports WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM payments WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM penalties WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM payment_methods WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM reports WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM auth_sessions WHERE user_id = ?").bind(userId).run();
    await c.env.DB.prepare("DELETE FROM users WHERE id = ?").bind(userId).run();

    return c.json({ success: true, message: "Account deleted permanently" });
  } catch (error) {
    console.error("Error deleting user account:", error);
    return c.json({ error: "Failed to delete account" }, 500);
  }
});

// ============================================================================
// Penalties Routes
// ============================================================================

app.get("/api/penalties", authMiddleware, async (c) => {
  const authUser = c.get("user") as MochaUser;
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mocha_user_id = ?"
  )
    .bind(authUser.id)
    .first<User>();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM penalties WHERE user_id = ? ORDER BY created_at DESC"
  )
    .bind(user.id)
    .all<Penalty>();

  return c.json(results);
});

// ============================================================================
// DMP Officer Routes
// ============================================================================

app.get("/api/dmp/reports/pending", authMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      "SELECT * FROM reports WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50"
    ).all<Report>();

    return c.json(results || []);
  } catch (error) {
    console.error("Error fetching pending reports:", error);
    return c.json([]);
  }
});

app.post("/api/dmp/reports/verify", authMiddleware, async (c) => {
  const body = await c.req.json();
  const data = VerifyReportSchema.parse(body);

  const report = await c.env.DB.prepare("SELECT * FROM reports WHERE id = ?")
    .bind(data.reportId)
    .first<Report>();

  if (!report) {
    return c.json({ error: "Report not found" }, 404);
  }

  const authUser = c.get("user") as MochaUser;

  if (data.action === "approve") {
    const fineAmount = VIOLATION_FINES[report.violation_type] || 500;
    const rewardAmount = fineAmount * 0.2;

    await c.env.DB.prepare(
      `UPDATE reports SET status = 'approved', fine_amount = ?, reward_amount = ?, 
       officer_notes = ?, verified_by = ?, verified_at = CURRENT_TIMESTAMP 
       WHERE id = ?`
    )
      .bind(fineAmount, rewardAmount, data.notes || null, authUser.email, data.reportId)
      .run();

    await c.env.DB.prepare(
      `UPDATE users SET approved_reports = approved_reports + 1, 
       total_rewards = total_rewards + ? WHERE id = ?`
    )
      .bind(rewardAmount, report.user_id)
      .run();
  } else {
    await c.env.DB.prepare(
      `UPDATE reports SET status = 'rejected', rejection_reason = ?, 
       is_false_report = ?, verified_by = ?, verified_at = CURRENT_TIMESTAMP 
       WHERE id = ?`
    )
      .bind(data.notes || null, data.isFalseReport || false, authUser.email, data.reportId)
      .run();

    // Apply penalty if false report
    if (data.isFalseReport) {
      const penaltyId = crypto.randomUUID();
      const amount = 500;
      const dueDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

      await c.env.DB.prepare(
        `INSERT INTO penalties (id, user_id, report_id, amount, reason, due_date)
         VALUES (?, ?, ?, ?, 'false_report', ?)`
      )
        .bind(penaltyId, report.user_id, data.reportId, amount, dueDate)
        .run();

      await c.env.DB.prepare(
        "UPDATE users SET has_pending_penalties = 1, account_status = 'restricted' WHERE id = ?"
      )
        .bind(report.user_id)
        .run();
    }
  }

  return c.json({ success: true });
});

export default app;
