import { z } from "zod";

// Vehicle Types
export const VEHICLE_TYPES = [
  "Private Car",
  "Motorcycle", 
  "Public Transport",
  "E-Rickshaw",
  "Commercial Vehicle"
] as const;

// Traffic Violation Categories (Comprehensive Bangladesh Traffic Laws)
export const TRAFFIC_VIOLATION_CATEGORIES = {
  "Private Car": {
    en: [
      "Driving without a valid driving licence",
      "Driving on the wrong side of the road", 
      "Ignoring traffic lights or police signals",
      "Overspeeding or racing",
      "Using a mobile phone while driving",
      "Driving under the influence of alcohol/drugs",
      "Not wearing seat belts",
      "Illegal parking",
      "Using high beams improperly", 
      "Blocking pedestrian crossings",
      "Making illegal U-turns",
      "Using horns in silent zones",
      "Driving an unregistered vehicle",
      "Driving without valid insurance",
      "Refusing to stop for police"
    ],
    bn: [
      "বৈধ ড্রাইভিং লাইসেন্স ছাড়া গাড়ি চালানো",
      "রাস্তার ভুল পাশে গাড়ি চালানো",
      "ট্রাফিক সিগন্যাল বা পুলিশের নির্দেশ অমান্য করা", 
      "অতিরিক্ত গতিতে বা রেস করে গাড়ি চালানো",
      "গাড়ি চালানোর সময় মোবাইল ব্যবহার করা",
      "মদ্যপ বা নেশাগ্রস্ত অবস্থায় গাড়ি চালানো",
      "সিটবেল্ট না পরা",
      "বেআইনি বা রাস্তা অবরোধ করে পার্কিং করা",
      "অযথা হাই বিম বা ফগ লাইট ব্যবহার",
      "জেব্রা ক্রসিং বা মোড়ে গাড়ি থামিয়ে পথচারী বাধা সৃষ্টি করা",
      "সংকেত না দিয়ে ইউ-টার্ন বা মোড় নেওয়া",
      "নিষিদ্ধ এলাকায় হর্ন ব্যবহার",
      "রেজিস্ট্রেশন মেয়াদোত্তীর্ণ বা অনিবন্ধিত গাড়ি চালানো",
      "বীমা বা ফিটনেস সার্টিফিকেট ছাড়া গাড়ি চালানো", 
      "পুলিশের নির্দেশে না থামা"
    ]
  },
  "Motorcycle": {
    en: [
      "Riding without a helmet",
      "Triple riding", 
      "Wrong-side riding",
      "Riding on footpaths",
      "Overspeeding or reckless overtaking",
      "Driving without licence",
      "Not using indicators",
      "Modified exhaust pipes",
      "Carrying goods unsafely", 
      "Using a mobile phone while riding",
      "Performing stunts",
      "Parking on sidewalks",
      "Driving without proper lights at night"
    ],
    bn: [
      "চালক বা আরোহী হেলমেট না পরা",
      "এক মোটরসাইকেলে তিনজন বা তার বেশি যাত্রী বহন",
      "রাস্তার ভুল পাশে চালানো",
      "ফুটপাথ বা জনপথে মোটরসাইকেল চালানো", 
      "অতিরিক্ত গতি বা ঝুঁকিপূর্ণ ওভারটেক",
      "লাইসেন্স বা রেজিস্ট্রেশন ছাড়া চালানো",
      "মোড় নেওয়ার সময় সংকেত না দেওয়া",
      "নিষিদ্ধ সাইলেন্সার বা মাফলার ব্যবহার (শব্দদূষণ)",
      "বিপজ্জনকভাবে মালামাল বহন",
      "চালানোর সময় মোবাইল ব্যবহার", 
      "রাস্তার মধ্যে স্টান্ট বা হুইলি করা",
      "ফুটপাথে বেআইনি পার্কিং",
      "রাতে লাইট ছাড়া চালানো"
    ]
  },
  "Public Transport": {
    en: [
      "Picking up/dropping passengers in non-designated areas",
      "Overloading passengers", 
      "Aggressive driving for passengers",
      "Stopping suddenly in the road",
      "Overcharging or denying meter-based fare",
      "Driving without route permit",
      "Ignoring traffic police signals",
      "Using defective or smoky vehicles",
      "Blocking lanes or intersections",
      "Not maintaining bus stops",
      "Reckless overtaking",
      "Driving with open doors",
      "Not maintaining vehicle fitness",
      "Misbehaviour by driver/conductor"
    ],
    bn: [
      "নির্ধারিত স্থানের বাইরে যাত্রী ওঠা-নামা করানো",
      "যাত্রী ধারণক্ষমতার বেশি যাত্রী বহন",
      "যাত্রী নেওয়ার প্রতিযোগিতায় বেপরোয়া চালানো",
      "রাস্তার মাঝখানে হঠাৎ থামা",
      "ভাড়ার বেশি টাকা নেওয়া বা মিটার ব্যবহার না করা (সিএনজি/অটোরিকশা)",
      "রুট পারমিট বা রেজিস্ট্রেশন ছাড়া চলাচল",
      "ট্রাফিক পুলিশের নির্দেশ অমান্য করা", 
      "ধোঁয়া নির্গত বা ত্রুটিপূর্ণ যানবাহন ব্যবহার",
      "রাস্তা বা মোড় অবরোধ করা",
      "নির্ধারিত বাস স্টপ বা বে ব্যবহার না করা",
      "বেপরোয়া ওভারটেক বা লেন ভঙ্গ",
      "খোলা দরজা বা ঝুলন্ত যাত্রী নিয়ে চালানো",
      "বীমা বা ফিটনেস ছাড়া গাড়ি চালানো",
      "চালক বা সহকারীর অসদাচরণ বা হয়রানি"
    ]
  },
  "E-Rickshaw": {
    en: [
      "Overloading passengers or goods",
      "Charging excessive fare",
      "Driving without valid registration",
      "Riding on prohibited roads", 
      "Reckless driving and wrong-side riding",
      "Obstructive parking",
      "Using non-standard batteries",
      "Driving without proper lights at night",
      "Illegal modification of motor or chassis"
    ],
    bn: [
      "যাত্রী বা মালামাল অতিরিক্ত বহন",
      "অতিরিক্ত ভাড়া নেওয়া",
      "বৈধ রেজিস্ট্রেশন বা পারমিট ছাড়া চালানো",
      "যে রাস্তায় ই-রিকশা চলাচল নিষিদ্ধ সেখানে চলাচল",
      "বেপরোয়া গাড়ি চালানো ও ভুল দিকে চলাচল",
      "যানজট সৃষ্টি করে পার্কিং",
      "অননুমোদিত বা অনিরাপদ ব্যাটারি ব্যবহার",
      "রাতে সঠিক লাইট বা রিফ্লেক্টর ছাড়া চালানো",
      "মোটর বা চ্যাসির অবৈধ পরিবর্তন"
    ]
  },
  "Commercial Vehicle": {
    en: [
      "Overloading beyond legal weight limit",
      "Carrying passengers in goods vehicles",
      "Driving without proper documents", 
      "Parking on roads blocking traffic",
      "Operating without reflective signs/lights at night",
      "Driving with uncovered cargo",
      "Illegal modification of vehicle body",
      "Not maintaining brake/lighting systems",
      "Driving during restricted hours",
      "Failing to give way to emergency vehicles",
      "Driving under fatigue"
    ],
    bn: [
      "অনুমোদিত ওজনসীমার বেশি মালামাল বহন",
      "পণ্যবাহী গাড়িতে যাত্রী বহন",
      "বৈধ নথি (লাইসেন্স, রুট পারমিট, ফিটনেস) ছাড়া চালানো",
      "রাস্তা বা মোড়ে গাড়ি দাঁড় করিয়ে যানজট সৃষ্টি",
      "রাতে রিফ্লেকটিভ সাইন বা লাইট ছাড়া চলাচল", 
      "খোলা বা ঠিকভাবে বাঁধা নয় এমন মাল বহন",
      "অনুমতি ছাড়া গাড়ির কাঠামো পরিবর্তন",
      "ব্রেক বা লাইট ত্রুটিপূর্ণ অবস্থায় চালানো",
      "নির্দিষ্ট সময়ে নিষিদ্ধ এলাকায় প্রবেশ",
      "এমার্জেন্সি যানবাহনকে পথ না দেওয়া",
      "ক্লান্তি বা নিদ্রাহীন অবস্থায় গাড়ি চালানো"
    ]
  }
} as const;

// Get violations for vehicle type with bilingual support
export function getViolationsForVehicle(vehicleType: string, language: 'en' | 'bn' = 'en'): readonly string[] {
  const category = TRAFFIC_VIOLATION_CATEGORIES[vehicleType as keyof typeof TRAFFIC_VIOLATION_CATEGORIES];
  return category ? category[language] : [];
}

// Updated violation fines based on Bangladesh Traffic Laws 2025
export const VIOLATION_FINES: Record<string, number> = {
  // Private Car Violations
  "Driving without a valid driving licence": 25000,
  "Driving on the wrong side of the road": 10000,
  "Ignoring traffic lights or police signals": 5000,
  "Overspeeding or racing": 50000,
  "Using a mobile phone while driving": 5000,
  "Driving under the influence of alcohol/drugs": 10000,
  "Not wearing seat belts": 500,
  "Illegal parking": 5000,
  "Using high beams improperly": 5000,
  "Blocking pedestrian crossings": 5000,
  "Making illegal U-turns": 5000,
  "Using horns in silent zones": 5000,
  "Driving an unregistered vehicle": 50000,
  "Driving without valid insurance": 10000,
  "Refusing to stop for police": 25000,
  
  // Motorcycle Violations  
  "Riding without a helmet": 1000,
  "Triple riding": 5000,
  "Wrong-side riding": 5000,
  "Riding on footpaths": 5000,
  "Overspeeding or reckless overtaking": 10000,
  "Driving without licence": 25000,
  "Not using indicators": 1000,
  "Modified exhaust pipes": 5000,
  "Carrying goods unsafely": 2000,
  "Using a mobile phone while riding": 5000,
  "Performing stunts": 10000,
  "Parking on sidewalks": 1000,
  "Driving without proper lights at night": 2000,
  
  // Public Transport Violations
  "Picking up/dropping passengers in non-designated areas": 10000,
  "Overloading passengers": 25000,
  "Aggressive driving for passengers": 10000,
  "Stopping suddenly in the road": 5000,
  "Overcharging or denying meter-based fare": 5000,
  "Driving without route permit": 25000,
  "Ignoring traffic police signals": 10000,
  "Using defective or smoky vehicles": 15000,
  "Blocking lanes or intersections": 10000,
  "Not maintaining bus stops": 5000,
  "Reckless overtaking": 10000,
  "Driving with open doors": 10000,
  "Not maintaining vehicle fitness": 25000,
  "Misbehaviour by driver/conductor": 5000,
  
  // E-Rickshaw Violations
  "Overloading passengers or goods": 5000,
  "Charging excessive fare": 2000,
  "Driving without valid registration": 10000,
  "Riding on prohibited roads": 5000,
  "Reckless driving and wrong-side riding": 5000,
  "Obstructive parking": 2000,
  "Using non-standard batteries": 10000,
  "Illegal modification of motor or chassis": 15000,
  
  // Commercial Vehicle Violations
  "Overloading beyond legal weight limit": 100000,
  "Carrying passengers in goods vehicles": 25000,
  "Driving without proper documents": 25000,
  "Parking on roads blocking traffic": 10000,
  "Operating without reflective signs/lights at night": 10000,
  "Driving with uncovered cargo": 15000,
  "Illegal modification of vehicle body": 300000,
  "Not maintaining brake/lighting systems": 25000,
  "Driving during restricted hours": 10000,
  "Failing to give way to emergency vehicles": 10000,
  "Driving under fatigue": 10000
};

// Social Crime Categories (Comprehensive Bangladesh Law)
export const SOCIAL_CRIME_CATEGORIES = {
  "Crimes of Violence / Person-centric": {
    en: [
      "Murder / Homicide",
      "Attempted murder", 
      "Assault (serious bodily harm)",
      "Rape / Sexual assault / child sexual abuse",
      "Domestic violence (spousal abuse, child abuse)",
      "Kidnapping / Abduction",
      "Human trafficking (for labour, sexual exploitation)",
      "Mob violence / lynching"
    ],
    bn: [
      "হত্যা / হুমকিহত্যা",
      "হত্যা প্রচেষ্টা",
      "মারামারি, গুরুতর দেহরোগ সৃষ্টি করা",
      "ধর্ষণ / যৌন নির্যাতন / শিশু যৌন নির্যাতন",
      "পারিবারিক হিংসা (স্বামী স্ত্রী নির্যাতন, শিশু নির্যাতন)",
      "অপহরণ / অনৈচ্ছিক বন্দী রাখার অপরাধ",
      "মানব পাচার (শ্রমিক, যৌন শোষণ)",
      "গণহত্যা / মব হিংসা"
    ]
  },
  "Property Crimes": {
    en: [
      "Theft / Burglary",
      "Robbery / Dacoity (armed robbery)",
      "Motor vehicle theft / snatching",
      "Land grabbing / illegal possession of land", 
      "Arson (setting property on fire)"
    ],
    bn: [
      "চুরি / ঘর ভাঙ্গচুর",
      "ডাকাতি / সশস্ত্র ডাকাতি",
      "মোটরযান চুরি / ছিনতাই",
      "জমি দখল / অনৈতিকভাবে জমি অধিকার করা",
      "অগ্নিসংযোগ (সম্পত্তিতে আগুন দেওয়া)"
    ]
  },
  "Economic / White-collar Crimes": {
    en: [
      "Corruption / bribery",
      "Embezzlement / misappropriation of funds",
      "Fraud (financial frauds, bank frauds)",
      "Money laundering",
      "Smuggling / contraband trade",
      "Tax evasion"
    ],
    bn: [
      "দুর্নীতি / ঘুষ",
      "তহবিল বদলি / অর্থ দুর্নীতি",
      "প্রতারণা (ব্যাংক প্রতারণা, আর্থিক স্ক্যাম)",
      "টাকা পাচার",
      "চোরাচালানি / অবৈধ কর্পোরেট বাণিজ্য",
      "কর ফাঁকি"
    ]
  },
  "Crimes against Social / Moral Legislation": {
    en: [
      "Dowry harassment / forced dowry",
      "Child marriage",
      "Prostitution / trafficking in the sex trade",
      "Indecent representation / sexual harassment in public / eve-teasing",
      "Drugs addiction / illegal drug trafficking",
      "Cyber‐crimes (online exploitation, pornography, cyber-bullying)"
    ],
    bn: [
      "যৌতুক নির্যাতন / জবরদস্তি যৌতুক",
      "বাল্যবিয়ে",
      "পতিতাবৃত্তি / যৌন পাচার",
      "অশ্লীল আচরণ / জনসমক্ষে যৌন হয়রানি / ইভ-টিজিং",
      "মাদকাসক্তি / অবৈধ মাদক পাচার",
      "সাইবার অপরাধ (অনলাইনে শোষণ, পর্নোগ্রাফি, সাইবার বুলিং)"
    ]
  },
  "Organised & High-Tech Crimes": {
    en: [
      "Gang crime / organised youth gangs",
      "Organized drug cartels", 
      "Cybercrime (hacking, identity theft, online scamming)",
      "Trafficking networks (women, children, organs)"
    ],
    bn: [
      "গ্যাং অপরাধ / কিশোর গ্যাং",
      "মাদক সিন্ডিকেট",
      "সাইবার অপরাধ (হ্যাকিং, পরিচয় চুরি, অনলাইন স্ক্যাম)",
      "পাচার নেটওয়ার্ক (নারী, শিশু, অঙ্গ পাচার)"
    ]
  },
  "Crimes against Public Order / State / Society": {
    en: [
      "Terrorism / violent extremism",
      "Hate crimes / communal violence / violence against minorities",
      "Political violence / election‐related offences",
      "Offences affecting public health and safety (unsafe food, adulteration)",
      "Violations of regulatory rules (weights & measures, consumer protection)"
    ],
    bn: [
      "সন্ত্রাসবাদ / উগ্রবাদী কার্যক্রম",
      "ঘৃণাজনক অপরাধ / সাম্প্রদায়িক হিংসা / সংখ্যালঘু নির্যাতন",
      "রাজনৈতিক হিংসা / নির্বাচন-সংক্রান্ত অপরাধ",
      "জনস্বাস্থ্য ও নিরাপত্তা লঙ্ঘন (অনিরাপদ খাদ্য, ভেজাল)",
      "নিয়ন্ত্রক বিধি লঙ্ঘন (ওজন ও পরিমাপ, ভোক্তা সুরক্ষা)"
    ]
  }
} as const;

// Get social crime categories with bilingual support
export function getSocialCrimeCategories(language: 'en' | 'bn' = 'en'): Record<string, string[]> {
  const result: Record<string, string[]> = {};
  Object.entries(SOCIAL_CRIME_CATEGORIES).forEach(([category, crimes]) => {
    result[category] = [...crimes[language]]; // Convert readonly to mutable array
  });
  return result;
}

// Payment Methods (Extended)
export const PAYMENT_METHODS = [
  "bkash",
  "nagad",
  "rocket",
  "upay",
  "mcash",
  "cellfin",
  "surecash",
  "trust_money"
] as const;

// Commission Rate (20%)
export const COMMISSION_RATE = 0.20;

// Report Schema
export const CreateReportSchema = z.object({
  vehicleType: z.string().min(1),
  violationType: z.string().min(1),
  vehicleNumber: z.string().optional(),
  description: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  address: z.string(),
});

// Social Crime Report Schema
export const CreateSocialCrimeReportSchema = z.object({
  category: z.string().min(1),
  description: z.string().min(10),
  latitude: z.number(),
  longitude: z.number(),
  address: z.string(),
  isAnonymous: z.boolean().default(false),
});

export type CreateReportInput = z.infer<typeof CreateReportSchema>;

// KYC Schema
export const KYCSubmissionSchema = z.object({
  documentType: z.enum(["nid", "passport", "driving_license"]),
  documentNumber: z.string().min(1),
  phoneNumber: z.string().regex(/^\+?880\d{10}$/),
});

export type KYCSubmissionInput = z.infer<typeof KYCSubmissionSchema>;

// Payment Schema
export const InitiatePaymentSchema = z.object({
  reportId: z.string(),
  phoneNumber: z.string(),
  paymentMethod: z.enum(["bkash", "nagad", "rocket"]),
});

export type InitiatePaymentInput = z.infer<typeof InitiatePaymentSchema>;

// DMP Verification Schema
export const VerifyReportSchema = z.object({
  reportId: z.string(),
  action: z.enum(["approve", "reject"]),
  notes: z.string().optional(),
  isFalseReport: z.boolean().optional(),
});

export type VerifyReportInput = z.infer<typeof VerifyReportSchema>;

// Registration Schema
export const RegistrationSchema = z.object({
  userType: z.enum(['citizen', 'dmp', 'brta']),
  phoneNumber: z.string(),
  documentType: z.string(),
  documentNumber: z.string(),
  badgeNumber: z.string().optional(),
  employeeId: z.string().optional(),
  rank: z.string().optional(),
  division: z.string().optional(),
  region: z.string().optional(),
  paymentMethod: z.string().optional(),
  accountNumber: z.string().optional(),
  accountName: z.string().optional(),
});

export type RegistrationInput = z.infer<typeof RegistrationSchema>;

// Database Types
export interface User {
  id: string;
  mocha_user_id: string;
  phone_number: string | null;
  kyc_status: "pending" | "verified" | "rejected";
  kyc_document_type: string | null;
  kyc_document_number: string | null;
  kyc_verified_at: string | null;
  account_status: "active" | "restricted" | "banned";
  total_reports: number;
  approved_reports: number;
  total_rewards: number;
  has_pending_penalties: boolean;
  default_payment_method: string | null;
  selfie_key: string | null;
  document_image_key: string | null;
  registration_completed: boolean;
  user_type: string;
  created_at: string;
  updated_at: string;
}

export interface Report {
  id: string;
  user_id: string;
  case_number: string | null;
  violation_type: string;
  vehicle_number: string;
  description: string | null;
  image_key: string;
  video_key: string | null;
  latitude: number;
  longitude: number;
  address: string;
  status: "pending" | "approved" | "rejected";
  fine_amount: number;
  reward_amount: number;
  officer_notes: string | null;
  rejection_reason: string | null;
  verified_by: string | null;
  verified_at: string | null;
  is_false_report: boolean;
  incident_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Penalty {
  id: string;
  user_id: string;
  report_id: string;
  amount: number;
  reason: string;
  status: "pending" | "paid" | "overdue";
  payment_method: string | null;
  payment_transaction_id: string | null;
  due_date: string;
  paid_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  user_id: string;
  report_id: string | null;
  amount: number;
  payment_type: "reward" | "penalty";
  payment_method: string;
  transaction_id: string | null;
  status: "pending" | "completed" | "failed";
  created_at: string;
  updated_at: string;
}

export interface DMPOfficer {
  id: string;
  mocha_user_id: string;
  badge_number: string | null;
  rank: string;
  division: string;
  total_verified: number;
  created_at: string;
  updated_at: string;
}

export interface BRTAOfficer {
  id: string;
  mocha_user_id: string;
  employee_id: string;
  rank: string;
  division: string;
  region: string;
  total_verified: number;
  created_at: string;
  updated_at: string;
}

export interface PaymentMethod {
  id: string;
  user_id: string;
  method_type: string;
  account_number: string;
  account_name: string;
  is_primary: boolean;
  created_at: string;
  updated_at: string;
}
