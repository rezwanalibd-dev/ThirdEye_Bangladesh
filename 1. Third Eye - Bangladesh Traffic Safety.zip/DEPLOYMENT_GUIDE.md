# Third Eye - Deployment Guide for Non-Developers

This guide will help you get your Third Eye app online, even if you've never deployed an app before.

---

## 🎯 What You'll Accomplish

By the end of this guide, your app will be:
- ✅ Live on the internet with its own URL
- ✅ Accessible from any device
- ✅ Ready for app store submission
- ✅ Automatically updating when you make changes

---

## 📋 Prerequisites (What You Need)

### Required:
1. **Computer** with internet access (Windows, Mac, or Linux)
2. **GitHub Account** (free - sign up at https://github.com)
3. **Cloudflare Account** (free - sign up at https://cloudflare.com)
4. **Text Editor** - VS Code recommended (free - https://code.visualstudio.com)
5. **Node.js** installed (free - https://nodejs.org - download LTS version)

### Nice to Have:
- Credit/debit card for app store accounts (later)
- Custom domain name (optional - you can use free Cloudflare subdomain)

---

## 🚀 Deployment Methods

### Method 1: Cloudflare Pages (Recommended - Easiest)
- ✅ Completely free
- ✅ Automatic deployments
- ✅ Fast global CDN
- ✅ Free SSL certificate
- ⏱️ Setup time: 15 minutes

### Method 2: Cloudflare Workers
- ✅ Full-stack deployment
- ✅ Edge computing (ultra-fast)
- ✅ Includes database and storage
- ⏱️ Setup time: 20 minutes

We'll use **Method 1** (Cloudflare Pages) because it's easiest.

---

## 📝 Step-by-Step Deployment

### Step 1: Prepare Your Computer (One-Time Setup)

#### 1.1 Install Node.js
1. Go to https://nodejs.org
2. Download the LTS version (left button - e.g., 20.10.0)
3. Run the installer
4. Click "Next" through all steps
5. Restart your computer

**Verify Installation:**
Open Command Prompt (Windows) or Terminal (Mac/Linux) and type:
```bash
node --version
```
You should see: `v20.10.0` or similar.

```bash
npm --version
```
You should see: `10.2.3` or similar.

#### 1.2 Install Git
1. Go to https://git-scm.com/downloads
2. Download for your operating system
3. Install with default settings
4. Restart your computer

**Verify Installation:**
```bash
git --version
```
You should see: `git version 2.42.0` or similar.

---

### Step 2: Get Your Code Ready

#### 2.1 Download or Clone Your Project

**Option A: If you have the code in a folder already**
- Just navigate to that folder in your terminal/command prompt

**Option B: If your code is on GitHub**
```bash
git clone https://github.com/yourusername/third-eye-app.git
cd third-eye-app
```

#### 2.2 Install Dependencies
Open terminal/command prompt in your project folder and run:
```bash
npm install
```
This will take 2-5 minutes. You'll see a progress bar.

#### 2.3 Test Locally (Make Sure It Works)
```bash
npm run dev
```

This starts a local development server. You should see:
```
  VITE v5.0.0  ready in 1234 ms

  ➜  Local:   http://localhost:5173/
```

Open http://localhost:5173/ in your browser. You should see your app!

**Stop the server:** Press `Ctrl + C` in terminal.

---

### Step 3: Create GitHub Repository

#### 3.1 Create New Repository on GitHub
1. Go to https://github.com/new
2. Repository name: `third-eye-app`
3. Description: `Third Eye - Bangladesh Traffic Safety App`
4. Choose: Public (or Private if you have paid plan)
5. **Do NOT** check "Add README" or ".gitignore"
6. Click "Create repository"

#### 3.2 Push Your Code to GitHub
```bash
# In your project folder, run these commands one by one:

git init
git add .
git commit -m "Initial commit - Third Eye app"
git remote add origin https://github.com/YOUR-USERNAME/third-eye-app.git
git branch -M main
git push -u origin main
```

**Replace `YOUR-USERNAME`** with your actual GitHub username!

**If it asks for credentials:**
- Username: Your GitHub username
- Password: Use a Personal Access Token (not your GitHub password)
  - Create token at: https://github.com/settings/tokens
  - Select: repo (Full control of private repositories)
  - Copy the token and use it as password

---

### Step 4: Deploy to Cloudflare Pages

#### 4.1 Sign Up for Cloudflare
1. Go to https://dash.cloudflare.com/sign-up
2. Enter email and create password
3. Verify your email
4. Complete onboarding (skip domain setup for now)

#### 4.2 Connect GitHub to Cloudflare
1. In Cloudflare Dashboard, click "Workers & Pages"
2. Click "Create Application"
3. Choose "Pages"
4. Click "Connect to Git"
5. Click "GitHub" → Authorize Cloudflare
6. Select your `third-eye-app` repository
7. Click "Begin setup"

#### 4.3 Configure Build Settings
```
Production branch: main
Build command: npm run build
Build output directory: dist
Root directory: /
```

**Environment Variables (Important!):**
Click "Environment variables" and add these:

| Variable Name | Value |
|--------------|-------|
| NODE_VERSION | 20 |
| MOCHA_USERS_SERVICE_API_URL | (provided by Mocha) |
| MOCHA_USERS_SERVICE_API_KEY | (provided by Mocha) |

*Note: The MOCHA values should already be configured in your secrets.*

#### 4.4 Deploy!
1. Click "Save and Deploy"
2. Wait 2-5 minutes for first deployment
3. You'll see build logs
4. When done, you'll see "Success!"
5. Click the provided URL (e.g., `third-eye-app.pages.dev`)

**🎉 Congratulations! Your app is live!**

---

### Step 5: Set Up Database

Your app needs a database. Let's set it up:

#### 5.1 Create D1 Database
```bash
# In your project folder:
npx wrangler d1 create third-eye-db
```

You'll see output like:
```
[[d1_databases]]
binding = "DB"
database_name = "third-eye-db"
database_id = "abc123-def456-ghi789"
```

#### 5.2 Run Database Migrations
```bash
# Apply database schema:
npx wrangler d1 migrations apply third-eye-db --remote
```

This creates all the tables (users, reports, penalties, etc.)

#### 5.3 Link Database to Your Deployment
1. Go to Cloudflare Dashboard → Workers & Pages
2. Select your `third-eye-app` project
3. Go to Settings → Bindings
4. Add D1 Database Binding:
   - Variable name: `DB`
   - D1 database: Select `third-eye-db`
5. Save

---

### Step 6: Set Up File Storage (R2)

For storing photos:

#### 6.1 Create R2 Bucket
```bash
npx wrangler r2 bucket create third-eye-photos
```

#### 6.2 Link R2 to Your Deployment
1. Cloudflare Dashboard → Workers & Pages
2. Select your `third-eye-app` project
3. Settings → Bindings
4. Add R2 Bucket Binding:
   - Variable name: `R2_BUCKET`
   - R2 bucket: `third-eye-photos`
5. Save

---

### Step 7: Custom Domain (Optional)

Want `thirdeyebangladesh.com` instead of `third-eye-app.pages.dev`?

#### 7.1 Buy a Domain
- GoDaddy: https://godaddy.com
- Namecheap: https://namecheap.com
- Local registrar in Bangladesh

#### 7.2 Add Domain to Cloudflare
1. Cloudflare Dashboard → Add Site
2. Enter your domain name
3. Choose Free plan
4. Cloudflare will scan your DNS records
5. Copy the nameservers (e.g., `adam.ns.cloudflare.com`)
6. Go to your domain registrar
7. Change nameservers to Cloudflare's
8. Wait 1-24 hours for propagation

#### 7.3 Connect Domain to Your App
1. Workers & Pages → Your app
2. Custom domains → Add
3. Enter your domain
4. Click "Activate domain"

---

## 🔄 Making Updates

Every time you make changes:

```bash
# 1. Make your code changes in VS Code
# 2. Test locally:
npm run dev

# 3. When ready, push to GitHub:
git add .
git commit -m "Description of changes"
git push

# 4. Cloudflare automatically deploys!
# Wait 2-3 minutes and your changes are live.
```

---

## 🎯 Important URLs to Bookmark

After deployment, save these URLs:

1. **Your Live App:** `https://third-eye-app.pages.dev` (or your custom domain)
2. **Cloudflare Dashboard:** https://dash.cloudflare.com
3. **GitHub Repo:** https://github.com/YOUR-USERNAME/third-eye-app
4. **Deployment Logs:** Cloudflare Dashboard → Workers & Pages → Your app → Deployments

---

## 📱 Test Your Deployed App

### Test on Phone
1. Open your app URL on your phone's browser
2. Click browser menu → "Add to Home Screen"
3. App installs like a native app!
4. Test all features:
   - [ ] Login/Signup works
   - [ ] Can take photos
   - [ ] Can get GPS location
   - [ ] Can submit reports
   - [ ] Can view dashboard
   - [ ] Can search cases

### Test on Multiple Devices
- Android phone
- iPhone
- Tablet
- Desktop computer

---

## 🐛 Troubleshooting Common Issues

### "Build failed" Error
**Solution:**
1. Check build logs in Cloudflare Dashboard
2. Make sure `package.json` has correct build script
3. Verify all dependencies are installed
4. Try building locally first: `npm run build`

### "Database not found" Error
**Solution:**
1. Make sure D1 database is created
2. Check binding name matches (`DB`)
3. Run migrations again
4. Check database in Cloudflare Dashboard → D1

### "Cannot upload photos" Error
**Solution:**
1. Verify R2 bucket is created
2. Check binding name matches (`R2_BUCKET`)
3. Check R2 permissions

### "App loads but features don't work"
**Solution:**
1. Check browser console for errors (F12 → Console)
2. Verify environment variables are set
3. Check API routes are working (test /api/users/me)

### "Changes not showing after deploy"
**Solution:**
1. Wait 5 minutes (caching)
2. Hard refresh browser (Ctrl+Shift+R)
3. Clear browser cache
4. Check deployment logs

---

## 📊 Monitoring Your App

### Check App Status
**Cloudflare Dashboard:**
- Workers & Pages → Your app → Analytics
- Shows visits, requests, bandwidth

### Check Errors
**Browser Console:**
1. Open your app
2. Press F12
3. Go to Console tab
4. Look for red errors

### Check Database
```bash
# Query your database:
npx wrangler d1 execute third-eye-db --remote --command "SELECT COUNT(*) FROM users"
```

---

## 🔒 Security Checklist

Before going public:
- [ ] All secrets are set as environment variables (not in code)
- [ ] Database has proper access controls
- [ ] R2 bucket permissions are correct
- [ ] HTTPS is enabled (automatic with Cloudflare)
- [ ] Authentication is working
- [ ] KYC verification is mandatory for reporting
- [ ] Officer accounts are protected

---

## 💰 Costs

### Free Tier Includes:
- **Cloudflare Pages:** Unlimited requests
- **D1 Database:** 100,000 reads/day, 100,000 writes/day
- **R2 Storage:** 10 GB storage, 10 million reads/month
- **Bandwidth:** Unlimited (included)

### When You Need to Upgrade:
- More than 100K users/day
- More than 10 GB photos
- Advanced features needed

**Cost if you exceed free tier:** ~$5-10/month for most small apps

---

## ✅ Deployment Checklist

Before submitting to app stores:

- [ ] App is deployed and accessible online
- [ ] Custom domain configured (if applicable)
- [ ] Database is set up and working
- [ ] File uploads working (can submit reports with photos)
- [ ] Authentication working (can login/signup)
- [ ] All pages load correctly
- [ ] Mobile-responsive (test on phone)
- [ ] PWA installable (shows "Add to Home Screen")
- [ ] No console errors
- [ ] Privacy policy page exists
- [ ] Terms of service page exists
- [ ] Contact/support email works
- [ ] Test accounts created for app store review

---

## 🆘 Getting Help

If you're stuck:

1. **Check Logs:**
   - Cloudflare Dashboard → Your app → Deployments → Latest → Logs

2. **Search Error Messages:**
   - Copy exact error message
   - Google it with "Cloudflare Pages"

3. **Community Help:**
   - Cloudflare Community: https://community.cloudflare.com
   - Stack Overflow: https://stackoverflow.com (tag: cloudflare)

4. **Documentation:**
   - Cloudflare Pages: https://developers.cloudflare.com/pages
   - D1 Database: https://developers.cloudflare.com/d1
   - R2 Storage: https://developers.cloudflare.com/r2

---

## 🎉 Congratulations!

Your app is now live on the internet! 

**What's Next:**
1. Test thoroughly on multiple devices
2. Create app store assets (see ASSET_CREATION_GUIDE.md)
3. Submit to Google Play Store (see MOBILE_PUBLISHING_GUIDE.md)
4. Submit to Apple App Store (see MOBILE_PUBLISHING_GUIDE.md)

---

## 📞 Support

If something goes wrong or you need help:
- Review the logs carefully
- Check each step in this guide
- Test locally first before debugging online
- Keep backups of your code

Good luck with your deployment! 🚀📱
