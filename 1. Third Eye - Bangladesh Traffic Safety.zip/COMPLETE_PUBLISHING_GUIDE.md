# Third Eye Bangladesh - Complete Publishing Guide

## 🎯 OVERVIEW

This guide will take you from the current web app to published mobile apps on Google Play Store and Apple App Store. The process includes web testing, mobile app conversion, and store submission.

## 📋 PREREQUISITES

### Required Software
- **Node.js** (v18 or later)
- **Git** (for version control)
- **Android Studio** (for Android publishing)
- **Xcode** (for iOS publishing - macOS only)

### Required Accounts
- **Google Play Console Account** ($25 one-time fee)
- **Apple Developer Account** ($99/year)
- **Cloudflare Account** (for hosting)

## 🌐 PHASE 1: WEB BROWSER TESTING

### Step 1: Download Project Files

**Option A: Direct Download**
1. Right-click in file explorer → "Download All Files"
2. Extract the ZIP file to `third-eye-bangladesh` folder

**Option B: Copy Individual Files**
Create these folders and copy the content:
```
third-eye-bangladesh/
├── src/react-app/        # All React components
├── src/worker/           # Backend API code  
├── src/shared/           # Shared TypeScript types
├── public/               # Static assets
├── package.json          # Dependencies (locked file)
└── index.html           # Main HTML file
```

### Step 2: Install Dependencies
```bash
cd third-eye-bangladesh
npm install
```

### Step 3: Test in Development Mode
```bash
npm run dev
```
- Open: http://localhost:5173
- Test all features thoroughly
- Verify emergency calling works
- Check responsive design on different screen sizes

### Step 4: Test Production Build
```bash
npm run build
npm run preview
```
- Ensures app works in production mode
- Verifies all assets load correctly

### Step 5: Web Deployment (Optional)
Deploy to Cloudflare Workers for live web testing:
```bash
npm run deploy
```

## 📱 PHASE 2: MOBILE APP CONVERSION

### Step 1: Install Capacitor
```bash
# Install Capacitor CLI globally
npm install -g @capacitor/cli @capacitor/core

# Install Ionic CLI (recommended)
npm install -g @ionic/cli
```

### Step 2: Initialize Mobile App
```bash
# Initialize Capacitor in your project
npx cap init "Third Eye Bangladesh" "com.thirdeyebd.app"

# This creates capacitor.config.ts
```

### Step 3: Add Mobile Platforms
```bash
# Add Android platform
npx cap add android

# Add iOS platform (macOS only)
npx cap add ios
```

### Step 4: Configure Mobile Settings

**Create: `capacitor.config.ts`**
```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thirdeyebd.app',
  appName: 'Third Eye Bangladesh',
  webDir: 'dist/client',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Camera: {
      permissions: ['camera', 'photos']
    },
    Geolocation: {
      permissions: ['location']
    },
    Device: {
      permissions: ['device-info']
    },
    Clipboard: {
      permissions: ['clipboard-read', 'clipboard-write']
    }
  }
};

export default config;
```

### Step 5: Build and Sync
```bash
# Build the web app
npm run build

# Sync with mobile platforms
npx cap sync
```

## 🤖 PHASE 3: ANDROID PUBLISHING

### Step 1: Install Android Studio
1. Download from: https://developer.android.com/studio
2. Install with default settings
3. Open Android Studio
4. Install Android SDK (API 21+ for compatibility)

### Step 2: Configure Android Project
```bash
# Open Android project in Android Studio
npx cap open android
```

### Step 3: Update Android Manifest

**File: `android/app/src/main/AndroidManifest.xml`**
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.thirdeyebd.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

    <application
        android:name=".MainApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Third Eye Bangladesh"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:theme="@style/AppTheme.NoActionBarLaunch">

            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

### Step 4: Create App Icons
Replace default icons in `android/app/src/main/res/`:
- `mipmap-hdpi/ic_launcher.png` (72x72)
- `mipmap-mdpi/ic_launcher.png` (48x48)  
- `mipmap-xhdpi/ic_launcher.png` (96x96)
- `mipmap-xxhdpi/ic_launcher.png` (144x144)
- `mipmap-xxxhdpi/ic_launcher.png` (192x192)

### Step 5: Generate Signed APK

**In Android Studio:**
1. **Build** → **Generate Signed Bundle / APK**
2. **Choose** → **Android App Bundle (AAB)** for Play Store
3. **Create** new keystore (save keystore file safely!)
4. **Fill** keystore details:
   - Key alias: `thirdeye`
   - Password: Create secure password
   - Validity: 25 years
5. **Build** release version

### Step 6: Test APK
1. Install APK on physical Android device
2. Test all functionality
3. Verify permissions work correctly
4. Test emergency calling features

### Step 7: Google Play Store Submission

**Create Google Play Console Account:**
1. Go to: https://play.google.com/console
2. Pay $25 registration fee
3. Complete account setup

**Upload App:**
1. **Create** new application
2. **Upload** AAB file to Internal Testing
3. **Fill** store listing:
   - **Title**: "Third Eye Bangladesh - Traffic Safety"
   - **Short description**: "Report traffic violations, earn rewards"
   - **Full description**: 
     ```
     Third Eye Bangladesh is the official traffic violation reporting app for Bangladesh. Partner with DMP and BRTA to make roads safer.

     Features:
     • Report traffic violations with photo evidence
     • GPS location tracking for accurate reporting
     • Reward system for verified reports
     • Emergency services quick access (999, 100, 102, 199)
     • Social crime reporting with anonymous option
     • Multi-language support (English & Bengali)

     Make Bangladesh roads safer - one report at a time!
     ```
   - **Category**: Productivity
   - **Content rating**: Mature 17+
   - **Screenshots**: Take 4-8 screenshots showing key features

4. **Complete** content rating questionnaire
5. **Add** privacy policy URL
6. **Submit** for review

## 🍎 PHASE 4: iOS PUBLISHING

### Step 1: Install Xcode (macOS Required)
1. Download Xcode from Mac App Store
2. Install and accept license agreements
3. Install iOS Simulator

### Step 2: Configure iOS Project
```bash
# Open iOS project in Xcode
npx cap open ios
```

### Step 3: Update iOS Configuration

**File: `ios/ThirdEye/Info.plist`**
```xml
<dict>
    <key>CFBundleDisplayName</key>
    <string>Third Eye Bangladesh</string>
    
    <key>CFBundleIdentifier</key>
    <string>com.thirdeyebd.app</string>
    
    <key>CFBundleShortVersionString</key>
    <string>1.0.0</string>
    
    <key>CFBundleVersion</key>
    <string>1</string>
    
    <key>NSCameraUsageDescription</key>
    <string>This app needs camera access to capture evidence photos of traffic violations</string>
    
    <key>NSLocationWhenInUseUsageDescription</key>
    <string>This app needs location access to record accurate incident locations</string>
    
    <key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
    <string>Location access helps provide accurate incident reporting</string>
    
    <key>NSPhotoLibraryUsageDescription</key>
    <string>Access to photo library to select evidence images</string>
</dict>
```

### Step 4: Configure Xcode Project
**In Xcode:**
1. **Select** project root → **Targets** → **ThirdEye**
2. **General** tab:
   - **Display Name**: "Third Eye Bangladesh"
   - **Bundle Identifier**: com.thirdeyebd.app
   - **Version**: 1.0.0
   - **Build**: 1
   - **Deployment Target**: iOS 13.0
3. **Signing & Capabilities**:
   - **Enable** "Automatically manage signing"
   - **Select** your Apple Developer team
   - **Add capabilities**: Camera, Location

### Step 5: Create App Icons
Add app icons to `ios/ThirdEye/Assets.xcassets/AppIcon.appiconset/`:
- Multiple sizes required (20x20 to 1024x1024)
- Use consistent eye icon design
- High quality PNG files

### Step 6: Build iOS App
**In Xcode:**
1. **Select** "Any iOS Device" as target
2. **Product** → **Archive**
3. **Wait** for build to complete
4. **Organizer** window opens automatically

### Step 7: App Store Connect Submission

**Create Apple Developer Account:**
1. Go to: https://developer.apple.com
2. Pay $99 annual fee
3. Complete registration

**Create App in App Store Connect:**
1. Go to: https://appstoreconnect.apple.com
2. **Apps** → **+** → **New App**
3. **Fill details**:
   - **Name**: "Third Eye Bangladesh"
   - **Bundle ID**: com.thirdeyebd.app
   - **SKU**: thirdeye-bangladesh-001
   - **User Access**: Full Access

**Upload Build:**
1. **In Xcode Organizer** → **Distribute App**
2. **Choose** "App Store Connect"
3. **Upload** → **Automatically manage signing**
4. **Upload** (takes 5-10 minutes)

**Complete App Store Listing:**
1. **App Information**:
   - **Name**: Third Eye Bangladesh
   - **Subtitle**: Traffic Safety Reporter
   - **Category**: Productivity
2. **Privacy**:
   - **Privacy Policy URL**: Required
   - **App Privacy**: Complete questionnaire
3. **App Review Information**:
   - **Contact info**: Your email
   - **Demo account**: Create test account
4. **Version Information**:
   - **Screenshots**: 4-8 screenshots for each device type
   - **App description**: Same as Google Play
   - **Keywords**: traffic,safety,bangladesh,violation,report
5. **Build**: Select uploaded build
6. **Submit** for review

## 🚀 PHASE 5: FINAL DEPLOYMENT

### Step 1: Domain Setup (Web Version)
1. **Purchase** domain: `thirdeyebd.com`
2. **Configure** Cloudflare DNS
3. **Deploy** to custom domain

### Step 2: Monitor App Reviews
- **Google Play**: 1-3 days review time
- **Apple App Store**: 1-7 days review time
- **Respond** to any review feedback promptly

### Step 3: Post-Launch Marketing
1. **Create** social media accounts
2. **Contact** DMP and BRTA for official partnership
3. **Develop** user onboarding materials
4. **Plan** feature updates

## 📊 SUCCESS METRICS

### Launch Goals
- **Downloads**: 1,000+ in first month
- **Active Users**: 100+ daily reporters
- **Reports**: 500+ verified violations
- **Rating**: 4.5+ stars on both stores

### Long-term Goals
- **Partnership**: Official DMP/BRTA integration
- **Expansion**: Other cities in Bangladesh
- **Features**: Real-time traffic updates
- **Community**: Active user forum

## 🛠️ MAINTENANCE PLAN

### Regular Updates
- **Monthly**: Bug fixes and improvements
- **Quarterly**: New features
- **Annually**: Major version updates

### Monitoring
- **Analytics**: User behavior tracking
- **Crash Reports**: Automatic error reporting
- **Performance**: App speed and stability
- **Security**: Regular security audits

## ✅ PUBLISHING CHECKLIST

### Pre-Launch
- [ ] Web app tested thoroughly
- [ ] Mobile apps built successfully
- [ ] All permissions working
- [ ] Emergency calling tested
- [ ] Privacy policy created
- [ ] Terms of service written
- [ ] App icons created
- [ ] Screenshots taken
- [ ] Store descriptions written
- [ ] Content rating completed

### Store Submission
- [ ] Google Play Console account created
- [ ] Android AAB uploaded
- [ ] Apple Developer account created  
- [ ] iOS app uploaded
- [ ] App Store Connect listing completed
- [ ] Both apps submitted for review

### Post-Launch
- [ ] Monitor review status
- [ ] Respond to user feedback
- [ ] Track download metrics
- [ ] Plan feature updates
- [ ] Maintain user support

## 🎉 CONCLUSION

Following this guide will take your Third Eye Bangladesh app from development to published mobile apps on both major platforms. The app is designed to make a real impact on road safety in Bangladesh.

**Total Timeline**: 1-2 weeks from start to app store approval
**Total Cost**: ~$125 (Google Play $25 + Apple Developer $99)

Your app is ready to help make Bangladesh roads safer! 🇧🇩
