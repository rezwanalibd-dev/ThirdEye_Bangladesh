# Complete Testing Guide

## Overview
This guide will help you test all features of the Traffic Enforcement app before publishing. The app includes special testing features that are only available in development mode.

## Quick Start Testing

### 1. Access Testing Dashboard
Navigate to: `http://localhost:5173/testing` in your browser

This dashboard provides:
- Current development mode status
- Recent OTP codes for testing
- Quick access to test all user flows
- Database cleanup utilities

### 2. Testing OTP Authentication

**Problem**: Not receiving OTP codes during testing
**Solution**: In development mode, OTP codes are displayed in the response

#### Testing Steps:
1. Go to sign-up or login page
2. Enter email or mobile number
3. Click "Send OTP"
4. **Check the browser console or testing dashboard** - the OTP code will be displayed there
5. Use the displayed code to complete authentication

#### Example OTP Testing Flow:
```
1. Enter: test@example.com
2. Click "Send OTP" 
3. Response will include: { "devCode": "123456", "isDevelopmentMode": true }
4. Enter: 123456 to verify
```

## Complete Feature Testing Checklist

### ✅ Authentication Testing
- [ ] **Email OTP Registration**: Use any valid email format
- [ ] **Mobile OTP Registration**: Use Bangladesh format (01XXXXXXXXX)
- [ ] **Google OAuth**: Click "Continue with Google"
- [ ] **Login vs Registration**: Test both flows

### ✅ User Type Registration
- [ ] **Citizen**: Complete all 3 steps including payment method
- [ ] **DMP Officer**: Provide badge number, rank, division
- [ ] **BRTA Officer**: Provide employee ID, rank, division, region

### ✅ Report Submission
- [ ] **Create Report**: Upload image, set location, select violation
- [ ] **Duplicate Detection**: Submit same violation within 5 minutes
- [ ] **First Reporter Bonus**: Check who gets the reward

### ✅ Officer Functions
- [ ] **DMP Dashboard**: Verify/reject reports
- [ ] **Fine Calculations**: Check automatic fine amounts
- [ ] **False Report Penalties**: Test penalty system

### ✅ Search & History
- [ ] **Case Number Search**: Use format TE-YYYY-MM-DD-XXXXX
- [ ] **Vehicle Search**: Search by license plate
- [ ] **Report History**: View personal reports

## Test Data You Can Use

### Valid Phone Numbers (Bangladesh Format)
```
01712345678
+8801712345678
8801712345678
01512345678
01612345678
```

### Sample Document Numbers
```
NID: 1234567890
License: DL-123456789
Badge: DMP-2024-001
Employee ID: BRTA-2024-001
```

### Sample Vehicle Numbers
```
DHK-GA-12-3456
CHA-KA-45-6789
RAJ-BA-78-9012
```

### Test Violation Types
- Illegal Parking
- Speed Violation
- Signal Violation
- Wrong Way
- No Helmet
- Phone Usage

## Development Mode Features

### Available Testing Endpoints
- `GET /api/testing/status` - Check if in development mode
- `GET /api/testing/otps` - View recent OTP codes
- `POST /api/testing/cleanup-otps` - Clear expired OTPs

### Development Mode Benefits
1. **OTP Codes Visible**: No need for real SMS/email delivery
2. **Extended Debugging**: More detailed error messages
3. **Testing Utilities**: Special endpoints for testing
4. **Relaxed Validation**: Some validations are less strict

## Common Testing Issues & Solutions

### Issue: "Not receiving OTP"
**Solution**: Check browser console or testing dashboard for the dev code

### Issue: "Invalid session" 
**Solution**: Clear browser localStorage and try again

### Issue: "User not found"
**Solution**: Make sure to complete registration flow properly

### Issue: "KYC verification required"
**Solution**: Complete full registration including document upload

### Issue: "Account restricted"
**Solution**: Check penalties page and clear any false report penalties

## Testing Different Scenarios

### Happy Path Testing
1. Register as citizen with mobile OTP
2. Complete KYC verification
3. Submit valid traffic violation report
4. Switch to DMP officer account
5. Verify the report
6. Check reward credited to citizen

### Error Path Testing
1. Submit false report
2. Have DMP officer mark as false
3. Check penalty applied
4. Test restricted account functionality

### Edge Case Testing
1. Submit duplicate reports within 5 minutes
2. Test expired OTP codes
3. Test invalid document formats
4. Test network error scenarios

## Database Testing

### Viewing Test Data
Use the testing dashboard to:
- View all recent OTP codes
- Check user registration status
- Monitor report submissions
- Track penalty assignments

### Cleaning Test Data
- Clear expired OTPs: Use cleanup utility
- Reset user data: Manually clear localStorage
- Fresh start: Clear browser data completely

## Pre-Publication Checklist

Before publishing, ensure you've tested:
- [ ] All user registration types work
- [ ] OTP authentication works reliably
- [ ] Report submission and verification flow
- [ ] Payment method integration
- [ ] Officer dashboards and functions
- [ ] Search functionality
- [ ] Penalty and reward systems
- [ ] Mobile responsive design
- [ ] Error handling and edge cases

## Need Help?

If you encounter issues:
1. Check the testing dashboard first
2. Look at browser console for errors
3. Verify you're in development mode
4. Try clearing browser data and starting fresh
5. Check the database schema matches expected structure

## Production Deployment Notes

When deploying to production:
- Development mode features will be automatically disabled
- Real SMS/email integration will be required
- All test data should be cleared
- Security validations will be enforced

---

**Important**: Always test thoroughly in development before deploying to production. The testing features described here are only available in development mode for security reasons.
