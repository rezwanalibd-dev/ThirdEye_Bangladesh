# Third Eye - Complete File Structure Guide

This document explains every folder and file in your project so you know what everything does.

---

## 📁 Root Directory

```
third-eye-app/
├── public/                  # Static files (icons, service worker)
├── src/                     # Application source code
├── package.json            # Project dependencies
├── index.html              # Main HTML file
├── vite.config.ts          # Build configuration
├── tailwind.config.js      # Styling configuration
├── wrangler.json           # Cloudflare deployment config
└── README.md               # Project documentation
```

---

## 📂 Detailed Folder Structure

### `/public` - Static Assets
Files here are served as-is to users.

```
public/
├── manifest.json           # PWA manifest (app name, icons, colors)
└── sw.js                   # Service worker (offline support)
```

**What these do:**
- `manifest.json`: Tells browsers how to install your app (name, icons, theme color)
- `sw.js`: Enables offline functionality and caching

**DO NOT EDIT** unless you know what you're doing!

---

### `/src` - Application Source Code

```
src/
├── react-app/              # Frontend React application
├── worker/                 # Backend API server
└── shared/                 # Code shared between frontend and backend
```

---

### `/src/react-app` - Frontend Code

This is what users see and interact with.

```
src/react-app/
├── pages/                  # Full page components
├── components/             # Reusable UI components
├── hooks/                  # Reusable React logic
├── App.tsx                 # Main app component with routing
├── main.tsx                # App entry point
└── index.css               # Global styles
```

---

### `/src/react-app/pages` - Page Components

Each file is a complete page in the app.

```
pages/
├── Home.tsx                # Welcome/landing page
├── LoginPortals.tsx        # Login page for all user types
├── SignUpPortals.tsx       # Signup page for all user types
├── OnboardingFlow.tsx      # Multi-step registration wizard
├── UserTypeSelection.tsx   # Choose citizen/DMP/BRTA
├── Registration.tsx        # Complete registration form
├── Dashboard.tsx           # Main dashboard after login
├── Report.tsx              # Report violation page
├── Search.tsx              # Search cases page
├── KYC.tsx                 # KYC verification page
├── Penalties.tsx           # View/pay penalties
├── DMPDashboard.tsx        # DMP officer dashboard
├── Emergency.tsx           # Emergency contacts page
└── AuthCallback.tsx        # OAuth login callback handler
```

**Key Pages Explained:**

**Home.tsx**
- First page users see
- Login/signup buttons
- DMP/BRTA portal access
- Language switcher

**Dashboard.tsx**
- Shows user stats (reports, rewards, success rate)
- Quick action buttons (Report, Search)
- Recent reports list
- Alerts (KYC needed, penalties)

**Report.tsx**
- Camera to capture violation photo
- GPS location capture
- Violation type selection
- Vehicle number input
- Submit report button

**Search.tsx**
- Search by case number
- Search by vehicle number
- View report details

**OnboardingFlow.tsx**
- Step 1: Choose user type (citizen/DMP/BRTA)
- Step 2: Complete registration with documents

---

### `/src/react-app/components` - Reusable Components

Small UI pieces used across multiple pages.

```
components/
├── MobileLayout.tsx        # Page wrapper with bottom navigation
├── MobileHeader.tsx        # Page header with back button
└── InstallPrompt.tsx       # PWA install prompt popup
```

**Component Descriptions:**

**MobileLayout.tsx**
- Wraps every page
- Shows bottom navigation (Home, Report, Search, Profile)
- Mobile-optimized layout

**MobileHeader.tsx**
- Shows page title
- Back button (arrow)
- Notification bell
- Can be customized per page

**InstallPrompt.tsx**
- Popup asking user to install app
- Shows after 3 seconds
- Can be dismissed

---

### `/src/react-app/hooks` - Custom React Hooks

Reusable logic that multiple components need.

```
hooks/
├── useLanguage.tsx         # Language switching (EN/BN)
└── usePWA.ts              # PWA install detection
```

**Hook Descriptions:**

**useLanguage.tsx**
- Manages English/Bengali translation
- Stores language choice in browser
- Provides `t()` function for translations

**usePWA.ts**
- Detects if app can be installed
- Shows install prompt
- Checks if already installed

---

### `/src/worker` - Backend API Server

Handles data, database, authentication, file uploads.

```
worker/
└── index.ts               # API routes and business logic
```

**What This Does:**
- Handles user authentication (login/signup)
- Stores reports in database
- Uploads photos to cloud storage
- Verifies reports (DMP/BRTA)
- Manages rewards and penalties
- Processes payments

**API Routes Available:**
```
POST /api/sessions              # Login
GET  /api/users/me              # Get current user
POST /api/registration          # Complete registration
POST /api/reports               # Create report
GET  /api/reports               # Get user's reports
GET  /api/reports/:id/image     # Get report photo
GET  /api/search/case/:number   # Search by case number
POST /api/kyc                   # Submit KYC documents
GET  /api/penalties             # Get user penalties
POST /api/dmp/reports/verify    # Verify report (DMP officers)
```

---

### `/src/shared` - Shared Code

Code used by both frontend and backend.

```
shared/
└── types.ts               # Data models and validation schemas
```

**What's Defined Here:**
- User data structure
- Report data structure
- Penalty data structure
- Validation rules
- Violation types and fines

**Example Data Structures:**
```typescript
User {
  id: string
  phone_number: string
  kyc_status: 'pending' | 'verified'
  total_reports: number
  total_rewards: number
}

Report {
  id: string
  case_number: string
  violation_type: string
  vehicle_number: string
  status: 'pending' | 'approved' | 'rejected'
  reward_amount: number
}
```

---

## 🗄️ Database Structure

Your app uses SQLite (D1) database with these tables:

### Tables

**users**
- Stores citizen, DMP, and BRTA user accounts
- Tracks KYC status
- Tracks rewards and penalties

**reports**
- All violation reports
- Links to user who reported
- Contains photo, location, vehicle details
- Stores verification status and reward amount

**dmp_officers**
- DMP officer accounts
- Badge numbers, rank, division

**brta_officers**
- BRTA officer accounts
- Employee ID, rank, region

**penalties**
- Penalties for false reports
- Amount, due date, payment status

**incident_races**
- Tracks first reporter for same incident
- Only first reporter gets reward

**case_sequences**
- Generates unique case numbers

---

## 🎨 Styling & Design

### Colors Used (DO NOT CHANGE)
```css
Primary Blue: #3b82f6
Purple: #9333ea
Orange: #f97316
Red: #ef4444
Green: #10b981
Gray backgrounds: #f9fafb, #f3f4f6
```

### Fonts
- Default system fonts (San Francisco on iOS, Roboto on Android)
- Font sizes: Mobile-optimized (14-16px body, 18-24px headings)

### Design Principles
- Mobile-first responsive design
- Bottom navigation for easy thumb access
- Large tap targets (48px minimum)
- High contrast text
- Rounded corners (16-24px border radius)
- Gradients for action buttons
- Card-based layout

---

## 🔧 Configuration Files

### `package.json`
Lists all dependencies (libraries) the app needs.
**DO NOT EDIT** manually. Use npm commands.

### `vite.config.ts`
Build tool configuration.
**DO NOT EDIT** unless you know Vite.

### `tailwind.config.js`
CSS framework configuration.
**DO NOT EDIT** - controls app styling.

### `wrangler.json`
Cloudflare deployment settings.
**Edit only**: App name, account ID.

### `tsconfig.json` files
TypeScript compiler settings.
**DO NOT EDIT**.

---

## 📦 Dependencies (Libraries Used)

Your app uses these technologies:

### Frontend
- **React** - UI framework
- **React Router** - Page navigation
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **Zod** - Form validation

### Backend
- **Hono** - API framework
- **Cloudflare D1** - Database
- **Cloudflare R2** - File storage
- **Mocha Users Service** - Authentication

### Build Tools
- **Vite** - Fast development server
- **TypeScript** - Type-safe JavaScript

---

## 🚀 How Files Connect

1. User visits `index.html`
2. Loads `src/react-app/main.tsx`
3. Which loads `src/react-app/App.tsx`
4. App.tsx sets up routing to pages
5. Pages use components and hooks
6. Pages call API routes in `src/worker/index.ts`
7. Worker accesses database and storage
8. Data flows back to user

---

## ✏️ What You Can Safely Edit

### Safe to Edit:
- `src/react-app/pages/*.tsx` - Page content and layout
- `src/react-app/hooks/useLanguage.tsx` - Add more translations
- `public/manifest.json` - App name, description
- Color values in Tailwind classes

### Edit with Caution:
- `src/worker/index.ts` - API logic (can break functionality)
- `src/shared/types.ts` - Data models (must match database)

### Never Edit:
- `package.json` - Use npm commands instead
- `*.config.js/ts` files - Build configuration
- `node_modules/` folder - Downloaded dependencies

---

## 🔍 Finding Specific Features

**Want to change the welcome page text?**
→ Edit `src/react-app/pages/Home.tsx`

**Want to add a translation?**
→ Edit `src/react-app/hooks/useLanguage.tsx`

**Want to change app name in install prompt?**
→ Edit `public/manifest.json`

**Want to add a new violation type?**
→ Edit `src/shared/types.ts` (VIOLATION_TYPES array)

**Want to change reward percentage?**
→ Edit `src/worker/index.ts` (search for "0.2")

**Want to customize colors?**
→ Search for color codes (e.g., "blue-600") and replace

---

## 📱 Mobile-Specific Files

These files make the app work like a native mobile app:

- `public/manifest.json` - PWA configuration
- `public/sw.js` - Offline support
- `src/react-app/hooks/usePWA.ts` - Install detection
- `src/react-app/components/MobileLayout.tsx` - Mobile UI
- `src/react-app/components/MobileHeader.tsx` - Mobile header

---

## 🆘 Troubleshooting Common Issues

**"Cannot find module" error**
→ Run: `npm install`

**"Port already in use" error**
→ Close other development servers or change port

**"Database error"**
→ Check wrangler.json configuration

**App looks broken**
→ Clear browser cache and reload

**Changes not showing**
→ Stop server (Ctrl+C) and restart

---

## 📞 Getting Help

If you're stuck:
1. Check this guide first
2. Search the error message online
3. Check documentation for the specific technology
4. Ask in developer communities (Reddit, Stack Overflow)

---

## ✅ File Structure Checklist

Use this to verify you have all necessary files:

- [ ] index.html (main HTML)
- [ ] public/manifest.json (PWA config)
- [ ] public/sw.js (service worker)
- [ ] src/react-app/App.tsx (main app)
- [ ] src/react-app/main.tsx (entry point)
- [ ] src/react-app/pages/ (all pages)
- [ ] src/react-app/components/ (UI components)
- [ ] src/worker/index.ts (backend API)
- [ ] src/shared/types.ts (data models)
- [ ] package.json (dependencies)
- [ ] wrangler.json (deployment config)

---

This guide should help you understand what every file does. Remember: When in doubt, don't delete or modify files unless you understand their purpose! 📁✨
