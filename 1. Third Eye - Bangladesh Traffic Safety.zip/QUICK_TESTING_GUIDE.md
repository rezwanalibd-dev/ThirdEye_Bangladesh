# Quick Testing Guide - Third Eye Bangladesh App

## How to Test WITHOUT OTP Authentication

Your app has a built-in testing system that lets you bypass OTP verification completely. Here are two ways to access it:

---

## Method 1: Direct Testing Dashboard (Recommended)

### Step 1: Start the Development Server
```bash
npm install
npm run dev
```

### Step 2: Open Testing Dashboard
Go directly to: **http://localhost:5173/testing**

### Step 3: Choose Quick Testing Access
You'll see a green section called "🚀 Quick Testing Access (No OTP)". Click one of these buttons:

- **Test as Citizen** - Test reporting violations, viewing dashboard, etc.
- **Test as DMP Officer** - Test verifying reports, officer dashboard
- **Test as BRTA Officer** - Test BRTA officer features

### Step 4: Start Testing
After clicking a button, you'll be logged in automatically and can test all features without any authentication!

---

## Method 2: Testing Button on Home Page

### Step 1: Go to Home Page
Open: **http://localhost:5173/**

### Step 2: Look for Testing Button
You should see a **yellow button with a test tube icon** in the bottom-right corner (only visible in development mode).

### Step 3: Click Testing Button
This will take you to the testing dashboard where you can bypass authentication.

---

## What You Can Test (No OTP Required)

### As a Citizen:
✅ **Dashboard** - View statistics, quick actions, recent reports
✅ **Report Violations** - Camera, GPS, violation types, vehicle numbers
✅ **Search Reports** - By case number or vehicle number
✅ **Emergency Contacts** - All emergency calling features
✅ **Social Crime Reporting** - Report serious crimes
✅ **Language Switching** - English ↔ Bengali

### As DMP Officer:
✅ **Officer Dashboard** - View pending reports
✅ **Verify Reports** - Approve/reject citizen reports
✅ **Case Management** - Officer notes, fine amounts
✅ **Penalty System** - Apply penalties for false reports

### As BRTA Officer:
✅ **Vehicle Verification** - BRTA-specific features
✅ **License Checks** - Vehicle registration data
✅ **Regional Management** - Area-specific controls

---

## Complete Testing Workflow

### 1. Basic App Testing
```
1. Go to: http://localhost:5173/testing
2. Click "Test as Citizen"
3. You're now logged in! Test these:
   - View dashboard
   - Create a report (use camera/GPS)
   - Search for reports
   - Call emergency numbers (999, 100, 102, 199)
   - Switch between English/Bengali
```

### 2. Officer Testing
```
1. Open another browser tab
2. Go to: http://localhost:5173/testing
3. Click "Test as DMP Officer" 
4. Test these:
   - View pending reports
   - Approve/reject reports
   - Add officer notes
```

### 3. Mobile Testing
```
1. Open on your phone: http://192.168.1.XXX:5173/testing
   (Replace XXX with your computer's IP address)
2. Click "Test as Citizen"
3. Test mobile features:
   - Touch interface
   - Camera access
   - GPS location
   - Phone calling
   - PWA installation
```

---

## What's Pre-Configured for Testing

Your testing system automatically creates:

### Test Citizen Account:
- ✅ **KYC Status**: Verified
- ✅ **Account Status**: Active  
- ✅ **Phone**: +8801711175314
- ✅ **Payment Method**: Configured
- ✅ **All Permissions**: Enabled

### Test DMP Officer Account:
- ✅ **Badge Number**: Auto-generated
- ✅ **Rank**: Inspector
- ✅ **Division**: Traffic Division
- ✅ **Verification Rights**: Full access

### Test BRTA Officer Account:
- ✅ **Employee ID**: Auto-generated
- ✅ **Rank**: Inspector
- ✅ **Region**: Dhaka
- ✅ **All Permissions**: Enabled

---

## Emergency Testing (Important!)

### Test All Emergency Numbers:
1. **Police**: 999 ✅
2. **Fire Service**: 100 ✅  
3. **Ambulance**: 102 ✅
4. **Women Helpline**: 199 ✅

**Note**: These will make real calls! Test carefully or use airplane mode.

---

## OTP Testing (If You Want)

If you want to test OTP authentication:

### Step 1: Go to Normal Sign Up
1. Visit: http://localhost:5173/
2. Click "Start Reporting"
3. Choose email or mobile signup

### Step 2: View OTP Codes
1. Open: http://localhost:5173/testing
2. Scroll down to "Recent OTP Codes"
3. Copy the 6-digit code and paste it in the signup form

---

## Testing Checklist

Use this to verify everything works:

### Core Features:
- [ ] Home page loads
- [ ] Language toggle works (EN ↔ BN)
- [ ] Testing dashboard accessible
- [ ] Quick login works (no OTP)
- [ ] Dashboard shows user stats
- [ ] Camera works for reports
- [ ] GPS location captured
- [ ] Report submission successful
- [ ] Search by case number
- [ ] Search by vehicle number
- [ ] Emergency calling works
- [ ] Officer verification works

### Mobile Features:
- [ ] Touch interface responsive
- [ ] Bottom navigation works
- [ ] Camera access on mobile
- [ ] GPS works on mobile
- [ ] Phone calling works
- [ ] PWA installation prompt
- [ ] Offline functionality

### Multi-language:
- [ ] Bengali text displays correctly
- [ ] All UI elements translated
- [ ] Language persists on refresh

---

## Cleanup After Testing

To clear test data:
1. Go to testing dashboard: http://localhost:5173/testing
2. Click **"Cleanup Test Data"** button
3. This removes all test accounts and reports

---

## Need Help?

If testing doesn't work:

1. **Check Console**: Press F12 → Console tab for errors
2. **Restart Server**: Stop (Ctrl+C) and run `npm run dev` again  
3. **Clear Browser**: Clear localStorage and cookies
4. **Check Network**: Ensure you're on http://localhost:5173

---

## Next Steps After Testing

Once you confirm everything works:
1. **Web Deployment**: Deploy to Cloudflare for public access
2. **Android Publishing**: Create APK/AAB for Google Play Store
3. **iOS Publishing**: Build IPA for Apple App Store

**Your app is ready for production!** 🚀
