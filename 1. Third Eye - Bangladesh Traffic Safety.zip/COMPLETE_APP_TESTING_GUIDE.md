# Complete App Testing Guide - Traffic Enforcement System

## 🚀 Quick Start: How to Test OTP Without SMS/Email

**The Problem**: You're not receiving OTP codes when testing signup/login
**The Solution**: Use the built-in testing dashboard to see all OTP codes

### Step-by-Step Testing Process:

#### Method 1: Testing Dashboard (Easiest)
1. **Open Testing Dashboard**: Go to `http://localhost:5173/testing`
2. **Start Registration**: In another tab, go to `http://localhost:5173/` and click "Sign Up"
3. **Choose Mobile/Email**: Select either mobile or email option
4. **Enter Test Data**: 
   - Mobile: `01712345678` 
   - Email: `test@example.com`
5. **Click "Send OTP"**: The system will generate a code
6. **Check Testing Dashboard**: Refresh the testing dashboard to see the OTP code
7. **Complete Registration**: Copy the 6-digit code and paste it in the verification field

#### Method 2: Browser Console (Alternative)
1. Open browser Developer Tools (F12)
2. Go to Console tab
3. Start OTP process
4. Look for log message: "OTP for [your-number]: 123456"

## 📱 Complete Testing Scenarios

### ✅ 1. User Registration Testing

#### A. Citizen Registration
```
Test Phone: 01712345678
Test Email: citizen@test.com
Document Type: NID
Document Number: 1234567890123
Payment Method: bKash
Account Number: 01712345678
Account Name: Test User
```

**Steps:**
1. Go to Sign Up → Mobile/Email
2. Complete OTP verification
3. Choose "Citizen" user type
4. Upload any image for selfie and document
5. Fill in the form with test data above
6. Complete payment method setup

#### B. DMP Officer Registration
```
Test Phone: 01812345678
Test Email: dmp@test.com
Badge Number: DMP-2024-001
Rank: Constable
Division: Ramna
```

#### C. BRTA Officer Registration
```
Test Phone: 01912345678
Test Email: brta@test.com
Employee ID: BRTA-2024-001
Rank: Officer
Division: Dhaka Metro
Region: Dhaka
```

### ✅ 2. Google OAuth Testing
1. Click "Continue with Google" on any login page
2. Complete Google authentication
3. Return to app and complete registration

### ✅ 3. Report Submission Testing

#### Test Violation Data:
```
Vehicle Number: DHK-GA-12-3456
Violation Type: Illegal Parking
Location: Set to current location or use coordinates
Description: Vehicle parked in no-parking zone
Image: Upload any image (doesn't need to be real violation)
```

#### Testing Duplicate Reports:
1. Submit a report with specific vehicle/location
2. Within 5 minutes, submit another report with same vehicle at same location
3. System should detect duplicate and show appropriate message

### ✅ 4. Officer Dashboard Testing

#### DMP Officer Actions:
1. Login as DMP officer
2. Go to DMP Dashboard
3. View pending reports
4. Approve a report (sets fine amount, gives reward to reporter)
5. Reject a report as false (applies penalty to reporter)

### ✅ 5. Search Functionality Testing

#### Case Number Search:
- Format: `TE-YYYY-MM-DD-XXXXX`
- Example: `TE-2024-10-31-00001`

#### Vehicle Search:
- Format: `DHK-GA-12-3456`
- Shows all reports for that vehicle

## 🔧 Testing Tools & Utilities

### Testing Dashboard Features:
- **Real-time OTP viewing**: See all generated codes
- **Automatic refresh**: Updates every few seconds
- **Cleanup tools**: Remove expired OTPs
- **Status indicators**: See if codes are used/expired

### Development Mode Benefits:
- OTP codes visible in browser console
- Extended error messages
- No real SMS/email sending required
- Testing endpoints available

## 🗃️ Sample Test Data

### Valid Phone Numbers (Bangladesh):
```
01712345678
01812345679
01912345680
01612345681
01512345682
```

### Sample Documents:
```
NID: 1234567890123
License: DL-123456789012
Passport: AB1234567
```

### Sample Vehicle Numbers:
```
DHK-GA-12-3456
CHA-KA-45-6789
RAJ-BA-78-9012
SYL-HA-11-2233
```

### Payment Methods:
```
bKash: 01712345678
Nagad: 01812345679
Rocket: 01912345680
Bank Account: 1234567890
```

## 🚨 Troubleshooting Common Issues

### Issue: "No OTP received"
**Solution**: Check testing dashboard at `/testing` - OTP codes appear there instantly

### Issue: "Invalid session"
**Solution**: Clear browser localStorage and start fresh

### Issue: "User not found" during login
**Solution**: Make sure you registered first - you can't login without registering

### Issue: "KYC verification required"
**Solution**: Complete full registration including document upload

### Issue: "Account restricted"
**Solution**: Check penalties page - you may have false report penalties

### Issue: Testing dashboard not working
**Solution**: Make sure you're running in development mode (localhost:5173)

## 📋 Pre-Publishing Checklist

Test each item before publishing:

### Authentication Flow:
- [ ] Mobile OTP registration works
- [ ] Email OTP registration works  
- [ ] Google OAuth registration works
- [ ] Login with existing accounts works

### User Types:
- [ ] Citizen registration complete (including payment method)
- [ ] DMP Officer registration complete (including badge info)
- [ ] BRTA Officer registration complete (including employee info)

### Core Functionality:
- [ ] Report submission works with image upload
- [ ] Duplicate report detection works
- [ ] Officer verification/rejection works
- [ ] Search by case number works
- [ ] Search by vehicle number works

### Mobile Responsiveness:
- [ ] All pages work on mobile screen sizes
- [ ] Touch interactions work properly
- [ ] Images upload properly from mobile

### Error Handling:
- [ ] Invalid OTP codes show proper errors
- [ ] Expired OTP codes show proper errors
- [ ] Network errors are handled gracefully

## 🔐 Security Notes

### Development vs Production:
- **Development**: OTP codes visible for testing
- **Production**: OTP codes hidden, real SMS/email required

### Before Publishing:
1. Switch to production mode
2. Set up real SMS/email service
3. Clear all test data
4. Test one final time with real phone numbers

## 📞 Need Help?

If you encounter any issues:

1. **Check Testing Dashboard**: `http://localhost:5173/testing`
2. **Check Browser Console**: F12 → Console tab for errors
3. **Clear Browser Data**: localStorage and cookies
4. **Restart Development Server**: Sometimes fixes connection issues

Remember: The testing dashboard is your best friend for OTP testing. It shows every code generated in real-time!
