
DROP INDEX idx_auth_sessions_token;
DROP TABLE auth_sessions;
DROP INDEX idx_otp_identifier;
DROP TABLE otp_codes;
