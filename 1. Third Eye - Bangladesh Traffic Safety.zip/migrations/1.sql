
-- Users table (extends Mocha user with app-specific data)
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  mocha_user_id TEXT NOT NULL UNIQUE,
  phone_number TEXT,
  kyc_status TEXT DEFAULT 'pending',
  kyc_document_type TEXT,
  kyc_document_number TEXT,
  kyc_verified_at DATETIME,
  account_status TEXT DEFAULT 'active',
  total_reports INTEGER DEFAULT 0,
  approved_reports INTEGER DEFAULT 0,
  total_rewards REAL DEFAULT 0,
  has_pending_penalties BOOLEAN DEFAULT 0,
  default_payment_method TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Violation reports
CREATE TABLE reports (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  case_number TEXT UNIQUE,
  violation_type TEXT NOT NULL,
  vehicle_number TEXT NOT NULL,
  description TEXT,
  image_key TEXT NOT NULL,
  video_key TEXT,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  address TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  fine_amount REAL DEFAULT 0,
  reward_amount REAL DEFAULT 0,
  officer_notes TEXT,
  rejection_reason TEXT,
  verified_by TEXT,
  verified_at DATETIME,
  is_false_report BOOLEAN DEFAULT 0,
  incident_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reports_user_id ON reports(user_id);
CREATE INDEX idx_reports_status ON reports(status);
CREATE INDEX idx_reports_case_number ON reports(case_number);
CREATE INDEX idx_reports_vehicle_number ON reports(vehicle_number);

-- Case number sequences
CREATE TABLE case_sequences (
  date_key TEXT PRIMARY KEY,
  sequence INTEGER DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Incident races (first valid reporter tracking)
CREATE TABLE incident_races (
  id TEXT PRIMARY KEY,
  first_reporter_id TEXT NOT NULL,
  first_report_id TEXT NOT NULL,
  vehicle_number TEXT NOT NULL,
  violation_type TEXT NOT NULL,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  total_reports INTEGER DEFAULT 1,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_incident_races_vehicle ON incident_races(vehicle_number);
CREATE INDEX idx_incident_races_location ON incident_races(latitude, longitude);

-- Duplicate reports (not first reporter)
CREATE TABLE duplicate_reports (
  id TEXT PRIMARY KEY,
  incident_id TEXT NOT NULL,
  report_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  position INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Penalties for false reports
CREATE TABLE penalties (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  report_id TEXT NOT NULL,
  amount REAL NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  payment_method TEXT,
  payment_transaction_id TEXT,
  due_date DATETIME NOT NULL,
  paid_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_penalties_user_id ON penalties(user_id);
CREATE INDEX idx_penalties_status ON penalties(status);

-- Payment history
CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  report_id TEXT,
  amount REAL NOT NULL,
  payment_type TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_id TEXT,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payments_user_id ON payments(user_id);

-- DMP Officers
CREATE TABLE dmp_officers (
  id TEXT PRIMARY KEY,
  mocha_user_id TEXT NOT NULL UNIQUE,
  badge_number TEXT UNIQUE,
  rank TEXT NOT NULL,
  division TEXT NOT NULL,
  total_verified INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
