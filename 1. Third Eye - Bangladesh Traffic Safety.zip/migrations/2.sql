
CREATE TABLE brta_officers (
  id TEXT PRIMARY KEY,
  mocha_user_id TEXT NOT NULL UNIQUE,
  employee_id TEXT UNIQUE,
  rank TEXT NOT NULL,
  division TEXT NOT NULL,
  region TEXT NOT NULL,
  total_verified INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payment_methods (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  method_type TEXT NOT NULL,
  account_number TEXT NOT NULL,
  account_name TEXT NOT NULL,
  is_primary BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users ADD COLUMN selfie_key TEXT;
ALTER TABLE users ADD COLUMN document_image_key TEXT;
ALTER TABLE users ADD COLUMN registration_completed BOOLEAN DEFAULT 0;
ALTER TABLE users ADD COLUMN user_type TEXT DEFAULT 'citizen';
