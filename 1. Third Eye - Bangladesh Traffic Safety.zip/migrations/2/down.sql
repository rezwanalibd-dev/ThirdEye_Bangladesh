
ALTER TABLE users DROP COLUMN user_type;
ALTER TABLE users DROP COLUMN registration_completed;
ALTER TABLE users DROP COLUMN document_image_key;
ALTER TABLE users DROP COLUMN selfie_key;
DROP TABLE payment_methods;
DROP TABLE brta_officers;
