
ALTER TABLE users ADD COLUMN profile_image_key TEXT;
