
DROP INDEX IF EXISTS idx_payments_user_id;
DROP TABLE IF EXISTS payments;

DROP INDEX IF EXISTS idx_penalties_status;
DROP INDEX IF EXISTS idx_penalties_user_id;
DROP TABLE IF EXISTS penalties;

DROP TABLE IF EXISTS duplicate_reports;

DROP INDEX IF EXISTS idx_incident_races_location;
DROP INDEX IF EXISTS idx_incident_races_vehicle;
DROP TABLE IF EXISTS incident_races;

DROP TABLE IF EXISTS case_sequences;

DROP INDEX IF EXISTS idx_reports_vehicle_number;
DROP INDEX IF EXISTS idx_reports_case_number;
DROP INDEX IF EXISTS idx_reports_status;
DROP INDEX IF EXISTS idx_reports_user_id;
DROP TABLE IF EXISTS reports;

DROP TABLE IF EXISTS dmp_officers;
DROP TABLE IF EXISTS users;
