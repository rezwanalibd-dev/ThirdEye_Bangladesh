# Third Eye - Project Structure

## Overview
Third Eye is a comprehensive traffic violation reporting system for Bangladesh, built as a Progressive Web App (PWA) with mobile app capabilities.

## Directory Structure

```
third-eye-app/
├── android/                          # Android mobile app files
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml   # Android permissions & config
│   │   │   └── res/                  # Android resources
│   │   └── build.gradle              # Android build configuration
│   └── README.md                     # Android setup instructions
│
├── ios/                              # iOS mobile app files
│   ├── App/
│   │   ├── App/
│   │   │   ├── Info.plist           # iOS permissions & config
│   │   │   └── Assets.xcassets/     # iOS app icons & resources
│   │   └── App.xcodeproj/           # Xcode project file
│   └── README.md                    # iOS setup instructions
│
├── src/
│   ├── react-app/                   # Frontend React application
│   │   ├── components/              # Reusable UI components
│   │   │   ├── BackButton.tsx
│   │   │   ├── EmergencyContactCard.tsx
│   │   │   ├── HierarchicalEmergencyContacts.tsx
│   │   │   ├── LoadingSpinner.tsx
│   │   │   ├── ProtectedRoute.tsx
│   │   │   ├── QuickCameraButton.tsx
│   │   │   ├── SafetyTipsCard.tsx
│   │   │   └── ViolationCard.tsx
│   │   │
│   │   ├── contexts/                # React context providers
│   │   │   ├── AuthContext.tsx      # Authentication state
│   │   │   └── LanguageContext.tsx  # Bilingual support
│   │   │
│   │   ├── hooks/                   # Custom React hooks
│   │   │   └── useApi.ts            # API interaction hook
│   │   │
│   │   ├── pages/                   # Main page components
│   │   │   ├── AuthCallback.tsx     # OAuth callback
│   │   │   ├── BiometricVerification.tsx
│   │   │   ├── Cases.tsx            # View submitted reports
│   │   │   ├── Dashboard.tsx        # Main user dashboard
│   │   │   ├── Features.tsx         # App features showcase
│   │   │   ├── Home.tsx             # Landing page
│   │   │   ├── IdentityVerification.tsx
│   │   │   ├── OTPVerification.tsx
│   │   │   ├── Profile.tsx          # User profile management
│   │   │   ├── Report.tsx           # Traffic violation reporting
│   │   │   ├── Setup.tsx            # Account setup flow
│   │   │   ├── Signin.tsx           # User authentication
│   │   │   ├── Signup.tsx           # User registration
│   │   │   ├── SocialCrime.tsx      # Anonymous crime reporting
│   │   │   ├── TrafficFines.tsx     # Fine information
│   │   │   └── VehicleRules.tsx     # Traffic rules education
│   │   │
│   │   ├── App.tsx                  # Main app component
│   │   ├── index.css                # Global styles
│   │   └── main.tsx                 # App entry point
│   │
│   ├── shared/                      # Shared utilities and constants
│   │   ├── constants.ts             # App-wide constants
│   │   └── types.ts                 # TypeScript type definitions
│   │
│   └── worker/                      # Cloudflare Worker backend
│       └── index.ts                 # API routes and business logic
│
├── public/                          # Static assets
├── dist/                           # Built application files
│   ├── client/                     # Frontend build output
│   └── 019a458a_2f26_7a6d_bb5d_5ca2247cbffc/  # Worker build
│
├── capacitor.config.ts             # Mobile app configuration
├── tailwind.config.js              # Tailwind CSS configuration
├── vite.config.ts                  # Vite build configuration
├── package.json                    # Dependencies and scripts
├── tsconfig.json                   # TypeScript configuration
├── wrangler.json                   # Cloudflare deployment config
│
├── MOBILE_DEPLOYMENT_GUIDE.md      # Complete mobile deployment guide
├── PROJECT_STRUCTURE.md            # This file
└── README.md                       # Main project documentation
```

## Key Features

### Frontend (React + TypeScript)
- **Responsive Design**: Mobile-first, works on all devices
- **Bilingual Support**: Complete English/Bengali interface
- **Real-time Updates**: Live case status tracking
- **Camera Integration**: Native camera access for evidence
- **GPS Location**: Automatic location detection
- **Emergency Contacts**: Quick access to Bangladesh emergency services

### Backend (Cloudflare Workers)
- **Serverless Architecture**: Scalable, global edge computing
- **SQLite Database**: Fast, reliable data storage with D1
- **Authentication**: Secure user management with JWT
- **File Storage**: R2 bucket integration for media files
- **Real-time Processing**: Instant report validation and routing

### Mobile Apps (Capacitor)
- **Cross-platform**: Single codebase for iOS and Android
- **Native Integration**: Camera, GPS, notifications
- **Offline Capability**: Core features work without internet
- **Push Notifications**: Real-time case updates
- **App Store Ready**: Optimized for distribution

## Data Flow

1. **User Registration**: 
   - Mobile/email signup → OTP verification → KYC documents → Biometric verification

2. **Report Submission**:
   - Vehicle type selection → Violation type → Details & location → Evidence upload → Submit

3. **Case Processing**:
   - Officer review → Approval/rejection → Fine collection → Commission payment

4. **User Dashboard**:
   - Case tracking → Earnings summary → Profile management → Emergency access

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, React Router
- **Mobile**: Capacitor, Native plugins
- **Backend**: Cloudflare Workers, Hono framework
- **Database**: Cloudflare D1 (SQLite)
- **Storage**: Cloudflare R2
- **Authentication**: Custom JWT implementation
- **Build Tools**: Vite, ESLint, PostCSS
- **Deployment**: Cloudflare Pages, Google Play Store, Apple App Store

## Environment Setup

### Development
```bash
npm install           # Install dependencies
npm run dev          # Start development server
npm run build        # Build for production
npx cap sync         # Sync mobile apps
```

### Mobile Development
```bash
npx cap add android  # Add Android platform
npx cap add ios      # Add iOS platform
npx cap open android # Open in Android Studio
npx cap open ios     # Open in Xcode
```

## API Endpoints

### Authentication
- `POST /api/auth/signup` - User registration
- `POST /api/auth/signin` - User login
- `POST /api/auth/verify-otp` - OTP verification
- `POST /api/auth/logout` - User logout

### User Management
- `GET /api/users/me` - Get user profile
- `POST /api/profile` - Update user profile
- `POST /api/auth/verify-identity` - Submit KYC documents
- `POST /api/auth/verify-biometric` - Submit biometric data

### Case Management
- `GET /api/cases` - List user's cases
- `POST /api/cases` - Submit new violation report
- `GET /api/cases/:id` - Get specific case details
- `GET /api/violation-types` - List available violations

### Dashboard
- `GET /api/dashboard/stats` - Get user statistics

## Security Features

- **Authentication**: JWT-based session management
- **Data Validation**: Input sanitization and validation
- **File Upload**: Secure media handling with type validation
- **Privacy Protection**: Anonymous reporting options
- **Encryption**: All data transmitted over HTTPS

## Deployment Environments

### Development
- Local development server
- SQLite database
- Mock services for testing

### Staging
- Cloudflare Pages preview
- D1 staging database
- Limited access for testing

### Production
- Cloudflare global network
- Production D1 database
- Mobile app stores
- 24/7 monitoring

## Contributing

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`
4. Make changes and test thoroughly
5. Build and verify: `npm run build`
6. Submit pull request with detailed description

## Support

- **Technical Issues**: Create GitHub issue
- **Feature Requests**: Submit feature request template
- **Security Concerns**: Email security team directly
- **General Questions**: Check documentation first

This structure ensures scalability, maintainability, and ease of deployment across all platforms while maintaining code quality and security standards.
