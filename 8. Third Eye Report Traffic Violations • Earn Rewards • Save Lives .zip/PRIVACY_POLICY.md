# Privacy Policy - Third Eye Traffic Reporter

**Effective Date**: November 2025  
**Last Updated**: November 3, 2025

## Introduction

Third Eye ("we," "our," or "us") operates the Third Eye mobile application (the "Service") to help citizens report traffic violations and contribute to road safety in Bangladesh.

This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application.

---

## Information We Collect

### Personal Information
- **Account Information**: Full name, mobile number, email address (optional)
- **Identity Verification**: National ID, driving license, or passport details
- **Biometric Data**: Facial recognition data for identity verification
- **Contact Information**: Phone number, emergency contact details
- **Payment Information**: Mobile wallet details (bKash, Rocket, Nagad)

### Usage Data
- **Location Data**: GPS coordinates when submitting violation reports
- **Camera Data**: Photos and videos captured for violation evidence
- **Device Information**: Device model, operating system, app version
- **App Usage**: Features used, time spent, interaction patterns

### Automatically Collected Data
- **Log Data**: IP address, access times, pages viewed
- **Device Identifiers**: Unique device ID, advertising ID
- **Crash Reports**: Error logs and app performance data

---

## How We Use Your Information

### Primary Purposes
- **Violation Reporting**: Process and verify traffic violation reports
- **Identity Verification**: Ensure user authenticity and prevent fraud
- **Commission Payments**: Calculate and distribute earnings to users
- **Emergency Services**: Provide quick access to emergency contacts
- **App Improvement**: Enhance features and user experience

### Secondary Purposes
- **Communication**: Send notifications about case updates and earnings
- **Legal Compliance**: Comply with traffic laws and government regulations
- **Safety**: Protect users and prevent misuse of the platform
- **Analytics**: Understand app usage patterns and improve performance

---

## Information Sharing

### Government Agencies
We share violation reports with:
- **Bangladesh Traffic Police**: For violation verification and fine processing
- **Department of Transport**: For traffic safety statistics
- **Law Enforcement**: When required by law or court order

### Service Providers
We share data with trusted third parties:
- **Payment Processors**: Mobile wallet providers for commission payments
- **Cloud Storage**: For secure data backup and storage
- **Analytics Services**: For app performance monitoring
- **Customer Support**: For user assistance and troubleshooting

### We Do NOT Share
- **Personal data for marketing**: We never sell your data to advertisers
- **Sensitive information**: Beyond what's necessary for our services
- **Data with unauthorized parties**: All sharing is governed by strict agreements

---

## Data Security

### Protection Measures
- **Encryption**: All data transmitted using HTTPS/TLS encryption
- **Secure Storage**: Personal data encrypted at rest
- **Access Controls**: Limited access to authorized personnel only
- **Regular Audits**: Security assessments and vulnerability testing

### Payment Security
- **PCI Compliance**: Payment processing follows industry standards
- **Tokenization**: Credit card and wallet details are tokenized
- **No Storage**: We don't store sensitive payment information
- **Secure Transmission**: All payment data encrypted during transfer

---

## Your Rights and Choices

### Account Control
- **Access**: View and download your personal data
- **Correction**: Update inaccurate or incomplete information
- **Deletion**: Request deletion of your account and data
- **Portability**: Export your data in machine-readable format

### Privacy Settings
- **Location Services**: Control when location data is collected
- **Notifications**: Manage push notification preferences
- **Data Sharing**: Opt out of non-essential data sharing
- **Marketing**: Unsubscribe from promotional communications

### How to Exercise Rights
Contact us at **privacy@thirdeye.bd** or through the app's settings to:
- Request data access or deletion
- Update your preferences  
- Report privacy concerns
- Ask questions about this policy

---

## Data Retention

### Retention Periods
- **Active Accounts**: Data retained while account is active
- **Violation Reports**: Kept for 7 years for legal compliance
- **Payment Records**: Retained for 3 years for tax/audit purposes
- **Deleted Accounts**: Most data deleted within 30 days

### Legal Requirements
Some data may be retained longer to:
- Comply with legal obligations
- Resolve disputes and enforce agreements
- Maintain security and prevent fraud
- Support ongoing investigations

---

## Children's Privacy

- **Age Restriction**: Our app is not intended for users under 18
- **Parental Consent**: Required for users under 18 in their jurisdiction
- **Data Minimization**: We collect minimal data from younger users
- **Special Protection**: Enhanced privacy measures for minors

---

## International Data Transfers

- **Local Processing**: Data primarily processed within Bangladesh
- **Cloud Services**: May use international cloud providers
- **Adequate Protection**: All transfers protected by appropriate safeguards
- **Your Consent**: International transfers only with your consent

---

## Cookie and Tracking Policy

### Cookies We Use
- **Essential Cookies**: Required for app functionality
- **Analytics Cookies**: Help us understand app usage
- **Preference Cookies**: Remember your settings
- **Security Cookies**: Protect against fraud and abuse

### Third-Party Tracking
- **Limited Use**: Only essential third-party services
- **Opt-Out Options**: Control tracking through device settings
- **Transparency**: Clear disclosure of all tracking technologies

---

## Updates to This Policy

### Notification of Changes
- **Email Alerts**: Significant changes communicated via email
- **In-App Notices**: Important updates shown in the app
- **Website Updates**: Latest version always available online
- **Effective Date**: Changes effective 30 days after notification

### Your Options
- **Review Changes**: Carefully read updated policies
- **Continued Use**: Using the app after changes constitutes acceptance
- **Discontinue Use**: Stop using the app if you disagree with changes
- **Contact Us**: Reach out with questions or concerns

---

## Contact Information

### Privacy Officer
**Email**: privacy@thirdeye.bd  
**Phone**: +880-1XXX-XXXXXX  
**Address**: Third Eye Privacy Team, Dhaka, Bangladesh

### Data Protection Authority
For complaints about our privacy practices, contact:
**Bangladesh Personal Data Protection Authority**  
(When established under upcoming data protection laws)

### Response Time
We respond to privacy inquiries within:
- **General Questions**: 7 business days
- **Access Requests**: 30 days
- **Urgent Matters**: 48 hours
- **Legal Requests**: As required by law

---

## Legal Basis for Processing

### Lawful Bases (GDPR/Similar Laws)
- **Contract Performance**: Processing necessary for our services
- **Legal Obligation**: Compliance with traffic laws and regulations
- **Legitimate Interests**: App improvement and fraud prevention
- **Consent**: Where you have specifically opted in

### Bangladesh Data Protection
- **Compliance**: Following local data protection requirements
- **Government Cooperation**: Working with traffic authorities
- **User Rights**: Respecting citizen privacy rights
- **Transparency**: Clear disclosure of data practices

---

## Special Categories of Data

### Biometric Data
- **Purpose**: Identity verification only
- **Consent**: Explicit consent required
- **Security**: Highest level of protection
- **Retention**: Deleted after verification complete

### Location Data
- **Precision**: Only as accurate as needed for reporting
- **Control**: Can be disabled in device settings
- **Storage**: Temporary storage for violation reporting
- **Sharing**: Only with traffic authorities for case processing

---

## Automated Decision Making

### Algorithm Use
- **Violation Detection**: Automated analysis of submitted reports
- **Fraud Prevention**: Automated screening for suspicious activity
- **Earnings Calculation**: Automated commission calculations
- **Human Review**: All automated decisions subject to human oversight

### Your Rights
- **Explanation**: Request explanation of automated decisions
- **Human Review**: Request human review of automated decisions
- **Appeal**: Challenge decisions you believe are incorrect
- **Opt-Out**: Request manual processing where possible

---

## Data Breach Response

### Our Commitment
- **Immediate Action**: Quick response to any security incidents
- **Investigation**: Thorough investigation of all breaches
- **Notification**: Prompt notification to affected users and authorities
- **Remediation**: Swift action to prevent further incidents

### User Actions
If you suspect a breach:
1. **Change Password**: Immediately update your account password
2. **Monitor Activity**: Check your account for suspicious activity
3. **Contact Us**: Report suspected breaches immediately
4. **Update Security**: Enable additional security measures

---

## Conclusion

Your privacy is fundamental to our mission of making Bangladesh roads safer. This policy reflects our commitment to protecting your personal information while enabling you to contribute meaningfully to traffic safety.

By using Third Eye, you acknowledge that you have read and understood this Privacy Policy and agree to the collection, use, and disclosure of your information as described.

**For the latest version of this policy, visit our website or check the app settings.**

---

**Third Eye - Making Bangladesh Roads Safer Through Community Participation**

*This privacy policy is compliant with Bangladesh data protection laws, GDPR principles, and international privacy standards.*
