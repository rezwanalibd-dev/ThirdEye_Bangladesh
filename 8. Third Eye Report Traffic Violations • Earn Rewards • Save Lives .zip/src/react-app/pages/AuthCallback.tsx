import { useEffect } from 'react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useNavigate } from 'react-router';
import LoadingSpinner from '@/react-app/components/LoadingSpinner';

export default function AuthCallback() {
  const { fetchUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleCallback = async () => {
      try {
        await fetchUser();
        // After successful authentication, check if user needs setup
        navigate('/setup');
      } catch (error) {
        console.error('Authentication failed:', error);
        navigate('/');
      }
    };

    handleCallback();
  }, [fetchUser, navigate]);

  return <LoadingSpinner />;
}
