import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Shield, Upload, FileText, CreditCard, BookOpen, AlertCircle, CheckCircle } from "lucide-react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import BackButton from '@/react-app/components/BackButton';

type DocumentType = 'nid' | 'driving_license' | 'passport';

export default function IdentityVerification() {
  const navigate = useNavigate();
  const { verifyIdentity } = useAuth();
  const { t } = useLanguage();
  
  const [documentType, setDocumentType] = useState<DocumentType>('nid');
  const [documentNumber, setDocumentNumber] = useState("");
  const [frontImage, setFrontImage] = useState<File | null>(null);
  const [backImage, setBackImage] = useState<File | null>(null);
  const [frontImageUrl, setFrontImageUrl] = useState("");
  const [backImageUrl, setBackImageUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const documentTypes = [
    {
      type: 'nid' as DocumentType,
      icon: CreditCard,
      name: t('National ID Card', 'জাতীয় পরিচয়পত্র'),
      description: t('NID card front and back required', 'NID কার্ডের সামনে ও পিছনে প্রয়োজন'),
      placeholder: t('Enter NID number', 'NID নম্বর লিখুন')
    },
    {
      type: 'driving_license' as DocumentType,
      icon: FileText,
      name: t('Driving License', 'ড্রাইভিং লাইসেন্স'),
      description: t('License front and back required', 'লাইসেন্সের সামনে ও পিছনে প্রয়োজন'),
      placeholder: t('Enter license number', 'লাইসেন্স নম্বর লিখুন')
    },
    {
      type: 'passport' as DocumentType,
      icon: BookOpen,
      name: t('Passport', 'পাসপোর্ট'),
      description: t('Information page only', 'শুধুমাত্র তথ্য পাতা'),
      placeholder: t('Enter passport number', 'পাসপোর্ট নম্বর লিখুন')
    }
  ];

  const handleImageUpload = (file: File, type: 'front' | 'back') => {
    if (!file.type.startsWith('image/')) {
      setError(t('Please select a valid image file', 'অনুগ্রহ করে একটি বৈধ ইমেজ ফাইল নির্বাচন করুন'));
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError(t('Image size must be less than 5MB', 'ইমেজের সাইজ ৫MB এর কম হতে হবে'));
      return;
    }

    // Mock upload - in production, upload to R2 or similar service
    const url = URL.createObjectURL(file);
    
    if (type === 'front') {
      setFrontImage(file);
      setFrontImageUrl(url);
    } else {
      setBackImage(file);
      setBackImageUrl(url);
    }
    
    setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!documentNumber) {
      setError(t('Please enter document number', 'অনুগ্রহ করে ডকুমেন্ট নম্বর লিখুন'));
      return;
    }

    if (!frontImage) {
      setError(t('Please upload front image', 'অনুগ্রহ করে সামনের ছবি আপলোড করুন'));
      return;
    }

    if (documentType !== 'passport' && !backImage) {
      setError(t('Please upload back image', 'অনুগ্রহ করে পিছনের ছবি আপলোড করুন'));
      return;
    }

    setLoading(true);
    
    try {
      // Mock upload to generate URLs - in production, upload to actual storage
      const frontUrl = `https://mock-storage.com/identity/${Date.now()}-front.jpg`;
      const backUrl = documentType !== 'passport' ? `https://mock-storage.com/identity/${Date.now()}-back.jpg` : undefined;

      await verifyIdentity({
        document_type: documentType,
        document_number: documentNumber,
        document_front_url: frontUrl,
        document_back_url: backUrl
      });

      navigate('/verify-biometric');
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setError(errorMessage || t('Identity verification failed', 'পরিচয় যাচাই ব্যর্থ'));
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <BackButton 
              to="/verify-otp" 
              label={t("Back to OTP Verification", "OTP যাচাইকরণে ফিরুন")}
              className="inline-flex items-center text-indigo-600 hover:text-indigo-700"
            />
          </div>
          
          <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-4 rounded-xl w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Shield className="w-8 h-8 text-white" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t("Identity Verification", "পরিচয় যাচাইকরণ")}
          </h1>
          <p className="text-gray-600">
            {t("Upload your identity document for verification", "যাচাইকরণের জন্য আপনার পরিচয়পত্র আপলোড করুন")}
          </p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 flex-shrink-0" />
              <span className="text-red-700 text-sm">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Document Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">
                {t("Select Document Type", "ডকুমেন্টের ধরন নির্বাচন করুন")}
              </label>
              <div className="grid md:grid-cols-3 gap-4">
                {documentTypes.map((doc) => {
                  const Icon = doc.icon;
                  return (
                    <button
                      key={doc.type}
                      type="button"
                      onClick={() => setDocumentType(doc.type)}
                      className={`p-4 border-2 rounded-xl text-center transition-all duration-200 ${
                        documentType === doc.type
                          ? 'border-indigo-500 bg-indigo-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <Icon className={`w-8 h-8 mx-auto mb-2 ${
                        documentType === doc.type ? 'text-indigo-600' : 'text-gray-400'
                      }`} />
                      <h3 className={`font-medium text-sm ${
                        documentType === doc.type ? 'text-indigo-900' : 'text-gray-900'
                      }`}>
                        {doc.name}
                      </h3>
                      <p className={`text-xs mt-1 ${
                        documentType === doc.type ? 'text-indigo-600' : 'text-gray-500'
                      }`}>
                        {doc.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Document Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t("Document Number", "ডকুমেন্ট নম্বর")}
              </label>
              <input
                type="text"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder={documentTypes.find(d => d.type === documentType)?.placeholder}
                required
              />
            </div>

            {/* Image Upload - Front */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {documentType === 'passport' 
                  ? t("Information Page", "তথ্য পাতা")
                  : t("Front Side", "সামনের দিক")
                }
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                {frontImageUrl ? (
                  <div className="space-y-4">
                    <img src={frontImageUrl} alt="Front" className="max-h-48 mx-auto rounded-lg" />
                    <button
                      type="button"
                      onClick={() => {
                        setFrontImage(null);
                        setFrontImageUrl("");
                      }}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      {t("Remove", "সরান")}
                    </button>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">
                      {t("Click to upload or drag and drop", "আপলোড করতে ক্লিক করুন বা ড্র্যাগ করুন")}
                    </p>
                    <p className="text-xs text-gray-500">
                      {t("PNG, JPG up to 5MB", "PNG, JPG সর্বোচ্চ ৫MB")}
                    </p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'front')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Image Upload - Back (if not passport) */}
            {documentType !== 'passport' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t("Back Side", "পিছনের দিক")}
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                  {backImageUrl ? (
                    <div className="space-y-4">
                      <img src={backImageUrl} alt="Back" className="max-h-48 mx-auto rounded-lg" />
                      <button
                        type="button"
                        onClick={() => {
                          setBackImage(null);
                          setBackImageUrl("");
                        }}
                        className="text-red-600 hover:text-red-700 text-sm"
                      >
                        {t("Remove", "সরান")}
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-2">
                        {t("Click to upload or drag and drop", "আপলোড করতে ক্লিক করুন বা ড্র্যাগ করুন")}
                      </p>
                      <p className="text-xs text-gray-500">
                        {t("PNG, JPG up to 5MB", "PNG, JPG সর্বোচ্চ ৫MB")}
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'back')}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Instructions */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
                <div className="text-blue-700 text-sm">
                  <p className="font-medium mb-2">
                    {t("Photo Guidelines", "ছবির নির্দেশনা")}
                  </p>
                  <ul className="space-y-1 text-xs">
                    <li>• {t("Clear, well-lit photos", "পরিষ্কার, ভাল আলোকিত ছবি")}</li>
                    <li>• {t("All text must be readable", "সমস্ত লেখা পড়ার যোগ্য হতে হবে")}</li>
                    <li>• {t("No glare or shadows", "কোন চকচকে বা ছায়া নেই")}</li>
                    <li>• {t("Full document visible in frame", "সম্পূর্ণ ডকুমেন্ট ফ্রেমে দৃশ্যমান")}</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !frontImage || (documentType !== 'passport' && !backImage)}
              className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-indigo-700 hover:to-blue-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading 
                ? t("Uploading...", "আপলোড করা হচ্ছে...") 
                : t("Continue to Biometric Verification", "বায়োমেট্রিক যাচাইকরণে এগিয়ে যান")
              }
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
