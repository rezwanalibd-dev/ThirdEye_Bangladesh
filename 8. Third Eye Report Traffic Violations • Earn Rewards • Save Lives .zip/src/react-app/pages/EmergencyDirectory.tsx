import { useState } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { Phone, Search, ChevronDown, ChevronRight, Eye } from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

// Comprehensive Bangladesh Emergency Directory
const EMERGENCY_DIRECTORY = {
  // 🚨 URGENT EMERGENCY SERVICES
  urgent_emergency: [
    {
      number: "999",
      name_en: "National Emergency Service",
      name_bn: "জাতীয় জরুরি সেবা",
      description_en: "Police, Fire, Ambulance (24/7, free nationwide)",
      description_bn: "পুলিশ, ফায়ার, অ্যাম্বুলেন্স (২৪/৭, দেশব্যাপী বিনামূল্যে)",
      icon: "🚨"
    },
    {
      number: "333",
      name_en: "National Information Service",
      name_bn: "জাতীয় তথ্য সেবা",
      description_en: "Government info, social support, local admin contact",
      description_bn: "সরকারি তথ্য, সামাজিক সহায়তা, স্থানীয় প্রশাসনিক যোগাযোগ",
      icon: "📞"
    },
    {
      number: "109",
      name_en: "Violence Against Women & Children",
      name_bn: "নারী ও শিশু নির্যাতন হটলাইন",
      description_en: "Legal, shelter, counselling support",
      description_bn: "আইনি, আশ্রয়, পরামর্শ সহায়তা",
      icon: "👥"
    },
    {
      number: "16263",
      name_en: "National Health Hotline",
      name_bn: "জাতীয় স্বাস্থ্য হটলাইন",
      description_en: "Medical advice, hospital info, COVID info",
      description_bn: "চিকিৎসা পরামর্শ, হাসপাতালের তথ্য, কোভিড তথ্য",
      icon: "🏥"
    },
    {
      number: "106",
      name_en: "Anti-Corruption Commission",
      name_bn: "দুর্নীতি দমন কমিশন",
      description_en: "Report corruption or misuse of power",
      description_bn: "দুর্নীতি বা ক্ষমতার অপব্যবহার রিপোর্ট করুন",
      icon: "🚫"
    }
  ],

  // 🏥 HOSPITALS & MEDICAL EMERGENCY
  hospitals: [
    {
      number: "02-55165088",
      name_en: "Dhaka Medical College Hospital (DMCH)",
      name_bn: "ঢাকা মেডিকেল কলেজ হাসপাতাল",
      description_en: "Emergency Contact",
      description_bn: "জরুরি যোগাযোগ",
      icon: "🏥"
    },
    {
      number: "10616",
      name_en: "Square Hospital",
      name_bn: "স্কয়ার হাসপাতাল",
      description_en: "Private Hospital Emergency",
      description_bn: "প্রাইভেট হাসপাতাল জরুরি",
      icon: "🏥"
    },
    {
      number: "10666",
      name_en: "United Hospital",
      name_bn: "ইউনাইটেড হাসপাতাল",
      description_en: "Emergency Services",
      description_bn: "জরুরি সেবা",
      icon: "🏥"
    },
    {
      number: "10678",
      name_en: "Evercare Hospital Dhaka",
      name_bn: "এভারকেয়ার হাসপাতাল ঢাকা",
      description_en: "Emergency & Critical Care",
      description_bn: "জরুরি ও গুরুত্বপূর্ণ চিকিৎসা",
      icon: "🏥"
    },
    {
      number: "02-48114040",
      name_en: "Ibn Sina Hospital",
      name_bn: "ইবনে সিনা হাসপাতাল",
      description_en: "Medical Emergency",
      description_bn: "চিকিৎসা জরুরি",
      icon: "🏥"
    },
    {
      number: "10606",
      name_en: "Labaid Hospital",
      name_bn: "ল্যাবএইড হাসপাতাল",
      description_en: "Emergency Care",
      description_bn: "জরুরি চিকিৎসা",
      icon: "🏥"
    },
    {
      number: "02-48311700",
      name_en: "Holy Family Red Crescent Hospital",
      name_bn: "হলি ফ্যামিলি রেড ক্রিসেন্ট হাসপাতাল",
      description_en: "Emergency Services",
      description_bn: "জরুরি সেবা",
      icon: "🏥"
    },
    {
      number: "02-55062350",
      name_en: "Kurmitola General Hospital",
      name_bn: "কুর্মিটোলা জেনারেল হাসপাতাল",
      description_en: "Government Hospital",
      description_bn: "সরকারি হাসপাতাল",
      icon: "🏥"
    }
  ],

  // 🚑 AMBULANCE SERVICES
  ambulance: [
    {
      number: "01811-458500",
      name_en: "Red Crescent Ambulance",
      name_bn: "রেড ক্রিসেন্ট অ্যাম্বুলেন্স",
      description_en: "Private ambulance service",
      description_bn: "ব্যক্তিগত অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "02-9336611",
      name_en: "Anjuman Mufidul Islam",
      name_bn: "আঞ্জুমান মুফিদুল ইসলাম",
      description_en: "Charitable ambulance service",
      description_bn: "দাতব্য অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "10647",
      name_en: "BRB Hospital Ambulance",
      name_bn: "বিআরবি হাসপাতাল অ্যাম্বুলেন্স",
      description_en: "Hospital ambulance service",
      description_bn: "হাসপাতাল অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "01713-032903",
      name_en: "Al-Markazul Islami",
      name_bn: "আল-মারকাযুল ইসলামী",
      description_en: "Islamic foundation ambulance",
      description_bn: "ইসলামিক ফাউন্ডেশন অ্যাম্বুলেন্স",
      icon: "🚑"
    }
  ],

  // 🧠 MENTAL HEALTH & COUNSELLING
  mental_health: [
    {
      number: "01779554391",
      name_en: "Kaan Pete Roi",
      name_bn: "কান পেতে রই",
      description_en: "24/7 confidential listening service",
      description_bn: "২৪/৭ গোপনীয় শ্রবণ সেবা",
      icon: "🧠"
    },
    {
      number: "01779554391",
      name_en: "Moner Bondhu",
      name_bn: "মনের বন্ধু",
      description_en: "Counselling and mental health support",
      description_bn: "পরামর্শ এবং মানসিক স্বাস্থ্য সহায়তা",
      icon: "💚"
    },
    {
      number: "09666-787878",
      name_en: "Bangladesh Psychological Association",
      name_bn: "বাংলাদেশ সাইকোলজিক্যাল অ্যাসোসিয়েশন",
      description_en: "Professional counselling",
      description_bn: "পেশাদার পরামর্শ",
      icon: "🧠"
    }
  ],

  // 👶 WOMEN & CHILD SUPPORT
  child_support: [
    {
      number: "1098",
      name_en: "Child Helpline (DSS)",
      name_bn: "শিশু হেল্পলাইন (সমাজসেবা অধিদপ্তর)",
      description_en: "Department of Social Services",
      description_bn: "সমাজসেবা অধিদপ্তর",
      icon: "🧒"
    },
    {
      number: "01730336699",
      name_en: "BRAC Legal Aid",
      name_bn: "ব্র্যাক আইনি সহায়তা",
      description_en: "Free Legal Help",
      description_bn: "বিনামূল্যে আইনি সহায়তা",
      icon: "⚖️"
    },
    {
      number: "01796132524",
      name_en: "Acid Survivors Foundation",
      name_bn: "এসিড সারভাইভার ফাউন্ডেশন",
      description_en: "Support for acid attack victims",
      description_bn: "এসিড হামলার শিকারদের সহায়তা",
      icon: "🛡️"
    },
    {
      number: "01713373191",
      name_en: "Police Victim Support Centre",
      name_bn: "পুলিশ ভিকটিম সাপোর্ট সেন্টার",
      description_en: "Support for crime victims (Tejgaon)",
      description_bn: "অপরাধের শিকারদের সহায়তা (তেজগাঁও)",
      icon: "🚔"
    }
  ],

  // 🚔 LAW ENFORCEMENT
  law_enforcement: [
    {
      number: "100",
      name_en: "Bangladesh Police HQ",
      name_bn: "বাংলাদেশ পুলিশ সদর দপ্তর",
      description_en: "999 replaced this officially",
      description_bn: "৯৯৯ এটিকে আনুষ্ঠানিকভাবে প্রতিস্থাপন করেছে",
      icon: "🚔"
    },
    {
      number: "01320-040244",
      name_en: "Traffic Police",
      name_bn: "ট্রাফিক পুলিশ",
      description_en: "Traffic Accidents",
      description_bn: "ট্রাফিক দুর্ঘটনা",
      icon: "🚓"
    },
    {
      number: "16107",
      name_en: "Road Transport (BRTA)",
      name_bn: "সড়ক পরিবহন (বিআরটিএ)",
      description_en: "Vehicle registration and licensing",
      description_bn: "যানবাহন নিবন্ধন এবং লাইসেন্সিং",
      icon: "🚗"
    },
    {
      number: "01769693535",
      name_en: "Cyber Crime Complaint (CID)",
      name_bn: "সাইবার ক্রাইম অভিযোগ (সিআইডি)",
      description_en: "Online fraud or harassment",
      description_bn: "অনলাইন জালিয়াতি বা হয়রানি",
      icon: "💻"
    },
    {
      number: "16121",
      name_en: "Consumer Rights Authority",
      name_bn: "ভোক্তা অধিকার কর্তৃপক্ষ",
      description_en: "Unfair business, fraud, price gouging",
      description_bn: "অন্যায্য ব্যবসা, জালিয়াতি, মূল্য বৃদ্ধি",
      icon: "🛡️"
    }
  ],

  // 💳 FINANCIAL SERVICES
  financial: [
    {
      number: "16247",
      name_en: "bKash Customer Care",
      name_bn: "বিকাশ কাস্টমার কেয়ার",
      description_en: "Mobile financial services",
      description_bn: "মোবাইল আর্থিক সেবা",
      icon: "💳"
    },
    {
      number: "16167",
      name_en: "Nagad Customer Care",
      name_bn: "নগদ কাস্টমার কেয়ার",
      description_en: "Digital payment service",
      description_bn: "ডিজিটাল পেমেন্ট সেবা",
      icon: "📱"
    },
    {
      number: "16216",
      name_en: "Rocket (DBBL)",
      name_bn: "রকেট (ডিবিবিএল)",
      description_en: "Mobile banking service",
      description_bn: "মোবাইল ব্যাংকিং সেবা",
      icon: "🚀"
    },
    {
      number: "16236",
      name_en: "Sonali Bank",
      name_bn: "সোনালী ব্যাংক",
      description_en: "National bank services",
      description_bn: "জাতীয় ব্যাংক সেবা",
      icon: "🏦"
    },
    {
      number: "16234",
      name_en: "City Bank (Amex)",
      name_bn: "সিটি ব্যাংক (আমেক্স)",
      description_en: "Credit card / bank issues",
      description_bn: "ক্রেডিট কার্ড / ব্যাংক সমস্যা",
      icon: "💳"
    },
    {
      number: "16233",
      name_en: "Standard Chartered Bank",
      name_bn: "স্ট্যান্ডার্ড চার্টার্ড ব্যাংক",
      description_en: "24/7 banking support",
      description_bn: "২৪/৭ ব্যাংকিং সহায়তা",
      icon: "🏦"
    }
  ],

  // ⚡ UTILITY SERVICES (Electricity, Gas, Water)
  utilities: [
    {
      number: "16120",
      name_en: "DESCO (Electricity)",
      name_bn: "ডেসকো (বিদ্যুৎ)",
      description_en: "Mirpur, Gulshan, Uttara, Tongi - Power outage, safety issue",
      description_bn: "মিরপুর, গুলশান, উত্তরা, টঙ্গী - বিদ্যুৎ বিভ্রাট, নিরাপত্তা সমস্যা",
      icon: "⚡"
    },
    {
      number: "02-9632304",
      name_en: "DPDC (Electricity)",
      name_bn: "ডিপিডিসি (বিদ্যুৎ)",
      description_en: "Dhanmondi, Motijheel, Jatrabari - Power failure, billing",
      description_bn: "ধানমন্ডি, মতিঝিল, যাত্রাবাড়ী - বিদ্যুৎ ব্যর্থতা, বিলিং",
      icon: "⚡"
    },
    {
      number: "16121",
      name_en: "BPDB (Power)",
      name_bn: "বিপিডিবি (বিদ্যুৎ)",
      description_en: "Chattogram, Sylhet, Barishal, Rajshahi",
      description_bn: "চট্টগ্রাম, সিলেট, বরিশাল, রাজশাহী",
      icon: "⚡"
    },
    {
      number: "16496",
      name_en: "Titas Gas",
      name_bn: "তিতাস গ্যাস",
      description_en: "Dhaka, Narayanganj, Gazipur - Gas leak, low pressure",
      description_bn: "ঢাকা, নারায়ণগঞ্জ, গাজীপুর - গ্যাস লিক, কম চাপ",
      icon: "🔥"
    },
    {
      number: "16512",
      name_en: "Karnaphuli Gas",
      name_bn: "কর্ণফুলী গ্যাস",
      description_en: "Chattogram region",
      description_bn: "চট্টগ্রাম অঞ্চল",
      icon: "🔥"
    },
    {
      number: "0821-717921",
      name_en: "Jalalabad Gas",
      name_bn: "জালালাবাদ গ্যাস",
      description_en: "Sylhet region",
      description_bn: "সিলেট অঞ্চল",
      icon: "🔥"
    },
    {
      number: "16162",
      name_en: "WASA (Water)",
      name_bn: "ওয়াসা (পানি)",
      description_en: "Dhaka water supply & sewerage",
      description_bn: "ঢাকা পানি সরবরাহ ও নর্দমা",
      icon: "💧"
    }
  ],

  // ✈️ TRANSPORT & TRAVEL
  transport: [
    {
      number: "02-8901904",
      name_en: "Hazrat Shahjalal Airport",
      name_bn: "হযরত শাহজালাল বিমানবন্দর",
      description_en: "Airport Information",
      description_bn: "বিমানবন্দরের তথ্য",
      icon: "✈️"
    },
    {
      number: "131",
      name_en: "Bangladesh Railway Info",
      name_bn: "বাংলাদেশ রেলওয়ে তথ্য",
      description_en: "Train schedules and bookings",
      description_bn: "ট্রেনের সময়সূচী এবং বুকিং",
      icon: "🚂"
    },
    {
      number: "02-8901600",
      name_en: "Biman Bangladesh Airlines",
      name_bn: "বিমান বাংলাদেশ এয়ারলাইনস",
      description_en: "Flight information",
      description_bn: "ফ্লাইটের তথ্য",
      icon: "✈️"
    },
    {
      number: "01321168105",
      name_en: "Launch / River Transport",
      name_bn: "লঞ্চ / নদী পরিবহন",
      description_en: "River transport control room",
      description_bn: "নদী পরিবহন নিয়ন্ত্রণ কক্ষ",
      icon: "⛴️"
    },
    {
      number: "02-9559774",
      name_en: "BIWTA",
      name_bn: "বিআইডব্লিউটিএ",
      description_en: "Inland Water Transport Authority",
      description_bn: "অভ্যন্তরীণ জল পরিবহন কর্তৃপক্ষ",
      icon: "🚢"
    }
  ],

  // 📱 TELECOM SERVICES
  telecom: [
    {
      number: "121",
      name_en: "Grameenphone",
      name_bn: "গ্রামীণফোন",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "123",
      name_en: "Robi",
      name_bn: "রবি",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "121",
      name_en: "Banglalink",
      name_bn: "বাংলালিংক",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "121",
      name_en: "Teletalk",
      name_bn: "টেলিটক",
      description_en: "Govt. SIM customer care",
      description_bn: "সরকারি সিম কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "16402",
      name_en: "BTCL (Landline)",
      name_bn: "বিটিসিএল (ল্যান্ডলাইন)",
      description_en: "Telephone issues",
      description_bn: "টেলিফোন সমস্যা",
      icon: "☎️"
    },
    {
      number: "100",
      name_en: "ISP Complaint (BTRC)",
      name_bn: "আইএসপি অভিযোগ (বিটিআরসি)",
      description_en: "Report telecom or internet fraud",
      description_bn: "টেলিকম বা ইন্টারনেট জালিয়াতি রিপোর্ট",
      icon: "🌐"
    }
  ],

  // 🌪️ DISASTER & CRISIS
  disaster: [
    {
      number: "1090",
      name_en: "Disaster Management",
      name_bn: "দুর্যোগ ব্যবস্থাপনা",
      description_en: "Natural Disasters",
      description_bn: "প্রাকৃতিক দুর্যোগ",
      icon: "🌪️"
    },
    {
      number: "1090",
      name_en: "Cyclone Warning",
      name_bn: "ঘূর্ণিঝড় সতর্কতা",
      description_en: "Storm Alerts",
      description_bn: "ঝড় সতর্কবার্তা",
      icon: "🌀"
    },
    {
      number: "1090",
      name_en: "Flood Warning",
      name_bn: "বন্যা সতর্কতা",
      description_en: "Flood Safety",
      description_bn: "বন্যা নিরাপত্তা",
      icon: "🌊"
    }
  ],

  // 🏛️ GOVERNMENT SERVICES
  government: [
    {
      number: "16157",
      name_en: "Public Service Commission",
      name_bn: "সরকারি সেবা কমিশন",
      description_en: "Job Exam Info",
      description_bn: "চাকরির পরীক্ষার তথ্য",
      icon: "📋"
    },
    {
      number: "16169",
      name_en: "National Board of Revenue (NBR)",
      name_bn: "জাতীয় রাজস্ব বোর্ড (এনবিআর)",
      description_en: "Tax return, VAT, online payment issues",
      description_bn: "কর রিটার্ন, ভ্যাট, অনলাইন পেমেন্ট সমস্যা",
      icon: "💰"
    },
    {
      number: "105",
      name_en: "NID (Election Commission)",
      name_bn: "এনআইডি (নির্বাচন কমিশন)",
      description_en: "Voter ID correction, reissue, online ID",
      description_bn: "ভোটার আইডি সংশোধন, পুনঃইস্যু, অনলাইন আইডি",
      icon: "🆔"
    }
  ],

  // 💼 LAND & TAX SERVICES
  land_tax: [
    {
      number: "16122",
      name_en: "Land Service Helpline",
      name_bn: "ভূমি সেবা হেল্পলাইন",
      description_en: "Land mutation, khatian, land record, e-namjari",
      description_bn: "ভূমি মিউটেশন, খতিয়ান, ভূমি রেকর্ড, ই-নামজারি",
      icon: "🏡"
    },
    {
      number: "16106",
      name_en: "Dhaka North City Corporation (DNCC)",
      name_bn: "ঢাকা উত্তর সিটি কর্পোরেশন (ডিএনসিসি)",
      description_en: "Holding tax payment, trade license, property assessment",
      description_bn: "হোল্ডিং ট্যাক্স পেমেন্ট, ব্যবসায়িক লাইসেন্স, সম্পত্তি মূল্যায়ন",
      icon: "🏢"
    },
    {
      number: "16104",
      name_en: "Dhaka South City Corporation (DSCC)",
      name_bn: "ঢাকা দক্ষিণ সিটি কর্পোরেশন (ডিএসসিসি)",
      description_en: "Holding tax, sanitation, building-related taxes",
      description_bn: "হোল্ডিং ট্যাক্স, স্যানিটেশন, ভবন সম্পর্কিত কর",
      icon: "🏢"
    }
  ],

  // 🎓 EDUCATION & SERVICES
  education: [
    {
      number: "16222",
      name_en: "Education Board (SSC/HSC)",
      name_bn: "শিক্ষা বোর্ড (এসএসসি/এইচএসসি)",
      description_en: "Results, registration",
      description_bn: "ফলাফল, নিবন্ধন",
      icon: "🎓"
    },
    {
      number: "09666778888",
      name_en: "University Grants Commission (UGC)",
      name_bn: "বিশ্ববিদ্যালয় মঞ্জুরি কমিশন (ইউজিসি)",
      description_en: "Private university issues",
      description_bn: "বেসরকারি বিশ্ববিদ্যালয় সমস্যা",
      icon: "🎓"
    },
    {
      number: "16211",
      name_en: "Post Office & EMS Courier",
      name_bn: "পোস্ট অফিস ও ইএমএস কুরিয়ার",
      description_en: "Parcel tracking, delay or complaint",
      description_bn: "পার্সেল ট্র্যাকিং, বিলম্ব বা অভিযোগ",
      icon: "📮"
    }
  ]
};

const sectionTitles = {
  urgent_emergency: {
    en: '🚨 URGENT EMERGENCY SERVICES',
    bn: '🚨 জরুরি জরুরি সেবা'
  },
  hospitals: {
    en: '🏥 Hospitals & Medical Emergency',
    bn: '🏥 হাসপাতাল ও চিকিৎসা জরুরি'
  },
  ambulance: {
    en: '🚑 Ambulance Services',
    bn: '🚑 অ্যাম্বুলেন্স সেবা'
  },
  mental_health: {
    en: '🧠 Mental Health & Counselling',
    bn: '🧠 মানসিক স্বাস্থ্য ও পরামর্শ'
  },
  child_support: {
    en: '👶 Women & Child Support',
    bn: '👶 নারী ও শিশু সহায়তা'
  },
  law_enforcement: {
    en: '🚔 Law Enforcement',
    bn: '🚔 আইন প্রয়োগকারী'
  },
  financial: {
    en: '💳 Financial Services',
    bn: '💳 আর্থিক সেবা'
  },
  utilities: {
    en: '⚡ Utility Services (Electricity, Gas, Water)',
    bn: '⚡ উপযোগিতা সেবা (বিদ্যুৎ, গ্যাস, পানি)'
  },
  transport: {
    en: '✈️ Transport & Travel',
    bn: '✈️ পরিবহন ও ভ্রমণ'
  },
  telecom: {
    en: '📱 Telecom Services',
    bn: '📱 টেলিকম সেবা'
  },
  disaster: {
    en: '🌪️ Disaster & Crisis Management',
    bn: '🌪️ দুর্যোগ ও সংকট ব্যবস্থাপনা'
  },
  government: {
    en: '🏛️ Government Services',
    bn: '🏛️ সরকারি সেবা'
  },
  land_tax: {
    en: '💼 Land & Tax Services',
    bn: '💼 ভূমি ও কর সেবা'
  },
  education: {
    en: '🎓 Education & Postal Services',
    bn: '🎓 শিক্ষা ও ডাক সেবা'
  }
};

export default function EmergencyDirectory() {
  const { language, t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(['urgent_emergency']) // Urgent emergency expanded by default
  );

  const toggleSection = (sectionKey: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionKey)) {
      newExpanded.delete(sectionKey);
    } else {
      newExpanded.add(sectionKey);
    }
    setExpandedSections(newExpanded);
  };

  // Filter contacts based on search term
  const filterContacts = (contacts: any[]) => {
    if (!searchTerm) return contacts;
    return contacts.filter(contact => 
      contact.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.name_bn.includes(searchTerm) ||
      contact.number.includes(searchTerm) ||
      contact.description_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.description_bn.includes(searchTerm)
    );
  };

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-10" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center space-x-4">
            <BackButton 
              to="/"
              className="p-2 hover:bg-ash rounded-lg transition-colors"
            />
            <div className="flex items-center space-x-3">
              <div className="icon-danger w-12 h-12">
                <Eye className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('Complete Emergency Directory', 'সম্পূর্ণ জরুরি ডিরেক্টরি')}
                </h1>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  {t('Bangladesh National Emergency Contacts', 'বাংলাদেশ জাতীয় জরুরি যোগাযোগ')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder={t('Search emergency contacts...', 'জরুরি যোগাযোগ খুঁজুন...')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg"
            />
          </div>
        </div>

        {/* Emergency Contacts Directory */}
        <div className="space-y-4">
          {Object.entries(EMERGENCY_DIRECTORY).map(([sectionKey, contacts]) => {
            const filteredContacts = filterContacts(contacts);
            if (filteredContacts.length === 0 && searchTerm) return null;
            
            const isExpanded = expandedSections.has(sectionKey);
            const sectionTitle = sectionTitles[sectionKey as keyof typeof sectionTitles];
            
            return (
              <div key={sectionKey} className="card-base overflow-hidden">
                <button
                  onClick={() => toggleSection(sectionKey)}
                  className={`
                    w-full p-4 sm:p-6 flex items-center justify-between transition-all hover:bg-ash
                    ${sectionKey === 'urgent_emergency' ? 'bg-danger text-white hover:opacity-90' : ''}
                  `}
                  style={{
                    backgroundColor: sectionKey === 'urgent_emergency' ? 'var(--color-light-red-dark)' : undefined
                  }}
                >
                  <h3 className={`text-lg sm:text-xl font-bold ${
                    sectionKey === 'urgent_emergency' ? 'text-white' : ''
                  }`} style={{
                    color: sectionKey !== 'urgent_emergency' ? 'var(--text-primary)' : undefined
                  }}>
                    {language === 'en' ? sectionTitle.en : sectionTitle.bn}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium px-3 py-1 rounded-full ${
                      sectionKey === 'urgent_emergency' ? 'bg-white bg-opacity-20 text-white' : 'bg-ash'
                    }`} style={{
                      color: sectionKey !== 'urgent_emergency' ? 'var(--text-secondary)' : undefined
                    }}>
                      {filteredContacts.length}
                    </span>
                    {isExpanded ? (
                      <ChevronDown className={`w-6 h-6 ${
                        sectionKey === 'urgent_emergency' ? 'text-white' : ''
                      }`} style={{
                        color: sectionKey !== 'urgent_emergency' ? 'var(--text-secondary)' : undefined
                      }} />
                    ) : (
                      <ChevronRight className={`w-6 h-6 ${
                        sectionKey === 'urgent_emergency' ? 'text-white' : ''
                      }`} style={{
                        color: sectionKey !== 'urgent_emergency' ? 'var(--text-secondary)' : undefined
                      }} />
                    )}
                  </div>
                </button>

                {isExpanded && (
                  <div className="border-t" style={{ borderColor: 'var(--color-light-blue)' }}>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 sm:p-6">
                      {filteredContacts.map((contact, index) => (
                        <div 
                          key={`${contact.number}-${index}`} 
                          className="bg-white rounded-xl p-4 sm:p-6 shadow-sm border border-gray-200 hover:shadow-md transition-all"
                        >
                          <div className="flex items-start space-x-3 mb-4">
                            <div className="text-2xl sm:text-3xl flex-shrink-0">{contact.icon}</div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-sm sm:text-base leading-tight mb-1" style={{ color: 'var(--text-primary)' }}>
                                {language === 'en' ? contact.name_en : contact.name_bn}
                              </h4>
                              <p className="text-xs sm:text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                                {language === 'en' ? contact.description_en : contact.description_bn}
                              </p>
                            </div>
                          </div>
                          
                          <a
                            href={`tel:${contact.number}`}
                            className={`
                              w-full flex items-center justify-center px-4 py-3 rounded-xl font-bold text-sm sm:text-base transition-all transform hover:scale-[1.02] shadow-md hover:shadow-lg
                              ${sectionKey === 'urgent_emergency' 
                                ? 'bg-red-600 hover:bg-red-700 text-white' 
                                : 'bg-blue-600 hover:bg-blue-700 text-white'}
                            `}
                          >
                            <Phone className="w-4 h-4 mr-2" />
                            {contact.number}
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Search Results Summary */}
        {searchTerm && (
          <div className="mt-8 text-center">
            <p className="text-gray-600">
              {t(
                `Found ${Object.values(EMERGENCY_DIRECTORY).flat().filter(contact => 
                  contact.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  contact.name_bn.includes(searchTerm) ||
                  contact.number.includes(searchTerm)
                ).length} results for "${searchTerm}"`,
                `"${searchTerm}" এর জন্য ${Object.values(EMERGENCY_DIRECTORY).flat().filter(contact => 
                  contact.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  contact.name_bn.includes(searchTerm) ||
                  contact.number.includes(searchTerm)
                ).length} ফলাফল পাওয়া গেছে`
              )}
            </p>
          </div>
        )}

        {/* Important Notice */}
        <div className="mt-8 bg-blue-50 rounded-xl p-6 border border-blue-200">
          <h3 className="font-bold text-blue-900 mb-3 flex items-center text-lg">
            <span className="text-xl mr-2">ℹ️</span>
            {t('Important Information', 'গুরুত্বপূর্ণ তথ্য')}
          </h3>
          <div className="space-y-2 text-blue-800 text-sm">
            <p>• {t('All emergency contact numbers are updated as of 2025', 'সমস্ত জরুরি যোগাযোগ নম্বর ২০২৫ সালের হিসাবে আপডেট করা হয়েছে')}</p>
            <p>• {t('Save important numbers in your phone for quick access', 'দ্রুত অ্যাক্সেসের জন্য গুরুত্বপূর্ণ নম্বরগুলি আপনার ফোনে সেভ করুন')}</p>
            <p>• {t('For life-threatening emergencies, always call 999 first', 'জীবন-হুমকিপূর্ণ জরুরি অবস্থায়, সর্বদা প্রথমে ৯৯৯ এ কল করুন')}</p>
            <p>• {t('This directory is available 24/7 without any registration', 'এই ডিরেক্টরিটি কোনো নিবন্ধন ছাড়াই ২৪/৭ উপলব্ধ')}</p>
          </div>
        </div>
      </main>
    </div>
  );
}
