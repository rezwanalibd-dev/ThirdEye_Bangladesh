import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { 
  Eye, 
  Shield, 
  Award, 
  Camera, 
  MapPin, 
  TrendingUp,
  Users,
  CheckCircle,
  Phone,
  Menu,
  X,
  Globe
} from 'lucide-react';
import { EMERGENCY_CONTACTS_FLAT } from '@/shared/constants';

export default function Home() {
  const { user } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const stats = [
    {
      icon: Users,
      number: '50,000+',
      label_en: 'Active Users',
      label_bn: 'সক্রিয় ব্যবহারকারী',
      color: 'var(--color-light-blue-dark)'
    },
    {
      icon: CheckCircle,
      number: '25,000+',
      label_en: 'Cases Resolved',
      label_bn: 'সমাধানকৃত মামলা',
      color: 'var(--color-light-green-dark)'
    },
    {
      icon: Award,
      number: '৳10L+',
      label_en: 'Rewards Paid',
      label_bn: 'প্রদত্ত পুরস্কার',
      color: 'var(--color-light-red-dark)'
    },
    {
      icon: TrendingUp,
      number: '85%',
      label_en: 'Success Rate',
      label_bn: 'সফলতার হার',
      color: 'var(--color-light-ash-dark)'
    }
  ];

  const features = [
    {
      icon: Camera,
      title_en: 'Report Violations',
      title_bn: 'আইন লঙ্ঘন রিপোর্ট করুন',
      desc_en: 'Capture traffic violations with your phone camera and submit reports instantly',
      desc_bn: 'আপনার ফোনের ক্যামেরা দিয়ে ট্রাফিক আইন লঙ্ঘন ক্যাপচার করুন এবং তাৎক্ষণিক রিপোর্ট জমা দিন',
      color: 'var(--color-light-blue-dark)',
      bgColor: 'var(--color-light-blue)'
    },
    {
      icon: Award,
      title_en: 'Earn Rewards',
      title_bn: 'পুরস্কার অর্জন করুন',
      desc_en: 'Get 20% commission on successful violation reports directly to your mobile wallet',
      desc_bn: 'সফল আইন লঙ্ঘন রিপোর্টে ২০% কমিশন সরাসরি আপনার মোবাইল ওয়ালেটে পান',
      color: 'var(--color-light-green-dark)',
      bgColor: 'var(--color-light-green)'
    },
    {
      icon: Shield,
      title_en: 'Anonymous Reporting',
      title_bn: 'বেনামি রিপোর্টিং',
      desc_en: 'Report social crimes anonymously with complete protection of your identity',
      desc_bn: 'আপনার পরিচয়ের সম্পূর্ণ সুরক্ষা সহ বেনামে সামাজিক অপরাধ রিপোর্ট করুন',
      color: 'var(--color-light-red-dark)',
      bgColor: 'var(--color-light-red)'
    },
    {
      icon: MapPin,
      title_en: 'GPS Tracking',
      title_bn: 'জিপিএস ট্র্যাকিং',
      desc_en: 'Automatic location capture ensures accurate violation reporting and quick response',
      desc_bn: 'স্বয়ংক্রিয় অবস্থান ক্যাপচার সঠিক আইন লঙ্ঘন রিপোর্টিং এবং দ্রুত প্রতিক্রিয়া নিশ্চিত করে',
      color: 'var(--color-light-ash-dark)',
      bgColor: 'var(--color-light-ash)'
    }
  ];

  const emergencyContacts = EMERGENCY_CONTACTS_FLAT.slice(0, 4);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="icon-primary w-10 h-10">
                <Eye className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-heading-1 font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-xs font-medium" style={{ color: 'var(--color-light-blue-dark)' }}>
                  {t('Report Traffic Violations • Earn Rewards • Save Lives', 'ট্রাফিক লঙ্ঘন রিপোর্ট • পুরস্কার অর্জন • জীবন বাঁচান')}
                </p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <Link to="/traffic-fines" className="nav-link">
                {t('Traffic Fines', 'ট্রাফিক জরিমানা')}
              </Link>
              <Link to="/vehicle-rules" className="nav-link">
                {t('Vehicle Rules', 'যানবাহন নিয়ম')}
              </Link>
              <Link to="/features" className="nav-link">
                {t('Features', 'বৈশিষ্ট্য')}
              </Link>
              
              <button
                onClick={toggleLanguage}
                className="nav-link flex items-center space-x-2"
              >
                <Globe className="w-4 h-4" />
                <span>{language === 'en' ? 'বাং' : 'ENG'}</span>
              </button>

              {user ? (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="btn-primary btn-small"
                >
                  {t('Dashboard', 'ড্যাশবোর্ড')}
                </button>
              ) : (
                <div className="flex items-center space-x-4">
                  <Link to="/signin" className="nav-link">
                    {t('Sign In', 'সাইন ইন')}
                  </Link>
                  <Link to="/signup" className="btn-primary btn-small">
                    {t('Get Started', 'শুরু করুন')}
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg hover:bg-ash transition-colors"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t" style={{ borderColor: 'var(--color-light-blue)' }}>
            <div className="px-4 py-6 space-y-4">
              <Link to="/traffic-fines" className="block nav-link">
                {t('Traffic Fines', 'ট্রাফিক জরিমানা')}
              </Link>
              <Link to="/vehicle-rules" className="block nav-link">
                {t('Vehicle Rules', 'যানবাহন নিয়ম')}
              </Link>
              <Link to="/features" className="block nav-link">
                {t('Features', 'বৈশিষ্ট্য')}
              </Link>
              
              <button
                onClick={toggleLanguage}
                className="flex items-center space-x-2 nav-link"
              >
                <Globe className="w-4 h-4" />
                <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
              </button>

              {user ? (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="btn-primary w-full"
                >
                  {t('Dashboard', 'ড্যাশবোর্ড')}
                </button>
              ) : (
                <div className="space-y-3">
                  <Link to="/signin" className="btn-secondary w-full text-center block">
                    {t('Sign In', 'সাইন ইন')}
                  </Link>
                  <Link to="/signup" className="btn-primary w-full text-center block">
                    {t('Get Started', 'শুরু করুন')}
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white">
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-black mb-6 leading-tight">
              {t('Are You Ready to Make a Difference?', 'আপনি কি পরিবর্তন আনতে প্রস্তুত?')}
            </h1>
            
            <div className="max-w-4xl mx-auto text-black space-y-3 mb-8">
              <p className="text-xl sm:text-2xl font-semibold text-black">
                {t('Your Report Can Save Lives', 'আপনার রিপোর্ট জীবন বাঁচাতে পারে')}
              </p>
              
              <p className="text-lg sm:text-xl text-black leading-relaxed">
                {t('Every traffic violation you witness—wrong-side driving, footpath riding, illegal horns, or mobile use while driving—can be reported to prevent accidents.',
                   'আপনি যে ট্রাফিক আইন লঙ্ঘন দেখেন—ভুল দিকে গাড়ি চালানো, ফুটপাতে গাড়ি চালানো, অবৈধ হর্ন, বা গাড়ি চালানোর সময় মোবাইল ব্যবহার—দুর্ঘটনা প্রতিরোধের জন্য রিপোর্ট করা যেতে পারে।')}
              </p>
              
              <p className="text-lg sm:text-xl text-black leading-relaxed">
                {t('Whether it\'s speeding, helmetless riders, or illegal parking, your report ensures everyone\'s safety. Don\'t just be a bystander—become a guardian of your community.',
                   'এটি দ্রুত গতি, হেলমেটবিহীন রাইডার, বা অবৈধ পার্কিং যাই হোক না কেন, আপনার রিপোর্ট সবার নিরাপত্তা নিশ্চিত করে। শুধু একজন দর্শক হয়ে থাকবেন না—আপনার সম্প্রদায়ের একজন অভিভাবক হয়ে উঠুন।')}
              </p>
              
              <p className="text-xl sm:text-2xl font-semibold text-black">
                {t('Your Voice Matters', 'আপনার কণ্ঠস্বর গুরুত্বপূর্ণ')}
              </p>
              
              <p className="text-lg sm:text-xl text-black leading-relaxed">
                {t('Report a traffic violation today.',
                   'আজই একটি ট্রাফিক আইন লঙ্ঘন রিপোর্ট করুন।')}
              </p>
              
              <p className="text-lg sm:text-xl text-black leading-relaxed">
                {t('Help create safer, rule-respecting streets where every life is valued.',
                   'নিরাপদ, নিয়ম-সম্মানকারী রাস্তা তৈরি করতে সাহায্য করুন যেখানে প্রতিটি জীবনকে মূল্য দেওয়া হয়।')}
              </p>
            </div>
            
            <div className="mt-8">
              <Link to="/report" className="btn-primary btn-large inline-flex items-center shadow-xl hover:shadow-2xl transform hover:scale-105">
                <Camera className="w-6 h-6 mr-3" />
                {t('Report for Safer Roads', 'নিরাপদ রাস্তার জন্য রিপোর্ট করুন')}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Social Crimes Section */}
      <section className="relative overflow-hidden bg-white">
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-black mb-6 leading-tight">
              {t('Stand Against Social Crimes', 'সামাজিক অপরাধের বিরুদ্ধে দাঁড়ান')}
            </h1>
            
            <div className="max-w-4xl mx-auto text-black space-y-2 mb-8">
              <p className="text-xl sm:text-2xl font-semibold text-black">
                {t('Your Courage Saves Lives.', 'আপনার সাহস জীবন বাঁচায়।')}
              </p>
              
              <p className="text-base sm:text-lg text-black leading-snug whitespace-nowrap overflow-x-auto">
                {t('Break the silence against injustice. Report violence, theft, corruption, harassment, or criminal activities anonymously.',
                   'অন্যায়ের বিরুদ্ধে নীরবতা ভাঙুন। সহিংসতা, চুরি, দুর্নীতি, হয়রানি বা অপরাধমূলক কার্যকলাপ বেনামে রিপোর্ট করুন।')}
              </p>
              <p className="text-base sm:text-lg text-black leading-snug">
                {t('Your report shields the vulnerable and fights for justice.',
                   'আপনার রিপোর্ট দুর্বলদের রক্ষা করে এবং ন্যায়বিচারের জন্য লড়ে।')}
              </p>
              <p className="text-base sm:text-lg text-black leading-snug font-semibold">
                {t('Every unreported crime denies justice. Be the guardian your society needs.',
                   'প্রতিটি অপ্রকাশিত অপরাধ ন্যায়বিচারকে অস্বীকার করে। আপনার সমাজের প্রয়োজনীয় অভিভাবক হয়ে উঠুন।')}
              </p>
              <p className="text-xl sm:text-2xl font-semibold text-black">
                {t('Your Identity Protected. Your Impact Eternal.', 'আপনার পরিচয় সুরক্ষিত। আপনার প্রভাব চিরস্থায়ী।')}
              </p>
              <p className="text-base sm:text-lg text-black leading-snug">
                {t('Build a fearless Bangladesh where safety is everyone\'s right.',
                   'একটি নির্ভীক বাংলাদেশ গড়ুন যেখানে নিরাপত্তা সবার অধিকার।')}
              </p>
              <p className="text-xl sm:text-2xl font-semibold text-black">
                {t('Don\'t Stay Silent—Act Today.', 'নীরব থাকবেন না—আজই কাজ করুন।')}
              </p>
            </div>
            
            <div className="mt-8">
              <Link to="/social-crime" className="btn-danger btn-large inline-flex items-center shadow-xl hover:shadow-2xl transform hover:scale-105">
                <Shield className="w-6 h-6 mr-3" />
                {t('Report Social Crime Anonymously', 'বেনামে সামাজিক অপরাধ রিপোর্ট করুন')}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 p-4 rounded-2xl flex items-center justify-center" style={{ backgroundColor: stat.color }}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl lg:text-4xl font-bold mb-2" style={{ color: stat.color }}>
                    {stat.number}
                  </div>
                  <p className="text-body font-medium" style={{ color: 'var(--text-secondary)' }}>
                    {language === 'en' ? stat.label_en : stat.label_bn}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-ash">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-display-1 font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              {t('How Third Eye Works', 'তৃতীয় চোখ কিভাবে কাজ করে')}
            </h2>
            <p className="text-body-large max-w-3xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
              {t('Simple, secure, and rewarding way to make Bangladesh roads safer for everyone', 
                 'সবার জন্য বাংলাদেশের রাস্তা নিরাপদ করার সহজ, নিরাপদ এবং পুরস্কারপ্রাপ্ত উপায়')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="card-base p-8 text-center hover:scale-105 transition-all duration-300">
                  <div className="w-20 h-20 mx-auto mb-6 p-5 rounded-2xl flex items-center justify-center" style={{ backgroundColor: feature.bgColor }}>
                    <Icon className="w-10 h-10" style={{ color: feature.color }} />
                  </div>
                  <h3 className="text-heading-1 font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                    {language === 'en' ? feature.title_en : feature.title_bn}
                  </h3>
                  <p className="text-body leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                    {language === 'en' ? feature.desc_en : feature.desc_bn}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Emergency Contacts Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-display-2 font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              🚨 {t('URGENT EMERGENCY CONTACT', 'জরুরি জরুরি যোগাযোগ')}
            </h2>
            <p className="text-body-large" style={{ color: 'var(--text-secondary)' }}>
              {t('Complete nationwide emergency directory for Bangladesh', 'বাংলাদেশের সম্পূর্ণ জাতীয় জরুরি ডিরেক্টরি')}
            </p>
          </div>

          {/* Quick Access Emergency Contacts */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="card-base p-6 text-center hover:shadow-lg transition-all">
                <div className="text-4xl mb-4">{contact.icon}</div>
                <h3 className="text-heading-2 font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                  {language === 'en' ? contact.name_en : contact.name_bn}
                </h3>
                <p className="text-body mb-4" style={{ color: 'var(--text-secondary)' }}>
                  {language === 'en' ? contact.description_en : contact.description_bn}
                </p>
                <a
                  href={`tel:${contact.number}`}
                  className="btn-danger w-full flex items-center justify-center"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  {contact.number}
                </a>
              </div>
            ))}
          </div>

          {/* Complete Emergency Directory Button */}
          <div className="text-center">
            <Link
              to="/emergency-directory"
              className="btn-danger btn-large inline-flex items-center shadow-xl hover:shadow-2xl transform hover:scale-105"
            >
              <span className="text-2xl mr-3">📞</span>
              {t('Complete Emergency Directory', 'সম্পূর্ণ জরুরি ডিরেক্টরি')}
            </Link>
            <p className="text-sm mt-4" style={{ color: 'var(--text-secondary)' }}>
              {t('Access all Bangladesh emergency contacts - No registration required', 'সমস্ত বাংলাদেশ জরুরি যোগাযোগ অ্যাক্সেস করুন - কোনো নিবন্ধন প্রয়োজন নেই')}
            </p>
          </div>
        </div>
      </section>

      

      {/* Footer */}
      <footer className="bg-ash py-12 border-t" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="icon-primary w-10 h-10">
                  <Eye className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-heading-1 font-bold" style={{ color: 'var(--text-primary)' }}>
                    {t('Third Eye', 'তৃতীয় চোখ')}
                  </h3>
                </div>
              </div>
              <p className="text-body mb-6" style={{ color: 'var(--text-secondary)' }}>
                {t('Making Bangladesh roads safer through community reporting and citizen engagement', 
                   'কমিউনিটি রিপোর্টিং এবং নাগরিক সম্পৃক্ততার মাধ্যমে বাংলাদেশের রাস্তা নিরাপদ করা')}
              </p>
            </div>

            <div>
              <h4 className="text-heading-2 font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                {t('Quick Links', 'দ্রুত লিংক')}
              </h4>
              <div className="space-y-3">
                <Link to="/traffic-fines" className="block text-body hover:underline" style={{ color: 'var(--text-secondary)' }}>
                  {t('Traffic Fines', 'ট্রাফিক জরিমানা')}
                </Link>
                <Link to="/vehicle-rules" className="block text-body hover:underline" style={{ color: 'var(--text-secondary)' }}>
                  {t('Vehicle Rules', 'যানবাহন নিয়ম')}
                </Link>
                <Link to="/features" className="block text-body hover:underline" style={{ color: 'var(--text-secondary)' }}>
                  {t('Features', 'বৈশিষ্ট্য')}
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-heading-2 font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                {t('Support', 'সাহায্য')}
              </h4>
              <div className="space-y-3">
                <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
                  {t('Emergency: 999', 'জরুরি: ৯৯৯')}
                </p>
                <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
                  {t('Police: 01713-090411', 'পুলিশ: ০১৭১৩-০৯০৪১১')}
                </p>
              </div>
            </div>
          </div>

          <div className="border-t pt-8 mt-8 text-center" style={{ borderColor: 'var(--color-light-blue)' }}>
            <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
              © 2024 Third Eye Bangladesh. {t('All rights reserved.', 'সকল অধিকার সংরক্ষিত।')}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
