import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate } from 'react-router';
import { useApi } from '@/react-app/hooks/useApi';
import { 
  Shield, 
  MapPin, 
  Upload, 
  CheckCircle,
  X,
  AlertTriangle,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';
import { SOCIAL_CRIME_CATEGORIES, generateCaseNumber } from '@/shared/constants';

export default function SocialCrime() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const submitReportApi = useApi();

  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationName, setLocationName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedCaseNumber, setSubmittedCaseNumber] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);

  const [formData, setFormData] = useState({
    crime_category: '',
    location_description: '',
    description: '',
    urgency_level: 'medium',
    witness_available: false,
  });

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude });
          reverseGeocode(latitude, longitude);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  };

  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      // Mock location name for demo
      setLocationName(`Dhaka, Bangladesh (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
    } catch (error) {
      console.error('Reverse geocoding failed:', error);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(prev => [...prev, ...files].slice(0, 5)); // Max 5 files
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.crime_category || !formData.description) {
      alert(t('Please fill in required fields', 'প্রয়োজনীয় ক্ষেত্রগুলি পূরণ করুন'));
      return;
    }

    try {
      // Mock file upload - in production, upload to R2/S3
      const evidence_urls = selectedFiles.map((_, index) => 
        `https://thirdeye-storage.com/social-crime/${Date.now()}-${index}.jpg`
      );

      const caseNumber = generateCaseNumber();

      const reportData = {
        case_number: caseNumber,
        report_type: 'social_crime',
        crime_category: formData.crime_category,
        latitude: location?.lat,
        longitude: location?.lng,
        location_description: formData.location_description || locationName,
        description: formData.description,
        urgency_level: formData.urgency_level,
        is_anonymous: isAnonymous,
        witness_available: formData.witness_available,
        evidence_urls,
      };

      await submitReportApi.execute('/api/social-crime', {
        method: 'POST',
        body: reportData,
      });

      setSubmittedCaseNumber(caseNumber);
      setIsSubmitted(true);
    } catch (error) {
      console.error('Failed to submit report:', error);
      alert(t('Failed to submit report. Please try again.', 'রিপোর্ট জমা দিতে ব্যর্থ। আবার চেষ্টা করুন।'));
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-success flex items-center justify-center px-6">
        <div className="max-w-md w-full card-base p-8 text-center">
          <div className="icon-success w-20 h-20 mx-auto mb-6">
            <CheckCircle className="w-12 h-12" />
          </div>
          
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
            {t('Report Submitted Successfully!', 'রিপোর্ট সফলভাবে জমা দেওয়া হয়েছে!')}
          </h2>
          
          <div className="bg-success border rounded-xl p-4 mb-6" style={{ borderColor: 'var(--color-light-green-dark)' }}>
            <p className="text-sm mb-2" style={{ color: 'var(--color-light-green-dark)' }}>
              {t('Anonymous Report ID', 'বেনামি রিপোর্ট আইডি')}:
            </p>
            <p className="text-xl font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
              {submittedCaseNumber}
            </p>
          </div>
          
          <div className="bg-primary border rounded-xl p-4 mb-8" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-primary-blue-dark)' }} />
              <div className="text-left">
                <h4 className="font-semibold mb-1" style={{ color: 'var(--color-primary-blue-dark)' }}>
                  {t('Your Safety is Protected', 'আপনার নিরাপত্তা সুরক্ষিত')}
                </h4>
                <p className="text-sm" style={{ color: 'var(--color-primary-blue-dark)' }}>
                  {t('This report is anonymous and your identity is completely protected. Authorities will investigate discretely.', 
                     'এই রিপোর্টটি বেনামি এবং আপনার পরিচয় সম্পূর্ণ সুরক্ষিত। কর্তৃপক্ষ বিচক্ষণতার সাথে তদন্ত করবে।')}
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="btn-primary w-full"
            >
              {t('Back to Dashboard', 'ড্যাশবোর্ডে ফিরে যান')}
            </button>
            <button
              onClick={() => {
                setIsSubmitted(false);
                setFormData({
                  crime_category: '',
                  location_description: '',
                  description: '',
                  urgency_level: 'medium',
                  witness_available: false,
                });
                setSelectedFiles([]);
              }}
              className="btn-secondary w-full"
            >
              {t('Report Another Crime', 'আরেকটি অপরাধ রিপোর্ট করুন')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-light-blue-dark)' }}>
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <BackButton 
              to="/dashboard"
              className="p-2 hover:bg-ash rounded-lg transition-all"
            />
            <div className="flex-1">
              <div className="flex items-center space-x-3">
                <div className="icon-danger w-10 h-10">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Report Social Crime', 'সামাজিক অপরাধ রিপোর্ট করুন')}
                  </h1>
                  <p className="text-sm text-gray-600">
                    {t('Anonymous & Secure Reporting', 'বেনামি ও নিরাপদ রিপোর্টিং')}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Privacy Toggle */}
            <button
              onClick={() => setIsAnonymous(!isAnonymous)}
              className={`
                flex items-center space-x-2 px-4 py-2 rounded-xl transition-all
                ${isAnonymous ? 'bg-success' : 'bg-danger'}
              `}
              style={{
                color: isAnonymous ? 'var(--color-light-green-dark)' : 'var(--color-light-red-dark)'
              }}
            >
              {isAnonymous ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span className="text-sm font-semibold">
                {isAnonymous ? t('Anonymous', 'বেনামি') : t('Identified', 'পরিচয়সহ')}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Privacy Notice */}
        <div className="bg-primary border rounded-2xl p-6 mb-8" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
          <div className="flex items-start space-x-4">
            <div className="icon-primary w-12 h-12">
              <Lock className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-primary-blue-dark)' }}>
                {t('100% Anonymous & Secure', '১০০% বেনামি এবং নিরাপদ')}
              </h3>
              <p className="leading-relaxed" style={{ color: 'var(--color-primary-blue-dark)' }}>
                {t('Your identity is completely protected. This platform uses advanced encryption to ensure your safety while helping authorities address social crimes. Reports are investigated discretely without revealing the source.', 
                   'আপনার পরিচয় সম্পূর্ণ সুরক্ষিত। এই প্ল্যাটফর্মটি আপনার নিরাপত্তা নিশ্চিত করতে উন্নত এনক্রিপশন ব্যবহার করে যখন কর্তৃপক্ষকে সামাজিক অপরাধের সমাধানে সহায়তা করে। রিপোর্টগুলি উৎস প্রকাশ না করে বিচক্ষণভাবে তদন্ত করা হয়।')}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Crime Category */}
          <div className="card-base p-8">
            <h3 className="text-2xl font-bold mb-6 flex items-center" style={{ color: 'var(--color-light-ash-dark)' }}>
              <div className="icon-danger w-10 h-10 mr-3">
                <AlertTriangle className="w-6 h-6" />
              </div>
              {t('What type of crime are you reporting?', 'আপনি কি ধরনের অপরাধ রিপোর্ট করছেন?')}
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {SOCIAL_CRIME_CATEGORIES.map((category) => (
                <label
                  key={category.id}
                  className={`
                    p-4 border-2 rounded-2xl cursor-pointer transition-all duration-200 hover:shadow-lg
                    ${formData.crime_category === category.id 
                      ? 'shadow-md transform scale-105' 
                      : 'bg-white hover:bg-ash'}
                  `}
                  style={{
                    borderColor: formData.crime_category === category.id ? 'var(--color-light-red-dark)' : 'var(--color-primary-blue)',
                    backgroundColor: formData.crime_category === category.id ? 'var(--color-light-red)' : undefined
                  }}
                >
                  <input
                    type="radio"
                    name="crime_category"
                    value={category.id}
                    checked={formData.crime_category === category.id}
                    onChange={(e) => setFormData({ ...formData, crime_category: e.target.value })}
                    className="sr-only"
                  />
                  
                  <div className="text-center">
                    <div className={`
                      w-16 h-16 mx-auto mb-3 rounded-2xl flex items-center justify-center transition-colors
                      ${formData.crime_category === category.id 
                        ? '' 
                        : 'bg-ash'}
                    `} style={{
                      backgroundColor: formData.crime_category === category.id ? 'var(--color-light-red-dark)' : undefined,
                      color: formData.crime_category === category.id ? 'white' : 'var(--color-light-ash-dark)'
                    }}>
                      <span className="text-3xl">{category.icon}</span>
                    </div>
                    <h4 className={`font-bold text-sm transition-colors ${
                      formData.crime_category === category.id ? '' : ''
                    }`} style={{
                      color: formData.crime_category === category.id ? 'var(--color-light-red-dark)' : 'var(--color-light-ash-dark)'
                    }}>
                      {t(category.name_en, category.name_bn)}
                    </h4>
                  </div>

                  {formData.crime_category === category.id && (
                    <div className="absolute top-2 right-2">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--color-light-red-dark)' }}>
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* Details & Location */}
          <div className="card-base p-8">
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Crime Details', 'অপরাধের বিবরণ')}
            </h3>
            
            <div className="space-y-6">
              {/* Description */}
              <div>
                <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Describe what you witnessed', 'আপনি যা দেখেছেন তা বর্ণনা করুন')} *
                </label>
                <textarea
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="input-base"
                  rows={6}
                  placeholder={t('Provide as much detail as possible: what happened, when, who was involved, any suspicious behavior, etc. Your detailed description helps authorities take appropriate action.', 
                               'যতটা সম্ভব বিস্তারিত প্রদান করুন: কি হয়েছিল, কখন, কে জড়িত ছিল, কোন সন্দেহজনক আচরণ ইত্যাদি। আপনার বিস্তারিত বর্ণনা কর্তৃপক্ষকে যথাযথ পদক্ষেপ নিতে সাহায্য করে।')}
                />
              </div>

              {/* Urgency Level */}
              <div>
                <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Urgency Level', 'জরুরি মাত্রা')}
                </label>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { value: 'low', label: t('Low', 'কম'), bgColor: 'bg-success', textColor: 'var(--color-light-green-dark)', borderColor: 'var(--color-light-green-dark)' },
                    { value: 'medium', label: t('Medium', 'মাঝারি'), bgColor: 'bg-ash', textColor: 'var(--color-light-ash-dark)', borderColor: 'var(--color-light-ash-dark)' },
                    { value: 'high', label: t('High', 'উচ্চ'), bgColor: 'bg-danger', textColor: 'var(--color-light-red-dark)', borderColor: 'var(--color-light-red-dark)' }
                  ].map((urgency) => (
                    <label
                      key={urgency.value}
                      className={`
                        p-4 border-2 rounded-xl cursor-pointer transition-all text-center
                        ${formData.urgency_level === urgency.value 
                          ? urgency.bgColor + ' shadow-md' 
                          : 'bg-white border-gray-200 hover:bg-ash'}
                      `}
                      style={{
                        borderColor: formData.urgency_level === urgency.value ? urgency.borderColor : 'var(--color-primary-blue)',
                        color: formData.urgency_level === urgency.value ? urgency.textColor : 'var(--color-light-ash-dark)'
                      }}
                    >
                      <input
                        type="radio"
                        name="urgency_level"
                        value={urgency.value}
                        checked={formData.urgency_level === urgency.value}
                        onChange={(e) => setFormData({ ...formData, urgency_level: e.target.value })}
                        className="sr-only"
                      />
                      <div className="font-semibold">{urgency.label}</div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div>
                <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Crime Location', 'অপরাধের স্থান')}
                </label>
                <div className="bg-primary border rounded-xl p-4 mb-4" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-6 h-6" style={{ color: 'var(--color-primary-blue-dark)' }} />
                    <div>
                      <p className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>{t('Auto-detected', 'স্বয়ংক্রিয়')}</p>
                      <p className="text-sm text-gray-600">
                        {locationName || t('Getting location...', 'অবস্থান পাওয়া হচ্ছে...')}
                      </p>
                    </div>
                  </div>
                </div>

                <input
                  type="text"
                  value={formData.location_description}
                  onChange={(e) => setFormData({ ...formData, location_description: e.target.value })}
                  className="input-base"
                  placeholder={t('Additional location details (building name, landmarks, specific area)', 'অতিরিক্ত অবস্থানের বিবরণ (ভবনের নাম, ল্যান্ডমার্ক, নির্দিষ্ট এলাকা)')}
                />
              </div>

              {/* Witness Availability */}
              <div>
                <label className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={formData.witness_available}
                    onChange={(e) => setFormData({ ...formData, witness_available: e.target.checked })}
                    className="w-5 h-5 rounded border-gray-300 focus:ring-2"
                    style={{ 
                      accentColor: 'var(--color-primary-blue-dark)'
                    }}
                  />
                  <span className="text-lg font-medium" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Witnesses available (anonymous contact possible)', 'সাক্ষী উপলব্ধ (বেনামি যোগাযোগ সম্ভব)')}
                  </span>
                </label>
              </div>
            </div>
          </div>

          {/* Evidence Upload */}
          <div className="card-base p-8">
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Evidence (Optional)', 'প্রমাণ (ঐচ্ছিক)')}
            </h3>
            
            <div className="border-2 border-dashed rounded-2xl p-8 text-center hover:bg-ash transition-all" style={{ borderColor: 'var(--color-primary-blue)' }}>
              <div className="icon-secondary w-16 h-16 mx-auto mb-4">
                <Upload className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-semibold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Upload Evidence (if safe to do so)', 'প্রমাণ আপলোড করুন (নিরাপদ হলে)')}
              </h4>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                {t('Only upload if you can do so safely. All files are encrypted and your identity remains protected.', 
                   'কেবল নিরাপদে করতে পারলেই আপলোড করুন। সব ফাইল এনক্রিপ্ট করা হয় এবং আপনার পরিচয় সুরক্ষিত থাকে।')}
              </p>
              
              <label className="btn-primary inline-flex items-center cursor-pointer">
                <Upload className="w-5 h-5 mr-2" />
                {t('Select Files', 'ফাইল নির্বাচন করুন')}
                <input
                  type="file"
                  multiple
                  accept="image/*,video/*,audio/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </label>
            </div>

            {/* Selected Files */}
            {selectedFiles.length > 0 && (
              <div className="mt-6">
                <h5 className="font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Selected Evidence', 'নির্বাচিত প্রমাণ')} ({selectedFiles.length}/5)
                </h5>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="relative bg-ash rounded-xl p-4 border" style={{ borderColor: 'var(--color-primary-blue)' }}>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="absolute -top-2 -right-2 text-white rounded-full p-1 hover:scale-110 transition-all"
                        style={{ backgroundColor: 'var(--color-light-red-dark)' }}
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <div className="text-center">
                        <span className="text-2xl mb-2 block">
                          {file.type.startsWith('image/') ? '📷' : file.type.startsWith('video/') ? '🎥' : '🎵'}
                        </span>
                        <p className="text-sm truncate" style={{ color: 'var(--color-light-ash-dark)' }}>{file.name}</p>
                        <p className="text-xs text-gray-500">{(file.size / 1024 / 1024).toFixed(1)} MB</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => navigate('/dashboard')}
              className="btn-secondary flex-1"
            >
              {t('Cancel', 'বাতিল')}
            </button>
            <button
              type="submit"
              disabled={submitReportApi.loading || !formData.crime_category || !formData.description}
              className="btn-danger flex-1 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02] shadow-lg"
            >
              {submitReportApi.loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2 inline-block"></div>
                  {t('Submitting Anonymously...', 'বেনামে জমা দেওয়া হচ্ছে...')}
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 mr-2 inline-block" />
                  {t('Submit Anonymous Report', 'বেনামি রিপোর্ট জমা দিন')}
                </>
              )}
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
