import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useApi } from '@/react-app/hooks/useApi';
import { 
  Camera, 
  Shield, 
  Award, 
  FileText, 
  Eye,
  Bell,
  User,
  Settings,
  LogOut,
  AlertTriangle,
  CheckCircle,
  Clock,
  Car
} from 'lucide-react';
import LoadingSpinner from '@/react-app/components/LoadingSpinner';
// import QuickCameraButton from '@/react-app/components/QuickCameraButton';
import HierarchicalEmergencyContacts from '@/react-app/components/HierarchicalEmergencyContacts';
import SafetyTipsCard from '@/react-app/components/SafetyTipsCard';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  const [userStats, setUserStats] = useState<any>(null);
  const [recentCases, setRecentCases] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  
  const statsApi = useApi();
  const casesApi = useApi();
  const notificationsApi = useApi();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch user stats
      const stats = await statsApi.execute('/api/dashboard/stats');
      setUserStats(stats);

      // Fetch recent cases
      const cases = await casesApi.execute('/api/cases?limit=5');
      setRecentCases(cases);

      // Fetch notifications
      const notifs = await notificationsApi.execute('/api/notifications?limit=5');
      setNotifications(notifs);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Sign out failed:', error);
    }
  };

  const quickActions = [
    {
      title: t('Report Violation', 'আইন লঙ্ঘন রিপোর্ট'),
      subtitle: t('Traffic violations', 'ট্রাফিক লঙ্ঘন'),
      icon: Camera,
      path: '/report',
      color: 'icon-primary',
      bgColor: 'bg-primary'
    },
    {
      title: t('Social Crime', 'সামাজিক অপরাধ'),
      subtitle: t('Anonymous reporting', 'বেনামি রিপোর্টিং'),
      icon: Shield,
      path: '/social-crime',
      color: 'icon-danger',
      bgColor: 'bg-danger'
    },
    {
      title: t('My Cases', 'আমার কেসগুলি'),
      subtitle: t('Track progress', 'অগ্রগতি ট্র্যাক করুন'),
      icon: FileText,
      path: '/cases',
      color: 'icon-success',
      bgColor: 'bg-success'
    },
    {
      title: t('Emergency', 'জরুরি'),
      subtitle: t('Quick contacts', 'দ্রুত যোগাযোগ'),
      icon: AlertTriangle,
      path: '/emergency',
      color: 'icon-warning',
      bgColor: 'bg-danger'
    }
  ];

  const mockStats = {
    total_reports: 24,
    approved_reports: 18,
    pending_reports: 4,
    rejected_reports: 2,
    total_rewards: 5400,
    this_month_rewards: 1200,
    approval_rate: 75
  };

  const stats = userStats || mockStats;

  // Ensure all stats values are properly defined with fallbacks
  const safeStats = {
    total_reports: stats?.total_reports || 0,
    approved_reports: stats?.approved_reports || 0,
    pending_reports: stats?.pending_reports || 0,
    rejected_reports: stats?.rejected_reports || 0,
    total_rewards: stats?.total_rewards || 0,
    this_month_rewards: stats?.this_month_rewards || 0,
    approval_rate: stats?.approval_rate || 0
  };

  if (!user) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="icon-primary w-10 h-10">
                <Eye className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                  {t('Dashboard', 'ড্যাশবোর্ড')}
                </p>
              </div>
            </div>

            {/* Header Actions */}
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <button className="relative p-2 rounded-lg hover:bg-ash transition-colors">
                <Bell className="w-6 h-6" style={{ color: 'var(--color-light-ash-dark)' }} />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full text-xs font-bold text-white flex items-center justify-center" style={{ backgroundColor: 'var(--color-light-red-dark)' }}>
                    {notifications.length}
                  </span>
                )}
              </button>

              {/* Settings Button - Prominent */}
              <Link
                to="/settings"
                className="btn-primary flex items-center space-x-2"
              >
                <Settings className="w-5 h-5" />
                <span className="hidden md:inline">{t('Settings', 'সেটিংস')}</span>
              </Link>

              {/* Profile Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center space-x-2 p-2 rounded-lg hover:bg-ash transition-colors"
                >
                  <div className="icon-secondary w-8 h-8">
                    <User className="w-5 h-5" />
                  </div>
                  <span className="font-medium" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {user.email?.split('@')[0] || 'User'}
                  </span>
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-48 card-base py-2 z-50">
                    <Link
                      to="/profile"
                      className="flex items-center px-4 py-2 text-sm hover:bg-ash transition-colors"
                      style={{ color: 'var(--color-light-ash-dark)' }}
                    >
                      <User className="w-4 h-4 mr-3" />
                      {t('Profile', 'প্রোফাইল')}
                    </Link>
                    <Link
                      to="/settings"
                      className="flex items-center px-4 py-2 text-sm hover:bg-ash transition-colors"
                      style={{ color: 'var(--color-light-ash-dark)' }}
                    >
                      <Settings className="w-4 h-4 mr-3" />
                      {t('Settings', 'সেটিংস')}
                    </Link>
                    <hr className="my-2" style={{ borderColor: 'var(--color-primary-blue)' }} />
                    <button
                      onClick={handleSignOut}
                      className="flex items-center w-full px-4 py-2 text-sm hover:bg-danger transition-colors"
                      style={{ color: 'var(--color-light-red-dark)' }}
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      {t('Sign Out', 'সাইন আউট')}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
            {t('Welcome back!', 'স্বাগতম!')}
          </h2>
          <p className="text-gray-600">
            {t('Here\'s what\'s happening with your reports', 'আপনার রিপোর্টের সাথে এখানে কী ঘটছে')}
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link
                key={index}
                to={action.path}
                className="card-interactive p-6 text-center hover:scale-105 transition-all duration-200"
              >
                <div className={`${action.color} w-14 h-14 mx-auto mb-4`}>
                  <Icon className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-base mb-1" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {action.title}
                </h3>
                <p className="text-sm text-gray-600">{action.subtitle}</p>
              </Link>
            );
          })}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="icon-primary w-12 h-12">
                <FileText className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold" style={{ color: 'var(--color-primary-blue-dark)' }}>
                {safeStats.total_reports}
              </span>
            </div>
            <h3 className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Total Reports', 'মোট রিপোর্ট')}
            </h3>
            <p className="text-sm text-gray-600">
              {t('All time', 'সব সময়')}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="icon-success w-12 h-12">
                <CheckCircle className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                {safeStats.approved_reports}
              </span>
            </div>
            <h3 className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Approved', 'অনুমোদিত')}
            </h3>
            <p className="text-sm text-gray-600">
              {safeStats.approval_rate}% {t('success rate', 'সফলতার হার')}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="icon-warning w-12 h-12">
                <Clock className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold" style={{ color: 'var(--color-light-red-dark)' }}>
                {safeStats.pending_reports}
              </span>
            </div>
            <h3 className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Pending', 'অপেক্ষমাণ')}
            </h3>
            <p className="text-sm text-gray-600">
              {t('Under review', 'পর্যালোচনাধীন')}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="icon-success w-12 h-12">
                <Award className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                ৳{safeStats.total_rewards.toLocaleString()}
              </span>
            </div>
            <h3 className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('Total Earned', 'মোট আয়')}
            </h3>
            <p className="text-sm" style={{ color: 'var(--color-light-green-dark)' }}>
              +৳{safeStats.this_month_rewards.toLocaleString()} {t('this month', 'এই মাসে')}
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Cases */}
          <div className="lg:col-span-2">
            <div className="card-base p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Recent Cases', 'সাম্প্রতিক কেসগুলি')}
                </h3>
                <Link 
                  to="/cases" 
                  className="text-sm font-medium hover:underline"
                  style={{ color: 'var(--color-primary-blue-dark)' }}
                >
                  {t('View all', 'সব দেখুন')}
                </Link>
              </div>

              <div className="space-y-4">
                {recentCases.length > 0 ? recentCases.map((case_item, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:bg-ash transition-colors" style={{ borderColor: 'var(--color-primary-blue)' }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-sm" style={{ color: 'var(--color-primary-blue-dark)' }}>
                        {case_item.case_number}
                      </span>
                      <span className={`badge-base ${
                        case_item.status === 'approved' ? 'badge-success' :
                        case_item.status === 'pending' ? 'badge-warning' :
                        case_item.status === 'rejected' ? 'badge-danger' : 'badge-info'
                      }`}>
                        {t(case_item.status, case_item.status)}
                      </span>
                    </div>
                    <p className="font-medium mb-1" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {case_item.vehicle_number}
                    </p>
                    <p className="text-sm text-gray-600">{case_item.location_description}</p>
                  </div>
                )) : (
                  <div className="text-center py-8">
                    <Car className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-light-ash-dark)' }} />
                    <p className="text-gray-600 mb-4">
                      {t('No cases yet', 'এখনও কোনো কেস নেই')}
                    </p>
                    <Link to="/report" className="btn-primary">
                      {t('Report First Violation', 'প্রথম লঙ্ঘন রিপোর্ট করুন')}
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Emergency Contacts */}
            <HierarchicalEmergencyContacts />
            
            {/* Safety Tips */}
            <SafetyTipsCard />
            
            {/* Quick Stats */}
            <div className="card-base p-6">
              <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Quick Stats', 'দ্রুত পরিসংখ্যান')}
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    {t('Success Rate', 'সফলতার হার')}
                  </span>
                  <span className="font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                    {safeStats.approval_rate}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    {t('This Month', 'এই মাসে')}
                  </span>
                  <span className="font-bold" style={{ color: 'var(--color-primary-blue-dark)' }}>
                    {Math.floor(safeStats.total_reports / 3)} {t('reports', 'রিপোর্ট')}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    {t('Avg. Response', 'গড় প্রতিক্রিয়া')}
                  </span>
                  <span className="font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                    2-3 {t('days', 'দিন')}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Quick Camera Button */}
      {/* <QuickCameraButton /> */}
    </div>
  );
}
