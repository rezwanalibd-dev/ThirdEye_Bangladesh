import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { ArrowLeft, ArrowRight, Eye } from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

interface VehicleDetails {
  registration_en: string[];
  registration_bn: string[];
  licensing_en: string[];
  licensing_bn: string[];
  safety_en: string[];
  safety_bn: string[];
}

interface VehicleType {
  id: string;
  icon: string;
  title_en: string;
  title_bn: string;
  subtitle_en: string;
  subtitle_bn: string;
  details: VehicleDetails;
}

const VEHICLE_TYPES: VehicleType[] = [
  {
    id: 'motorbike',
    icon: '🏍️',
    title_en: 'Motorbike',
    title_bn: '🏍️মোটরবাইক',
    subtitle_en: 'Motorcycles & Scooters - Helmet mandatory, max 2 persons',
    subtitle_bn: 'মোটরসাইকেল এবং স্কুটার - হেলমেট বাধ্যতামূলক, সর্বোচ্চ ২ জন',
    details: {
      registration_en: [
        'Process: Apply at BRTA office with invoice, chassis/engine numbers',
        'Fees: BDT 2,000-5,000 (new), BDT 1,000 (transfer)',
        'Digital plate with RFID is issued',
        'Validity: Lifetime for private use'
      ],
      registration_bn: [
        'প্রক্রিয়া: চালান, চ্যাসিস/ইঞ্জিন নম্বর সহ বিআরটিএ অফিসে আবেদন করুন',
        'ফি: নতুনের জন্য ২,০০০-৫,০০০ টাকা, স্থানান্তরের জন্য ১,০০০ টাকা',
        'আরএফআইডি সহ ডিজিটাল প্লেট জারি করা হয়',
        'বৈধতা: ব্যক্তিগত ব্যবহারের জন্য আজীবন'
      ],
      licensing_en: [
        'Minimum age: 18 years',
        'Education: Class 8 minimum',
        'Written test: 20 questions, must pass 12',
        'Practical driving test required',
        'Renewal: Every 5 years (BDT 500-1,000)'
      ],
      licensing_bn: [
        'ন্যূনতম বয়স: ১৮ বছর',
        'শিক্ষা: ন্যূনতম অষ্টম শ্রেণী',
        'লিখিত পরীক্ষা: ২০টি প্রশ্ন, ১২টি সঠিক হতে হবে',
        'ব্যবহারিক ড্রাইভিং পরীক্ষা প্রয়োজন',
        'নবায়ন: প্রতি ৫ বছরে (৫০০-১,০০০ টাকা)'
      ],
      safety_en: [
        'Helmet mandatory for both rider and pillion',
        'Maximum 2 persons allowed',
        'Speed Limits: City 40 km/h, Highway 60 km/h',
        'No modifications without BRTA approval',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'চালক এবং পেছনের যাত্রী উভয়ের জন্য হেলমেট বাধ্যতামূলক',
        'সর্বোচ্চ ২ জন অনুমোদিত',
        'গতিসীমা: শহর ৪০ কিমি/ঘন্টা, হাইওয়ে ৬০ কিমি/ঘন্টা',
        'বিআরটিএ অনুমোদন ছাড়া কোনো পরিবর্তন নেই',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'car',
    icon: '🚗',
    title_en: 'Car',
    title_bn: '🚗গাড়ি',
    subtitle_en: 'Private Cars, Jeeps, Taxis - Seatbelts mandatory in front seats',
    subtitle_bn: 'ব্যক্তিগত গাড়ি, জিপ, ট্যাক্সি - সামনের আসনে সিটবেল্ট বাধ্যতামূলক',
    details: {
      registration_en: [
        'Process: BRTA application with customs documents',
        'Fees: BDT 10,000-20,000 (new)',
        'Carbon Tax: BDT 5,000-20,000 (based on engine capacity)',
        'Annual tax varies by engine CC',
        'Semi-annual fitness check required'
      ],
      registration_bn: [
        'প্রক্রিয়া: কাস্টমস নথিপত্র সহ বিআরটিএ আবেদন',
        'ফি: নতুনের জন্য ১০,০০০-২০,০০০ টাকা',
        'কার্বন ট্যাক্স: ৫,০০০-২০,০০০ টাকা (ইঞ্জিন ক্ষমতার উপর ভিত্তি করে)',
        'বার্ষিক কর ইঞ্জিন সিসি অনুযায়ী পরিবর্তিত হয়',
        'অর্ধবার্ষিক ফিটনেস পরীক্ষা প্রয়োজন'
      ],
      licensing_en: [
        'Age: 20+ years for private cars',
        'Professional license required for taxis',
        'Renewal: BDT 1,000-2,000 every 5 years',
        'Point system: 12 points maximum'
      ],
      licensing_bn: [
        'বয়স: ব্যক্তিগত গাড়ির জন্য ২০+ বছর',
        'ট্যাক্সির জন্য পেশাদার লাইসেন্স প্রয়োজন',
        'নবায়ন: প্রতি ৫ বছরে ১,০০০-২,০০০ টাকা',
        'পয়েন্ট সিস্টেম: সর্বোচ্চ ১২ পয়েন্ট'
      ],
      safety_en: [
        'Seatbelts mandatory in front seats',
        'No overcrowding beyond seating capacity',
        'Speed Limits: City 50 km/h, Highway 80 km/h',
        'Left-hand drive requires special approval',
        'Modifications prohibited without BRTA approval'
      ],
      safety_bn: [
        'সামনের আসনের জন্য সিটবেল্ট বাধ্যতামূলক',
        'আসন ক্ষমতার বাইরে ভিড় নিষিদ্ধ',
        'গতিসীমা: শহর ৫০ কিমি/ঘন্টা, হাইওয়ে ৮০ কিমি/ঘন্টা',
        'বাম-হাত ড্রাইভের জন্য বিশেষ অনুমোদন প্রয়োজন',
        'বিআরটিএ অনুমোদন ছাড়া পরিবর্তন নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'bus',
    icon: '🚌',
    title_en: 'Bus',
    title_bn: '🚌বাস',
    subtitle_en: 'Buses & Microbuses - Route permit required, conductor mandatory',
    subtitle_bn: 'বাস এবং মাইক্রোবাস - রুট পারমিট প্রয়োজন, পরিচালক বাধ্যতামূলক',
    details: {
      registration_en: [
        'Fees: BDT 25,000+ (new)',
        'Annual tax: BDT 5,000-15,000',
        'Route permit mandatory',
        'Annual fitness and route permit renewal',
        'Exempt from carbon tax'
      ],
      registration_bn: [
        'ফি: নতুনের জন্য ২৫,০০০+ টাকা',
        'বার্ষিক কর: ৫,০০০-১৫,০০০ টাকা',
        'রুট পারমিট বাধ্যতামূলক',
        'বার্ষিক ফিটনেস এবং রুট পারমিট নবায়ন',
        'কার্বন ট্যাক্স থেকে মুক্ত'
      ],
      licensing_en: [
        'Age: 21+ years',
        'Professional heavy vehicle license required',
        'Driver and conductor both mandatory',
        'Regular training and renewal required'
      ],
      licensing_bn: [
        'বয়স: ২১+ বছর',
        'পেশাদার ভারী যানবাহন লাইসেন্স প্রয়োজন',
        'চালক এবং পরিচালক উভয়ই বাধ্যতামূলক',
        'নিয়মিত প্রশিক্ষণ এবং নবায়ন প্রয়োজন'
      ],
      safety_en: [
        'Must stop only at designated bus stops',
        'Exact seating capacity must be maintained',
        'Emergency exits must be clear',
        'Speed governor mandatory',
        'Speed Limits: City 40 km/h, Highway 60 km/h'
      ],
      safety_bn: [
        'শুধুমাত্র নির্ধারিত বাস স্টপে থামতে হবে',
        'সঠিক আসন ক্ষমতা বজায় রাখতে হবে',
        'জরুরি প্রস্থান পথ পরিষ্কার থাকতে হবে',
        'স্পিড গভর্নর বাধ্যতামূলক',
        'গতিসীমা: শহর ৪০ কিমি/ঘন্টা, হাইওয়ে ৬০ কিমি/ঘন্টা'
      ]
    }
  },
  {
    id: 'truck',
    icon: '🚛',
    title_en: 'Truck',
    title_bn: '🚛ট্রাক',
    subtitle_en: 'Trucks & Lorries - Load permit required, weight restrictions',
    subtitle_bn: 'ট্রাক এবং লরি - লোড পারমিট প্রয়োজন, ওজন সীমাবদ্ধতা',
    details: {
      registration_en: [
        'Process: BRTA weight and load verification',
        'Fees: BDT 25,000-50,000 (new)',
        'Annual fitness certificate required',
        'Load permits mandatory',
        'Exempt from carbon tax'
      ],
      registration_bn: [
        'প্রক্রিয়া: বিআরটিএ ওজন এবং লোড যাচাইকরণ',
        'ফি: নতুনের জন্য ২৫,০০০-৫০,০০০ টাকা',
        'বার্ষিক ফিটনেস সার্টিফিকেট প্রয়োজন',
        'লোড পারমিট বাধ্যতামূলক',
        'কার্বন ট্যাক্স থেকে মুক্ত'
      ],
      licensing_en: [
        'Age: 21+ years',
        'Heavy vehicle license endorsement required',
        'Special training for cargo handling',
        'Regular fitness tests mandatory'
      ],
      licensing_bn: [
        'বয়স: ২১+ বছর',
        'ভারী যানবাহন লাইসেন্স অনুমোদন প্রয়োজন',
        'পণ্য পরিচালনার জন্য বিশেষ প্রশিক্ষণ',
        'নিয়মিত ফিটনেস পরীক্ষা বাধ্যতামূলক'
      ],
      safety_en: [
        'Load must be secured properly',
        'No overhang >1m without flag',
        'Reflective tapes mandatory at night',
        'Speed Limits: City 30 km/h, Highway 50 km/h',
        'Banned from city centers during peak hours'
      ],
      safety_bn: [
        'লোড সঠিকভাবে সুরক্ষিত করতে হবে',
        'পতাকা ছাড়া >১ মিটার ওভারহ্যাং নিষিদ্ধ',
        'রাতে প্রতিফলক টেপ বাধ্যতামূলক',
        'গতিসীমা: শহর ৩০ কিমি/ঘন্টা, হাইওয়ে ৫০ কিমি/ঘন্টা',
        'পিক আওয়ারে শহরের কেন্দ্র থেকে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'erickshaw',
    icon: '🔋',
    title_en: 'E-rickshaw',
    title_bn: '🔋ই-রিকশা',
    subtitle_en: 'E-Rickshaws & Easy-Bikes - Eco-friendly, local roads only',
    subtitle_bn: 'ই-রিকশা এবং ইজি-বাইক - পরিবেশ বান্ধব, শুধুমাত্র স্থানীয় রাস্তা',
    details: {
      registration_en: [
        'Process: BRTA for motorized variants',
        'Fees: BDT 2,000-5,000',
        'Annual fitness check',
        'Battery recycling mandatory',
        'Maximum age limit: 10 years'
      ],
      registration_bn: [
        'প্রক্রিয়া: মোটরচালিত ভ্যারিয়েন্টের জন্য বিআরটিএ',
        'ফি: ২,০০০-৫,০০০ টাকা',
        'বার্ষিক ফিটনেস পরীক্ষা',
        'ব্যাটারি পুনর্ব্যবহার বাধ্যতামূলক',
        'সর্বোচ্চ বয়স সীমা: ১০ বছর'
      ],
      licensing_en: [
        'Age: 18+ years',
        'Basic driving license required',
        'Eco-friendly vehicle training',
        'Battery safety certification'
      ],
      licensing_bn: [
        'বয়স: ১৮+ বছর',
        'মৌলিক ড্রাইভিং লাইসেন্স প্রয়োজন',
        'পরিবেশ বান্ধব যানবাহন প্রশিক্ষণ',
        'ব্যাটারি নিরাপত্তা সার্টিফিকেশন'
      ],
      safety_en: [
        'Speed Limit: City 25 km/h',
        'Restricted to local roads only',
        'Maximum 2-3 passengers',
        'Battery must be properly secured',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'গতিসীমা: শহর ২৫ কিমি/ঘন্টা',
        'শুধুমাত্র স্থানীয় রাস্তায় সীমাবদ্ধ',
        'সর্বোচ্চ ২-৩ জন যাত্রী',
        'ব্যাটারি সঠিকভাবে সুরক্ষিত থাকতে হবে',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'cng',
    icon: '🛺',
    title_en: 'CNG',
    title_bn: '🛺সিএনজি',
    subtitle_en: 'CNG Auto-Rickshaws - Meter mandatory, max 3 passengers',
    subtitle_bn: 'সিএনজি অটো-রিকশা - মিটার বাধ্যতামূলক, সর্বোচ্চ ৩ জন যাত্রী',
    details: {
      registration_en: [
        'Process: BRTA application with meter calibration',
        'Fees: BDT 5,000-10,000 (new)',
        'Government-approved meter mandatory',
        'Annual fitness required',
        'Phased out after 9-15 years'
      ],
      registration_bn: [
        'প্রক্রিয়া: মিটার ক্যালিব্রেশন সহ বিআরটিএ আবেদন',
        'ফি: নতুনের জন্য ৫,০০০-১০,০০০ টাকা',
        'সরকার অনুমোদিত মিটার বাধ্যতামূলক',
        'বার্ষিক ফিটনেস প্রয়োজন',
        '৯-১৫ বছর পরে পর্যায়ক্রমে বন্ধ'
      ],
      licensing_en: [
        'Age: 18+ years',
        'Professional license required',
        'Route knowledge test',
        'Annual CNG leak check mandatory'
      ],
      licensing_bn: [
        'বয়স: ১৮+ বছর',
        'পেশাদার লাইসেন্স প্রয়োজন',
        'রুট জ্ঞান পরীক্ষা',
        'বার্ষিক সিএনজি লিক পরীক্ষা বাধ্যতামূলক'
      ],
      safety_en: [
        'Maximum 3 passengers allowed',
        'Must use government-approved meter',
        'Speed Limit: City 30 km/h',
        'Not allowed on highways',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'সর্বোচ্চ ৩ জন যাত্রী অনুমোদিত',
        'সরকার অনুমোদিত মিটার ব্যবহার করতে হবে',
        'গতিসীমা: শহর ৩০ কিমি/ঘন্টা',
        'হাইওয়েতে অনুমোদিত নয়',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  }
];

interface CommonRequirement {
  icon: string;
  title_en: string;
  title_bn: string;
  desc_en: string;
  desc_bn: string;
}

const COMMON_REQUIREMENTS: CommonRequirement[] = [
  {
    icon: '🪪',
    title_en: 'Driving License',
    title_bn: 'ড্রাইভিং লাইসেন্স',
    desc_en: 'Renew every 5 years (BDT 500-2,000)',
    desc_bn: 'প্রতি ৫ বছরে নবায়ন (৫০০-২,০০০ টাকা)'
  },
  {
    icon: '📝',
    title_en: 'Vehicle Registration',
    title_bn: 'যানবাহন নিবন্ধন',
    desc_en: 'Within 30 days of purchase',
    desc_bn: 'ক্রয়ের ৩০ দিনের মধ্যে'
  },
  {
    icon: '🏥',
    title_en: 'Fitness Certificate',
    title_bn: 'ফিটনেস সার্টিফিকেট',
    desc_en: 'Annual (commercial), Semi-annual (private)',
    desc_bn: 'বার্ষিক (বাণিজ্যিক), অর্ধবার্ষিক (ব্যক্তিগত)'
  },
  {
    icon: '🛡️',
    title_en: 'Insurance',
    title_bn: 'বীমা',
    desc_en: 'Third-party mandatory (BDT 500-5,000)',
    desc_bn: 'তৃতীয় পক্ষের বাধ্যতামূলক (৫০০-৫,০০০ টাকা)'
  },
  {
    icon: '🎫',
    title_en: 'Tax Token',
    title_bn: 'ট্যাক্স টোকেন',
    desc_en: 'Annual renewal (25% late fee)',
    desc_bn: 'বার্ষিক নবায়ন (২৫% দেরি ফি)'
  },
  {
    icon: '📊',
    title_en: 'Point System',
    title_bn: 'পয়েন্ট সিস্টেম',
    desc_en: '12 points maximum license',
    desc_bn: '১২ পয়েন্ট সর্বোচ্চ লাইসেন্স'
  }
];

export default function VehicleRules() {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [showTaxTokenModal, setShowTaxTokenModal] = useState(false);

  const selectedType = VEHICLE_TYPES.find(v => v.id === selectedVehicle);

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center space-x-3 sm:space-x-4">
            <BackButton 
              onClick={() => selectedVehicle ? setSelectedVehicle(null) : navigate('/')}
              className="p-2 hover:bg-ash rounded-lg transition-colors"
            />
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="icon-primary w-12 h-12">
                <Eye className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                  {t('Vehicle Rules', 'যানবাহন নিয়ম')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {!selectedVehicle ? (
          <>
            {/* Title Section */}
            <div className="text-center mb-6 sm:mb-8">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                {t('Complete Vehicle Rules in Bangladesh', 'বাংলাদেশে সম্পূর্ণ যানবাহন নিয়ম')}
              </h2>
              <p className="text-base sm:text-lg text-gray-600">
                {t('Registration, Licensing & Safety Requirements', 'নিবন্ধন, লাইসেন্সিং এবং নিরাপত্তা প্রয়োজনীয়তা')}
              </p>
            </div>

            {/* Select Vehicle Type */}
            <div className="mb-8 sm:mb-12">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">
                {t('Select Vehicle Type', 'যানবাহনের ধরন নির্বাচন করুন')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {VEHICLE_TYPES.map((vehicle) => (
                  <button
                    key={vehicle.id}
                    onClick={() => setSelectedVehicle(vehicle.id)}
                    className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border-2 border-gray-200 hover:border-blue-500 hover:shadow-lg transition-all text-left group hover:scale-[1.02] transform duration-200"
                  >
                    <div className="text-3xl sm:text-4xl mb-3 sm:mb-4">{vehicle.icon}</div>
                    <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {language === 'en' ? vehicle.title_en : vehicle.title_bn}
                    </h4>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed mb-3">
                      {language === 'en' ? vehicle.subtitle_en : vehicle.subtitle_bn}
                    </p>
                    <p className="text-blue-600 font-medium text-xs sm:text-sm flex items-center">
                      {t('View Details', 'বিস্তারিত দেখুন')}
                      <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 ml-2 transform rotate-180" />
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Common Requirements */}
            <div className="mb-8 sm:mb-12">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">
                {t('Common Requirements for All Vehicles', 'সকল যানবাহনের জন্য সাধারণ প্রয়োজনীয়তা')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {COMMON_REQUIREMENTS.map((req, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      if (req.title_en === 'Tax Token') {
                        setShowTaxTokenModal(true);
                      }
                    }}
                    className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-200 hover:shadow-lg transition-all hover:scale-[1.02] transform duration-200 text-left w-full group"
                  >
                    <div className="text-2xl sm:text-3xl mb-3 sm:mb-4">{req.icon}</div>
                    <h4 className="text-base sm:text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {language === 'en' ? req.title_en : req.title_bn}
                    </h4>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed mb-3">
                      {language === 'en' ? req.desc_en : req.desc_bn}
                    </p>
                    {req.title_en === 'Tax Token' && (
                      <p className="text-blue-600 font-medium text-xs sm:text-sm flex items-center">
                        {t('View Details', 'বিস্তারিত দেখুন')}
                        <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                      </p>
                    )}
                  </button>
                ))}
              </div>
              
              {/* Compliance Checklist Button - positioned after Tax Token */}
              <div className="text-center mt-6 sm:mt-8">
                <button
                  onClick={() => navigate('/vehicle-rules')}
                  className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl transform hover:scale-105 duration-200 flex items-center gap-2 sm:gap-3 mx-auto text-sm sm:text-base flex-wrap justify-center"
                >
                  <span className="text-xl sm:text-2xl">📋</span>
                  <span className="text-center">
                    {t('VIEW COMPLETE VEHICLE RULES', 'সম্পূর্ণ যানবাহন নিয়ম দেখুন')}
                  </span>
                </button>
              </div>
            </div>

            {/* Point System Visual */}
            <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 border-2 border-red-200 mb-6 sm:mb-8">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">📊</span>
                {t('Driving License Point System', 'ড্রাইভিং লাইসেন্স পয়েন্ট সিস্টেম')}
              </h3>
              <div className="bg-white rounded-xl p-4 sm:p-6 mb-4 sm:mb-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-base sm:text-lg font-semibold text-gray-700">{t('Current Points', 'বর্তমান পয়েন্ট')}</span>
                  <span className="text-xl sm:text-2xl font-bold text-red-600">12/12</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-4 sm:h-6 overflow-hidden">
                  <div className="bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 h-full w-full rounded-full"></div>
                </div>
                <div className="flex justify-between text-xs text-gray-600 mt-2">
                  <span>0</span>
                  <span>6</span>
                  <span>12</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 text-sm">
                <div className="bg-green-50 p-3 sm:p-4 rounded-lg border border-green-200">
                  <p className="font-semibold text-green-800 mb-1">{t('0-4 Points:', '০-৪ পয়েন্ট:')}</p>
                  <p className="text-green-700">{t('Safe driving record', 'নিরাপদ ড্রাইভিং রেকর্ড')}</p>
                </div>
                <div className="bg-yellow-50 p-3 sm:p-4 rounded-lg border border-yellow-200">
                  <p className="font-semibold text-yellow-800 mb-1">{t('5-8 Points:', '৫-৮ পয়েন্ট:')}</p>
                  <p className="text-yellow-700">{t('Warning issued', 'সতর্কতা জারি')}</p>
                </div>
                <div className="bg-orange-50 p-3 sm:p-4 rounded-lg border border-orange-200">
                  <p className="font-semibold text-orange-800 mb-1">{t('9-11 Points:', '৯-১১ পয়েন্ট:')}</p>
                  <p className="text-orange-700">{t('Mandatory safety course', 'বাধ্যতামূলক নিরাপত্তা কোর্স')}</p>
                </div>
                <div className="bg-red-50 p-3 sm:p-4 rounded-lg border border-red-200">
                  <p className="font-semibold text-red-800 mb-1">{t('12 Points:', '১২ পয়েন্ট:')}</p>
                  <p className="text-red-700">{t('6-month license suspension', '৬ মাসের লাইসেন্স সাসপেনশন')}</p>
                </div>
              </div>
            </div>

            {/* Important Notes */}
            <div className="bg-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-blue-200">
              <h4 className="font-bold text-blue-900 mb-3 flex items-center text-base sm:text-lg">
                <span className="text-lg sm:text-xl mr-2">ℹ️</span>
                {t('Important Information', 'গুরুত্বপূর্ণ তথ্য')}
              </h4>
              <div className="space-y-2 text-blue-800 text-xs sm:text-sm">
                <p>• {t('All information is based on current Bangladesh Road Transport Act 2018', 'সমস্ত তথ্য বর্তমান বাংলাদেশ সড়ক পরিবহন আইন ২০১৮ এর উপর ভিত্তি করে')}</p>
                <p>• {t('Fees and requirements may change - always verify with BRTA', 'ফি এবং প্রয়োজনীয়তা পরিবর্তিত হতে পারে - সর্বদা বিআরটিএ দিয়ে যাচাই করুন')}</p>
                <p>• {t('This guide is for educational purposes only', 'এই গাইড শুধুমাত্র শিক্ষামূলক উদ্দেশ্যে')}</p>
              </div>
            </div>

            {/* Tax Token Modal */}
            {showTaxTokenModal && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-6xl max-h-[90vh] overflow-y-auto w-full">
                  <div className="sticky top-0 bg-white dark:bg-gray-800 p-6 border-b border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between items-center">
                      <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 flex items-center gap-3">
                        <span className="text-3xl">🎫</span>
                        {language === 'bn' ? 'ট্যাক্স টোকেন বিস্তারিত' : 'Tax Token Details'}
                      </h2>
                      <button 
                        onClick={() => setShowTaxTokenModal(false)}
                        className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 text-2xl font-bold"
                      >
                        ×
                      </button>
                    </div>
                  </div>

                  <div className="p-4 sm:p-6 space-y-6 sm:space-y-8">
                    {/* Detailed Requirements */}
                    <div>
                      <h3 className="text-lg sm:text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4 flex items-center gap-2">
                        <span>💰</span>
                        {language === 'bn' ? 'বিস্তারিত প্রয়োজনীয়তা' : 'Detailed Requirements'}
                      </h3>
                      <div className="overflow-x-auto">
                        <table className="w-full border border-gray-300 dark:border-gray-600 rounded-lg min-w-full">
                          <thead className="bg-gray-50 dark:bg-gray-700">
                            <tr>
                              <th className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 text-left font-semibold text-sm sm:text-base">
                                {language === 'bn' ? 'দিক' : 'Aspect'}
                              </th>
                              <th className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 text-left font-semibold text-sm sm:text-base">
                                {language === 'bn' ? 'বিস্তারিত' : 'Details'}
                              </th>
                            </tr>
                          </thead>
                          <tbody className="text-sm sm:text-base">
                            <tr>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 font-medium">
                                {language === 'bn' ? 'বৈধতার মেয়াদ' : 'Validity Period'}
                              </td>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2">
                                {language === 'bn' ? '১ বছর (জানুয়ারি-ডিসেম্বর)' : '1 year (January-December)'}
                              </td>
                            </tr>
                            <tr className="bg-gray-50 dark:bg-gray-700">
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 font-medium">
                                {language === 'bn' ? 'নবায়নের সময়' : 'Renewal Time'}
                              </td>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2">
                                {language === 'bn' ? 'বার্ষিক, জানুয়ারিতে প্রাধিকৃত' : 'Annually, preferably in January'}
                              </td>
                            </tr>
                            <tr>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 font-medium">
                                {language === 'bn' ? 'বিলম্ব ফি' : 'Late Fee'}
                              </td>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2">
                                {language === 'bn' ? 'বার্ষিক করের ২৫%' : '25% of annual tax'}
                              </td>
                            </tr>
                            <tr className="bg-gray-50 dark:bg-gray-700">
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 font-medium">
                                {language === 'bn' ? 'পেমেন্ট পদ্ধতি' : 'Payment Method'}
                              </td>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2">
                                {language === 'bn' ? 'অনলাইন, ব্যাংক, বিআরটিএ অফিস' : 'Online, bank, BRTA office'}
                              </td>
                            </tr>
                            <tr>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2 font-medium">
                                {language === 'bn' ? 'কার্বন ট্যাক্স' : 'Carbon Tax'}
                              </td>
                              <td className="border border-gray-300 dark:border-gray-600 px-3 sm:px-4 py-2">
                                {language === 'bn' ? 'একাধিক ব্যক্তিগত গাড়ির জন্য অতিরিক্ত' : 'Additional for multiple private cars'}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        ) : selectedType && (
          <div className="space-y-6 sm:space-y-8">
            {/* Vehicle Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-xl">
              <div className="flex items-center space-x-3 sm:space-x-4">
                <div className="text-4xl sm:text-6xl">{selectedType.icon}</div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold mb-2">
                    {language === 'en' ? selectedType.title_en : selectedType.title_bn}
                  </h2>
                  <p className="text-blue-100 text-sm sm:text-lg">
                    {language === 'en' ? selectedType.subtitle_en : selectedType.subtitle_bn}
                  </p>
                </div>
              </div>
            </div>

            {/* Registration Details */}
            <div className="bg-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">📝</span>
                {t('Registration & Fees', 'নিবন্ধন এবং ফি')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.registration_en : selectedType.details.registration_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-blue-600 text-xs sm:text-sm font-bold">✓</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Licensing Requirements */}
            <div className="bg-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">🪪</span>
                {t('Licensing Requirements', 'লাইসেন্সের প্রয়োজনীয়তা')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.licensing_en : selectedType.details.licensing_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-green-600 text-xs sm:text-sm font-bold">✓</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Safety Rules */}
            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 border-2 border-red-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">⚠️</span>
                {t('Key Safety Rules', 'মূল নিরাপত্তা নিয়ম')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.safety_en : selectedType.details.safety_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-red-600 text-xs sm:text-sm font-bold">!</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed font-medium text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Back to List Button */}
            <div className="text-center">
              <button
                onClick={() => setSelectedVehicle(null)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 sm:px-8 py-3 rounded-xl font-semibold transition-colors shadow-lg hover:shadow-xl text-sm sm:text-base"
              >
                {t('Back to Vehicle Types', 'যানবাহনের ধরনে ফিরে যান')}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
