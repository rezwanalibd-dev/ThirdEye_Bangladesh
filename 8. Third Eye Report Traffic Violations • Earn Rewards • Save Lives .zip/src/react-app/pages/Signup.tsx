import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Eye, EyeOff, Phone, Mail, User, Shield, CheckCircle, AlertCircle } from "lucide-react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import BackButton from '@/react-app/components/BackButton';

export default function Signup() {
  const navigate = useNavigate();
  const { signup } = useAuth();
  const { t } = useLanguage();
  
  const [formData, setFormData] = useState({
    full_name: "",
    mobile_number: "",
    email: "",
    password: "",
    confirmPassword: ""
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const validatePassword = (password: string) => {
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);
    const isLongEnough = password.length >= 8;
    
    return {
      hasUppercase,
      hasLowercase,
      hasNumber,
      hasSymbol,
      isLongEnough,
      isValid: hasUppercase && hasLowercase && hasNumber && hasSymbol && isLongEnough
    };
  };

  const passwordValidation = validatePassword(formData.password);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formData.full_name || !formData.mobile_number || !formData.password) {
      setError(t("Please fill in all required fields", "সকল প্রয়োজনীয় ক্ষেত্র পূরণ করুন"));
      return;
    }

    if (!passwordValidation.isValid) {
      setError(t("Password does not meet requirements", "পাসওয়ার্ড প্রয়োজনীয়তা পূরণ করে না"));
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError(t("Passwords do not match", "পাসওয়ার্ড মিলছে না"));
      return;
    }

    setLoading(true);
    try {
      const result = await signup({
        full_name: formData.full_name,
        mobile_number: formData.mobile_number,
        email: formData.email || undefined,
        password: formData.password
      });

      // Navigate to OTP verification with user ID
      navigate(`/verify-otp?user_id=${result.user_id}&mobile=${encodeURIComponent(formData.mobile_number)}`);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setError(errorMessage || t("Signup failed", "সাইন আপ ব্যর্থ"));
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-ash flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <BackButton 
              to="/" 
              label={t("Back to Home", "হোমে ফিরুন")}
              className="inline-flex items-center hover:bg-primary p-2 rounded-lg transition-colors"
            />
          </div>
          
          <div className="icon-primary w-16 h-16 mx-auto mb-4">
            <Shield className="w-8 h-8" />
          </div>
          
          <h1 className="text-display-2 font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            {t("Create Account", "অ্যাকাউন্ট তৈরি করুন")}
          </h1>
          <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
            {t("Join thousands making roads safer", "হাজার হাজার মানুষের সাথে রাস্তা নিরাপদ করুন")}
          </p>
        </div>

        {/* Form */}
        <div className="card-base p-8">
          {error && (
            <div className="bg-danger border rounded-lg p-4 mb-6 flex items-center" style={{ borderColor: 'var(--color-light-red-dark)' }}>
              <AlertCircle className="w-5 h-5 mr-3 flex-shrink-0" style={{ color: 'var(--color-light-red-dark)' }} />
              <span className="text-sm" style={{ color: 'var(--color-light-red-dark)' }}>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Full Name", "পূর্ণ নাম")} *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                <input
                  type="text"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="input-base pl-10"
                  placeholder={t("Enter your full name", "আপনার পূর্ণ নাম লিখুন")}
                  required
                />
              </div>
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Mobile Number", "মোবাইল নম্বর")} *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                <input
                  type="tel"
                  value={formData.mobile_number}
                  onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                  className="input-base pl-10"
                  placeholder={t("01XXXXXXXXX", "০১XXXXXXXXX")}
                  required
                />
              </div>
              <p className="text-xs mt-1" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("OTP will be sent to this number", "এই নম্বরে OTP পাঠানো হবে")}
              </p>
            </div>

            {/* Email (Optional) */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Email Address", "ইমেইল ঠিকানা")} ({t("Optional", "ঐচ্ছিক")})
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="input-base pl-10"
                  placeholder={t("your@email.com", "your@email.com")}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Password", "পাসওয়ার্ড")} *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="input-base pr-10"
                  placeholder={t("Create a strong password", "একটি শক্তিশালী পাসওয়ার্ড তৈরি করুন")}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 hover:bg-ash p-1 rounded transition-colors"
                >
                  {showPassword ? 
                    <EyeOff className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} /> : 
                    <Eye className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                  }
                </button>
              </div>

              {/* Password Requirements */}
              {formData.password && (
                <div className="mt-3 space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className={`flex items-center ${passwordValidation.hasUppercase ? 'text-green-600' : 'text-gray-400'}`}>
                      <CheckCircle className={`w-3 h-3 mr-1 ${passwordValidation.hasUppercase ? 'text-green-500' : 'text-gray-300'}`} />
                      {t("Uppercase", "বড় হাতের অক্ষর")}
                    </div>
                    <div className={`flex items-center ${passwordValidation.hasLowercase ? 'text-green-600' : 'text-gray-400'}`}>
                      <CheckCircle className={`w-3 h-3 mr-1 ${passwordValidation.hasLowercase ? 'text-green-500' : 'text-gray-300'}`} />
                      {t("Lowercase", "ছোট হাতের অক্ষর")}
                    </div>
                    <div className={`flex items-center ${passwordValidation.hasNumber ? 'text-green-600' : 'text-gray-400'}`}>
                      <CheckCircle className={`w-3 h-3 mr-1 ${passwordValidation.hasNumber ? 'text-green-500' : 'text-gray-300'}`} />
                      {t("Number", "সংখ্যা")}
                    </div>
                    <div className={`flex items-center ${passwordValidation.hasSymbol ? 'text-green-600' : 'text-gray-400'}`}>
                      <CheckCircle className={`w-3 h-3 mr-1 ${passwordValidation.hasSymbol ? 'text-green-500' : 'text-gray-300'}`} />
                      {t("Symbol", "চিহ্ন")}
                    </div>
                    <div className={`flex items-center col-span-2 ${passwordValidation.isLongEnough ? 'text-green-600' : 'text-gray-400'}`}>
                      <CheckCircle className={`w-3 h-3 mr-1 ${passwordValidation.isLongEnough ? 'text-green-500' : 'text-gray-300'}`} />
                      {t("At least 8 characters", "কমপক্ষে ৮ অক্ষর")}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Confirm Password", "পাসওয়ার্ড নিশ্চিত করুন")} *
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="input-base pr-10"
                  placeholder={t("Confirm your password", "আপনার পাসওয়ার্ড নিশ্চিত করুন")}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 hover:bg-ash p-1 rounded transition-colors"
                >
                  {showConfirmPassword ? 
                    <EyeOff className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} /> : 
                    <Eye className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                  }
                </button>
              </div>
              {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                <p className="text-xs mt-1" style={{ color: 'var(--color-light-red-dark)' }}>
                  {t("Passwords do not match", "পাসওয়ার্ড মিলছে না")}
                </p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !passwordValidation.isValid || formData.password !== formData.confirmPassword}
              className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? t("Creating Account...", "অ্যাকাউন্ট তৈরি করা হচ্ছে...") : t("Create Account", "অ্যাকাউন্ট তৈরি করুন")}
            </button>
          </form>

          {/* Sign In Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {t("Already have an account?", "ইতিমধ্যে অ্যাকাউন্ট আছে?")} {" "}
              <Link to="/signin" className="font-medium hover:underline" style={{ color: 'var(--color-primary-blue-dark)' }}>
                {t("Sign In", "সাইন ইন")}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
