import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate, useLocation } from 'react-router';
import { useApi } from '@/react-app/hooks/useApi';
import { 
  Camera, 
  MapPin, 
  Upload, 
  AlertTriangle, 
  CheckCircle,
  ArrowLeft,
  X,
  Car
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';
import { VEHICLE_TYPES, getViolationsForVehicle, generateCaseNumber } from '@/shared/constants';
import ViolationCard from '@/react-app/components/ViolationCard';

export default function Report() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const routerLocation = useLocation();
  const submitReportApi = useApi();

  const [currentStep, setCurrentStep] = useState(0);
  const [violationTypes, setViolationTypes] = useState<any[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [gpsLocation, setGpsLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationName, setLocationName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedCaseNumber, setSubmittedCaseNumber] = useState('');

  const [formData, setFormData] = useState({
    vehicle_type: '',
    violation_type_id: '',
    vehicle_number: '',
    location_description: '',
    description: '',
  });

  useEffect(() => {
    getCurrentLocation();
    
    // Handle prefilled media from quick capture
    const state = routerLocation.state as Record<string, unknown> | null;
    if (state?.prefilledMedia && state?.quickCapture) {
      const prefilledMedia = state.prefilledMedia as string[];
      const files = prefilledMedia.map((_: string, index: number) => {
        // Create a mock file object for display purposes
        return new File([''], `captured-${index + 1}.jpg`, { type: 'image/jpeg' });
      });
      setSelectedFiles(files);
    }
  }, [routerLocation]);

  const handleGetCurrentLocation = React.useCallback(() => {
    getCurrentLocation();
  }, []);

  useEffect(() => {
    getCurrentLocation();
  }, [handleGetCurrentLocation]);

  useEffect(() => {
    if (formData.vehicle_type) {
      const applicableViolations = getViolationsForVehicle(formData.vehicle_type);
      setViolationTypes([...applicableViolations]);
      setFormData(prev => ({ ...prev, violation_type_id: '' })); // Reset violation selection
    }
  }, [formData.vehicle_type]);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setGpsLocation({ lat: latitude, lng: longitude });
          reverseGeocode(latitude, longitude);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  };

  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      // Mock location name for demo
      setLocationName(`Dhaka, Bangladesh (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
    } catch (error) {
      console.error('Reverse geocoding failed:', error);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(prev => [...prev, ...files].slice(0, 5)); // Max 5 files
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.vehicle_type || !formData.violation_type_id || !formData.vehicle_number) {
      alert(t('Please fill in required fields', 'প্রয়োজনীয় ক্ষেত্রগুলি পূরণ করুন'));
      return;
    }

    if (selectedFiles.length === 0) {
      alert(t('Please upload at least one photo or video as evidence', 'প্রমাণ হিসেবে অন্তত একটি ছবি বা ভিডিও আপলোড করুন'));
      return;
    }

    try {
      // Mock file upload - in production, upload to R2/S3
      const evidence_urls = selectedFiles.map((_, index) => 
        `https://thirdeye-storage.com/evidence/${Date.now()}-${index}.jpg`
      );

      const caseNumber = generateCaseNumber();
      const selectedViolation = violationTypes.find(v => v.id === formData.violation_type_id);

      const reportData = {
        case_number: caseNumber,
        vehicle_type: formData.vehicle_type,
        violation_type_id: formData.violation_type_id,
        vehicle_number: formData.vehicle_number,
        latitude: gpsLocation?.lat,
        longitude: gpsLocation?.lng,
        location_description: formData.location_description || locationName,
        description: formData.description,
        evidence_urls,
        fine_amount: selectedViolation?.fine_amount || 0,
        reward_amount: selectedViolation ? selectedViolation.fine_amount * selectedViolation.reward_percentage : 0,
      };

      await submitReportApi.execute('/api/cases', {
        method: 'POST',
        body: reportData,
      });

      setSubmittedCaseNumber(caseNumber);
      setIsSubmitted(true);
    } catch (error) {
      console.error('Failed to submit report:', error);
      alert(t('Failed to submit report. Please try again.', 'রিপোর্ট জমা দিতে ব্যর্থ। আবার চেষ্টা করুন।'));
    }
  };

  const canContinueStep = (step: number): boolean => {
    switch (step) {
      case 0: return !!formData.vehicle_type;
      case 1: return !!formData.violation_type_id;
      case 2: return !!formData.vehicle_number;
      case 3: return selectedFiles.length > 0;
      default: return true;
    }
  };

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-success flex items-center justify-center px-6">
        <div className="max-w-md w-full card-base p-8 text-center">
          <div className="icon-success w-20 h-20 mx-auto mb-6">
            <CheckCircle className="w-12 h-12" />
          </div>
          
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            {t('Report Submitted!', 'রিপোর্ট জমা দেওয়া হয়েছে!')}
          </h2>
          
          <p className="mb-2" style={{ color: 'var(--text-secondary)' }}>
            {t('Case Number', 'কেস নম্বর')}:
          </p>
          <p className="text-xl font-bold mb-6" style={{ color: 'var(--color-light-blue-dark)' }}>
            {submittedCaseNumber}
          </p>
          
          <p className="mb-8" style={{ color: 'var(--text-secondary)' }}>
            {t('Your report is under review. You will be notified once it\'s approved.', 
               'আপনার রিপোর্ট পর্যালোচনাধীন। এটি অনুমোদিত হলে আপনাকে জানানো হবে।')}
          </p>
          
          <div className="space-y-4">
            <button
              onClick={() => navigate('/cases')}
              className="btn-primary w-full"
            >
              {t('View All Cases', 'সব কেস দেখুন')}
            </button>
            <button
              onClick={() => {
                setIsSubmitted(false);
                setCurrentStep(0);
                setFormData({
                  vehicle_type: '',
                  violation_type_id: '',
                  vehicle_number: '',
                  location_description: '',
                  description: '',
                });
                setSelectedFiles([]);
              }}
              className="btn-secondary w-full"
            >
              {t('Submit Another Report', 'আরেকটি রিপোর্ট জমা দিন')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <BackButton 
              to="/dashboard"
              className="p-2 hover:bg-ash rounded-lg transition-colors"
            />
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {t('Report Violation', 'আইন লঙ্ঘন রিপোর্ট করুন')}
              </h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                {t('Help make roads safer', 'রাস্তা নিরাপদ করতে সাহায্য করুন')}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {['Vehicle', 'Violation', 'Details', 'Evidence'].map((step, index) => (
              <div key={step} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all
                    ${index <= currentStep 
                      ? 'border-2 text-white' 
                      : 'bg-white'}
                  `} style={{
                    backgroundColor: index <= currentStep ? 'var(--color-light-red-dark)' : 'white',
                    borderColor: index <= currentStep ? 'var(--color-light-red-dark)' : 'var(--color-light-ash-medium)',
                    color: index <= currentStep ? 'white' : 'var(--text-light)'
                  }}>
                    {index < currentStep ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <span className="text-sm font-bold">{index + 1}</span>
                    )}
                  </div>
                  <p className="mt-2 text-sm font-medium" style={{
                    color: index <= currentStep ? 'var(--color-light-red-dark)' : 'var(--text-light)'
                  }}>
                    {t(step, step === 'Vehicle' ? 'যানবাহন' : 
                                step === 'Violation' ? 'আইন লঙ্ঘন' :
                                step === 'Details' ? 'বিবরণ' : 'প্রমাণ')}
                  </p>
                </div>
                {index < 3 && (
                  <div className={`h-1 w-full mx-4 rounded transition-all ${
                    index < currentStep ? '' : ''
                  }`} style={{
                    backgroundColor: index < currentStep ? 'var(--color-light-red-dark)' : 'var(--color-primary-blue)'
                  }} />
                )}
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Step 0: Vehicle Type Selection */}
          {currentStep === 0 && (
            <div className="card-base p-8">
              <div className="text-center mb-8">
                <div className="icon-danger w-16 h-16 mx-auto mb-4">
                  <Car className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Select Vehicle Type', 'যানবাহনের ধরন নির্বাচন করুন')}
                </h3>
                <p className="text-gray-600">
                  {t('Choose the type of vehicle involved in the violation', 'আইন লঙ্ঘনে জড়িত যানবাহনের ধরন বেছে নিন')}
                </p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {VEHICLE_TYPES.map((vehicle) => (
                  <label
                    key={vehicle}
                    className={`
                      relative p-6 border-2 rounded-2xl cursor-pointer transition-all duration-200 hover:shadow-lg
                      ${formData.vehicle_type === vehicle 
                        ? 'shadow-md transform scale-105' 
                        : 'bg-white hover:bg-ash'}
                    `}
                    style={{
                      borderColor: formData.vehicle_type === vehicle ? 'var(--color-light-red-dark)' : 'var(--color-primary-blue)',
                      backgroundColor: formData.vehicle_type === vehicle ? 'var(--color-light-red)' : undefined
                    }}
                  >
                    <input
                      type="radio"
                      name="vehicle_type"
                      value={vehicle}
                      checked={formData.vehicle_type === vehicle}
                      onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
                      className="sr-only"
                    />
                    
                    <div className="text-center">
                      <div className={`
                        w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center transition-colors
                        ${formData.vehicle_type === vehicle 
                          ? '' 
                          : 'bg-ash'}
                      `} style={{
                        backgroundColor: formData.vehicle_type === vehicle ? 'var(--color-light-red-dark)' : undefined,
                        color: formData.vehicle_type === vehicle ? 'white' : 'var(--color-light-ash-dark)'
                      }}>
                        {vehicle === 'Motorcycle' && '🏍️'}
                        {vehicle === 'Car' && '🚗'}
                        {vehicle === 'Bus' && '🚌'}
                        {vehicle === 'Truck' && '🚚'}
                        {vehicle === 'CNG' && '🛺'}
                        {vehicle === 'E-Rickshaw' && '🔋'}
                      </div>
                      <h4 className={`font-bold text-lg transition-colors ${
                        formData.vehicle_type === vehicle ? '' : ''
                      }`} style={{
                        color: formData.vehicle_type === vehicle ? 'var(--color-light-red-dark)' : 'var(--color-light-ash-dark)'
                      }}>
                        {t(vehicle, 
                          vehicle === 'Motorcycle' ? 'মোটরবাইক' :
                          vehicle === 'Car' ? 'গাড়ি' :
                          vehicle === 'Bus' ? 'বাস' :
                          vehicle === 'Truck' ? 'ট্রাক' :
                          vehicle === 'CNG' ? 'সিএনজি' :
                          vehicle === 'E-Rickshaw' ? 'ই-রিকশা' : vehicle
                        )}
                      </h4>
                    </div>

                    {formData.vehicle_type === vehicle && (
                      <div className="absolute top-4 right-4">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--color-light-red-dark)' }}>
                          <CheckCircle className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    )}
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Step 1: Violation Type Selection */}
          {currentStep === 1 && (
            <div className="card-base p-8">
              <div className="text-center mb-8">
                <div className="icon-danger w-16 h-16 mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Select Violation Type', 'আইন লঙ্ঘনের ধরন নির্বাচন করুন')}
                </h3>
                <p className="text-gray-600">
                  {t(`Violations applicable for ${formData.vehicle_type}`, `${formData.vehicle_type} এর জন্য প্রযোজ্য আইন লঙ্ঘনসমূহ`)}
                </p>
              </div>
              
              <div className="grid gap-6">
                {violationTypes.map((violation) => (
                  <ViolationCard
                    key={violation.id}
                    violation={violation}
                    isSelected={formData.violation_type_id === violation.id}
                    onSelect={(id) => setFormData({ ...formData, violation_type_id: id })}
                    vehicleType={formData.vehicle_type}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Vehicle Details */}
          {currentStep === 2 && (
            <div className="card-base p-8">
              <div className="text-center mb-8">
                <div className="icon-primary w-16 h-16 mx-auto mb-4">
                  <span className="text-3xl text-white">📝</span>
                </div>
                <h3 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Vehicle & Location Details', 'যানবাহন ও অবস্থানের বিবরণ')}
                </h3>
                <p className="text-gray-600">
                  {t('Provide accurate information for proper verification', 'সঠিক যাচাইকরণের জন্য নির্ভুল তথ্য দিন')}
                </p>
              </div>
              
              <div className="space-y-8">
                {/* Vehicle Number */}
                <div>
                  <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Vehicle Number', 'যানবাহন নম্বর')} *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={formData.vehicle_number}
                      onChange={(e) => setFormData({ ...formData, vehicle_number: e.target.value.toUpperCase() })}
                      className="input-base font-mono"
                      placeholder={t('ঢাকা-মেট্রো-গ-১১-১২৩ৄ', 'DHAKA-METRO-GA-11-1234')}
                    />
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                      <span className="text-2xl">🚗</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">
                    {t('Enter the complete license plate number as shown on the vehicle', 'যানবাহনে দেখানো সম্পূর্ণ লাইসেন্স প্লেট নম্বর লিখুন')}
                  </p>
                </div>

                {/* Location Detection */}
                <div>
                  <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Violation Location', 'আইন লঙ্ঘনের অবস্থান')} *
                  </label>
                  <div className="bg-success border-2 rounded-xl p-6" style={{ borderColor: 'var(--color-light-green-dark)' }}>
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="icon-success w-12 h-12">
                        <MapPin className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-lg" style={{ color: 'var(--color-light-ash-dark)' }}>
                          {t('Auto-detected Location', 'স্বয়ংক্রিয় অবস্থান')}
                        </h4>
                        <p className="text-gray-600">
                          {locationName || t('Getting precise location...', 'সুনির্দিষ্ট অবস্থান নিরূপণ...')}
                        </p>
                      </div>
                      {gpsLocation && (
                        <div className="text-white px-4 py-2 rounded-lg text-sm font-semibold" style={{ backgroundColor: 'var(--color-light-green-dark)' }}>
                          {t('GPS Locked', 'জিপিএস লক')} ✓
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">{t('Latitude', 'অক্ষাংশ')}:</span>
                        <span className="ml-2 font-mono text-gray-800">{gpsLocation?.lat.toFixed(6) || '---'}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">{t('Longitude', 'দ্রাঘিমাংশ')}:</span>
                        <span className="ml-2 font-mono text-gray-800">{gpsLocation?.lng.toFixed(6) || '---'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Additional Location Details */}
                  <div className="mt-4">
                    <input
                      type="text"
                      value={formData.location_description}
                      onChange={(e) => setFormData({ ...formData, location_description: e.target.value })}
                      className="input-base"
                      placeholder={t('Additional location details (e.g., Near Shahbag intersection, in front of TSC)', 'অতিরিক্ত অবস্থানের বিবরণ (যেমন: শাহবাগ মোড়ের কাছে, টিএসসির সামনে)')}
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-lg font-semibold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Additional Details', 'অতিরিক্ত বিবরণ')} 
                    <span className="text-gray-500 font-normal text-base">({t('Optional', 'ঐচ্ছিক')})</span>
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="input-base"
                    rows={4}
                    placeholder={t('Describe the violation in detail - what exactly happened, time of incident, weather conditions, etc.', 'আইন লঙ্ঘনের বিস্তারিত বর্ণনা - ঠিক কি ঘটেছিল, ঘটনার সময়, আবহাওয়া ইত্যাদি।')}
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    {t('Clear descriptions help authorities process your report faster', 'স্পষ্ট বর্ণনা কর্তৃপক্ষকে আপনার রিপোর্ট দ্রুত প্রক্রিয়া করতে সাহায্য করে')}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Evidence Upload */}
          {currentStep === 3 && (
            <div className="card-base p-8">
              <div className="text-center mb-8">
                <div className="icon-primary w-16 h-16 mx-auto mb-4">
                  <Camera className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Upload Evidence', 'প্রমাণ আপলোড করুন')}
                </h3>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  {t('Clear photos and videos are crucial for report approval. Take multiple angles and ensure good lighting.', 'রিপোর্ট অনুমোদনের জন্য স্পষ্ট ছবি এবং ভিডিও অত্যন্ত গুরুত্বপূর্ণ। একাধিক কোণ থেকে তুলুন এবং ভালো আলো নিশ্চিত করুন।')}
                </p>
              </div>
              
              {selectedFiles.length === 0 ? (
                <div className="border-3 border-dashed rounded-2xl p-12 text-center hover:bg-ash transition-all" style={{ borderColor: 'var(--color-primary-blue)' }}>
                  <div className="icon-secondary w-20 h-20 mx-auto mb-6">
                    <Camera className="w-10 h-10" />
                  </div>
                  <h4 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Add Photos & Videos', 'ছবি এবং ভিডিও যোগ করুন')}
                  </h4>
                  <p className="text-gray-600 mb-8 max-w-lg mx-auto">
                    {t('Take clear, well-lit photos from multiple angles. Videos should be short and focused on the violation.', 'একাধিক কোণ থেকে স্পষ্ট, ভালো আলোর ছবি তুলুন। ভিডিও সংক্ষিপ্ত এবং আইন লঙ্ঘনের উপর কেন্দ্রীভূত হওয়া উচিত।')}
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <label className="btn-primary flex items-center transform hover:scale-105 transition-all shadow-lg cursor-pointer">
                      <Camera className="w-6 h-6 mr-3" />
                      {t('Take Photo', 'ছবি তুলুন')}
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                    
                    <label className="btn-danger flex items-center transform hover:scale-105 transition-all shadow-lg cursor-pointer">
                      <Upload className="w-6 h-6 mr-3" />
                      {t('Upload Files', 'ফাইল আপলোড')}
                      <input
                        type="file"
                        multiple
                        accept="image/*,video/*"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="mt-8 text-center">
                    <p className="text-sm text-gray-500">
                      {t('Supported formats: JPG, PNG, MP4, WebM • Max 10MB per file • Up to 5 files', 'সমর্থিত ফরম্যাট: JPG, PNG, MP4, WebM • প্রতি ফাইলে সর্বোচ্চ ১০MB • সর্বোচ্চ ৫টি ফাইল')}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* File Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="relative bg-ash rounded-2xl p-6 border-2 hover:shadow-lg transition-all" style={{ borderColor: 'var(--color-primary-blue)' }}>
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="absolute -top-3 -right-3 text-white rounded-full p-2 hover:scale-110 shadow-lg z-10 transform transition-all"
                          style={{ backgroundColor: 'var(--color-light-red-dark)' }}
                        >
                          <X className="w-4 h-4" />
                        </button>
                        
                        <div className="text-center">
                          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                            {file.type.startsWith('image/') ? (
                              <span className="text-3xl">📷</span>
                            ) : (
                              <span className="text-3xl">🎥</span>
                            )}
                          </div>
                          <h5 className="font-semibold mb-2 truncate" style={{ color: 'var(--color-light-ash-dark)' }}>{file.name}</h5>
                          <p className="text-sm text-gray-600 mb-1">
                            {(file.size / 1024 / 1024).toFixed(1)} MB
                          </p>
                          <p className="text-xs text-gray-500">
                            {file.type.split('/')[1].toUpperCase()}
                          </p>
                        </div>
                      </div>
                    ))}

                    {/* Add More Button */}
                    {selectedFiles.length < 5 && (
                      <label className="border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-ash transition-all text-center" style={{ borderColor: 'var(--color-primary-blue)' }}>
                        <div className="icon-secondary w-16 h-16 mb-4">
                          <Upload className="w-8 h-8" />
                        </div>
                        <p className="font-semibold mb-1" style={{ color: 'var(--color-light-ash-dark)' }}>
                          {t('Add More', 'আরো যোগ করুন')}
                        </p>
                        <p className="text-xs text-gray-500">
                          ({selectedFiles.length}/5)
                        </p>
                        <input
                          type="file"
                          multiple
                          accept="image/*,video/*"
                          onChange={handleFileSelect}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>

                  {/* Evidence Tips */}
                  <div className="bg-primary border rounded-2xl p-6" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
                    <h5 className="font-bold mb-3 flex items-center" style={{ color: 'var(--color-primary-blue-dark)' }}>
                      <span className="text-2xl mr-3">💡</span>
                      {t('Tips for Better Evidence', 'ভালো প্রমাণের জন্য টিপস')}
                    </h5>
                    <div className="grid md:grid-cols-2 gap-4">
                      <ul className="space-y-2 text-sm" style={{ color: 'var(--color-primary-blue-dark)' }}>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Capture license plate clearly', 'লাইসেন্স প্লেট স্পষ্টভাবে ধরুন')}
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Show the violation in action', 'আইন লঙ্ঘনটি কর্মরত অবস্থায় দেখান')}
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Include surrounding context', 'চারপাশের প্রসঙ্গ অন্তর্ভুক্ত করুন')}
                        </li>
                      </ul>
                      <ul className="space-y-2 text-sm" style={{ color: 'var(--color-primary-blue-dark)' }}>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Good lighting is essential', 'ভালো আলো অপরিহার্য')}
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Avoid shaky or blurry shots', 'কাঁপা বা ঝাপসা শট এড়িয়ে চলুন')}
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">✓</span>
                          {t('Multiple angles preferred', 'একাধিক কোণ পছন্দনীয়')}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={currentStep === 0 ? () => navigate('/dashboard') : prevStep}
              className="btn-secondary flex items-center"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              {currentStep === 0 ? t('Cancel', 'বাতিল') : t('Previous', 'পূর্ববর্তী')}
            </button>

            {currentStep < 3 ? (
              <button
                type="button"
                onClick={nextStep}
                disabled={!canContinueStep(currentStep)}
                className="btn-danger flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t('Next', 'পরবর্তী')}
                <ArrowLeft className="w-5 h-5 ml-2 transform rotate-180" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={submitReportApi.loading || !canContinueStep(currentStep)}
                className="btn-success flex items-center disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg"
              >
                {submitReportApi.loading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    {t('Submitting...', 'জমা দেওয়া হচ্ছে...')}
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2" />
                    {t('Submit Report', 'রিপোর্ট জমা দিন')}
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      </main>
    </div>
  );
}
