import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { SAFETY_TIPS } from '@/shared/constants';
import { Lightbulb, Shield, AlertTriangle } from 'lucide-react';

export default function SafetyTipsCard() {
  const { t } = useLanguage();

  const getRandomTips = (count: number) => {
    const shuffled = [...SAFETY_TIPS].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };

  const randomTips = getRandomTips(3);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'protective_gear':
        return Shield;
      case 'road_rules':
        return AlertTriangle;
      default:
        return Lightbulb;
    }
  };

  return (
    <div className="card-base p-6 md:p-8 bg-success border-2" style={{ borderColor: 'var(--color-light-green-dark)' }}>
      <div className="flex items-center space-x-4 mb-6">
        <div className="icon-success w-12 h-12">
          <AlertTriangle className="w-7 h-7 md:w-8 md:h-8" />
        </div>
        <div>
          <h3 className="text-display-3 font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
            {t('Daily Safety Tips', 'দৈনিক নিরাপত্তা টিপস')}
          </h3>
          <p className="text-body font-medium" style={{ color: 'var(--color-light-green-dark)' }}>
            {t('Stay safe on the roads', 'রাস্তায় নিরাপদ থাকুন')}
          </p>
        </div>
      </div>

      <div className="space-content">
        {randomTips.map((tip) => {
          const IconComponent = getCategoryIcon(tip.category);
          return (
            <div key={tip.id} className="bg-white/80 rounded-xl p-4 md:p-5 border backdrop-blur-sm hover:bg-white/90 transition-all duration-300" style={{ borderColor: 'var(--color-light-green-dark)' }}>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 mt-1">
                  <div className="icon-success w-10 h-10">
                    <IconComponent className="w-5 h-5" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-heading-2 font-semibold mb-2" style={{ color: 'var(--color-light-green-dark)' }}>
                    {t(tip.title_en, tip.title_bn)}
                  </h4>
                  <p className="text-body leading-relaxed" style={{ color: 'var(--color-light-green-dark)' }}>
                    {t(tip.description_en, tip.description_bn)}
                  </p>
                </div>
                <span className="text-2xl md:text-3xl flex-shrink-0">{tip.icon}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 pt-6 border-t" style={{ borderColor: 'var(--color-light-green-dark)' }}>
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 md:p-5 border" style={{ borderColor: 'var(--color-light-green-dark)' }}>
          <p className="text-center text-body font-medium leading-relaxed" style={{ color: 'var(--color-light-green-dark)' }}>
            💡 {t(
              'Following traffic rules saves lives and prevents accidents',
              'ট্রাফিক নিয়ম মেনে চলা জীবন বাঁচায় এবং দুর্ঘটনা প্রতিরোধ করে'
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
