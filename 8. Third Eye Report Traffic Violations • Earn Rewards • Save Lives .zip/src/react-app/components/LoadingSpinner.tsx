import { Loader2 } from 'lucide-react';

export default function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <div className="relative">
        {/* Outer ring */}
        <div className="w-20 h-20 border-4 rounded-full animate-pulse border-light-blue-300"></div>
        {/* Inner spinner */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-12 h-12 animate-spin text-light-blue-600" />
        </div>
      </div>
      <div className="mt-8 text-center space-y-2">
        <p className="text-heading-2 font-semibold" style={{ color: 'var(--text-primary)' }}>Loading...</p>
        <p className="text-body" style={{ color: 'var(--text-secondary)' }}>Please wait while we prepare your experience</p>
      </div>
      
      {/* Loading dots animation */}
      <div className="flex space-x-2 mt-6">
        <div className="w-2 h-2 rounded-full animate-bounce bg-blue-500"></div>
        <div className="w-2 h-2 rounded-full animate-bounce bg-blue-500" style={{ animationDelay: '0.1s' }}></div>
        <div className="w-2 h-2 rounded-full animate-bounce bg-blue-500" style={{ animationDelay: '0.2s' }}></div>
      </div>
    </div>
  );
}
