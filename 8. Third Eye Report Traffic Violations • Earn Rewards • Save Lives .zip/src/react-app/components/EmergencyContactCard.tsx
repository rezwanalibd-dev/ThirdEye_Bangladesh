import { Phone } from 'lucide-react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';

interface EmergencyContact {
  number: string;
  name_en: string;
  name_bn: string;
  description_en: string;
  description_bn: string;
  icon: string;
}

interface EmergencyContactCardProps {
  contact: EmergencyContact;
}

export default function EmergencyContactCard({ contact }: EmergencyContactCardProps) {
  const { language } = useLanguage();

  return (
    <div className="card-base p-6 hover:shadow-lg transition-all duration-200">
      <div className="flex items-center space-x-4 mb-4">
        <div className="text-4xl">{contact.icon}</div>
        <div className="flex-1">
          <h3 className="text-heading-2 font-bold" style={{ color: 'var(--text-primary)' }}>
            {language === 'en' ? contact.name_en : contact.name_bn}
          </h3>
          <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
            {language === 'en' ? contact.description_en : contact.description_bn}
          </p>
        </div>
      </div>
      
      <a
        href={`tel:${contact.number}`}
        className="btn-primary w-full flex items-center justify-center hover:scale-105 transform transition-all"
      >
        <Phone className="w-5 h-5 mr-2" />
        {contact.number}
      </a>
    </div>
  );
}
