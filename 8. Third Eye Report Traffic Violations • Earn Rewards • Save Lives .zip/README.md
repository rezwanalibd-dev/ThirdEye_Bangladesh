# Third Eye Bangladesh 🚗👁️

**Making Bangladesh roads safer through community reporting**

Third Eye Bangladesh is a comprehensive traffic violation reporting platform that empowers citizens to report traffic violations, earn rewards, and contribute to road safety across Bangladesh.

## 🌟 Key Features

- **📱 Easy Reporting**: Snap photos and report violations instantly
- **💰 Earn Rewards**: Get 20% commission on verified reports
- **🔒 Secure Platform**: KYC verified with instant mobile wallet payments
- **🌍 Bilingual**: Complete Bengali and English support
- **🔄 Real-time Tracking**: Monitor your reports and earnings
- **🚨 Anonymous Crime Reporting**: Report social crimes safely and anonymously

## 🚀 Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS with custom design system
- **Backend**: Cloudflare Workers + Hono
- **Database**: Cloudflare D1 (SQLite)
- **Mobile**: Capacitor for iOS/Android
- **Authentication**: Custom JWT-based system
- **Payments**: Mobile wallet integration (bKash, Nagad, Rocket, etc.)

## 📋 Prerequisites

- Node.js 18+ 
- npm or bun
- Cloudflare account (for deployment)

## 🛠️ Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/third-eye-bangladesh.git
   cd third-eye-bangladesh
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   bun install
   ```

3. **Set up environment variables**
   ```bash
   # Copy example env file
   cp .env.example .env.local
   
   # Edit .env.local with your configuration
   ```

4. **Initialize database**
   ```bash
   # Run database migrations
   npx wrangler d1 migrations apply third-eye-db --local
   ```

5. **Start development server**
   ```bash
   npm run dev
   # or
   bun run dev
   ```

   The app will be available at `http://localhost:5173`

## 📱 Mobile App Development

### iOS Setup
```bash
npx cap add ios
npx cap sync ios
npx cap open ios
```

### Android Setup
```bash
npx cap add android
npx cap sync android
npx cap open android
```

## 🚀 Deployment

### Web Deployment (Cloudflare)
```bash
# Build the project
npm run build

# Deploy to Cloudflare
npx wrangler deploy
```

### Mobile App Deployment
Follow the detailed guides in:
- [`ANDROID_PUBLISHING_GUIDE.md`](./ANDROID_PUBLISHING_GUIDE.md)
- [`IOS_PUBLISHING_GUIDE.md`](./IOS_PUBLISHING_GUIDE.md)

## 🎯 Target URL

The production app will be deployed at: **[thirdeyebangladesh.com](https://thirdeyebangladesh.com)**

## 📊 Database Schema

The app uses a comprehensive database schema including:
- User management and authentication
- KYC and biometric verification
- Traffic violation reporting
- Payment and reward tracking
- Social crime reporting (anonymous)

## 🔐 Security Features

- **KYC Verification**: Identity verification through NID/Driving License
- **Biometric Verification**: Facial recognition for additional security
- **Anonymous Reporting**: Secure social crime reporting
- **Session Management**: Secure JWT-based authentication
- **Data Encryption**: All sensitive data is encrypted

## 🌐 Supported Platforms

- **Web Browsers**: Chrome, Firefox, Safari, Edge
- **Mobile**: iOS 12+, Android 8+
- **Languages**: English, Bengali (বাংলা)

## 📈 Business Model

- **Commission-based**: Users earn 20% of traffic fine amounts
- **Digital Payments**: Integrated with Bangladesh mobile wallets
- **Government Partnership**: Working with DMP and BRTA

## 🤝 Contributing

We welcome contributions! Please read our contributing guidelines and submit pull requests.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

For support, email support@thirdeyebangladesh.com or create an issue on GitHub.

## 🙏 Acknowledgments

- Bangladesh Road Transport Authority (BRTA)
- Dhaka Metropolitan Police (DMP)
- All citizen reporters making roads safer

---

**Together, we're making Bangladesh roads safer, one report at a time! 🇧🇩**
