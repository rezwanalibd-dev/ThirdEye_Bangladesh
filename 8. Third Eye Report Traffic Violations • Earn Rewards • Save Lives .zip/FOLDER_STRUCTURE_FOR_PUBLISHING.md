# Third Eye Bangladesh - Folder Structure for App Store Publishing

## Complete Project Structure

```
third-eye-bangladesh/
│
├── 📱 MOBILE APP CONFIGURATION
│   ├── android/                           # Android native project
│   │   ├── app/
│   │   │   ├── src/main/
│   │   │   │   ├── AndroidManifest.xml    # App permissions & config
│   │   │   │   ├── res/
│   │   │   │   │   ├── drawable/          # App icons (all densities)
│   │   │   │   │   │   ├── ic_launcher.png (48dp, 72dp, 96dp, 144dp, 192dp)
│   │   │   │   │   │   └── splash.png
│   │   │   │   │   ├── mipmap/            # Launcher icons
│   │   │   │   │   ├── values/
│   │   │   │   │   │   ├── strings.xml    # App name & text
│   │   │   │   │   │   ├── colors.xml     # Brand colors
│   │   │   │   │   │   └── styles.xml     # App theme
│   │   │   │   │   └── xml/
│   │   │   │   │       └── config.xml     # Capacitor config
│   │   │   ├── build.gradle               # App build config
│   │   │   └── google-services.json       # Firebase config (if needed)
│   │   ├── gradle/                        # Gradle wrapper
│   │   └── build.gradle                   # Project build config
│   │
│   ├── ios/                               # iOS native project
│   │   ├── App/
│   │   │   ├── App/
│   │   │   │   ├── Info.plist             # iOS app configuration
│   │   │   │   ├── Assets.xcassets/       # App icons & images
│   │   │   │   │   ├── AppIcon.appiconset/
│   │   │   │   │   └── Splash.imageset/
│   │   │   │   ├── GoogleService-Info.plist # Firebase (if needed)
│   │   │   │   └── Resources/
│   │   │   └── App.xcodeproj/             # Xcode project
│   │   └── Podfile                        # CocoaPods dependencies
│   │
│   └── capacitor.config.ts                # Capacitor configuration
│
├── 🌐 WEB APPLICATION
│   ├── src/
│   │   ├── react-app/                     # React frontend
│   │   │   ├── components/                # Reusable UI components
│   │   │   │   ├── BackButton.tsx
│   │   │   │   ├── LoadingSpinner.tsx
│   │   │   │   ├── ProtectedRoute.tsx
│   │   │   │   ├── ViolationCard.tsx
│   │   │   │   ├── EmergencyContactCard.tsx
│   │   │   │   ├── HierarchicalEmergencyContacts.tsx
│   │   │   │   ├── SafetyTipsCard.tsx
│   │   │   │   └── QuickCameraButton.tsx
│   │   │   │
│   │   │   ├── contexts/                  # React Context providers
│   │   │   │   ├── AuthContext.tsx        # Authentication state
│   │   │   │   └── LanguageContext.tsx    # i18n language state
│   │   │   │
│   │   │   ├── hooks/                     # Custom React hooks
│   │   │   │   └── useApi.ts              # API call hook
│   │   │   │
│   │   │   ├── pages/                     # Page components
│   │   │   │   ├── Home.tsx               # Landing page
│   │   │   │   ├── Signup.tsx             # User registration
│   │   │   │   ├── Signin.tsx             # User login
│   │   │   │   ├── OTPVerification.tsx    # OTP verification
│   │   │   │   ├── IdentityVerification.tsx # KYC document upload
│   │   │   │   ├── BiometricVerification.tsx # Facial verification
│   │   │   │   ├── Setup.tsx              # Profile setup wizard
│   │   │   │   ├── Dashboard.tsx          # Main dashboard
│   │   │   │   ├── Report.tsx             # Traffic violation reporting
│   │   │   │   ├── SocialCrime.tsx        # Anonymous crime reporting
│   │   │   │   ├── Cases.tsx              # Case management
│   │   │   │   ├── Profile.tsx            # User profile
│   │   │   │   ├── EmergencyDirectory.tsx # Emergency contacts
│   │   │   │   ├── VehicleRules.tsx       # Traffic rules info
│   │   │   │   ├── TrafficFines.tsx       # Fine information
│   │   │   │   ├── Features.tsx           # App features page
│   │   │   │   └── AuthCallback.tsx       # Auth redirect handler
│   │   │   │
│   │   │   ├── App.tsx                    # Root React component
│   │   │   ├── main.tsx                   # React entry point
│   │   │   ├── index.css                  # Global styles
│   │   │   └── vite-env.d.ts              # Vite type definitions
│   │   │
│   │   ├── worker/                        # Cloudflare Worker backend
│   │   │   └── index.ts                   # API routes & handlers
│   │   │
│   │   └── shared/                        # Shared code
│   │       ├── types.ts                   # TypeScript interfaces
│   │       └── constants.ts               # App constants
│   │
│   ├── public/                            # Static assets
│   │   ├── icons/                         # App icons
│   │   └── images/                        # Images
│   │
│   └── dist/                              # Production build output
│       ├── client/                        # Frontend build
│       └── worker/                        # Backend build
│
├── 📚 DOCUMENTATION
│   ├── docs/
│   │   ├── api/                           # API documentation
│   │   ├── guides/                        # User guides
│   │   └── architecture/                  # Technical architecture
│   │
│   ├── README.md                          # Main readme
│   ├── PRIVACY_POLICY.md                  # Privacy policy
│   ├── TERMS_OF_SERVICE.md                # Terms of service
│   ├── APP_STORE_PREPARATION.md           # Publishing checklist
│   ├── MOBILE_RESPONSIVENESS_TEST.md      # Mobile testing results
│   ├── FEATURE_TESTING_CHECKLIST.md       # Feature testing status
│   ├── ANDROID_PUBLISHING_GUIDE.md        # Android publishing steps
│   ├── IOS_PUBLISHING_GUIDE.md            # iOS publishing steps
│   ├── MOBILE_DEPLOYMENT_GUIDE.md         # Deployment instructions
│   └── WEB_BROWSER_TESTING_GUIDE.md       # Browser testing guide
│
├── 🎨 DESIGN ASSETS
│   ├── design/
│   │   ├── app-icons/                     # Icon source files
│   │   │   ├── icon-512x512.png          # Base icon
│   │   │   ├── icon-1024x1024.png        # iOS App Store
│   │   │   └── adaptive-icon/            # Android adaptive icon
│   │   │       ├── foreground.png
│   │   │       └── background.png
│   │   │
│   │   ├── screenshots/                   # App store screenshots
│   │   │   ├── ios/
│   │   │   │   ├── 5.5-inch/             # iPhone 8 Plus
│   │   │   │   ├── 6.5-inch/             # iPhone 14 Pro Max
│   │   │   │   └── 12.9-inch/            # iPad Pro
│   │   │   └── android/
│   │   │       ├── phone/
│   │   │       └── tablet/
│   │   │
│   │   ├── feature-graphics/              # Store listing graphics
│   │   │   ├── google-play-feature.png   # 1024x500
│   │   │   └── app-store-preview.mp4     # iOS preview video
│   │   │
│   │   └── splash-screens/                # Splash screen variants
│   │       ├── ios/
│   │       └── android/
│   │
│   └── branding/
│       ├── logo.svg                       # Vector logo
│       ├── logo-variations/               # Logo variants
│       └── brand-guidelines.md            # Brand identity guide
│
├── 🧪 TESTING
│   ├── tests/
│   │   ├── unit/                          # Unit tests
│   │   ├── integration/                   # Integration tests
│   │   ├── e2e/                          # End-to-end tests
│   │   └── screenshots/                   # Test screenshots
│   │
│   └── test-devices/
│       ├── ios-devices.md                 # iOS test device list
│       └── android-devices.md             # Android test device list
│
├── 🔧 CONFIGURATION FILES
│   ├── package.json                       # NPM dependencies
│   ├── package-lock.json                  # Locked dependencies
│   ├── tsconfig.json                      # TypeScript config
│   ├── vite.config.ts                     # Vite build config
│   ├── tailwind.config.js                 # Tailwind CSS config
│   ├── postcss.config.js                  # PostCSS config
│   ├── eslint.config.js                   # ESLint config
│   ├── wrangler.toml                      # Cloudflare config
│   ├── .gitignore                         # Git ignore rules
│   └── .env.example                       # Environment variables template
│
├── 📦 DEPLOYMENT
│   ├── .github/
│   │   └── workflows/                     # CI/CD pipelines
│   │       ├── deploy-web.yml            # Web deployment
│   │       ├── build-android.yml         # Android build
│   │       └── build-ios.yml             # iOS build
│   │
│   ├── scripts/                           # Build scripts
│   │   ├── build-mobile.sh               # Mobile build script
│   │   ├── deploy-cloudflare.sh          # Web deployment script
│   │   └── generate-icons.sh             # Icon generation
│   │
│   └── releases/                          # Release builds
│       ├── android/
│       │   ├── app-release.aab           # Android App Bundle
│       │   └── app-release.apk           # Android APK
│       └── ios/
│           └── ThirdEye.ipa              # iOS IPA
│
└── 📄 LEGAL & COMPLIANCE
    ├── LICENSE                            # Software license
    ├── CONTRIBUTING.md                    # Contribution guidelines
    ├── CODE_OF_CONDUCT.md                 # Code of conduct
    └── SECURITY.md                        # Security policy
```

---

## Key Folders Explained

### 1. `/android` - Android Native Project
**Purpose**: Native Android app wrapper using Capacitor
- Contains all Android-specific code and resources
- Managed by Android Studio
- Generated APK/AAB files for Google Play Store

**Key Files**:
- `AndroidManifest.xml`: App permissions (camera, location, internet)
- `build.gradle`: Build configuration and dependencies
- `res/`: All app resources (icons, strings, layouts)

### 2. `/ios` - iOS Native Project
**Purpose**: Native iOS app wrapper using Capacitor
- Contains all iOS-specific code and resources
- Managed by Xcode
- Generated IPA file for Apple App Store

**Key Files**:
- `Info.plist`: App configuration and permissions
- `Assets.xcassets`: App icons and images
- `Podfile`: CocoaPods dependencies

### 3. `/src/react-app` - React Frontend
**Purpose**: Core application UI and user experience
- React 19 with TypeScript
- Component-based architecture
- Responsive design with Tailwind CSS

**Organization**:
- **Components**: Reusable UI elements (buttons, cards, etc.)
- **Pages**: Full page components (routes)
- **Contexts**: Global state management
- **Hooks**: Custom React hooks for logic reuse

### 4. `/src/worker` - Cloudflare Worker Backend
**Purpose**: API server and business logic
- Serverless backend on Cloudflare Workers
- Hono framework for routing
- D1 database for data storage

**Key Features**:
- Authentication endpoints
- Case management
- Payment processing
- File uploads

### 5. `/src/shared` - Shared Code
**Purpose**: Code used by both frontend and backend
- TypeScript type definitions
- Constants and configuration
- Validation schemas (Zod)

### 6. `/docs` - Documentation
**Purpose**: All project documentation
- User guides
- API documentation
- Publishing guides
- Testing reports

### 7. `/design` - Design Assets
**Purpose**: Visual assets for app stores and branding
- App icons (all sizes)
- Screenshots for store listings
- Feature graphics
- Splash screens

### 8. `/tests` - Testing Files
**Purpose**: Automated and manual tests
- Unit tests (Jest)
- Integration tests
- E2E tests (Playwright)
- Test screenshots

---

## File Size Requirements

### Google Play Store
- **App Icon**: 512x512 PNG (32-bit with alpha)
- **Feature Graphic**: 1024x500 PNG/JPG
- **Screenshots**: 
  - Phone: 320dp-3840dp wide
  - Tablet: 7-inch and 10-inch
  - Minimum 2, maximum 8 per device type
- **App Size**: < 150 MB (without expansion files)

### Apple App Store
- **App Icon**: 1024x1024 PNG (no alpha)
- **Screenshots**:
  - 6.5-inch (1242x2688 or 1284x2778)
  - 5.5-inch (1242x2208)
  - 12.9-inch iPad Pro (2048x2732)
- **App Preview Video**: Up to 30 seconds, max 500 MB
- **App Size**: < 4 GB (over-the-air limit: 200 MB)

---

## Asset Organization Best Practices

### 1. App Icons
```
design/app-icons/
├── source/
│   └── icon.svg                 # Vector source
├── ios/
│   └── AppIcon.appiconset/     # Xcode asset catalog
│       ├── icon-20@2x.png
│       ├── icon-20@3x.png
│       ├── icon-29@2x.png
│       ├── icon-29@3x.png
│       ├── icon-40@2x.png
│       ├── icon-40@3x.png
│       ├── icon-60@2x.png
│       ├── icon-60@3x.png
│       └── icon-1024.png       # App Store
└── android/
    ├── mipmap-mdpi/            # 48x48
    ├── mipmap-hdpi/            # 72x72
    ├── mipmap-xhdpi/           # 96x96
    ├── mipmap-xxhdpi/          # 144x144
    ├── mipmap-xxxhdpi/         # 192x192
    └── playstore.png           # 512x512
```

### 2. Screenshots
```
design/screenshots/
├── template.sketch             # Design template
├── ios/
│   ├── 6.5-inch/              # iPhone 14 Pro Max
│   │   ├── 01-home.png
│   │   ├── 02-report.png
│   │   ├── 03-dashboard.png
│   │   └── 04-cases.png
│   └── 12.9-inch/             # iPad Pro
└── android/
    ├── phone/
    │   ├── 01-home.png
    │   ├── 02-report.png
    │   ├── 03-dashboard.png
    │   └── 04-cases.png
    └── tablet/
```

---

## Code Organization Guidelines

### 1. Component Structure
```typescript
// Good: Single responsibility, well-named
components/
├── Button.tsx                  # Generic button
├── Card.tsx                    # Generic card
├── EmergencyContactCard.tsx    # Specific use case
└── ViolationCard.tsx           # Specific use case
```

### 2. Page Structure
```typescript
// Good: Clear hierarchy
pages/
├── Home.tsx                    # Public pages
├── Signup.tsx
├── Signin.tsx
├── Dashboard.tsx               # Protected pages
├── Report.tsx
└── Profile.tsx
```

### 3. Context Structure
```typescript
// Good: Separate concerns
contexts/
├── AuthContext.tsx             # Authentication state
├── LanguageContext.tsx         # i18n state
└── ThemeContext.tsx            # Theme state (if needed)
```

---

## Build Output Structure

### Production Build
```
dist/
├── client/                     # Frontend static files
│   ├── index.html
│   ├── assets/
│   │   ├── index-[hash].js    # JS bundle
│   │   └── index-[hash].css   # CSS bundle
│   └── images/
└── worker/                     # Backend worker
    └── index.js               # Compiled worker
```

### Mobile Build
```
android/app/build/outputs/
├── apk/
│   └── release/
│       └── app-release.apk    # Release APK
└── bundle/
    └── release/
        └── app-release.aab    # App Bundle (preferred)

ios/build/
└── ThirdEye.ipa              # iOS app package
```

---

## Version Control (.gitignore)

### Files to Ignore
```gitignore
# Dependencies
node_modules/
.pnp/

# Build outputs
dist/
build/
.cache/

# Environment files
.env
.env.local
.env.production

# IDE
.vscode/
.idea/
*.swp

# Mobile builds
android/app/build/
android/.gradle/
ios/App/build/
ios/Pods/

# OS files
.DS_Store
Thumbs.db

# Secrets
*.keystore
*.p12
*.mobileprovision
google-services.json
GoogleService-Info.plist
```

---

## Deployment Checklist

### Before Each Release
- [ ] Update version in package.json
- [ ] Update version in capacitor.config.ts
- [ ] Update version in Android build.gradle
- [ ] Update version in iOS Info.plist
- [ ] Run all tests
- [ ] Build for production
- [ ] Test on real devices
- [ ] Update CHANGELOG.md
- [ ] Create git tag (v1.0.0)
- [ ] Generate release notes

---

## Maintenance Guidelines

### Regular Updates
1. **Weekly**: Check for security updates
2. **Monthly**: Review app store analytics
3. **Quarterly**: Major feature releases
4. **Yearly**: Major version updates

### Backup Strategy
- Daily: Database backups
- Weekly: Full codebase backup
- Monthly: Archive release builds
- Yearly: Complete project archive

---

**Last Updated**: November 6, 2025
**Version**: 1.0.0
**Status**: Ready for App Store Submission
