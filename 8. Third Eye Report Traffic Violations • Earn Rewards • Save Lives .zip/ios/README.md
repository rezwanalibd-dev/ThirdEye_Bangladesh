# Third Eye iOS App

This directory contains the iOS version of the Third Eye mobile application for reporting traffic violations in Bangladesh.

## Prerequisites

- macOS with Xcode 12 or later
- iOS 13.0 or later
- Node.js and npm
- Capacitor CLI
- Apple Developer Account (for App Store submission)

## Setup Instructions

1. Install dependencies:
```bash
cd /path/to/third-eye-app
npm install
```

2. Build the web app:
```bash
npm run build
```

3. Add iOS platform:
```bash
npx cap add ios
```

4. Sync files to iOS:
```bash
npx cap sync ios
```

5. Open in Xcode:
```bash
npx cap open ios
```

## Build for Production

1. Build the web app for production:
```bash
npm run build
```

2. Sync the latest changes:
```bash
npx cap sync ios
```

3. Open Xcode and build for distribution to App Store

## App Features

- Traffic violation reporting with camera
- GPS location detection
- Real-time case tracking
- Digital wallet integration for payments
- Emergency contact access
- Bilingual support (English/Bengali)

## Configuration

The app is configured in `capacitor.config.ts` with:
- App ID: `com.thirdeyebangladesh.app`
- App Name: `Third Eye`
- Web directory: `dist/client`

## Permissions

The app requires the following permissions (configured in Info.plist):
- Camera (NSCameraUsageDescription)
- Location (NSLocationWhenInUseUsageDescription)
- Photo Library (NSPhotoLibraryUsageDescription)

## App Store Submission

1. Configure signing certificates in Xcode
2. Build for distribution
3. Upload to App Store Connect
4. Prepare store listing with screenshots
5. Submit for review

## iOS-Specific Considerations

- Camera access requires user permission
- Background location access may need special approval
- App Transport Security settings for API calls
- Dark mode support
- iPhone and iPad compatibility

For detailed setup instructions, see the main README.md file.
