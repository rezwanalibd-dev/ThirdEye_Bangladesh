
-- Users table for additional user data beyond what's in Mocha Users Service
CREATE TABLE user_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE,
  user_type TEXT NOT NULL CHECK (user_type IN ('citizen', 'officer')),
  full_name TEXT NOT NULL,
  phone_number TEXT,
  nid_number TEXT,
  driving_license TEXT,
  department TEXT,
  badge_id TEXT,
  kyc_status TEXT DEFAULT 'pending' CHECK (kyc_status IN ('pending', 'verified', 'rejected')),
  kyc_documents TEXT, -- JSON array of document URLs
  wallet_provider TEXT,
  wallet_number TEXT,
  wallet_verified BOOLEAN DEFAULT FALSE,
  total_reports INTEGER DEFAULT 0,
  approved_reports INTEGER DEFAULT 0,
  total_rewards REAL DEFAULT 0.0,
  is_active BOOLEAN DEFAULT TRUE,
  preferred_language TEXT DEFAULT 'en' CHECK (preferred_language IN ('en', 'bn')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Violation types with fines and rewards
CREATE TABLE violation_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_en TEXT NOT NULL,
  name_bn TEXT NOT NULL,
  description_en TEXT,
  description_bn TEXT,
  fine_amount REAL NOT NULL,
  reward_percentage REAL DEFAULT 0.20,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cases/Reports table
CREATE TABLE cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_number TEXT NOT NULL UNIQUE,
  reporter_id TEXT NOT NULL,
  violation_type_id INTEGER NOT NULL,
  vehicle_number TEXT NOT NULL,
  location_description TEXT,
  latitude REAL,
  longitude REAL,
  description TEXT,
  evidence_urls TEXT, -- JSON array of image/video URLs
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'approved', 'rejected', 'completed')),
  fine_amount REAL DEFAULT 0.0,
  reward_amount REAL DEFAULT 0.0,
  reviewing_officer_id TEXT,
  officer_notes TEXT,
  rejection_reason TEXT,
  reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TIMESTAMP,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (violation_type_id) REFERENCES violation_types(id)
);

-- Payments table for tracking commission payments
CREATE TABLE payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  payment_gateway TEXT NOT NULL,
  transaction_id TEXT,
  amount REAL NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  payment_type TEXT NOT NULL CHECK (payment_type IN ('commission', 'fine')),
  gateway_response TEXT, -- JSON response from payment gateway
  initiated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id)
);

-- Notifications table
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  title_en TEXT NOT NULL,
  title_bn TEXT NOT NULL,
  message_en TEXT NOT NULL,
  message_bn TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('case_update', 'payment', 'kyc', 'general')),
  related_case_id INTEGER,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (related_case_id) REFERENCES cases(id)
);

-- Create indexes for performance
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_cases_reporter_id ON cases(reporter_id);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_case_number ON cases(case_number);
CREATE INDEX idx_payments_case_id ON payments(case_id);
CREATE INDEX idx_payments_user_id ON payments(user_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
