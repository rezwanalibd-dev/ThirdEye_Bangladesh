
DELETE FROM violation_types;
