// Third Eye App Constants - Based on Bangladesh Traffic Rules
export const APP_NAME = 'Third Eye';
export const APP_TAGLINE = 'Report Traffic Violations • Earn Rewards • Save Lives';

// Vehicle Types (Exact match with requirements)
export const VEHICLE_TYPES = [
  'Motorcycle',
  'Car', 
  'Bus',
  'Truck',
  'E-Rickshaw',
  'CNG'
] as const;

// Base Violation Types (Universal + Vehicle-Specific as per requirements)
export const BASE_VIOLATIONS = [
  // Universal Violations (All Vehicles)
  {
    id: 'red_light_jumping',
    name_en: 'Red Light Jumping',
    name_bn: 'রেড লাইট জাম্পিং',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'wrong_side_driving',
    name_en: 'Wrong Side Driving',
    name_bn: 'ভুল দিক দিয়ে গাড়ি চালানো',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'speeding',
    name_en: 'Speeding',
    name_bn: 'গতি আইন লঙ্ঘন',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'using_mobile_phone',
    name_en: 'Using Mobile Phone',
    name_bn: 'মোবাইল ফোন ব্যবহার',
    fine_amount: 2000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'illegal_parking',
    name_en: 'Illegal Parking',
    name_bn: 'অবৈধ পার্কিং',
    fine_amount: 4000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'no_license',
    name_en: 'No License',
    name_bn: 'লাইসেন্স নেই',
    fine_amount: 25000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  // Vehicle-Specific Violations
  {
    id: 'footpath_driving',
    name_en: 'Driving on a Footpath',
    name_bn: 'ফুটপাতে গাড়ি চালানো',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: ['Motorcycle', 'CNG', 'E-Rickshaw']
  },
  {
    id: 'no_helmet',
    name_en: 'Not Wearing Helmet',
    name_bn: 'হেলমেট না পরা',
    fine_amount: 1000,
    reward_percentage: 0.20,
    applies_to: ['Motorcycle']
  },
  {
    id: 'no_seatbelt',
    name_en: 'Not Wearing Seatbelt',
    name_bn: 'সিটবেল্ট না পরা',
    fine_amount: 1000,
    reward_percentage: 0.20,
    applies_to: ['Car', 'Bus', 'Truck']
  },
  {
    id: 'overloading',
    name_en: 'Vehicle Overloading',
    name_bn: 'যানবাহনে অতিরিক্ত লোড',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: ['Bus', 'Truck', 'CNG', 'E-Rickshaw']
  },
  {
    id: 'hydraulic_horn',
    name_en: 'Using Hydraulic Horn',
    name_bn: 'হাইড্রোলিক হর্ন ব্যবহার',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: ['Bus', 'Truck']
  }
] as const;

// Get violations based on vehicle type
export const getViolationsForVehicle = (vehicleType: string) => {
  return BASE_VIOLATIONS.filter(violation => 
    violation.applies_to === 'all' || 
    (Array.isArray(violation.applies_to) && violation.applies_to.includes(vehicleType))
  );
};

// Payment Methods (Digital Wallets in Bangladesh)
export const PAYMENT_PROVIDERS = [
  { 
    name: 'bKash', 
    color: 'from-pink-500 to-pink-600',
    icon: '💳',
    popular: true 
  },
  { 
    name: 'Nagad', 
    color: 'from-orange-500 to-red-600',
    icon: '📱',
    popular: true 
  },
  { 
    name: 'Rocket', 
    color: 'from-blue-500 to-purple-600',
    icon: '🚀',
    popular: true 
  },
  { 
    name: 'Upay', 
    color: 'from-green-500 to-green-600',
    icon: '💰',
    popular: false 
  },
  { 
    name: 'mCash', 
    color: 'from-purple-500 to-purple-600',
    icon: '💵',
    popular: false 
  },
  { 
    name: 'CellFin', 
    color: 'from-yellow-500 to-orange-500',
    icon: '📞',
    popular: false 
  },
  { 
    name: 'SureCash', 
    color: 'from-blue-500 to-blue-600',
    icon: '💎',
    popular: false 
  },
  { 
    name: 'Trust Money', 
    color: 'from-gray-700 to-gray-800',
    icon: '🏦',
    popular: false 
  }
] as const;

// Commission Rate (20%)
export const COMMISSION_RATE = 0.20;

// Social Crime Categories
export const SOCIAL_CRIME_CATEGORIES = [
  {
    id: 'theft',
    name_en: 'Theft',
    name_bn: 'চুরি',
    icon: '🔐',
    anonymous: true
  },
  {
    id: 'fight',
    name_en: 'Public Fighting',
    name_bn: 'পাবলিক মারামারি',
    icon: '👊',
    anonymous: true
  },
  {
    id: 'youth_gang',
    name_en: 'Youth Gang Activity',
    name_bn: 'যুব গ্যাং কার্যকলাপ',
    icon: '👥',
    anonymous: true
  },
  {
    id: 'corruption',
    name_en: 'Corruption',
    name_bn: 'দুর্নীতি',
    icon: '💸',
    anonymous: true
  },
  {
    id: 'bribery',
    name_en: 'Bribery',
    name_bn: 'ঘুষ',
    icon: '🤝',
    anonymous: true
  },
  {
    id: 'robbery',
    name_en: 'Robbery',
    name_bn: 'ডাকাতি',
    icon: '💰',
    anonymous: true
  },
  {
    id: 'social_violence',
    name_en: 'Social Violence',
    name_bn: 'সামাজিক সহিংসতা',
    icon: '⚡',
    anonymous: true
  },
  {
    id: 'serious_crime',
    name_en: 'Serious Crime',
    name_bn: 'গুরুতর অপরাধ',
    icon: '🚨',
    anonymous: true
  }
] as const;

// Emergency Numbers Bangladesh - Complete National Directory
export const EMERGENCY_CONTACTS = {
  urgent_emergency: [
    {
      number: "999",
      name_en: "National Emergency Service",
      name_bn: "জাতীয় জরুরি সেবা",
      description_en: "Central helpline for police, fire, and ambulance (24/7, free)",
      description_bn: "পুলিশ, ফায়ার এবং অ্যাম্বুলেন্সের জন্য কেন্দ্রীয় হেল্পলাইন",
      icon: "🚨"
    },
    {
      number: "16163",
      name_en: "Fire Service and Civil Defence",
      name_bn: "ফায়ার সার্ভিস ও সিভিল ডিফেন্স",
      description_en: "For fires, rescue, or accidents",
      description_bn: "আগুন, উদ্ধার বা দুর্ঘটনার জন্য",
      icon: "🚒"
    },
    {
      number: "01713-398134",
      name_en: "Ambulance (Govt. & Private)",
      name_bn: "অ্যাম্বুলেন্স (সরকারি ও বেসরকারি)",
      description_en: "999 connects to nearest available ambulance",
      description_bn: "৯৯৯ নিকটতম উপলব্ধ অ্যাম্বুলেন্সের সাথে সংযোগ",
      icon: "🚑"
    },
    {
      number: "16263",
      name_en: "National Health Hotline",
      name_bn: "জাতীয় স্বাস্থ্য হটলাইন",
      description_en: "Medical advice, hospital info, COVID info",
      description_bn: "চিকিৎসা পরামর্শ, হাসপাতালের তথ্য, কোভিড তথ্য",
      icon: "💊"
    }
  ],
  
  law_enforcement: [
    {
      number: "100",
      name_en: "Bangladesh Police HQ",
      name_bn: "বাংলাদেশ পুলিশ সদর দপ্তর",
      description_en: "999 replaced this officially",
      description_bn: "৯৯৯ এটিকে আনুষ্ঠানিকভাবে প্রতিস্থাপন করেছে",
      icon: "🚔"
    },
    {
      number: "01320-040244",
      name_en: "Traffic Police",
      name_bn: "ট্রাফিক পুলিশ",
      description_en: "Traffic Accidents",
      description_bn: "ট্রাফিক দুর্ঘটনা",
      icon: "🚓"
    },
    {
      number: "16107",
      name_en: "Road Transport (BRTA)",
      name_bn: "সড়ক পরিবহন (বিআরটিএ)",
      description_en: "Vehicle registration and licensing",
      description_bn: "যানবাহন নিবন্ধন এবং লাইসেন্সিং",
      icon: "🚗"
    },
    {
      number: "01769693535",
      name_en: "Cyber Crime Complaint (CID)",
      name_bn: "সাইবার ক্রাইম অভিযোগ (সিআইডি)",
      description_en: "Online fraud or harassment",
      description_bn: "অনলাইন জালিয়াতি বা হয়রানি",
      icon: "💻"
    },
    {
      number: "16121",
      name_en: "Consumer Rights Authority",
      name_bn: "ভোক্তা অধিকার কর্তৃপক্ষ",
      description_en: "Unfair business, fraud, price gouging",
      description_bn: "অন্যায্য ব্যবসা, জালিয়াতি, মূল্য বৃদ্ধি",
      icon: "🛡️"
    }
  ],
  
  social_protection: [
    {
      number: "109",
      name_en: "Women & Child Helpline",
      name_bn: "নারী ও শিশু হেল্পলাইন",
      description_en: "Legal, medical & counselling support",
      description_bn: "আইনি, চিকিৎসা ও পরামর্শ সহায়তা",
      icon: "👩‍👧"
    },
    {
      number: "1098",
      name_en: "Child Helpline (DSS)",
      name_bn: "শিশু হেল্পলাইন (সমাজসেবা অধিদপ্তর)",
      description_en: "Department of Social Services",
      description_bn: "সমাজসেবা অধিদপ্তর",
      icon: "🧒"
    },
    {
      number: "01730336699",
      name_en: "BRAC Legal Aid",
      name_bn: "ব্র্যাক আইনি সহায়তা",
      description_en: "Free Legal Help",
      description_bn: "বিনামূল্যে আইনি সহায়তা",
      icon: "⚖️"
    },
    {
      number: "01796132524",
      name_en: "Acid Survivors Foundation",
      name_bn: "এসিড সারভাইভার ফাউন্ডেশন",
      description_en: "Support for acid attack victims",
      description_bn: "এসিড হামলার শিকারদের সহায়তা",
      icon: "🛡️"
    },
    {
      number: "01713373191",
      name_en: "Police Victim Support Centre",
      name_bn: "পুলিশ ভিকটিম সাপোর্ট সেন্টার",
      description_en: "Support for crime victims (Tejgaon)",
      description_bn: "অপরাধের শিকারদের সহায়তা (তেজগাঁও)",
      icon: "🚔"
    }
  ],
  
  health_medical: [
    {
      number: "02-55165088",
      name_en: "Dhaka Medical College Hospital",
      name_bn: "ঢাকা মেডিকেল কলেজ হাসপাতাল",
      description_en: "Emergency Contact",
      description_bn: "জরুরি যোগাযোগ",
      icon: "🏥"
    },
    {
      number: "10616",
      name_en: "Square Hospital",
      name_bn: "স্কয়ার হাসপাতাল",
      description_en: "Private Hospital Emergency",
      description_bn: "প্রাইভেট হাসপাতাল জরুরি",
      icon: "🏥"
    },
    {
      number: "10666",
      name_en: "United Hospital",
      name_bn: "ইউনাইটেড হাসপাতাল",
      description_en: "Emergency Services",
      description_bn: "জরুরি সেবা",
      icon: "🏥"
    },
    {
      number: "10678",
      name_en: "Evercare Hospital Dhaka",
      name_bn: "এভারকেয়ার হাসপাতাল ঢাকা",
      description_en: "Emergency & Critical Care",
      description_bn: "জরুরি ও গুরুত্বপূর্ণ চিকিৎসা",
      icon: "🏥"
    },
    {
      number: "02-48114040",
      name_en: "Ibn Sina Hospital",
      name_bn: "ইবনে সিনা হাসপাতাল",
      description_en: "Medical Emergency",
      description_bn: "চিকিৎসা জরুরি",
      icon: "🏥"
    },
    {
      number: "10606",
      name_en: "Labaid Hospital",
      name_bn: "ল্যাবএইড হাসপাতাল",
      description_en: "Emergency Care",
      description_bn: "জরুরি চিকিৎসা",
      icon: "🏥"
    }
  ],
  
  transport_utilities: [
    {
      number: "02-8901904",
      name_en: "Hazrat Shahjalal Airport",
      name_bn: "হযরত শাহজালাল বিমানবন্দর",
      description_en: "Airport Information",
      description_bn: "বিমানবন্দরের তথ্য",
      icon: "✈️"
    },
    {
      number: "131",
      name_en: "Bangladesh Railway Info",
      name_bn: "বাংলাদেশ রেলওয়ে তথ্য",
      description_en: "Train schedules and bookings",
      description_bn: "ট্রেনের সময়সূচী এবং বুকিং",
      icon: "🚂"
    },
    {
      number: "02-8901600",
      name_en: "Biman Bangladesh Airlines",
      name_bn: "বিমান বাংলাদেশ এয়ারলাইনস",
      description_en: "Flight information",
      description_bn: "ফ্লাইটের তথ্য",
      icon: "✈️"
    },
    {
      number: "01777717777",
      name_en: "Biman Bangladesh (Alternative)",
      name_bn: "বিমান বাংলাদেশ (বিকল্প)",
      description_en: "Flight booking and information",
      description_bn: "ফ্লাইট বুকিং এবং তথ্য",
      icon: "✈️"
    },
    {
      number: "01321168105",
      name_en: "Launch / River Transport",
      name_bn: "লঞ্চ / নদী পরিবহন",
      description_en: "River transport control room",
      description_bn: "নদী পরিবহন নিয়ন্ত্রণ কক্ষ",
      icon: "⛴️"
    },
    {
      number: "02-9559774",
      name_en: "BIWTA",
      name_bn: "বিআইডব্লিউটিএ",
      description_en: "Inland Water Transport Authority",
      description_bn: "অভ্যন্তরীণ জল পরিবহন কর্তৃপক্ষ",
      icon: "🚢"
    },
    {
      number: "16120",
      name_en: "DESCO (Electricity)",
      name_bn: "ডেসকো (বিদ্যুৎ)",
      description_en: "Mirpur, Gulshan, Uttara, Tongi",
      description_bn: "মিরপুর, গুলশান, উত্তরা, টঙ্গী",
      icon: "⚡"
    },
    {
      number: "09610016120",
      name_en: "DESCO (Alternative)",
      name_bn: "ডেসকো (বিকল্প)",
      description_en: "Power outage, safety issue",
      description_bn: "বিদ্যুৎ বিভ্রাট, নিরাপত্তা সমস্যা",
      icon: "⚡"
    },
    {
      number: "02-9632304",
      name_en: "DPDC (Electricity)",
      name_bn: "ডিপিডিসি (বিদ্যুৎ)",
      description_en: "Dhanmondi, Motijheel, Jatrabari",
      description_bn: "ধানমন্ডি, মতিঝিল, যাত্রাবাড়ী",
      icon: "⚡"
    },
    {
      number: "16117",
      name_en: "DPDC / BREB (Alternative)",
      name_bn: "ডিপিডিসি / বিআরইবি (বিকল্প)",
      description_en: "Power failure, billing",
      description_bn: "বিদ্যুৎ ব্যর্থতা, বিলিং",
      icon: "⚡"
    },
    {
      number: "16121",
      name_en: "BPDB (Power)",
      name_bn: "বিপিডিবি (বিদ্যুৎ)",
      description_en: "Chattogram, Sylhet, Barishal, Rajshahi",
      description_bn: "চট্টগ্রাম, সিলেট, বরিশাল, রাজশাহী",
      icon: "⚡"
    },
    {
      number: "09666777888",
      name_en: "NESCO (Power)",
      name_bn: "নেসকো (বিদ্যুৎ)",
      description_en: "Rajshahi, Rangpur zone",
      description_bn: "রাজশাহী, রংপুর অঞ্চল",
      icon: "⚡"
    },
    {
      number: "01713122505",
      name_en: "WZPDCL (Power)",
      name_bn: "ডব্লিউজেডপিডিসিএল (বিদ্যুৎ)",
      description_en: "Khulna, Barishal, Faridpur",
      description_bn: "খুলনা, বরিশাল, ফরিদপুর",
      icon: "⚡"
    },
    {
      number: "16496",
      name_en: "Titas Gas",
      name_bn: "তিতাস গ্যাস",
      description_en: "Dhaka, Narayanganj, Gazipur",
      description_bn: "ঢাকা, নারায়ণগঞ্জ, গাজীপুর",
      icon: "🔥"
    },
    {
      number: "16512",
      name_en: "Karnaphuli Gas",
      name_bn: "কর্ণফুলী গ্যাস",
      description_en: "Chattogram region",
      description_bn: "চট্টগ্রাম অঞ্চল",
      icon: "🔥"
    },
    {
      number: "0821-717921",
      name_en: "Jalalabad Gas",
      name_bn: "জালালাবাদ গ্যাস",
      description_en: "Sylhet region",
      description_bn: "সিলেট অঞ্চল",
      icon: "🔥"
    },
    {
      number: "01730337575",
      name_en: "Jalalabad Gas (Mobile)",
      name_bn: "জালালাবাদ গ্যাস (মোবাইল)",
      description_en: "Sylhet gas emergency",
      description_bn: "সিলেট গ্যাস জরুরি",
      icon: "🔥"
    },
    {
      number: "081-68431",
      name_en: "Bakhrabad Gas",
      name_bn: "বাখরাবাদ গ্যাস",
      description_en: "Comilla, Noakhali, Feni, Chandpur",
      description_bn: "কুমিল্লা, নোয়াখালী, ফেনী, চাঁদপুর",
      icon: "🔥"
    },
    {
      number: "01713035530",
      name_en: "Bakhrabad Gas (Mobile)",
      name_bn: "বাখরাবাদ গ্যাস (মোবাইল)",
      description_en: "Gas emergency",
      description_bn: "গ্যাস জরুরি",
      icon: "🔥"
    },
    {
      number: "16162",
      name_en: "WASA (Water)",
      name_bn: "ওয়াসা (পানি)",
      description_en: "Dhaka water supply & sewerage",
      description_bn: "ঢাকা পানি সরবরাহ ও নর্দমা",
      icon: "💧"
    }
  ],
  
  ambulance_services: [
    {
      number: "01811-458500",
      name_en: "Red Crescent Ambulance",
      name_bn: "রেড ক্রিসেন্ট অ্যাম্বুলেন্স",
      description_en: "Private ambulance service",
      description_bn: "ব্যক্তিগত অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "02-9336611",
      name_en: "Anjuman Mufidul Islam",
      name_bn: "আঞ্জুমান মুফিদুল ইসলাম",
      description_en: "Charitable ambulance service",
      description_bn: "দাতব্য অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "10647",
      name_en: "BRB Hospital Ambulance",
      name_bn: "বিআরবি হাসপাতাল অ্যাম্বুলেন্স",
      description_en: "Hospital ambulance service",
      description_bn: "হাসপাতাল অ্যাম্বুলেন্স সেবা",
      icon: "🚑"
    },
    {
      number: "01713-032903",
      name_en: "Al-Markazul Islami",
      name_bn: "আল-মারকাযুল ইসলামী",
      description_en: "Islamic foundation ambulance",
      description_bn: "ইসলামিক ফাউন্ডেশন অ্যাম্বুলেন্স",
      icon: "🚑"
    }
  ],

  mental_health: [
    {
      number: "01779554391",
      name_en: "Kaan Pete Roi",
      name_bn: "কান পেতে রই",
      description_en: "24/7 confidential listening service",
      description_bn: "২৪/৭ গোপনীয় শ্রবণ সেবা",
      icon: "🧠"
    },
    {
      number: "01779554391",
      name_en: "Moner Bondhu",
      name_bn: "মনের বন্ধু",
      description_en: "Counselling and mental health support",
      description_bn: "পরামর্শ এবং মানসিক স্বাস্থ্য সহায়তা",
      icon: "💚"
    },
    {
      number: "09666-787878",
      name_en: "Bangladesh Psychological Association",
      name_bn: "বাংলাদেশ সাইকোলজিক্যাল অ্যাসোসিয়েশন",
      description_en: "Professional counselling",
      description_bn: "পেশাদার পরামর্শ",
      icon: "🧠"
    }
  ],

  financial_services: [
    {
      number: "16247",
      name_en: "bKash Customer Care",
      name_bn: "বিকাশ কাস্টমার কেয়ার",
      description_en: "Mobile financial services",
      description_bn: "মোবাইল আর্থিক সেবা",
      icon: "💳"
    },
    {
      number: "16167",
      name_en: "Nagad Customer Care",
      name_bn: "নগদ কাস্টমার কেয়ার",
      description_en: "Digital payment service",
      description_bn: "ডিজিটাল পেমেন্ট সেবা",
      icon: "📱"
    },
    {
      number: "16216",
      name_en: "Rocket (DBBL)",
      name_bn: "রকেট (ডিবিবিএল)",
      description_en: "Mobile banking service",
      description_bn: "মোবাইল ব্যাংকিং সেবা",
      icon: "🚀"
    },
    {
      number: "16236",
      name_en: "Sonali Bank",
      name_bn: "সোনালী ব্যাংক",
      description_en: "National bank services",
      description_bn: "জাতীয় ব্যাংক সেবা",
      icon: "🏦"
    },
    {
      number: "16234",
      name_en: "City Bank (Amex)",
      name_bn: "সিটি ব্যাংক (আমেক্স)",
      description_en: "Credit card / bank issues",
      description_bn: "ক্রেডিট কার্ড / ব্যাংক সমস্যা",
      icon: "💳"
    },
    {
      number: "16233",
      name_en: "Standard Chartered Bank",
      name_bn: "স্ট্যান্ডার্ড চার্টার্ড ব্যাংক",
      description_en: "24/7 banking support",
      description_bn: "২৪/৭ ব্যাংকিং সহায়তা",
      icon: "🏦"
    }
  ],

  disaster_crisis: [
    {
      number: "1090",
      name_en: "Disaster Management",
      name_bn: "দুর্যোগ ব্যবস্থাপনা",
      description_en: "Natural Disasters",
      description_bn: "প্রাকৃতিক দুর্যোগ",
      icon: "🌪️"
    },
    {
      number: "1090",
      name_en: "Cyclone Warning",
      name_bn: "ঘূর্ণিঝড় সতর্কতা",
      description_en: "Storm Alerts",
      description_bn: "ঝড় সতর্কবার্তা",
      icon: "🌀"
    },
    {
      number: "1090",
      name_en: "Flood Warning",
      name_bn: "বন্যা সতর্কতা",
      description_en: "Flood Safety",
      description_bn: "বন্যা নিরাপত্তা",
      icon: "🌊"
    }
  ],
  
  government_services: [
    {
      number: "106",
      name_en: "Anti-Corruption Commission",
      name_bn: "দুর্নীতি দমন কমিশন",
      description_en: "Report corruption or misuse of power",
      description_bn: "দুর্নীতি বা ক্ষমতার অপব্যবহার রিপোর্ট করুন",
      icon: "🚫"
    },
    {
      number: "333",
      name_en: "Government Info Service",
      name_bn: "সরকারি তথ্য সেবা",
      description_en: "Govt. info, social support, local admin contact",
      description_bn: "সরকারি তথ্য, সামাজিক সহায়তা, স্থানীয় প্রশাসনিক যোগাযোগ",
      icon: "🏛️"
    },
    {
      number: "16157",
      name_en: "Public Service Commission",
      name_bn: "সরকারি সেবা কমিশন",
      description_en: "Job Exam Info",
      description_bn: "চাকরির পরীক্ষার তথ্য",
      icon: "📋"
    }
  ],

  telecom_services: [
    {
      number: "121",
      name_en: "Grameenphone",
      name_bn: "গ্রামীণফোন",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "123",
      name_en: "Robi",
      name_bn: "রবি",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "121",
      name_en: "Banglalink",
      name_bn: "বাংলালিংক",
      description_en: "Customer care",
      description_bn: "কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "121",
      name_en: "Teletalk",
      name_bn: "টেলিটক",
      description_en: "Govt. SIM customer care",
      description_bn: "সরকারি সিম কাস্টমার কেয়ার",
      icon: "📱"
    },
    {
      number: "16402",
      name_en: "BTCL (Landline)",
      name_bn: "বিটিসিএল (ল্যান্ডলাইন)",
      description_en: "Telephone issues",
      description_bn: "টেলিফোন সমস্যা",
      icon: "☎️"
    },
    {
      number: "100",
      name_en: "ISP Complaint (BTRC)",
      name_bn: "আইএসপি অভিযোগ (বিটিআরসি)",
      description_en: "Report telecom or internet fraud",
      description_bn: "টেলিকম বা ইন্টারনেট জালিয়াতি রিপোর্ট",
      icon: "🌐"
    }
  ]
};

// Flattened version for backward compatibility
export const EMERGENCY_CONTACTS_FLAT = [
  ...EMERGENCY_CONTACTS.urgent_emergency,
  ...EMERGENCY_CONTACTS.law_enforcement,
  ...EMERGENCY_CONTACTS.social_protection,
  ...EMERGENCY_CONTACTS.health_medical,
  ...EMERGENCY_CONTACTS.ambulance_services,
  ...EMERGENCY_CONTACTS.mental_health,
  ...EMERGENCY_CONTACTS.financial_services,
  ...EMERGENCY_CONTACTS.transport_utilities,
  ...EMERGENCY_CONTACTS.disaster_crisis,
  ...EMERGENCY_CONTACTS.government_services,
  ...EMERGENCY_CONTACTS.telecom_services
] as const;

// Safety Tips
export const SAFETY_TIPS = [
  {
    id: 'helmet',
    title_en: 'Always Wear Helmet',
    title_bn: 'সর্বদা হেলমেট পরুন',
    description_en: 'Helmet reduces head injury risk by 70% in motorcycle accidents',
    description_bn: 'হেলমেট মোটরসাইকেল দুর্ঘটনায় মাথার আঘাতের ঝুঁকি ৭০% কমায়',
    icon: '🪖',
    category: 'protective_gear'
  },
  {
    id: 'traffic_signals',
    title_en: 'Follow Traffic Signals',
    title_bn: 'ট্রাফিক সিগন্যাল মেনে চলুন',
    description_en: 'Traffic signals prevent 40% of intersection accidents',
    description_bn: 'ট্রাফিক সিগন্যাল মোড়ের দুর্ঘটনার ৪০% প্রতিরোধ করে',
    icon: '🚦',
    category: 'road_rules'
  },
  {
    id: 'phone_driving',
    title_en: 'No Phone While Driving',
    title_bn: 'গাড়ি চালানোর সময় ফোন নয়',
    description_en: 'Using phone increases accident risk by 400%',
    description_bn: 'ফোন ব্যবহার দুর্ঘটনার ঝুঁকি ৪০০% বৃদ্ধি করে',
    icon: '📵',
    category: 'distraction'
  },
  {
    id: 'safe_distance',
    title_en: 'Maintain Safe Distance',
    title_bn: 'নিরাপদ দূরত্ব বজায় রাখুন',
    description_en: 'Keep 3-second distance from the vehicle ahead',
    description_bn: 'সামনের গাড়ি থেকে ৩ সেকেন্ডের দূরত্ব রাখুন',
    icon: '↔️',
    category: 'defensive_driving'
  },
  {
    id: 'speed_limit',
    title_en: 'Respect Speed Limits',
    title_bn: 'গতিসীমা মেনে চলুন',
    description_en: 'Overspeeding causes 30% of all road accidents',
    description_bn: 'অতিরিক্ত গতি সব সড়ক দুর্ঘটনার ৩০% কারণ',
    icon: '🚗',
    category: 'speed'
  },
  {
    id: 'seatbelt',
    title_en: 'Use Seatbelt Always',
    title_bn: 'সর্বদা সিটবেল্ট ব্যবহার করুন',
    description_en: 'Seatbelts reduce death risk by 45% in car accidents',
    description_bn: 'সিটবেল্ট গাড়ি দুর্ঘটনায় মৃত্যুর ঝুঁকি ৪৫% কমায়',
    icon: '🔒',
    category: 'protective_gear'
  }
] as const;

// Document Types for KYC
export const DOCUMENT_TYPES = [
  {
    id: 'nid',
    name_en: 'National ID Card',
    name_bn: 'জাতীয় পরিচয়পত্র',
    icon: '🆔',
    required_sides: ['front', 'back']
  },
  {
    id: 'driving_license',
    name_en: 'Driving License',
    name_bn: 'ড্রাইভিং লাইসেন্স',
    icon: '🚗',
    required_sides: ['front', 'back']
  },
  {
    id: 'passport',
    name_en: 'Passport',
    name_bn: 'পাসপোর্ট',
    icon: '📘',
    required_sides: ['info_page']
  }
] as const;

// Selfie Types for Biometric Verification
export const SELFIE_TYPES = [
  {
    id: 'front',
    name_en: 'Front Face',
    name_bn: 'সামনের মুখ',
    instruction_en: 'Look directly at the camera',
    instruction_bn: 'সরাসরি ক্যামেরার দিকে তাকান',
    icon: '👤'
  },
  {
    id: 'left',
    name_en: 'Left Side Profile',
    name_bn: 'বাম পাশের প্রোফাইল',
    instruction_en: 'Turn your head to the left',
    instruction_bn: 'আপনার মাথা বাম দিকে ঘুরান',
    icon: '👈'
  },
  {
    id: 'right',
    name_en: 'Right Side Profile',
    name_bn: 'ডান পাশের প্রোফাইল',
    instruction_en: 'Turn your head to the right',
    instruction_bn: 'আপনার মাথা ডান দিকে ঘুরান',
    icon: '👉'
  }
] as const;

// Case Status Colors
export const STATUS_COLORS = {
  pending: 'text-yellow-700 bg-yellow-100 border-yellow-200',
  under_review: 'text-blue-700 bg-blue-100 border-blue-200',
  approved: 'text-green-700 bg-green-100 border-green-200',
  rejected: 'text-red-700 bg-red-100 border-red-200',
  completed: 'text-purple-700 bg-purple-100 border-purple-200'
} as const;

// Validation Patterns
export const VALIDATION_PATTERNS = {
  BANGLADESH_PHONE: /^(?:\+88|88)?(01[3-9]\d{8})$/,
  NID_NUMBER: /^\d{10}$|^\d{13}$|^\d{17}$/,
  LICENSE_PLATE: /^[A-Za-z\u0980-\u09FF\s-]+\d+$/,
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
} as const;

// App Configuration
export const APP_CONFIG = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  MAX_FILES_PER_REPORT: 5,
  SUPPORTED_FILE_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'],
  OTP_TIMEOUT: 2 * 60 * 1000, // 2 minutes
  COMMISSION_RATE: 0.20,
  AUTO_CASE_NUMBER_PREFIX: 'TE'
} as const;

// Generate unique case number
export const generateCaseNumber = (): string => {
  const now = new Date();
  const date = now.getFullYear().toString() + 
               (now.getMonth() + 1).toString().padStart(2, '0') + 
               now.getDate().toString().padStart(2, '0');
  const time = now.getHours().toString().padStart(2, '0') + 
               now.getMinutes().toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  
  return `${APP_CONFIG.AUTO_CASE_NUMBER_PREFIX}-${date}-${time}-${random}`;
};

// Helper functions
export const formatCurrency = (amount: number, currency = '৳'): string => {
  return `${currency}${amount.toLocaleString('en-IN')}`;
};

export const calculateReward = (fineAmount: number, rewardRate = COMMISSION_RATE): number => {
  return Math.floor(fineAmount * rewardRate);
};

export const validateBangladeshPhone = (phone: string): boolean => {
  return VALIDATION_PATTERNS.BANGLADESH_PHONE.test(phone);
};

export const formatPhoneNumber = (phone: string): string => {
  // Remove country code if present and format
  const cleaned = phone.replace(/^(\+88|88)/, '');
  if (cleaned.length === 11 && cleaned.startsWith('01')) {
    return `+88${cleaned}`;
  }
  return phone;
};

// Departments for Officers
export const OFFICER_DEPARTMENTS = [
  {
    id: 'dmp',
    name_en: 'Dhaka Metropolitan Police (DMP)',
    name_bn: 'ঢাকা মহানগর পুলিশ (ডিএমপি)',
    category: 'police'
  },
  {
    id: 'brta',
    name_en: 'Bangladesh Road Transport Authority (BRTA)',
    name_bn: 'বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ)',
    category: 'transport'
  },
  {
    id: 'traffic_police',
    name_en: 'Traffic Police',
    name_bn: 'ট্রাফিক পুলিশ',
    category: 'traffic'
  },
  {
    id: 'highway_police',
    name_en: 'Highway Police',
    name_bn: 'হাইওয়ে পুলিশ',
    category: 'highway'
  }
] as const;

export const API_ENDPOINTS = {
  USERS: '/api/users',
  CASES: '/api/cases',
  VIOLATIONS: '/api/violations',
  NOTIFICATIONS: '/api/notifications',
  AUTH: '/api/auth'
};

export const VIOLATION_STATUS = {
  PENDING: 'pending',
  UNDER_REVIEW: 'under_review',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  COMPLETED: 'completed'
} as const;

export const USER_TYPES = {
  CITIZEN: 'citizen',
  OFFICER: 'officer'
} as const;

export const KYC_STATUS = {
  PENDING: 'pending',
  VERIFIED: 'verified',
  REJECTED: 'rejected'
} as const;

export const LANGUAGES = {
  EN: 'en',
  BN: 'bn'
} as const;

export const NOTIFICATION_TYPES = {
  CASE_UPDATE: 'case_update',
  PAYMENT: 'payment',
  KYC: 'kyc',
  GENERAL: 'general'
} as const;
