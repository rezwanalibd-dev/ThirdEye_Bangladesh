import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: number;
  email?: string;
  mobile_number: string;
  full_name: string;
  is_verified: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  profile?: UserProfile | null;
  identity_verification?: IdentityVerification | null;
  biometric_verification?: BiometricVerification | null;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  signin: (mobile_number: string, password: string) => Promise<void>;
  signup: (data: SignupData) => Promise<{ user_id: number }>;
  verifyOTP: (user_id: number, otp_code: string) => Promise<void>;
  resendOTP: (user_id: number) => Promise<void>;
  logout: () => Promise<void>;
  fetchUser: () => Promise<void>;
  verifyIdentity: (data: IdentityVerificationData) => Promise<void>;
  verifyBiometric: (data: BiometricVerificationData) => Promise<void>;
}

interface SignupData {
  full_name: string;
  mobile_number: string;
  email?: string;
  password: string;
}

interface IdentityVerificationData {
  document_type: 'nid' | 'driving_license' | 'passport';
  document_number: string;
  document_front_url: string;
  document_back_url?: string;
}

interface BiometricVerificationData {
  front_face_url: string;
  left_side_url: string;
  right_side_url: string;
}

interface UserProfile {
  id: number;
  user_type: string;
  full_name: string;
  phone_number?: string;
  department?: string;
  badge_id?: string;
  preferred_language: string;
  wallet_provider?: string;
  wallet_number?: string;
  total_reports: number;
  approved_reports: number;
  total_rewards: number;
}

interface IdentityVerification {
  id: number;
  document_type: string;
  document_number: string;
  status: string;
  rejection_reason?: string;
  created_at: string;
}

interface BiometricVerification {
  id: number;
  status: string;
  rejection_reason?: string;
  created_at: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/users/me', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (data: SignupData): Promise<{ user_id: number }> => {
    const response = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'Signup failed');
    }

    return { user_id: result.user_id };
  };

  const verifyOTP = async (user_id: number, otp_code: string) => {
    const response = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ user_id, otp_code }),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'OTP verification failed');
    }

    setUser(result.user);
  };

  const resendOTP = async (user_id: number) => {
    const response = await fetch('/api/auth/resend-otp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ user_id }),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'Failed to resend OTP');
    }
  };

  const signin = async (mobile_number: string, password: string) => {
    const response = await fetch('/api/auth/signin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ mobile_number, password }),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'Signin failed');
    }

    setUser(result.user);
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setUser(null);
    }
  };

  const verifyIdentity = async (data: IdentityVerificationData) => {
    const response = await fetch('/api/auth/verify-identity', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'Identity verification failed');
    }

    // Refresh user data
    await fetchUser();
  };

  const verifyBiometric = async (data: BiometricVerificationData) => {
    const response = await fetch('/api/auth/verify-biometric', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      credentials: 'include'
    });

    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.error || 'Biometric verification failed');
    }

    // Refresh user data
    await fetchUser();
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const value = {
    user,
    isLoading,
    signin,
    signup,
    verifyOTP,
    resendOTP,
    logout,
    fetchUser,
    verifyIdentity,
    verifyBiometric,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
