import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@/react-app/contexts/AuthContext";
import { LanguageProvider } from "@/react-app/contexts/LanguageContext";
import PWAInstallPrompt from "@/react-app/components/PWAInstallPrompt";
import HomePage from "@/react-app/pages/Home";
import SignupPage from "@/react-app/pages/Signup";
import SigninPage from "@/react-app/pages/Signin";
import OTPVerificationPage from "@/react-app/pages/OTPVerification";
import IdentityVerificationPage from "@/react-app/pages/IdentityVerification";
import BiometricVerificationPage from "@/react-app/pages/BiometricVerification";
import DashboardPage from "@/react-app/pages/Dashboard";
import ReportPage from "@/react-app/pages/Report";
import SocialCrimePage from "@/react-app/pages/SocialCrime";
import CasesPage from "@/react-app/pages/Cases";
import ProfilePage from "@/react-app/pages/Profile";
import SetupPage from "@/react-app/pages/Setup";
import VehicleRulesPage from "@/react-app/pages/VehicleRules";
import TrafficFinesPage from "@/react-app/pages/TrafficFines";
import FeaturesPage from "@/react-app/pages/Features";
import EmergencyDirectoryPage from "@/react-app/pages/EmergencyDirectory";
import ProtectedRoute from "@/react-app/components/ProtectedRoute";

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <div className="min-h-screen bg-ash">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/signin" element={<SigninPage />} />
              <Route path="/verify-otp" element={<OTPVerificationPage />} />
              <Route path="/verify-identity" element={<IdentityVerificationPage />} />
              <Route path="/verify-biometric" element={<BiometricVerificationPage />} />
              <Route 
                path="/setup" 
                element={
                  <ProtectedRoute>
                    <SetupPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/report" 
                element={
                  <ProtectedRoute>
                    <ReportPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/social-crime" 
                element={
                  <ProtectedRoute>
                    <SocialCrimePage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/cases" 
                element={
                  <ProtectedRoute>
                    <CasesPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                } 
              />
              <Route path="/vehicle-rules" element={<VehicleRulesPage />} />
              <Route path="/traffic-fines" element={<TrafficFinesPage />} />
              <Route path="/features" element={<FeaturesPage />} />
              <Route path="/emergency-directory" element={<EmergencyDirectoryPage />} />
            </Routes>
            <PWAInstallPrompt />
          </div>
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}
