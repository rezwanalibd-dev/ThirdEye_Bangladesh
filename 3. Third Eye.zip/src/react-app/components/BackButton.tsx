import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router';

interface BackButtonProps {
  to?: string;
  onClick?: () => void;
  label?: string;
  className?: string;
}

export default function BackButton({ to, onClick, label, className = '' }: BackButtonProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (to) {
      navigate(to);
    } else {
      navigate(-1);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`
        inline-flex items-center space-x-2 p-2 rounded-lg transition-all
        hover:bg-ash active:scale-95 touch-target
        ${className}
      `}
      style={{ color: 'var(--text-secondary)' }}
    >
      <ArrowLeft className="w-5 h-5" />
      {label && <span className="text-sm font-medium">{label}</span>}
    </button>
  );
}
