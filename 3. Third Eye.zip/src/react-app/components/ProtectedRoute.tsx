import { useAuth } from "@/react-app/contexts/AuthContext";
import { Navigate } from "react-router";
import LoadingSpinner from "./LoadingSpinner";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return <Navigate to="/signin" replace />;
  }

  // Check if user needs to complete verification steps
  if (user && !user.identity_verification) {
    return <Navigate to="/verify-identity" replace />;
  }

  if (user && user.identity_verification?.status === 'pending' && !user.biometric_verification) {
    return <Navigate to="/verify-biometric" replace />;
  }

  return <>{children}</>;
}
