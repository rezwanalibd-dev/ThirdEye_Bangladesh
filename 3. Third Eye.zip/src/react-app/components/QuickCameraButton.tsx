import { useState } from 'react';
import { Camera, AlertCircle } from 'lucide-react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate } from 'react-router';

export default function QuickCameraButton() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleQuickReport = () => {
    setIsLoading(true);
    // Simulate quick camera access
    setTimeout(() => {
      setIsLoading(false);
      navigate('/report');
    }, 500);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <button
        onClick={handleQuickReport}
        disabled={isLoading}
        className="
          btn-danger btn-large rounded-full shadow-lg hover:shadow-xl
          transform hover:scale-110 active:scale-95 transition-all duration-200
          disabled:opacity-50 disabled:cursor-not-allowed
          flex items-center justify-center w-16 h-16 sm:w-auto sm:h-auto sm:px-6 sm:py-4
        "
        style={{ backgroundColor: 'var(--color-light-red-dark)' }}
      >
        {isLoading ? (
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
        ) : (
          <>
            <Camera className="w-6 h-6" />
            <span className="hidden sm:inline sm:ml-2 font-semibold">
              {t('Quick Report', 'দ্রুত রিপোর্ট')}
            </span>
          </>
        )}
      </button>

      {/* Tooltip for mobile */}
      <div className="sm:hidden absolute bottom-full right-0 mb-2 px-3 py-2 bg-ash rounded-lg shadow-lg opacity-0 pointer-events-none transition-opacity duration-200 hover:opacity-100">
        <div className="flex items-center space-x-2">
          <AlertCircle className="w-4 h-4" style={{ color: 'var(--color-light-red-dark)' }} />
          <span className="text-sm font-medium whitespace-nowrap" style={{ color: 'var(--text-primary)' }}>
            {t('Quick Report', 'দ্রুত রিপোর্ট')}
          </span>
        </div>
        <div className="absolute top-full right-4 -mt-1 border-4 border-transparent border-t-gray-200"></div>
      </div>
    </div>
  );
}
