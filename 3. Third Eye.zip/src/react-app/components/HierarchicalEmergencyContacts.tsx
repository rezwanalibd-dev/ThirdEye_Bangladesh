import { useState } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { EMERGENCY_CONTACTS } from '@/shared/constants';
import { ChevronDown, ChevronRight, Phone } from 'lucide-react';

export default function HierarchicalEmergencyContacts() {
  const { language } = useLanguage();
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['urgent_emergency']));

  const toggleSection = (sectionKey: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionKey)) {
      newExpanded.delete(sectionKey);
    } else {
      newExpanded.add(sectionKey);
    }
    setExpandedSections(newExpanded);
  };

  const sectionTitles = {
    urgent_emergency: {
      en: '🚨 URGENT EMERGENCY',
      bn: '🚨 জরুরি জরুরি'
    },
    law_enforcement: {
      en: '👮 Law Enforcement',
      bn: '👮 আইন প্রয়োগকারী'
    },
    social_protection: {
      en: '🛡️ Social Protection',
      bn: '🛡️ সামাজিক সুরক্ষা'
    },
    health_medical: {
      en: '🏥 Major Hospitals (Dhaka)',
      bn: '🏥 প্রধান হাসপাতাল (ঢাকা)'
    },
    ambulance_services: {
      en: '🚑 Private Ambulance Services',
      bn: '🚑 ব্যক্তিগত অ্যাম্বুলেন্স সেবা'
    },
    mental_health: {
      en: '🧠 Mental Health & Counselling',
      bn: '🧠 মানসিক স্বাস্থ্য ও পরামর্শ'
    },
    financial_services: {
      en: '💳 Banks & Financial Services',
      bn: '💳 ব্যাংক ও আর্থিক সেবা'
    },
    transport_utilities: {
      en: '🚗 Transport & Utilities',
      bn: '🚗 পরিবহন ও উপযোগিতা'
    },
    disaster_crisis: {
      en: '⛈️ Disaster & Crisis',
      bn: '⛈️ দুর্যোগ ও সংকট'
    },
    government_services: {
      en: '🏛️ Government Services',
      bn: '🏛️ সরকারি সেবা'
    },
    telecom_services: {
      en: '📱 Telecom Services',
      bn: '📱 টেলিকম সেবা'
    }
  };

  return (
    <div className="space-y-4">
      {Object.entries(EMERGENCY_CONTACTS).map(([sectionKey, contacts]) => {
        const isExpanded = expandedSections.has(sectionKey);
        const sectionTitle = sectionTitles[sectionKey as keyof typeof sectionTitles];
        
        return (
          <div key={sectionKey} className="card-base overflow-hidden">
            <button
              onClick={() => toggleSection(sectionKey)}
              className={`
                w-full p-4 flex items-center justify-between transition-all hover:bg-ash
                ${sectionKey === 'urgent_emergency' ? 'bg-danger text-white hover:opacity-90' : ''}
              `}
              style={{
                backgroundColor: sectionKey === 'urgent_emergency' ? 'var(--color-light-red-dark)' : undefined
              }}
            >
              <h3 className={`text-heading-2 font-bold ${
                sectionKey === 'urgent_emergency' ? 'text-white' : ''
              }`} style={{
                color: sectionKey !== 'urgent_emergency' ? 'var(--text-primary)' : undefined
              }}>
                {language === 'en' ? sectionTitle.en : sectionTitle.bn}
              </h3>
              {isExpanded ? (
                <ChevronDown className={`w-5 h-5 ${
                  sectionKey === 'urgent_emergency' ? 'text-white' : ''
                }`} style={{
                  color: sectionKey !== 'urgent_emergency' ? 'var(--text-secondary)' : undefined
                }} />
              ) : (
                <ChevronRight className={`w-5 h-5 ${
                  sectionKey === 'urgent_emergency' ? 'text-white' : ''
                }`} style={{
                  color: sectionKey !== 'urgent_emergency' ? 'var(--text-secondary)' : undefined
                }} />
              )}
            </button>

            {isExpanded && (
              <div className="border-t" style={{ borderColor: 'var(--color-light-blue)' }}>
                <div className="grid md:grid-cols-2 gap-4 p-4">
                  {contacts.map((contact, index) => (
                    <div key={index} className="bg-ash rounded-xl p-4 hover:shadow-md transition-all">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="text-2xl">{contact.icon}</div>
                        <div className="flex-1">
                          <h4 className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                            {language === 'en' ? contact.name_en : contact.name_bn}
                          </h4>
                          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                            {language === 'en' ? contact.description_en : contact.description_bn}
                          </p>
                        </div>
                      </div>
                      
                      <a
                        href={`tel:${contact.number}`}
                        className={`
                          btn-small w-full flex items-center justify-center transition-all
                          ${sectionKey === 'urgent_emergency' ? 'btn-danger' : 'btn-primary'}
                        `}
                      >
                        <Phone className="w-4 h-4 mr-2" />
                        {contact.number}
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
