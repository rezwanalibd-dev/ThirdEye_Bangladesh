import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useNavigate } from 'react-router';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useApi } from '@/react-app/hooks/useApi';
import { 
  UserCircle, 
  Shield, 
  Wallet, 
  Check, 
  Upload, 
  Camera,
  FileText,
  CreditCard,
  ArrowRight,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import LoadingSpinner from '@/react-app/components/LoadingSpinner';
import BackButton from '@/react-app/components/BackButton';

export default function Setup() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [userProfile, setUserProfile] = useState<Record<string, unknown> | null>(null);
  
  const profileApi = useApi();
  const kycApi = useApi();
  const walletApi = useApi();

  // Form states
  const [profileForm, setProfileForm] = useState({
    user_type: 'citizen',
    full_name: '',
    phone_number: '',
    nid_number: '',
    driving_license: '',
    passport_number: '',
    department: '',
    badge_id: '',
    rank: '',
  });

  const [documentType, setDocumentType] = useState<'nid' | 'driving_license' | 'passport'>('nid');
  const [documents, setDocuments] = useState({
    front: null as File | null,
    back: null as File | null,
  });

  const [selfies, setSelfies] = useState({
    front: null as File | null,
    left: null as File | null,
    right: null as File | null,
  });

  const [walletForm, setWalletForm] = useState({
    provider: '',
    phone_number: '',
  });

  useEffect(() => {
    checkUserProfile();
  }, []);

  const checkUserProfile = async () => {
    try {
      const response = await fetch('/api/users/me', { credentials: 'include' });
      const userData = await response.json();
      
      if (userData.profile) {
        setUserProfile(userData.profile);
        if (userData.profile.kyc_status === 'verified' && userData.profile.wallet_verified) {
          navigate('/dashboard');
        } else if (userData.profile.kyc_status === 'verified') {
          setCurrentStep(3);
        } else if (userData.profile.full_name) {
          setCurrentStep(1);
        }
      }
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!profileForm.full_name || !profileForm.phone_number) {
      alert(t('Please fill in all required fields', 'সব প্রয়োজনীয় ক্ষেত্র পূরণ করুন'));
      return;
    }

    // For officers, require additional fields
    if (profileForm.user_type === 'officer' && (!profileForm.department || !profileForm.badge_id)) {
      alert(t('Officers must provide department and badge ID', 'অফিসারদের বিভাগ এবং ব্যাজ আইডি প্রদান করতে হবে'));
      return;
    }

    try {
      await profileApi.execute('/api/profile', {
        method: 'POST',
        body: profileForm,
      });
      setCurrentStep(1);
    } catch (error) {
      console.error('Profile submission failed:', error);
      alert(t('Profile setup failed. Please try again.', 'প্রোফাইল সেটআপ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।'));
    }
  };

  const handleDocumentUpload = (type: 'front' | 'back', file: File) => {
    setDocuments(prev => ({ ...prev, [type]: file }));
  };

  const handleSelfieUpload = (type: 'front' | 'left' | 'right', file: File) => {
    setSelfies(prev => ({ ...prev, [type]: file }));
  };

  const handleKycSubmit = async () => {
    // Validate documents
    if (!documents.front || !documents.back) {
      alert(t('Please upload both sides of your document', 'আপনার নথির উভয় পাশ আপলোড করুন'));
      return;
    }

    try {
      // Mock document upload - in production, upload to R2
      const mockDocUrls = ['doc-front.jpg', 'doc-back.jpg'];
      
      await kycApi.execute('/api/kyc/upload', {
        method: 'POST',
        body: { document_urls: mockDocUrls },
      });
      
      setCurrentStep(2);
    } catch (error) {
      console.error('KYC submission failed:', error);
      alert(t('Document upload failed. Please try again.', 'নথি আপলোড ব্যর্থ হয়েছে। আবার চেষ্টা করুন।'));
    }
  };

  const handleSelfieSubmit = async () => {
    // Validate selfies
    if (!selfies.front || !selfies.left || !selfies.right) {
      alert(t('Please take all three selfies for verification', 'যাচাইকরণের জন্য তিনটি সেলফি নিন'));
      return;
    }

    try {
      // Mock selfie verification
      setCurrentStep(3);
    } catch (error) {
      console.error('Selfie verification failed:', error);
      alert(t('Selfie verification failed. Please try again.', 'সেলফি যাচাইকরণ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।'));
    }
  };

  const handleWalletSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!walletForm.provider || !walletForm.phone_number) {
      alert(t('Please select wallet and enter phone number', 'ওয়ালেট নির্বাচন করুন এবং ফোন নম্বর লিখুন'));
      return;
    }

    // Validate Bangladesh phone number
    const phoneRegex = /^(?:\+88|88)?(01[3-9]\d{8})$/;
    if (!phoneRegex.test(walletForm.phone_number)) {
      alert(t('Please enter a valid Bangladesh phone number', 'একটি বৈধ বাংলাদেশ ফোন নম্বর লিখুন'));
      return;
    }

    try {
      await walletApi.execute('/api/wallet/verify', {
        method: 'POST',
        body: walletForm,
      });
      navigate('/dashboard');
    } catch (error) {
      console.error('Wallet setup failed:', error);
      alert(t('Wallet setup failed. Please try again.', 'ওয়ালেট সেটআপ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।'));
    }
  };

  const steps = [
    {
      title: t('Profile Setup', 'প্রোফাইল সেটআপ'),
      subtitle: t('Basic Information', 'মৌলিক তথ্য'),
      icon: UserCircle,
      completed: userProfile?.full_name,
    },
    {
      title: t('Document Upload', 'নথি আপলোড'),
      subtitle: t('Identity Verification', 'পরিচয় যাচাইকরণ'),
      icon: FileText,
      completed: userProfile?.kyc_documents,
    },
    {
      title: t('Facial Verification', 'মুখ যাচাইকরণ'),
      subtitle: t('Security Check', 'নিরাপত্তা পরীক্ষা'),
      icon: Camera,
      completed: false,
    },
    {
      title: t('Wallet Setup', 'ওয়ালেট সেটআপ'),
      subtitle: t('Payment Method', 'পেমেন্ট পদ্ধতি'),
      icon: Wallet,
      completed: userProfile?.wallet_verified,
    },
  ];

  const walletProviders = [
    { name: 'bKash', color: 'from-pink-500 to-pink-600' },
    { name: 'Nagad', color: 'from-orange-500 to-red-600' },
    { name: 'Rocket', color: 'from-blue-500 to-purple-600' },
    { name: 'Upay', color: 'from-green-500 to-green-600' },
    { name: 'mCash', color: 'from-purple-500 to-purple-600' },
    { name: 'CellFin', color: 'from-yellow-500 to-orange-500' },
    { name: 'SureCash', color: 'from-blue-500 to-blue-600' },
    { name: 'Trust Money', color: 'from-gray-700 to-gray-800' },
  ];

  if (!user) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-ash">
      {/* Progress Header */}
      <div className="bg-white border-b py-8" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-5xl mx-auto px-6">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center space-x-4">
              <BackButton 
                to="/verify-biometric"
                className="p-2 hover:bg-ash rounded-lg transition-colors"
              />
              <div>
                <h1 className="text-display-3 font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('Account Setup', 'অ্যাকাউন্ট সেটআপ')}
                </h1>
                <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
                  {t('Complete these steps to start reporting', 'রিপোর্ট শুরু করতে এই ধাপগুলি সম্পূর্ণ করুন')}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">{t('Step', 'ধাপ')}</p>
              <p className="text-2xl font-bold text-indigo-600">{currentStep + 1} / {steps.length}</p>
            </div>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = step.completed;
              const isPast = index < currentStep;
              
              return (
                <div key={index} className="flex items-center flex-1">
                  <div className="flex flex-col items-center flex-1">
                    <div className={`
                      flex items-center justify-center w-14 h-14 rounded-full border-3 transition-all
                      ${isCompleted || isPast ? 'bg-green-500 border-green-500' : 
                        isActive ? 'bg-indigo-600 border-indigo-600' : 'bg-white border-gray-300'}
                    `}>
                      {isCompleted || isPast ? (
                        <Check className="w-7 h-7 text-white" />
                      ) : (
                        <Icon className={`w-7 h-7 ${isActive ? 'text-white' : 'text-gray-400'}`} />
                      )}
                    </div>
                    <div className="mt-3 text-center">
                      <p className={`text-sm font-semibold ${isActive ? 'text-indigo-600' : 'text-gray-600'}`}>
                        {step.title}
                      </p>
                      <p className="text-xs text-gray-500">{step.subtitle}</p>
                    </div>
                  </div>
                  
                  {index < steps.length - 1 && (
                    <div className={`
                      h-1 w-full mx-4 rounded transition-all
                      ${isPast || isCompleted ? 'bg-green-500' : 'bg-gray-200'}
                    `} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Step Content */}
      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
          {/* Step 0: Profile Setup */}
          {currentStep === 0 && (
            <div>
              <div className="flex items-center space-x-3 mb-8">
                <UserCircle className="w-10 h-10 text-indigo-600" />
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {t('Welcome! Let\'s set up your profile', 'স্বাগতম! আপনার প্রোফাইল সেট আপ করা যাক')}
                  </h2>
                  <p className="text-gray-600">
                    {t('This information helps us verify your identity', 'এই তথ্য আপনার পরিচয় যাচাই করতে সাহায্য করে')}
                  </p>
                </div>
              </div>

              <form onSubmit={handleProfileSubmit} className="space-y-6">
                {/* Account Type */}
                <div className="grid grid-cols-2 gap-4">
                  <label className={`
                    flex flex-col items-center p-6 border-2 rounded-xl cursor-pointer transition-all
                    ${profileForm.user_type === 'citizen' ? 'border-indigo-600 bg-indigo-50' : 'border-gray-200 hover:border-gray-300'}
                  `}>
                    <input
                      type="radio"
                      name="user_type"
                      value="citizen"
                      checked={profileForm.user_type === 'citizen'}
                      onChange={(e) => setProfileForm({ ...profileForm, user_type: e.target.value })}
                      className="sr-only"
                    />
                    <UserCircle className={`w-12 h-12 mb-3 ${profileForm.user_type === 'citizen' ? 'text-indigo-600' : 'text-gray-400'}`} />
                    <span className={`font-semibold ${profileForm.user_type === 'citizen' ? 'text-indigo-900' : 'text-gray-700'}`}>
                      {t('Citizen', 'নাগরিক')}
                    </span>
                  </label>

                  <label className={`
                    flex flex-col items-center p-6 border-2 rounded-xl cursor-pointer transition-all
                    ${profileForm.user_type === 'officer' ? 'border-indigo-600 bg-indigo-50' : 'border-gray-200 hover:border-gray-300'}
                  `}>
                    <input
                      type="radio"
                      name="user_type"
                      value="officer"
                      checked={profileForm.user_type === 'officer'}
                      onChange={(e) => setProfileForm({ ...profileForm, user_type: e.target.value })}
                      className="sr-only"
                    />
                    <Shield className={`w-12 h-12 mb-3 ${profileForm.user_type === 'officer' ? 'text-indigo-600' : 'text-gray-400'}`} />
                    <span className={`font-semibold ${profileForm.user_type === 'officer' ? 'text-indigo-900' : 'text-gray-700'}`}>
                      {t('DMP/BRTA Officer', 'ডিএমপি/বিআরটিএ অফিসার')}
                    </span>
                  </label>
                </div>

                {/* Basic Info */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('Full Name', 'পুরো নাম')} *
                    </label>
                    <input
                      type="text"
                      required
                      value={profileForm.full_name}
                      onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder={t('Enter your full name', 'আপনার পুরো নাম লিখুন')}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('Phone Number', 'ফোন নম্বর')} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={profileForm.phone_number}
                      onChange={(e) => setProfileForm({ ...profileForm, phone_number: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="01XXXXXXXXX"
                    />
                  </div>

                  {profileForm.user_type === 'citizen' ? (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          {t('NID Number (Optional)', 'এনআইডি নম্বর (ঐচ্ছিক)')}
                        </label>
                        <input
                          type="text"
                          value={profileForm.nid_number}
                          onChange={(e) => setProfileForm({ ...profileForm, nid_number: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder={t('Enter NID number', 'এনআইডি নম্বর লিখুন')}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          {t('Driving License (Optional)', 'ড্রাইভিং লাইসেন্স (ঐচ্ছিক)')}
                        </label>
                        <input
                          type="text"
                          value={profileForm.driving_license}
                          onChange={(e) => setProfileForm({ ...profileForm, driving_license: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder={t('Enter license number', 'লাইসেন্স নম্বর লিখুন')}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          {t('Department', 'বিভাগ')} *
                        </label>
                        <select
                          required
                          value={profileForm.department}
                          onChange={(e) => setProfileForm({ ...profileForm, department: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        >
                          <option value="">{t('Select Department', 'বিভাগ নির্বাচন করুন')}</option>
                          <option value="DMP">DMP - Dhaka Metropolitan Police</option>
                          <option value="BRTA">BRTA - Bangladesh Road Transport Authority</option>
                          <option value="Traffic Police">Traffic Police</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          {t('Badge/Employee ID', 'ব্যাজ/কর্মচারী আইডি')} *
                        </label>
                        <input
                          type="text"
                          required
                          value={profileForm.badge_id}
                          onChange={(e) => setProfileForm({ ...profileForm, badge_id: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder={t('Enter badge ID', 'ব্যাজ আইডি লিখুন')}
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          {t('Rank/Position (Optional)', 'পদবী/অবস্থান (ঐচ্ছিক)')}
                        </label>
                        <input
                          type="text"
                          value={profileForm.rank}
                          onChange={(e) => setProfileForm({ ...profileForm, rank: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder={t('e.g., Assistant Sub-Inspector', 'যেমন: সহকারী উপ-পরিদর্শক')}
                        />
                      </div>
                    </>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={profileApi.loading}
                  className="w-full bg-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                >
                  {profileApi.loading ? (
                    t('Saving...', 'সংরক্ষণ করা হচ্ছে...')
                  ) : (
                    <>
                      {t('Continue to Document Upload', 'নথি আপলোডে এগিয়ে যান')}
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* Step 1: Document Upload */}
          {currentStep === 1 && (
            <div>
              <div className="flex items-center space-x-3 mb-8">
                <FileText className="w-10 h-10 text-indigo-600" />
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {t('Upload Identity Documents', 'পরিচয়পত্র আপলোড করুন')}
                  </h2>
                  <p className="text-gray-600">
                    {t('We need to verify your identity to protect everyone', 'সবাইকে রক্ষা করতে আমাদের আপনার পরিচয় যাচাই করতে হবে')}
                  </p>
                </div>
              </div>

              {/* Document Type Selection */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  {t('Select Document Type', 'নথির ধরন নির্বাচন করুন')}
                </label>
                <div className="grid grid-cols-3 gap-4">
                  {(['nid', 'driving_license', 'passport'] as const).map((type) => (
                    <label
                      key={type}
                      className={`
                        flex flex-col items-center p-4 border-2 rounded-xl cursor-pointer transition-all
                        ${documentType === type ? 'border-indigo-600 bg-indigo-50' : 'border-gray-200 hover:border-gray-300'}
                      `}
                    >
                      <input
                        type="radio"
                        name="documentType"
                        value={type}
                        checked={documentType === type}
                        onChange={(e) => setDocumentType(e.target.value as typeof documentType)}
                        className="sr-only"
                      />
                      <CreditCard className={`w-8 h-8 mb-2 ${documentType === type ? 'text-indigo-600' : 'text-gray-400'}`} />
                      <span className={`text-sm font-medium ${documentType === type ? 'text-indigo-900' : 'text-gray-700'}`}>
                        {type === 'nid' ? t('NID', 'এনআইডি') : 
                         type === 'driving_license' ? t('Driving License', 'ড্রাইভিং লাইসেন্স') : 
                         t('Passport', 'পাসপোর্ট')}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Document Upload */}
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                {(['front', 'back'] as const).map((side) => (
                  <div key={side}>
                    <label className="block text-sm font-medium text-gray-700 mb-3">
                      {side === 'front' ? t('Front Side', 'সামনের দিক') : t('Back Side', 'পিছনের দিক')} *
                    </label>
                    <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-indigo-400 transition-all bg-gray-50">
                      {documents[side] ? (
                        <div className="text-center">
                          <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-2" />
                          <p className="text-sm font-medium text-gray-900">{documents[side]!.name}</p>
                          <p className="text-xs text-gray-500">{(documents[side]!.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm font-medium text-gray-700">{t('Click to upload', 'আপলোড করতে ক্লিক করুন')}</p>
                          <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                        </div>
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleDocumentUpload(side, file);
                        }}
                        className="hidden"
                      />
                    </label>
                  </div>
                ))}
              </div>

              {/* Info Box */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
                <div className="flex">
                  <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900 mb-1">
                      {t('Document Guidelines', 'নথি নির্দেশিকা')}
                    </h4>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• {t('Ensure all text is clearly visible', 'সব লেখা স্পষ্টভাবে দৃশ্যমান নিশ্চিত করুন')}</li>
                      <li>• {t('No glare or shadows on the document', 'নথিতে কোনো ঝলক বা ছায়া নেই')}</li>
                      <li>• {t('Document must be valid and not expired', 'নথি বৈধ এবং মেয়াদোত্তীর্ণ নয়')}</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setCurrentStep(0)}
                  className="flex-1 bg-gray-200 text-gray-700 py-4 px-6 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
                >
                  {t('Back', 'পেছনে')}
                </button>
                <button
                  onClick={handleKycSubmit}
                  disabled={!documents.front || !documents.back || kycApi.loading}
                  className="flex-1 bg-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                >
                  {kycApi.loading ? (
                    t('Uploading...', 'আপলোড হচ্ছে...')
                  ) : (
                    <>
                      {t('Continue to Facial Verification', 'মুখ যাচাইকরণে এগিয়ে যান')}
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Facial Verification */}
          {currentStep === 2 && (
            <div>
              <div className="flex items-center space-x-3 mb-8">
                <Camera className="w-10 h-10 text-indigo-600" />
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {t('Facial Verification', 'মুখ যাচাইকরণ')}
                  </h2>
                  <p className="text-gray-600">
                    {t('Take three selfies for identity verification', 'পরিচয় যাচাইয়ের জন্য তিনটি সেলফি নিন')}
                  </p>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                {(['front', 'left', 'right'] as const).map((angle) => (
                  <div key={angle}>
                    <label className="block text-sm font-medium text-gray-700 mb-3 text-center">
                      {angle === 'front' ? t('Front Face', 'সামনের মুখ') : 
                       angle === 'left' ? t('Left Side', 'বাম দিক') : 
                       t('Right Side', 'ডান দিক')} *
                    </label>
                    <label className="flex flex-col items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-indigo-400 transition-all bg-gray-50">
                      {selfies[angle] ? (
                        <div className="text-center">
                          <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-2" />
                          <p className="text-sm font-medium text-gray-900">
                            {t('Captured', 'ক্যাপচার করা হয়েছে')}
                          </p>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Camera className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm font-medium text-gray-700">
                            {t('Take Selfie', 'সেলফি নিন')}
                          </p>
                        </div>
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        capture="user"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleSelfieUpload(angle, file);
                        }}
                        className="hidden"
                      />
                    </label>
                  </div>
                ))}
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-8">
                <div className="flex">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-1">
                      {t('Selfie Guidelines', 'সেলফি নির্দেশিকা')}
                    </h4>
                    <ul className="text-sm text-yellow-800 space-y-1">
                      <li>• {t('Good lighting with clear face visibility', 'স্পষ্ট মুখ দৃশ্যমানতা সহ ভাল আলো')}</li>
                      <li>• {t('Remove glasses and face masks', 'চশমা এবং ফেস মাস্ক সরান')}</li>
                      <li>• {t('Look directly at camera for front selfie', 'সামনের সেলফির জন্য সরাসরি ক্যামেরার দিকে তাকান')}</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setCurrentStep(1)}
                  className="flex-1 bg-gray-200 text-gray-700 py-4 px-6 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
                >
                  {t('Back', 'পেছনে')}
                </button>
                <button
                  onClick={handleSelfieSubmit}
                  disabled={!selfies.front || !selfies.left || !selfies.right}
                  className="flex-1 bg-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                >
                  {t('Continue to Wallet Setup', 'ওয়ালেট সেটআপে এগিয়ে যান')}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Wallet Setup */}
          {currentStep === 3 && (
            <div>
              <div className="flex items-center space-x-3 mb-8">
                <Wallet className="w-10 h-10 text-indigo-600" />
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {t('Connect Digital Wallet', 'ডিজিটাল ওয়ালেট সংযুক্ত করুন')}
                  </h2>
                  <p className="text-gray-600">
                    {t('Receive automatic commission payments', 'স্বয়ংক্রিয় কমিশন পেমেন্ট পান')}
                  </p>
                </div>
              </div>

              <form onSubmit={handleWalletSubmit} className="space-y-8">
                {/* Wallet Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-4">
                    {t('Select Your Wallet Provider', 'আপনার ওয়ালেট প্রদানকারী নির্বাচন করুন')}
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {walletProviders.map((wallet) => (
                      <label
                        key={wallet.name}
                        className={`
                          flex flex-col items-center p-4 border-2 rounded-xl cursor-pointer transition-all
                          ${walletForm.provider === wallet.name ? 'border-indigo-600 bg-indigo-50' : 'border-gray-200 hover:border-gray-300'}
                        `}
                      >
                        <input
                          type="radio"
                          name="wallet_provider"
                          value={wallet.name}
                          checked={walletForm.provider === wallet.name}
                          onChange={(e) => setWalletForm({ ...walletForm, provider: e.target.value })}
                          className="sr-only"
                        />
                        <div className={`w-12 h-12 bg-gradient-to-br ${wallet.color} rounded-xl flex items-center justify-center mb-2`}>
                          <Wallet className="w-6 h-6 text-white" />
                        </div>
                        <span className={`text-sm font-medium ${walletForm.provider === wallet.name ? 'text-indigo-900' : 'text-gray-700'}`}>
                          {wallet.name}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('Wallet Phone Number', 'ওয়ালেট ফোন নম্বর')} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={walletForm.phone_number}
                    onChange={(e) => setWalletForm({ ...walletForm, phone_number: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="01XXXXXXXXX"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    {t('Commission will be sent to this number', 'এই নম্বরে কমিশন পাঠানো হবে')}
                  </p>
                </div>

                {/* Info Box */}
                <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                  <div className="flex">
                    <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-green-900 mb-1">
                        {t('How Commission Works', 'কমিশন কিভাবে কাজ করে')}
                      </h4>
                      <p className="text-sm text-green-800">
                        {t('You receive 20% of the fine amount automatically when your report is approved and the violator pays the fine.', 'আপনার রিপোর্ট অনুমোদিত হলে এবং আইন লঙ্ঘনকারী জরিমানা পরিশোধ করলে আপনি স্বয়ংক্রিয়ভাবে জরিমানা পরিমাণের ২০% পাবেন।')}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => navigate('/dashboard')}
                    className="flex-1 bg-gray-200 text-gray-700 py-4 px-6 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
                  >
                    {t('Skip for now', 'এখনও এড়িয়ে যান')}
                  </button>
                  <button
                    type="submit"
                    disabled={walletApi.loading || !walletForm.provider || !walletForm.phone_number}
                    className="flex-1 bg-green-600 text-white py-4 px-6 rounded-xl font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                  >
                    {walletApi.loading ? (
                      t('Verifying...', 'যাচাই করা হচ্ছে...')
                    ) : (
                      <>
                        <CheckCircle2 className="w-5 h-5 mr-2" />
                        {t('Complete Setup', 'সেটআপ সম্পূর্ণ করুন')}
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
