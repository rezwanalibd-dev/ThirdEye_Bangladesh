import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Eye, EyeOff, Phone, Shield, AlertCircle } from "lucide-react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import BackButton from '@/react-app/components/BackButton';

export default function Signin() {
  const { signin, user, isLoading } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  useEffect(() => {
    // If user is already logged in, redirect them to dashboard after they click sign in
    if (user && !isLoading) {
      navigate('/dashboard', { replace: true });
    }
  }, [user, isLoading, navigate]);
  
  const [formData, setFormData] = useState({
    mobile_number: "",
    password: ""
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (isLoading) {
    return <LoadingSpinner />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formData.mobile_number || !formData.password) {
      setError(t("Please fill in all fields", "সকল ক্ষেত্র পূরণ করুন"));
      return;
    }

    setLoading(true);
    try {
      await signin(formData.mobile_number, formData.password);
      // Navigate to dashboard after successful signin
      navigate('/dashboard', { replace: true });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setError(errorMessage || t("Sign in failed", "সাইন ইন ব্যর্থ"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-ash flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <BackButton 
              to="/" 
              label={t("Back to Home", "হোমে ফিরুন")}
              className="inline-flex items-center hover:bg-primary p-2 rounded-lg transition-colors"
            />
          </div>
          
          <div className="icon-primary w-16 h-16 mx-auto mb-4">
            <Shield className="w-8 h-8" />
          </div>
          
          <h1 className="text-display-2 font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            {t("Welcome Back", "স্বাগতম")}
          </h1>
          <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
            {t("Sign in to your Third Eye account", "আপনার তৃতীয় চোখ অ্যাকাউন্টে সাইন ইন করুন")}
          </p>
        </div>

        {/* Form */}
        <div className="card-base p-8">
          {error && (
            <div className="bg-danger border rounded-lg p-4 mb-6 flex items-center" style={{ borderColor: 'var(--color-light-red-dark)' }}>
              <AlertCircle className="w-5 h-5 mr-3 flex-shrink-0" style={{ color: 'var(--color-light-red-dark)' }} />
              <span className="text-sm" style={{ color: 'var(--color-light-red-dark)' }}>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Mobile Number */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Mobile Number", "মোবাইল নম্বর")}
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                <input
                  type="tel"
                  value={formData.mobile_number}
                  onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                  className="input-base pl-10"
                  placeholder={t("01XXXXXXXXX", "০১XXXXXXXXX")}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t("Password", "পাসওয়ার্ড")}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="input-base pr-10"
                  placeholder={t("Enter your password", "আপনার পাসওয়ার্ড লিখুন")}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 hover:bg-ash p-1 rounded transition-colors"
                >
                  {showPassword ? 
                    <EyeOff className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} /> : 
                    <Eye className="w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
                  }
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full"
            >
              {loading ? t("Signing In...", "সাইন ইন করা হচ্ছে...") : t("Sign In", "সাইন ইন")}
            </button>
          </form>

          {/* Sign Up Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {t("Don't have an account?", "অ্যাকাউন্ট নেই?")} {" "}
              <Link to="/signup" className="font-medium hover:underline" style={{ color: 'var(--color-primary-blue-dark)' }}>
                {t("Sign Up", "সাইন আপ")}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
