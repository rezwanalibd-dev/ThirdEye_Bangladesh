import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useApi } from '@/react-app/hooks/useApi';
import {
  User,
  Lock,
  Bell,
  Shield,
  LogOut,
  Camera,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  Trash2,
  PauseCircle,
  Save,
  X,
  Smartphone,
  Download
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

type SettingsTab = 'profile' | 'password' | 'notifications' | 'privacy' | 'mobile';

export default function Settings() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const updateProfileApi = useApi();
  const changePasswordApi = useApi();
  const deactivateAccountApi = useApi();
  const deleteAccountApi = useApi();

  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [profilePicture, setProfilePicture] = useState<string>('');
  const [uploadingPicture, setUploadingPicture] = useState(false);

  // Profile form
  const [profileForm, setProfileForm] = useState({
    full_name: user?.full_name || '',
    email: user?.email || '',
    mobile_number: user?.mobile_number || '',
  });

  // Password change form
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: '',
    otp_code: ''
  });
  const [otpSent, setOtpSent] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Notification settings
  const [notifications, setNotifications] = useState({
    case_updates: true,
    payment_alerts: true,
    new_features: true,
    email_notifications: true,
    sms_notifications: true
  });

  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleProfilePictureUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setMessage({ type: 'error', text: t('Image must be less than 5MB', 'ছবি ৫MB এর কম হতে হবে') });
      return;
    }

    setUploadingPicture(true);
    try {
      // Convert to base64 for demo - in production, upload to R2
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result as string);
        setMessage({ type: 'success', text: t('Profile picture updated', 'প্রোফাইল ছবি আপডেট হয়েছে') });
        setUploadingPicture(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to upload picture', 'ছবি আপলোড ব্যর্থ') });
      setUploadingPicture(false);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      await updateProfileApi.execute('/api/profile/update', {
        method: 'POST',
        body: {
          ...profileForm,
          profile_picture: profilePicture
        }
      });
      setMessage({ type: 'success', text: t('Profile updated successfully', 'প্রোফাইল সফলভাবে আপডেট হয়েছে') });
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to update profile', 'প্রোফাইল আপডেট ব্যর্থ') });
    }
  };

  const handleSendOTP = async () => {
    try {
      await changePasswordApi.execute('/api/auth/send-password-otp', {
        method: 'POST',
        body: {
          contact: user?.email || user?.mobile_number
        }
      });
      setOtpSent(true);
      setMessage({ type: 'success', text: t('OTP sent successfully', 'OTP সফলভাবে পাঠানো হয়েছে') });
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to send OTP', 'OTP পাঠাতে ব্যর্থ') });
    }
  };

  const handleChangePassword = async () => {
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      setMessage({ type: 'error', text: t('Passwords do not match', 'পাসওয়ার্ড মিলছে না') });
      return;
    }

    if (!otpSent || !passwordForm.otp_code) {
      setMessage({ type: 'error', text: t('Please verify OTP first', 'প্রথমে OTP যাচাই করুন') });
      return;
    }

    try {
      await changePasswordApi.execute('/api/auth/change-password', {
        method: 'POST',
        body: passwordForm
      });
      setMessage({ type: 'success', text: t('Password changed successfully', 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে') });
      setShowPasswordModal(false);
      setPasswordForm({
        current_password: '',
        new_password: '',
        confirm_password: '',
        otp_code: ''
      });
      setOtpSent(false);
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to change password', 'পাসওয়ার্ড পরিবর্তন ব্যর্থ') });
    }
  };

  const handleDeactivateAccount = async () => {
    try {
      await deactivateAccountApi.execute('/api/account/deactivate', {
        method: 'POST'
      });
      setMessage({ type: 'success', text: t('Account deactivated', 'অ্যাকাউন্ট নিষ্ক্রিয় করা হয়েছে') });
      setShowDeactivateModal(false);
      setTimeout(() => logout(), 2000);
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to deactivate account', 'অ্যাকাউন্ট নিষ্ক্রিয় ব্যর্থ') });
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await deleteAccountApi.execute('/api/account/delete', {
        method: 'POST'
      });
      setMessage({ type: 'success', text: t('Account deleted', 'অ্যাকাউন্ট মুছে ফেলা হয়েছে') });
      setShowDeleteModal(false);
      setTimeout(() => logout(), 2000);
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to delete account', 'অ্যাকাউন্ট মুছে ফেলা ব্যর্থ') });
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const tabs = [
    { id: 'profile' as SettingsTab, name: t('Edit Profile', 'প্রোফাইল সম্পাদনা'), icon: User },
    { id: 'password' as SettingsTab, name: t('Change Password', 'পাসওয়ার্ড পরিবর্তন'), icon: Lock },
    { id: 'notifications' as SettingsTab, name: t('Notification Settings', 'বিজ্ঞপ্তি সেটিংস'), icon: Bell },
    { id: 'privacy' as SettingsTab, name: t('Privacy & Security', 'গোপনীয়তা ও নিরাপত্তা'), icon: Shield },
    { id: 'mobile' as SettingsTab, name: t('Mobile App', 'মোবাইল অ্যাপ'), icon: Smartphone }
  ];

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BackButton to="/dashboard" className="p-2 hover:bg-ash rounded-lg transition-colors touch-target" />
              <div>
                <h1 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Settings', 'সেটিংস')}
                </h1>
                <p className="text-sm text-gray-600">
                  {t('Manage your account preferences', 'আপনার অ্যাকাউন্ট পছন্দ পরিচালনা করুন')}
                </p>
              </div>
            </div>
            <button onClick={handleLogout} className="btn-danger flex items-center space-x-2">
              <LogOut className="w-5 h-5" />
              <span>{t('Logout', 'লগআউট')}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Message */}
      {message && (
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className={`flex items-center p-4 rounded-lg ${
            message.type === 'success' ? 'bg-success border border-green-200' : 'bg-danger border border-red-200'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5 mr-3" style={{ color: 'var(--color-light-green-dark)' }} />
            ) : (
              <AlertCircle className="w-5 h-5 mr-3" style={{ color: 'var(--color-light-red-dark)' }} />
            )}
            <span className={message.type === 'success' ? 'text-green-700' : 'text-red-700'}>{message.text}</span>
            <button onClick={() => setMessage(null)} className="ml-auto">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      <main className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="card-base p-4 space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full text-left p-3 rounded-lg transition-all flex items-center space-x-3 ${
                      activeTab === tab.id
                        ? 'bg-primary text-blue-700 font-medium'
                        : 'hover:bg-ash text-gray-700'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-sm">{tab.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            {/* Edit Profile Tab */}
            {activeTab === 'profile' && (
              <div className="card-base p-8 space-y-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Edit Profile', 'প্রোফাইল সম্পাদনা')}
                </h2>

                {/* Profile Picture */}
                <div className="flex items-center space-x-6">
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full bg-ash flex items-center justify-center overflow-hidden">
                      {profilePicture ? (
                        <img src={profilePicture} alt="Profile" className="w-full h-full object-cover" />
                      ) : (
                        <User className="w-12 h-12 text-gray-400" />
                      )}
                    </div>
                    <label className="absolute bottom-0 right-0 bg-white p-2 rounded-full shadow-lg cursor-pointer hover:bg-ash transition-colors border border-gray-200">
                      <Camera className="w-4 h-4 text-gray-700" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleProfilePictureUpload}
                        className="hidden"
                        disabled={uploadingPicture}
                      />
                    </label>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{user?.full_name}</h3>
                    <p className="text-sm text-gray-600">{user?.email || user?.mobile_number}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {t('Click camera icon to upload photo', 'ছবি আপলোড করতে কোনো আইকনে ক্লিক করুন')}
                    </p>
                  </div>
                </div>

                {/* Profile Form */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('Full Name', 'পূর্ণ নাম')}</label>
                    <input
                      type="text"
                      value={profileForm.full_name}
                      onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                      className="input-base"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">{t('Email Address', 'ইমেল ঠিকানা')}</label>
                    <input
                      type="email"
                      value={profileForm.email}
                      onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                      className="input-base"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">{t('Mobile Number', 'মোবাইল নম্বর')}</label>
                    <input
                      type="tel"
                      value={profileForm.mobile_number}
                      className="input-base bg-gray-100 cursor-not-allowed"
                      disabled
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {t('Mobile number cannot be changed', 'মোবাইল নম্বর পরিবর্তন করা যাবে না')}
                    </p>
                  </div>

                  <button
                    onClick={handleUpdateProfile}
                    disabled={updateProfileApi.loading}
                    className="btn-primary flex items-center space-x-2"
                  >
                    <Save className="w-5 h-5" />
                    <span>{updateProfileApi.loading ? t('Saving...', 'সংরক্ষণ করা হচ্ছে...') : t('Save Changes', 'পরিবর্তন সংরক্ষণ করুন')}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Change Password Tab */}
            {activeTab === 'password' && (
              <div className="card-base p-8 space-y-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Change Password', 'পাসওয়ার্ড পরিবর্তন')}
                </h2>

                <button onClick={() => setShowPasswordModal(true)} className="btn-primary">
                  {t('Change Password with OTP', 'OTP দিয়ে পাসওয়ার্ড পরিবর্তন করুন')}
                </button>

                <div className="bg-primary p-4 rounded-lg border border-blue-200">
                  <p className="text-sm" style={{ color: 'var(--color-light-blue-dark)' }}>
                    {t('For security, you need to verify your identity with OTP sent to', 'নিরাপত্তার জন্য, আপনাকে OTP দিয়ে আপনার পরিচয় যাচাই করতে হবে')}:
                    <strong className="ml-1">{user?.email || user?.mobile_number}</strong>
                  </p>
                </div>
              </div>
            )}

            {/* Notification Settings Tab */}
            {activeTab === 'notifications' && (
              <div className="card-base p-8 space-y-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Notification Settings', 'বিজ্ঞপ্তি সেটিংস')}
                </h2>

                <div className="space-y-4">
                  {Object.entries(notifications).map(([key, value]) => (
                    <label key={key} className="flex items-center justify-between p-4 hover:bg-ash rounded-lg cursor-pointer">
                      <div>
                        <p className="font-medium">
                          {t(
                            key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
                            key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
                          )}
                        </p>
                        <p className="text-sm text-gray-600">
                          {t('Receive notifications for this category', 'এই বিভাগের জন্য বিজ্ঞপ্তি পান')}
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={value}
                        onChange={(e) => setNotifications({ ...notifications, [key]: e.target.checked })}
                        className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </label>
                  ))}
                </div>

                <button className="btn-primary">
                  {t('Save Notification Settings', 'বিজ্ঞপ্তি সেটিংস সংরক্ষণ করুন')}
                </button>
              </div>
            )}

            {/* Privacy & Security Tab */}
            {activeTab === 'privacy' && (
              <div className="card-base p-8 space-y-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Privacy & Security', 'গোপনীয়তা ও নিরাপত্তা')}
                </h2>

                <div className="space-y-4">
                  {/* Deactivate Account */}
                  <div className="border-2 border-yellow-200 bg-yellow-50 rounded-lg p-6">
                    <div className="flex items-start space-x-4">
                      <PauseCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
                      <div className="flex-1">
                        <h3 className="font-bold text-lg text-yellow-900 mb-2">
                          {t('Deactivate Account', 'অ্যাকাউন্ট নিষ্ক্রিয় করুন')}
                        </h3>
                        <p className="text-sm text-yellow-800 mb-4">
                          {t('Temporarily disable your account. You can reactivate it anytime by logging in.', 'সাময়িকভাবে আপনার অ্যাকাউন্ট নিষ্ক্রিয় করুন। আপনি লগ ইন করে যেকোনো সময় এটি পুনরায় সক্রিয় করতে পারেন।')}
                        </p>
                        <button
                          onClick={() => setShowDeactivateModal(true)}
                          className="btn-secondary text-yellow-700 border-yellow-300"
                        >
                          {t('Deactivate Account', 'অ্যাকাউন্ট নিষ্ক্রিয় করুন')}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Delete Account */}
                  <div className="border-2 border-red-200 bg-danger rounded-lg p-6">
                    <div className="flex items-start space-x-4">
                      <Trash2 className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                      <div className="flex-1">
                        <h3 className="font-bold text-lg text-red-900 mb-2">
                          {t('Delete Account Permanently', 'স্থায়ীভাবে অ্যাকাউন্ট মুছুন')}
                        </h3>
                        <p className="text-sm text-red-800 mb-4">
                          {t('Permanently delete your account and all data. This action cannot be undone.', 'স্থায়ীভাবে আপনার অ্যাকাউন্ট এবং সমস্ত ডেটা মুছুন। এই ক্রিয়া পূর্বাবস্থায় ফেরানো যাবে না।')}
                        </p>
                        <button
                          onClick={() => setShowDeleteModal(true)}
                          className="btn-danger"
                        >
                          {t('Delete Account Permanently', 'স্থায়ীভাবে অ্যাকাউন্ট মুছুন')}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Mobile App Tab */}
            {activeTab === 'mobile' && (
              <div className="card-base p-8 space-y-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Install Mobile App', 'মোবাইল অ্যাপ ইনস্টল করুন')}
                </h2>

                {/* PWA Install Section */}
                <div className="border-2 border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 text-center">
                  <div className="icon-primary w-20 h-20 mx-auto mb-4">
                    <Download className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-primary-blue-dark)' }}>
                    {t('Install Third Eye on Your Device', 'আপনার ডিভাইসে তৃতীয় চোখ ইনস্টল করুন')}
                  </h3>
                  <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
                    {t(
                      'Install our Progressive Web App directly on your device for the best experience. Works on Android, iOS, and all modern devices.',
                      'সর্বোত্তম অভিজ্ঞতার জন্য সরাসরি আপনার ডিভাইসে আমাদের প্রগ্রেসিভ ওয়েব অ্যাপ ইনস্টল করুন। Android, iOS এবং সমস্ত আধুনিক ডিভাইসে কাজ করে।'
                    )}
                  </p>

                  <div className="bg-white rounded-lg p-6 mb-6 text-left max-w-2xl mx-auto">
                    <h4 className="font-semibold mb-4 flex items-center">
                      <Smartphone className="w-5 h-5 mr-2" style={{ color: 'var(--color-primary-blue-dark)' }} />
                      {t('Installation Steps:', 'ইনস্টলেশন ধাপ:')}
                    </h4>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold text-xs">1</span>
                        <div>
                          <p className="font-medium">{t('Android:', 'Android:')}</p>
                          <p className="text-gray-600">{t('Tap "Add to Home Screen" in browser menu or wait for install prompt', 'ব্রাউজার মেনুতে "হোম স্ক্রিনে যোগ করুন" ট্যাপ করুন বা ইনস্টল প্রম্পটের জন্য অপেক্ষা করুন')}</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold text-xs">2</span>
                        <div>
                          <p className="font-medium">{t('iOS (Safari):', 'iOS (Safari):')}</p>
                          <p className="text-gray-600">{t('Tap Share button → "Add to Home Screen"', 'শেয়ার বাটন ট্যাপ করুন → "হোম স্ক্রিনে যোগ করুন"')}</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold text-xs">3</span>
                        <div>
                          <p className="font-medium">{t('Desktop:', 'ডেস্কটপ:')}</p>
                          <p className="text-gray-600">{t('Click install icon in address bar or browser menu', 'ঠিকানা বার বা ব্রাউজার মেনুতে ইনস্টল আইকন ক্লিক করুন')}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="inline-flex items-center px-6 py-3 bg-green-100 rounded-lg text-green-800 mb-4">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    <span className="font-medium">
                      {t('No app store needed • Instant install • Automatic updates', 'কোনো অ্যাপ স্টোর প্রয়োজন নেই • তাৎক্ষণিক ইনস্টল • স্বয়ংক্রিয় আপডেট')}
                    </span>
                  </div>
                </div>

                {/* App Features */}
                <div className="bg-ash p-6 rounded-lg">
                  <h4 className="font-semibold mb-4 text-lg">{t('App Features', 'অ্যাপ বৈশিষ্ট্য')}</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('Works Offline', 'অফলাইনে কাজ করে')}</p>
                        <p className="text-xs text-gray-600">{t('Access features without internet', 'ইন্টারনেট ছাড়াই বৈশিষ্ট্য অ্যাক্সেস করুন')}</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('Fast & Lightweight', 'দ্রুত এবং হালকা')}</p>
                        <p className="text-xs text-gray-600">{t('Less than 5MB download', '৫MB এর কম ডাউনলোড')}</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('Push Notifications', 'পুশ বিজ্ঞপ্তি')}</p>
                        <p className="text-xs text-gray-600">{t('Real-time case updates', 'রিয়েল-টাইম কেস আপডেট')}</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('Native Feel', 'নেটিভ ফিল')}</p>
                        <p className="text-xs text-gray-600">{t('App-like experience', 'অ্যাপের মতো অভিজ্ঞতা')}</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('Camera Access', 'ক্যামেরা অ্যাক্সেস')}</p>
                        <p className="text-xs text-gray-600">{t('Report violations instantly', 'তাৎক্ষণিক লঙ্ঘন রিপোর্ট করুন')}</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                      <div>
                        <p className="font-medium text-sm">{t('GPS Tracking', 'GPS ট্র্যাকিং')}</p>
                        <p className="text-xs text-gray-600">{t('Accurate location detection', 'সঠিক অবস্থান সনাক্তকরণ')}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Benefits */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg text-center">
                    <div className="text-3xl mb-2">⚡</div>
                    <p className="font-semibold text-sm">{t('Instant Access', 'তাৎক্ষণিক অ্যাক্সেস')}</p>
                    <p className="text-xs text-gray-600 mt-1">{t('Launch from home screen', 'হোম স্ক্রিন থেকে চালু করুন')}</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg text-center">
                    <div className="text-3xl mb-2">🔒</div>
                    <p className="font-semibold text-sm">{t('Secure & Private', 'নিরাপদ এবং ব্যক্তিগত')}</p>
                    <p className="text-xs text-gray-600 mt-1">{t('HTTPS encrypted', 'HTTPS এনক্রিপ্টেড')}</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg text-center">
                    <div className="text-3xl mb-2">🔄</div>
                    <p className="font-semibold text-sm">{t('Always Updated', 'সর্বদা আপডেট')}</p>
                    <p className="text-xs text-gray-600 mt-1">{t('Automatic updates', 'স্বয়ংক্রিয় আপডেট')}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="card-base max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">{t('Change Password', 'পাসওয়ার্ড পরিবর্তন')}</h2>
              <button onClick={() => setShowPasswordModal(false)} className="p-2 hover:bg-ash rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">{t('Current Password', 'বর্তমান পাসওয়ার্ড')}</label>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    value={passwordForm.current_password}
                    onChange={(e) => setPasswordForm({ ...passwordForm, current_password: e.target.value })}
                    className="input-base pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t('New Password', 'নতুন পাসওয়ার্ড')}</label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={passwordForm.new_password}
                    onChange={(e) => setPasswordForm({ ...passwordForm, new_password: e.target.value })}
                    className="input-base pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t('Confirm New Password', 'নতুন পাসওয়ার্ড নিশ্চিত করুন')}</label>
                <input
                  type="password"
                  value={passwordForm.confirm_password}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirm_password: e.target.value })}
                  className="input-base"
                />
              </div>

              {!otpSent ? (
                <button onClick={handleSendOTP} className="btn-primary w-full" disabled={changePasswordApi.loading}>
                  {t('Send OTP to Verify', 'যাচাই করতে OTP পাঠান')}
                </button>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('Enter OTP', 'OTP লিখুন')}</label>
                    <input
                      type="text"
                      value={passwordForm.otp_code}
                      onChange={(e) => setPasswordForm({ ...passwordForm, otp_code: e.target.value })}
                      className="input-base"
                      placeholder="000000"
                      maxLength={6}
                    />
                  </div>

                  <div className="flex space-x-3">
                    <button onClick={() => setShowPasswordModal(false)} className="btn-secondary flex-1">
                      {t('Cancel', 'বাতিল')}
                    </button>
                    <button onClick={handleChangePassword} className="btn-primary flex-1" disabled={changePasswordApi.loading}>
                      {changePasswordApi.loading ? t('Changing...', 'পরিবর্তন করা হচ্ছে...') : t('Change Password', 'পাসওয়ার্ড পরিবর্তন')}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Deactivate Account Modal */}
      {showDeactivateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="card-base max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4 text-yellow-900">{t('Deactivate Account?', 'অ্যাকাউন্ট নিষ্ক্রিয় করবেন?')}</h2>
            <p className="text-gray-700 mb-6">
              {t('Your account will be temporarily disabled. You can reactivate by logging in again.', 'আপনার অ্যাকাউন্ট সাময়িকভাবে নিষ্ক্রিয় করা হবে। আপনি আবার লগ ইন করে পুনরায় সক্রিয় করতে পারেন।')}
            </p>
            <div className="flex space-x-3">
              <button onClick={() => setShowDeactivateModal(false)} className="btn-secondary flex-1">
                {t('Cancel', 'বাতিল')}
              </button>
              <button onClick={handleDeactivateAccount} className="btn-danger flex-1" disabled={deactivateAccountApi.loading}>
                {deactivateAccountApi.loading ? t('Deactivating...', 'নিষ্ক্রিয় করা হচ্ছে...') : t('Deactivate', 'নিষ্ক্রিয় করুন')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Account Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="card-base max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4 text-red-900">{t('Delete Account Permanently?', 'স্থায়ীভাবে অ্যাকাউন্ট মুছবেন?')}</h2>
            <p className="text-gray-700 mb-6">
              {t('This action cannot be undone. All your data will be permanently deleted.', 'এই ক্রিয়া পূর্বাবস্থায় ফেরানো যাবে না। আপনার সমস্ত ডেটা স্থায়ীভাবে মুছে ফেলা হবে।')}
            </p>
            <div className="flex space-x-3">
              <button onClick={() => setShowDeleteModal(false)} className="btn-secondary flex-1">
                {t('Cancel', 'বাতিল')}
              </button>
              <button onClick={handleDeleteAccount} className="btn-danger flex-1" disabled={deleteAccountApi.loading}>
                {deleteAccountApi.loading ? t('Deleting...', 'মুছে ফেলা হচ্ছে...') : t('Delete Permanently', 'স্থায়ীভাবে মুছুন')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
