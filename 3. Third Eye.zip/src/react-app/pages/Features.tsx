import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Link } from "react-router";
import { Eye, Camera, Shield, DollarSign, Clock, Star, Globe, MapPin, Users, ArrowRight } from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

export default function Features() {
  const { language, setLanguage, t } = useLanguage();

  const features = [
    {
      icon: Camera,
      title: t('Easy Reporting', 'সহজ রিপোর্টিং'),
      desc: t('Snap photos and report violations instantly with our simple 4-step process', 'আমাদের সহজ ৪-ধাপ প্রক্রিয়ার সাথে ছবি তুলুন এবং তৎক্ষণাৎ আইন লঙ্ঘন রিপোর্ট করুন'),
      colorClass: 'bg-primary-dark'
    },
    {
      icon: DollarSign,
      title: t('Earn Rewards', 'পুরস্কার অর্জন'),
      desc: t('Get 20% commission on verified reports. Earn ৳500-5000 per month', 'যাচাইকৃত রিপোর্টে ২০% কমিশন পান। মাসে ৳৫০০-৫০০০ উপার্জন করুন'),
      colorClass: 'bg-success-dark'
    },
    {
      icon: Shield,
      title: t('Secure & Verified', 'নিরাপদ এবং যাচাইকৃত'),
      desc: t('KYC verified platform with instant mobile wallet payments', 'তাৎক্ষণিক মোবাইল ওয়ালেট পেমেন্ট সহ কেওয়াইসি যাচাইকৃত প্ল্যাটফর্ম'),
      colorClass: 'bg-danger-dark'
    },
    {
      icon: Clock,
      title: t('24/7 Monitoring', '২৪/৭ মনিটরিং'),
      desc: t('Round-the-clock officer review and case processing', 'সার্বক্ষণিক অফিসার পর্যালোচনা এবং কেস প্রক্রিয়াকরণ'),
      colorClass: 'bg-primary-dark'
    },
    {
      icon: Globe,
      title: t('Bilingual Support', 'দ্বিভাষিক সহায়তা'),
      desc: t('Complete Bengali and English interface for all users', 'সমস্ত ব্যবহারকারীদের জন্য সম্পূর্ণ বাংলা এবং ইংরেজি ইন্টারফেস'),
      colorClass: 'bg-success-dark'
    },
    {
      icon: MapPin,
      title: t('GPS Location', 'জিপিএস অবস্থান'),
      desc: t('Automatic location detection for accurate violation reporting', 'সঠিক আইন লঙ্ঘন রিপোর্টিংয়ের জন্য স্বয়ংক্রিয় অবস্থান সনাক্তকরণ'),
      colorClass: 'bg-danger-dark'
    }
  ];

  const stats = [
    { number: '15,000+', label: t('Active Users', 'সক্রিয় ব্যবহারকারী'), icon: Users },
    { number: '75,000+', label: t('Reports Submitted', 'রিপোর্ট জমা'), icon: Camera },
    { number: '3.5M+', label: t('Rewards Paid', 'পুরস্কার প্রদান'), icon: DollarSign },
    { number: '98%', label: t('Satisfaction Rate', 'সন্তুষ্টির হার'), icon: Star }
  ];

  const testimonials = [
    {
      name: t('Rashida Begum', 'রশিদা বেগম'),
      role: t('Housewife, Dhaka', 'গৃহিণী, ঢাকা'),
      text: t('I earned ৳2,500 last month just by reporting violations during my daily commute!', 'আমি গত মাসে আমার দৈনিক যাতায়াতের সময় আইন লঙ্ঘন রিপোর্ট করে ৳২,৫০০ উপার্জন করেছি!'),
      rating: 5
    },
    {
      name: t('Ahmed Rahman', 'আহমেদ রহমান'),
      role: t('Student, Chittagong', 'ছাত্র, চট্টগ্রাম'),
      text: t('The app is so easy to use. I help make roads safer and earn pocket money.', 'অ্যাপটি ব্যবহার করা খুবই সহজ। আমি রাস্তা নিরাপদ করতে সাহায্য করি এবং পকেট মানি উপার্জন করি।'),
      rating: 5
    },
    {
      name: t('Dr. Fatema Khatun', 'ড. ফাতেমা খাতুন'),
      role: t('Doctor, Sylhet', 'ডাক্তার, সিলেট'),
      text: t('As a healthcare worker, I see the impact of road accidents. This app helps prevent them.', 'একজন স্বাস্থ্যকর্মী হিসেবে আমি সড়ক দুর্ঘটনার প্রভাব দেখি। এই অ্যাপটি সেগুলো প্রতিরোধে সহায়তা করে।'),
      rating: 5
    }
  ];

  const violationTypes = [
    { name: t('Signal Violation', 'সিগন্যাল আইন লঙ্ঘন'), fine: '৳5,000' },
    { name: t('No Helmet', 'হেলমেট নেই'), fine: '৳2,000' },
    { name: t('Speed Limit Violation', 'গতিসীমা আইন লঙ্ঘন'), fine: '৳4,000' },
    { name: t('Mobile Use', 'মোবাইল ব্যবহার'), fine: '৳3,500' },
    { name: t('No Seatbelt', 'সিটবেল্ট নেই'), fine: '৳2,500' },
    { name: t('Road Blocking', 'রাস্তা অবরোধ'), fine: '৳4,000' },
    { name: t('Illegal Parking', 'অবৈধ পার্কিং'), fine: '৳2,000' },
    { name: t('One-Way Violation', 'ওয়ান-ওয়ে আইন লঙ্ঘন'), fine: '৳3,500' },
    { name: t('Driving on Footpath', 'ফুটপাথে গাড়ি চালানো'), fine: '৳3,500' },
    { name: t('Using Loud Exhausts', 'উচ্চস্বরে এক্সজস্ট ব্যবহার'), fine: '৳2,500' },
    { name: t('Using Hydraulic Horns', 'হাইড্রোলিক হর্ন ব্যবহার'), fine: '৳2,500' },
    { name: t('Using Red & Blue Emergency Lights', 'লাল এবং নীল জরুরি লাইট ব্যবহার'), fine: '৳5,000' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b shadow-sm" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <BackButton to="/" />
              <Link to="/" className="flex items-center space-x-3">
                <div className="icon-primary w-10 h-10 sm:w-12 sm:h-12">
                  <Eye className="w-6 h-6 sm:w-8 sm:h-8" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                    {t('Third Eye', 'তৃতীয় চোখ')}
                  </h1>
                  <p className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>
                    {t('Features & Benefits', 'বৈশিষ্ট্য এবং সুবিধা')}
                  </p>
                </div>
              </Link>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="btn-secondary btn-small"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
              
              <Link to="/signup" className="btn-primary flex items-center">
                {t('Sign Up', 'সাইন আপ')}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-24 pb-16">
        {/* Stats Section */}
        <div className="bg-primary py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Our Impact', 'আমাদের প্রভাব')}
              </h2>
              <p className="text-lg sm:text-xl text-gray-600">
                {t('Making a real difference on Bangladesh roads', 'বাংলাদেশের রাস্তায় প্রকৃত পরিবর্তন আনা')}
              </p>
            </div>
            <div className="grid-stats gap-4 sm:gap-8">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="text-center group">
                    <div className="card-base p-6 sm:p-8 hover:shadow-lg transition-all duration-300 group-hover:scale-105">
                      <div className="icon-primary w-12 h-12 mx-auto mb-4">
                        <Icon className="w-6 h-6 sm:w-8 sm:h-8" />
                      </div>
                      <p className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                        {stat.number}
                      </p>
                      <p className="text-sm sm:text-base text-gray-600 font-medium">{stat.label}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="bg-white py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12 sm:mb-16">
              <h3 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Why Choose Third Eye?', 'কেন তৃতীয় চোখ বেছে নিবেন?')}
              </h3>
              <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
                {t(
                  'Advanced features designed for the modern citizen who wants to make a difference',
                  'আধুনিক নাগরিকদের জন্য ডিজাইন করা উন্নত বৈশিষ্ট্য যারা একটি পরিবর্তন আনতে চান'
                )}
              </p>
            </div>
            
            <div className="grid-cards gap-6 sm:gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="card-base p-6 sm:p-8 hover:shadow-xl transition-all duration-300 group">
                    <div className={`${feature.colorClass} w-14 h-14 sm:w-16 sm:h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                    </div>
                    <h4 className="text-lg sm:text-xl font-bold mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {feature.title}
                    </h4>
                    <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                      {feature.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Common Violations Section */}
        <div className="bg-ash py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12 sm:mb-16">
              <h3 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Common Traffic Violations', 'সাধারণ ট্রাফিক আইন লঙ্ঘন')}
              </h3>
              <p className="text-lg sm:text-xl text-gray-600">
                {t('High-reward violations you can report', 'উচ্চ পুরস্কারের আইন লঙ্ঘন যা আপনি রিপোর্ট করতে পারেন')}
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {violationTypes.map((violation, index) => (
                <div key={index} className="card-base p-5 sm:p-6 hover:shadow-lg transition-all duration-300">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="font-semibold text-sm sm:text-base" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {violation.name}
                    </h4>
                    <span className="badge-success whitespace-nowrap ml-2">
                      {violation.fine}
                    </span>
                  </div>
                  <div className="flex items-center text-xs sm:text-sm text-gray-600">
                    <DollarSign className="w-4 h-4 mr-1 flex-shrink-0" style={{ color: 'var(--color-light-green-dark)' }} />
                    <span>
                      {t('Your commission: 20%', 'আপনার কমিশন: ২০%')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="bg-white py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12 sm:mb-16">
              <h3 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('What Our Users Say', 'আমাদের ব্যবহারকারীরা কী বলেন')}
              </h3>
              <p className="text-lg sm:text-xl text-gray-600">
                {t('Real stories from real people making a difference', 'পরিবর্তন আনা প্রকৃত মানুষের প্রকৃত গল্প')}
              </p>
            </div>
            
            <div className="grid-cards gap-6 sm:gap-8">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="card-base p-6 sm:p-8 hover:shadow-lg transition-all duration-300">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm sm:text-base text-gray-700 mb-6 italic leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  <div>
                    <p className="font-semibold text-sm sm:text-base" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {testimonial.name}
                    </p>
                    <p className="text-xs sm:text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-primary-dark py-16 sm:py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h3 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              {t('Ready to Get Started?', 'শুরু করতে প্রস্তুত?')}
            </h3>
            <p className="text-lg sm:text-xl text-white/90 mb-8">
              {t(
                'Join thousands of citizens making Bangladesh roads safer today',
                'আজই বাংলাদেশের রাস্তা নিরাপদ করতে হাজার হাজার নাগরিকের সাথে যোগ দিন'
              )}
            </p>
            <Link
              to="/signup"
              className="inline-flex items-center px-8 sm:px-10 py-4 sm:py-5 bg-white text-base sm:text-lg font-semibold rounded-xl hover:bg-ash transition-all duration-300 transform hover:scale-105 shadow-2xl"
              style={{ color: 'var(--color-primary-blue-dark)' }}
            >
              <Shield className="w-5 h-5 sm:w-6 sm:h-6 mr-3" />
              {t('Sign Up Free', 'বিনামূল্যে সাইন আপ করুন')}
              <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 ml-3" />
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-ash-dark text-white py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-sm sm:text-base text-gray-400">
            {t(
              '© 2025 Third Eye. Making Bangladesh roads safer through community participation.',
              '© ২০২৫ তৃতীয় চোখ। কমিউনিটি অংশগ্রহণের মাধ্যমে বাংলাদেশের রাস্তা নিরাপদ করা।'
            )}
          </p>
        </div>
      </footer>
    </div>
  );
}
