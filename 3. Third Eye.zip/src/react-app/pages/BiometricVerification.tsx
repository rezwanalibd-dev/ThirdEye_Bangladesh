import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Shield, Camera, RotateCcw, Check, AlertCircle, CheckCircle } from "lucide-react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import BackButton from '@/react-app/components/BackButton';

type CaptureStep = 'front' | 'left' | 'right' | 'complete';

export default function BiometricVerification() {
  const navigate = useNavigate();
  const { verifyBiometric } = useAuth();
  const { t } = useLanguage();
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [currentStep, setCurrentStep] = useState<CaptureStep>('front');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [captures, setCaptures] = useState({
    front: null as string | null,
    left: null as string | null,
    right: null as string | null
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [cameraReady, setCameraReady] = useState(false);

  const steps = [
    {
      key: 'front' as CaptureStep,
      title: t('Front Face', 'সামনের মুখ'),
      instruction: t('Look directly at the camera', 'সরাসরি ক্যামেরার দিকে তাকান'),
      icon: '👤'
    },
    {
      key: 'left' as CaptureStep,
      title: t('Left Profile', 'বাম প্রোফাইল'),
      instruction: t('Turn your head to the right', 'আপনার মাথা ডানদিকে ঘুরান'),
      icon: '👤'
    },
    {
      key: 'right' as CaptureStep,
      title: t('Right Profile', 'ডান প্রোফাইল'),
      instruction: t('Turn your head to the left', 'আপনার মাথা বামদিকে ঘুরান'),
      icon: '👤'
    }
  ];

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 }
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
          setCameraReady(true);
        };
      }
      setError("");
    } catch {
      setError(t('Camera access denied. Please allow camera access.', 'ক্যামেরা অ্যাক্সেস অস্বীকৃত। অনুগ্রহ করে ক্যামেরা অ্যাক্সেস অনুমতি দিন।'));
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setCameraReady(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    const imageDataUrl = canvas.toDataURL('image/jpeg', 0.8);
    
    if (currentStep !== 'complete') {
      setCaptures(prev => ({
        ...prev,
        [currentStep]: imageDataUrl
      }));
    }

    // Move to next step
    if (currentStep === 'front') {
      setCurrentStep('left');
    } else if (currentStep === 'left') {
      setCurrentStep('right');
    } else if (currentStep === 'right') {
      setCurrentStep('complete');
      stopCamera();
    }
  };

  const retakePhoto = (step: Exclude<CaptureStep, 'complete'>) => {
    setCaptures(prev => ({
      ...prev,
      [step]: null
    }));
    setCurrentStep(step);
    if (!cameraReady) {
      startCamera();
    }
  };

  const handleSubmit = async () => {
    if (!captures.front || !captures.left || !captures.right) {
      setError(t('Please capture all three photos', 'অনুগ্রহ করে তিনটি ছবিই তুলুন'));
      return;
    }

    setLoading(true);
    setError("");

    try {
      // Mock upload to generate URLs - in production, upload to actual storage
      const frontUrl = `https://mock-storage.com/biometric/${Date.now()}-front.jpg`;
      const leftUrl = `https://mock-storage.com/biometric/${Date.now()}-left.jpg`;
      const rightUrl = `https://mock-storage.com/biometric/${Date.now()}-right.jpg`;

      await verifyBiometric({
        front_face_url: frontUrl,
        left_side_url: leftUrl,
        right_side_url: rightUrl
      });

      navigate('/setup');
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : t('Biometric verification failed', 'বায়োমেট্রিক যাচাই ব্যর্থ');
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <BackButton 
              to="/verify-identity" 
              label={t("Back to Identity Verification", "পরিচয় যাচাইকরণে ফিরুন")}
              className="inline-flex items-center text-indigo-600 hover:text-indigo-700"
            />
          </div>
          
          <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-4 rounded-xl w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Shield className="w-8 h-8 text-white" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t("Biometric Verification", "বায়োমেট্রিক যাচাইকরণ")}
          </h1>
          <p className="text-gray-600">
            {t("Take three photos of your face for verification", "যাচাইকরণের জন্য আপনার মুখের তিনটি ছবি তুলুন")}
          </p>
        </div>

        {/* Progress Steps */}
        <div className="bg-white rounded-xl p-6 mb-6 shadow-lg">
          <div className="flex justify-between items-center">
            {steps.map((step, index) => {
              const isCompleted = captures[step.key as keyof typeof captures] !== null;
              const isCurrent = currentStep === step.key && currentStep !== 'complete';
              
              return (
                <div key={step.key} className="flex flex-col items-center flex-1">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                    isCompleted 
                      ? 'bg-green-500 text-white' 
                      : isCurrent 
                        ? 'bg-indigo-500 text-white' 
                        : 'bg-gray-200 text-gray-500'
                  }`}>
                    {isCompleted ? <Check className="w-6 h-6" /> : <Camera className="w-6 h-6" />}
                  </div>
                  <h3 className={`font-medium text-sm ${
                    isCompleted || isCurrent ? 'text-gray-900' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </h3>
                  {index < steps.length - 1 && (
                    <div className={`absolute top-6 left-1/2 w-full h-0.5 ${
                      isCompleted ? 'bg-green-500' : 'bg-gray-200'
                    }`} style={{ marginLeft: '3rem', width: 'calc(100% - 6rem)' }} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 flex-shrink-0" />
              <span className="text-red-700 text-sm">{error}</span>
            </div>
          )}

          {currentStep !== 'complete' && (
            <div className="text-center mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                {steps.find(s => s.key === currentStep)?.title}
              </h2>
              <p className="text-gray-600">
                {steps.find(s => s.key === currentStep)?.instruction}
              </p>
            </div>
          )}

          {/* Camera View */}
          {currentStep !== 'complete' && (
            <div className="relative mb-6">
              <div className="aspect-video bg-gray-900 rounded-xl overflow-hidden relative">
                {!cameraReady && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button
                      onClick={startCamera}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium flex items-center"
                    >
                      <Camera className="w-5 h-5 mr-2" />
                      {t('Start Camera', 'ক্যামেরা চালু করুন')}
                    </button>
                  </div>
                )}
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${cameraReady ? 'block' : 'hidden'}`}
                />
                <canvas ref={canvasRef} className="hidden" />
                
                {/* Face Guide Overlay */}
                {cameraReady && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="border-4 border-white border-dashed rounded-full w-64 h-64 opacity-50" />
                  </div>
                )}
              </div>

              {cameraReady && (
                <div className="flex justify-center mt-4">
                  <button
                    onClick={capturePhoto}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-medium flex items-center"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    {t('Capture Photo', 'ছবি তুলুন')}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Captured Photos Review */}
          {currentStep === 'complete' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-900 text-center mb-6">
                {t('Review Your Photos', 'আপনার ছবি পর্যালোচনা করুন')}
              </h2>
              
              <div className="grid md:grid-cols-3 gap-6">
                {steps.map((step) => (
                  <div key={step.key} className="text-center">
                    <h3 className="font-medium text-gray-900 mb-3">{step.title}</h3>
                    <div className="relative">
                      {captures[step.key as keyof typeof captures] && (
                        <img
                          src={captures[step.key as keyof typeof captures]!}
                          alt={step.title}
                          className="w-full aspect-square object-cover rounded-xl border-2 border-gray-200"
                        />
                      )}
                      <button
                        onClick={() => retakePhoto(step.key as Exclude<CaptureStep, 'complete'>)}
                        className="absolute bottom-2 right-2 bg-white hover:bg-gray-50 text-gray-700 p-2 rounded-lg shadow-lg border border-gray-200"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Instructions */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
                  <div className="text-blue-700 text-sm">
                    <p className="font-medium mb-2">
                      {t("Photo Quality Check", "ছবির মান পরীক্ষা")}
                    </p>
                    <ul className="space-y-1 text-xs">
                      <li>• {t("Face clearly visible in all photos", "সব ছবিতে মুখ স্পষ্টভাবে দৃশ্যমান")}</li>
                      <li>• {t("No glasses or face coverings", "কোন চশমা বা মুখ ঢাকা নেই")}</li>
                      <li>• {t("Good lighting without shadows", "ছায়া ছাড়া ভাল আলো")}</li>
                      <li>• {t("Different angles captured correctly", "বিভিন্ন কোণ সঠিকভাবে ক্যাপচার করা")}</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmit}
                disabled={loading}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading 
                  ? t("Submitting...", "জমা দেওয়া হচ্ছে...") 
                  : t("Complete Verification", "যাচাইকরণ সম্পূর্ণ করুন")
                }
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
