import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useApi } from '@/react-app/hooks/useApi';
import { 
  User, 
  Phone, 
  Mail, 
  Shield, 
  Wallet,
  Edit3,
  Save,
  X,
  Award,
  TrendingUp,
  CheckCircle,
  Camera,
  Globe,
  LogOut
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

export default function Profile() {
  const { user, logout } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const updateProfileApi = useApi();
  const updateWalletApi = useApi();

  const [profile, setProfile] = useState<Record<string, unknown> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    full_name: '',
    phone_number: '',
    nid_number: '',
    driving_license: '',
    preferred_language: 'en',
  });

  const [walletForm, setWalletForm] = useState({
    provider: '',
    phone_number: '',
  });
  const [showWalletModal, setShowWalletModal] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await fetch('/api/users/me', { credentials: 'include' });
      const userData = await response.json();
      
      if (userData.profile) {
        setProfile(userData.profile);
        setEditForm({
          full_name: userData.profile.full_name || '',
          phone_number: userData.profile.phone_number || '',
          nid_number: userData.profile.nid_number || '',
          driving_license: userData.profile.driving_license || '',
          preferred_language: userData.profile.preferred_language || 'en',
        });
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    }
  };

  const handleSaveProfile = async () => {
    try {
      await updateProfileApi.execute('/api/profile', {
        method: 'POST',
        body: {
          ...editForm,
          user_type: profile?.user_type || 'citizen',
        },
      });
      
      setIsEditing(false);
      fetchProfile();
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  const handleWalletUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateWalletApi.execute('/api/wallet/verify', {
        method: 'POST',
        body: walletForm,
      });
      
      setShowWalletModal(false);
      fetchProfile();
    } catch (error) {
      console.error('Failed to update wallet:', error);
    }
  };

  const getKycStatusConfig = (status: string) => {
    switch (status) {
      case 'verified': 
        return { 
          class: 'badge-success', 
          text: { en: 'Verified', bn: 'যাচাইকৃত' } 
        };
      case 'pending': 
        return { 
          class: 'badge-warning', 
          text: { en: 'Pending', bn: 'বিচারাধীন' } 
        };
      case 'rejected': 
        return { 
          class: 'badge-danger', 
          text: { en: 'Rejected', bn: 'প্রত্যাখ্যাত' } 
        };
      default: 
        return { 
          class: 'badge-base', 
          text: { en: status, bn: status } 
        };
    }
  };

  const kycConfig = getKycStatusConfig(String(profile?.kyc_status || 'pending'));

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ borderColor: 'var(--color-primary-blue)' }}>
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <BackButton 
              to="/dashboard"
              className="p-2 hover:bg-ash rounded-lg transition-colors touch-target"
            />
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Profile', 'প্রোফাইল')}
              </h1>
              <p className="text-sm text-gray-600">
                {t('Manage your account information', 'আপনার অ্যাকাউন্টের তথ্য পরিচালনা করুন')}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Profile Header */}
        <div className="bg-primary text-white rounded-2xl p-8 mb-8" style={{ backgroundColor: 'var(--color-light-blue-dark)' }}>
          <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-6">
            <div className="relative">
              <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg">
                <User className="w-12 h-12" style={{ color: 'var(--color-primary-blue-dark)' }} />
              </div>
              <button className="absolute bottom-0 right-0 bg-white p-2 rounded-full shadow-lg hover:bg-ash transition-colors touch-target">
                <Camera className="w-4 h-4" style={{ color: 'var(--color-primary-blue-dark)' }} />
              </button>
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-3xl font-bold mb-2">
                {(profile?.full_name as string) || user?.email?.split('@')[0] || 'User'}
              </h2>
              <p className="text-white opacity-90 mb-4">
                {user?.email} • {t(profile?.user_type === 'officer' ? 'Traffic Officer' : 'Citizen', 
                                   profile?.user_type === 'officer' ? 'ট্রাফিক অফিসার' : 'নাগরিক')}
              </p>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold">{(profile?.total_reports as number) || 0}</p>
                  <p className="text-blue-200 text-sm">{t('Total Reports', 'মোট রিপোর্ট')}</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{(profile?.approved_reports as number) || 0}</p>
                  <p className="text-blue-200 text-sm">{t('Approved', 'অনুমোদিত')}</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">৳{((profile?.total_rewards as number) || 0).toFixed(0)}</p>
                  <p className="text-blue-200 text-sm">{t('Total Earned', 'মোট আয়')}</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsEditing(!isEditing)}
              className="btn-secondary flex items-center space-x-2"
            >
              <Edit3 className="w-5 h-5" />
              <span>{t('Edit', 'সম্পাদনা')}</span>
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information */}
            <div className="card-base p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Personal Information', 'ব্যক্তিগত তথ্য')}
                </h3>
                {isEditing && (
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="p-2 text-gray-500 hover:bg-ash rounded-lg transition-colors touch-target"
                    >
                      <X className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleSaveProfile}
                      disabled={updateProfileApi.loading}
                      className="btn-success p-2 disabled:opacity-50"
                    >
                      <Save className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {t('Full Name', 'পুরো নাম')}
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editForm.full_name}
                        onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                        className="input-base"
                      />
                    ) : (
                      <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                        <User className="w-5 h-5 text-gray-500" />
                        <span>{(profile?.full_name as string) || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {t('Phone Number', 'ফোন নম্বর')}
                    </label>
                    {isEditing ? (
                      <input
                        type="tel"
                        value={editForm.phone_number}
                        onChange={(e) => setEditForm({ ...editForm, phone_number: e.target.value })}
                        className="input-base"
                        placeholder="01XXXXXXXXX"
                      />
                    ) : (
                      <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                        <Phone className="w-5 h-5 text-gray-500" />
                        <span>{(profile?.phone_number as string) || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {t('Email Address', 'ইমেল ঠিকানা')}
                    </label>
                    <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                      <Mail className="w-5 h-5 text-gray-500" />
                      <span>{user?.email}</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                      {t('Preferred Language', 'পছন্দের ভাষা')}
                    </label>
                    {isEditing ? (
                      <select
                        value={editForm.preferred_language}
                        onChange={(e) => setEditForm({ ...editForm, preferred_language: e.target.value })}
                        className="input-base"
                      >
                        <option value="en">English</option>
                        <option value="bn">বাংলা</option>
                      </select>
                    ) : (
                      <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                        <Globe className="w-5 h-5 text-gray-500" />
                        <span>{profile?.preferred_language === 'bn' ? 'বাংলা' : 'English'}</span>
                      </div>
                    )}
                  </div>
                </div>

                {profile?.user_type === 'citizen' && (
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                        {t('NID Number', 'এনআইডি নম্বর')}
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.nid_number}
                          onChange={(e) => setEditForm({ ...editForm, nid_number: e.target.value })}
                          className="input-base"
                        />
                      ) : (
                        <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                          <span>{(profile?.nid_number as string) || 'Not provided'}</span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                        {t('Driving License', 'ড্রাইভিং লাইসেন্স')}
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.driving_license}
                          onChange={(e) => setEditForm({ ...editForm, driving_license: e.target.value })}
                          className="input-base"
                        />
                      ) : (
                        <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                          <span>{(profile?.driving_license as string) || 'Not provided'}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Account Activity */}
            <div className="card-base p-6">
              <h3 className="text-xl font-bold mb-6" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Account Activity', 'অ্যাকাউন্ট কার্যকলাপ')}
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="text-center p-6 bg-primary rounded-xl border" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
                  <TrendingUp className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-primary-blue-dark)' }} />
                  <p className="text-2xl font-bold" style={{ color: 'var(--color-primary-blue-dark)' }}>
                    {(profile?.total_reports as number) || 0}
                  </p>
                  <p className="text-gray-600">{t('Reports Submitted', 'জমা দেওয়া রিপোর্ট')}</p>
                </div>

                <div className="text-center p-6 bg-success rounded-xl border" style={{ borderColor: 'var(--color-light-green-dark)' }}>
                  <Award className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-light-green-dark)' }} />
                  <p className="text-2xl font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                    ৳{((profile?.total_rewards as number) || 0).toFixed(0)}
                  </p>
                  <p className="text-gray-600">{t('Total Rewards', 'মোট পুরস্কার')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Status Cards */}
          <div className="space-y-6">
            {/* KYC Status */}
            <div className="card-base p-6">
              <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('KYC Status', 'কেওয়াইসি অবস্থা')}
              </h3>
              
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-8 h-8 text-gray-500" />
                <div>
                  <p className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {t('Identity Verification', 'পরিচয় যাচাইকরণ')}
                  </p>
                  <span className={kycConfig.class}>
                    {t(kycConfig.text.en, kycConfig.text.bn)}
                  </span>
                </div>
              </div>

              {profile?.kyc_status === 'verified' && (
                <div className="flex items-center space-x-2" style={{ color: 'var(--color-light-green-dark)' }}>
                  <CheckCircle className="w-5 h-5" />
                  <span className="text-sm">{t('Verified', 'যাচাইকৃত')}</span>
                </div>
              )}
            </div>

            {/* Wallet Status */}
            <div className="card-base p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Wallet Status', 'ওয়ালেট অবস্থা')}
                </h3>
                <button
                  onClick={() => setShowWalletModal(true)}
                  className="btn-primary btn-small"
                >
                  {profile?.wallet_verified ? t('Update', 'আপডেট') : t('Setup', 'সেটআপ')}
                </button>
              </div>

              <div className="flex items-center space-x-3">
                <Wallet className="w-8 h-8 text-gray-500" />
                <div>
                  <p className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
                    {profile?.wallet_verified 
                      ? `${profile.wallet_provider} - ${profile.wallet_number}`
                      : t('No wallet connected', 'কোনো ওয়ালেট সংযুক্ত নেই')
                    }
                  </p>
                  <div className="flex items-center space-x-2">
                    {profile?.wallet_verified ? (
                      <>
                        <CheckCircle className="w-4 h-4" style={{ color: 'var(--color-light-green-dark)' }} />
                        <span className="text-sm" style={{ color: 'var(--color-light-green-dark)' }}>
                          {t('Connected', 'সংযুক্ত')}
                        </span>
                      </>
                    ) : (
                      <span className="text-sm text-gray-500">{t('Not connected', 'সংযুক্ত নয়')}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Settings */}
            <div className="card-base p-6">
              <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Settings', 'সেটিংস')}
              </h3>
              
              <div className="space-y-4">
                <button
                  onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                  className="w-full text-left p-3 hover:bg-ash rounded-lg transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span>{t('Language', 'ভাষা')}</span>
                    <span className="text-gray-500">{language === 'en' ? 'English' : 'বাংলা'}</span>
                  </div>
                </button>

                <button
                  onClick={logout}
                  className="w-full text-left p-3 rounded-lg transition-colors hover:bg-danger flex items-center space-x-3"
                  style={{ color: 'var(--color-light-red-dark)' }}
                >
                  <LogOut className="w-5 h-5" />
                  <span>{t('Logout', 'লগআউট')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Wallet Setup Modal */}
      {showWalletModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="card-base max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                {t('Wallet Setup', 'ওয়ালেট সেটআপ')}
              </h2>
              <button
                onClick={() => setShowWalletModal(false)}
                className="p-2 hover:bg-ash rounded-lg transition-colors touch-target"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleWalletUpdate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Wallet Provider', 'ওয়ালেট প্রদানকারী')}
                </label>
                <select
                  value={walletForm.provider}
                  onChange={(e) => setWalletForm({ ...walletForm, provider: e.target.value })}
                  className="input-base"
                  required
                >
                  <option value="">{t('Select Wallet', 'ওয়ালেট নির্বাচন করুন')}</option>
                  <option value="bKash">bKash</option>
                  <option value="Nagad">Nagad</option>
                  <option value="Rocket">Rocket</option>
                  <option value="Upay">Upay</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
                  {t('Phone Number', 'ফোন নম্বর')}
                </label>
                <input
                  type="tel"
                  required
                  value={walletForm.phone_number}
                  onChange={(e) => setWalletForm({ ...walletForm, phone_number: e.target.value })}
                  className="input-base"
                  placeholder="01XXXXXXXXX"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setShowWalletModal(false)}
                  className="btn-secondary flex-1"
                >
                  {t('Cancel', 'বাতিল')}
                </button>
                <button
                  type="submit"
                  disabled={updateWalletApi.loading}
                  className="btn-primary flex-1 disabled:opacity-50"
                >
                  {updateWalletApi.loading 
                    ? t('Saving...', 'সংরক্ষণ করা হচ্ছে...')
                    : t('Save', 'সংরক্ষণ করুন')
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
