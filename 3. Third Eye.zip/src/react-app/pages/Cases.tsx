import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate } from 'react-router';
import { 
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  MapPin,
  Calendar,
  DollarSign,
  Image as ImageIcon,
  ChevronDown,
  Eye
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

interface CaseItem {
  id: number;
  case_number: string;
  status: string;
  vehicle_number: string;
  violation_name_en: string;
  violation_name_bn: string;
  reward_amount: number;
  fine_amount: number;
  reported_at: string;
  location_description?: string;
  description?: string;
  rejection_reason?: string;
  evidence_urls?: string;
}

export default function Cases() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [filteredCases, setFilteredCases] = useState<CaseItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);

  const filterCases = React.useCallback(() => {
    let filtered = [...cases];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(c =>
        c.case_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.vehicle_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.violation_name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.violation_name_bn.includes(searchTerm)
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(c => c.status === statusFilter);
    }

    setFilteredCases(filtered);
  }, [cases, searchTerm, statusFilter]);

  const fetchCases = async () => {
    try {
      const response = await fetch('/api/cases', { credentials: 'include' });
      const data = await response.json();
      setCases(data);
      setFilteredCases(data);
    } catch (error) {
      console.error('Failed to fetch cases:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCases();
  }, []);

  useEffect(() => {
    filterCases();
  }, [filterCases]);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'approved':
        return {
          color: 'badge-success',
          icon: CheckCircle,
          label: t('Approved', 'অনুমোদিত')
        };
      case 'pending':
        return {
          color: 'badge-warning',
          icon: Clock,
          label: t('Pending', 'বিচারাধীন')
        };
      case 'under_review':
        return {
          color: 'badge-info',
          icon: Clock,
          label: t('Under Review', 'পর্যালোচনাধীন')
        };
      case 'rejected':
        return {
          color: 'badge-danger',
          icon: XCircle,
          label: t('Rejected', 'প্রত্যাখ্যাত')
        };
      case 'completed':
        return {
          color: 'badge-success',
          icon: CheckCircle,
          label: t('Completed', 'সম্পন্ন')
        };
      default:
        return {
          color: 'badge-base',
          icon: Clock,
          label: status
        };
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'en' ? 'en-US' : 'bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const statusOptions = [
    { value: 'all', label: t('All Cases', 'সব কেস') },
    { value: 'pending', label: t('Pending', 'বিচারাধীন') },
    { value: 'under_review', label: t('Under Review', 'পর্যালোচনাধীন') },
    { value: 'approved', label: t('Approved', 'অনুমোদিত') },
    { value: 'rejected', label: t('Rejected', 'প্রত্যাখ্যাত') },
    { value: 'completed', label: t('Completed', 'সম্পন্ন') }
  ];

  const stats = {
    total: cases.length,
    pending: cases.filter(c => c.status === 'pending').length,
    approved: cases.filter(c => c.status === 'approved' || c.status === 'completed').length,
    rejected: cases.filter(c => c.status === 'rejected').length
  };

  return (
    <div className="min-h-screen bg-ash">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40" style={{ borderColor: 'var(--color-light-blue)' }}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BackButton 
                to="/dashboard"
                className="p-2 hover:bg-ash rounded-lg transition-colors touch-target"
              />
              <div>
                <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {t('My Reports', 'আমার রিপোর্ট')}
                </h1>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  {t('Track all your submitted cases', 'আপনার জমা দেওয়া সব কেস ট্র্যাক করুন')}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="icon-primary w-10 h-10">
                <Eye className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid-cards gap-6 mb-8">
          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-gray-600 text-sm">{t('Total Cases', 'মোট কেস')}</p>
              <div className="icon-primary w-10 h-10">
                <Eye className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-bold" style={{ color: 'var(--color-primary-blue-dark)' }}>
              {stats.total}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-gray-600 text-sm">{t('Pending', 'বিচারাধীন')}</p>
              <div className="icon-warning w-10 h-10">
                <Clock className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-bold" style={{ color: 'var(--color-light-red-dark)' }}>
              {stats.pending}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-gray-600 text-sm">{t('Approved', 'অনুমোদিত')}</p>
              <div className="icon-success w-10 h-10">
                <CheckCircle className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
              {stats.approved}
            </p>
          </div>

          <div className="card-base p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-gray-600 text-sm">{t('Rejected', 'প্রত্যাখ্যাত')}</p>
              <div className="icon-danger w-10 h-10">
                <XCircle className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-bold" style={{ color: 'var(--color-light-red-dark)' }}>
              {stats.rejected}
            </p>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="card-base p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--color-light-ash-dark)' }} />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('Search by case number, vehicle, or violation...', 'কেস নম্বর, যানবাহন বা আইন লঙ্ঘন দ্বারা অনুসন্ধান করুন...')}
                className="input-base pl-12"
              />
            </div>

            {/* Status Filter */}
            <div className="relative">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="btn-secondary flex items-center space-x-2 touch-target"
              >
                <Filter className="w-5 h-5" />
                <span>
                  {statusOptions.find(s => s.value === statusFilter)?.label}
                </span>
                <ChevronDown className="w-4 h-4" />
              </button>

              {showFilters && (
                <div className="absolute right-0 mt-2 w-56 card-base z-10 py-2">
                  {statusOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setStatusFilter(option.value);
                        setShowFilters(false);
                      }}
                      className={`
                        w-full text-left px-4 py-3 hover:bg-ash transition-colors
                        ${statusFilter === option.value ? 'bg-primary font-semibold' : ''}
                      `}
                      style={{
                        color: statusFilter === option.value ? 'var(--color-primary-blue-dark)' : 'var(--color-light-ash-dark)'
                      }}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Cases List */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-12 h-12 border-4 border-t-transparent rounded-full mx-auto" style={{ borderColor: 'var(--color-primary-blue-dark)' }}></div>
            <p className="text-gray-600 mt-4">{t('Loading cases...', 'কেস লোড হচ্ছে...')}</p>
          </div>
        ) : filteredCases.length > 0 ? (
          <div className="space-y-6">
            {filteredCases.map((caseItem) => {
              const statusConfig = getStatusConfig(caseItem.status);
              const StatusIcon = statusConfig.icon;
              const evidenceUrls = caseItem.evidence_urls ? JSON.parse(caseItem.evidence_urls) : [];

              return (
                <div
                  key={caseItem.id}
                  className="card-base p-6 hover:shadow-lg transition-all overflow-hidden"
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-xl font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                          {caseItem.case_number}
                        </h3>
                        <span className={`${statusConfig.color} flex items-center space-x-1`}>
                          <StatusIcon className="w-4 h-4" />
                          <span>{statusConfig.label}</span>
                        </span>
                      </div>
                      <p className="text-gray-600">
                        {language === 'en' ? caseItem.violation_name_en : caseItem.violation_name_bn}
                      </p>
                    </div>

                    {caseItem.reward_amount > 0 && caseItem.status === 'completed' && (
                      <div className="bg-success border rounded-xl px-4 py-2" style={{ borderColor: 'var(--color-light-green-dark)' }}>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="w-5 h-5" style={{ color: 'var(--color-light-green-dark)' }} />
                          <span className="font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                            ৳{caseItem.reward_amount.toFixed(0)}
                          </span>
                        </div>
                        <p className="text-xs" style={{ color: 'var(--color-light-green-dark)' }}>
                          {t('Earned', 'আয়')}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Details Grid */}
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                      <div className="icon-secondary w-8 h-8">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">{t('Vehicle Number', 'যানবাহন নম্বর')}</p>
                        <p className="font-semibold" style={{ color: 'var(--color-light-ash-dark)' }}>
                          {caseItem.vehicle_number}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-ash rounded-lg">
                      <div className="icon-secondary w-8 h-8">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">{t('Reported At', 'রিপোর্ট করা হয়েছে')}</p>
                        <p className="font-semibold text-sm" style={{ color: 'var(--color-light-ash-dark)' }}>
                          {formatDate(caseItem.reported_at)}
                        </p>
                      </div>
                    </div>

                    {caseItem.location_description && (
                      <div className="md:col-span-2 flex items-start space-x-3 p-3 bg-ash rounded-lg">
                        <div className="icon-secondary w-8 h-8">
                          <MapPin className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">{t('Location', 'অবস্থান')}</p>
                          <p className="font-medium" style={{ color: 'var(--color-light-ash-dark)' }}>
                            {caseItem.location_description}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Evidence Images */}
                  {evidenceUrls.length > 0 && (
                    <div className="mb-4">
                      <p className="text-sm font-medium mb-3" style={{ color: 'var(--color-light-ash-dark)' }}>
                        {t('Evidence Photos', 'প্রমাণ ছবি')} ({evidenceUrls.length})
                      </p>
                      <div className="grid grid-cols-4 gap-3">
                        {evidenceUrls.slice(0, 4).map((_: string, index: number) => (
                          <div key={index} className="aspect-square bg-ash rounded-lg border flex items-center justify-center" style={{ borderColor: 'var(--color-primary-blue)' }}>
                            <ImageIcon className="w-8 h-8 text-gray-400" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Description */}
                  {caseItem.description && (
                    <div className="mb-4 p-4 bg-primary border rounded-lg" style={{ borderColor: 'var(--color-primary-blue-dark)' }}>
                      <p className="text-sm font-medium mb-1" style={{ color: 'var(--color-primary-blue-dark)' }}>
                        {t('Description', 'বর্ণনা')}
                      </p>
                      <p className="text-sm" style={{ color: 'var(--color-primary-blue-dark)' }}>
                        {caseItem.description}
                      </p>
                    </div>
                  )}

                  {/* Rejection Reason */}
                  {caseItem.status === 'rejected' && caseItem.rejection_reason && (
                    <div className="p-4 bg-danger border rounded-lg" style={{ borderColor: 'var(--color-light-red-dark)' }}>
                      <p className="text-sm font-medium mb-1" style={{ color: 'var(--color-light-red-dark)' }}>
                        {t('Rejection Reason', 'প্রত্যাখ্যানের কারণ')}
                      </p>
                      <p className="text-sm" style={{ color: 'var(--color-light-red-dark)' }}>
                        {caseItem.rejection_reason}
                      </p>
                    </div>
                  )}

                  {/* Fine and Reward Info */}
                  {caseItem.fine_amount > 0 && (
                    <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: 'var(--color-primary-blue)' }}>
                      <div>
                        <p className="text-xs text-gray-500">{t('Fine Amount', 'জরিমানার পরিমাণ')}</p>
                        <p className="text-lg font-bold" style={{ color: 'var(--color-light-ash-dark)' }}>
                          ৳{caseItem.fine_amount.toFixed(0)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500">{t('Your Reward (20%)', 'আপনার পুরস্কার (২০%)')}</p>
                        <p className="text-lg font-bold" style={{ color: 'var(--color-light-green-dark)' }}>
                          ৳{caseItem.reward_amount.toFixed(0)}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="card-base p-12 text-center">
            <AlertCircle className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--color-light-ash-dark)' }}>
              {t('No cases found', 'কোনো কেস পাওয়া যায়নি')}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || statusFilter !== 'all'
                ? t('Try adjusting your search or filters', 'আপনার অনুসন্ধান বা ফিল্টার সামঞ্জস্য করার চেষ্টা করুন')
                : t('You haven\'t submitted any reports yet', 'আপনি এখনও কোনো রিপোর্ট জমা দেননি')
              }
            </p>
            {!searchTerm && statusFilter === 'all' && (
              <button
                onClick={() => navigate('/report')}
                className="btn-primary"
              >
                {t('Submit your first report', 'আপনার প্রথম রিপোর্ট জমা দিন')}
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
