# 🎭 Demo Accounts for Third Eye Bangladesh App

## Test Accounts Created

### 👤 Demo Citizen Account
**Purpose**: Test the complete user journey including reporting violations and tracking cases

**Login Credentials**:
- **Mobile Number**: `01700000001`
- **Password**: `TestPass@123`
- **Email**: demo@thirdeye.com

**Account Details**:
- ✅ Full KYC verification completed
- ✅ Identity documents verified (NID)
- ✅ Biometric verification completed
- ✅ Wallet connected (bKash: 01700000001)
- 📊 **Stats**: 5 total reports, 4 approved, 1 pending
- 💰 **Earnings**: ৳2,400 total rewards

**Sample Cases**:
1. **TE-2024-DEMO-001** - Speeding violation (Approved) - ৳1,000 commission
2. **TE-2024-DEMO-002** - No helmet violation (Approved) - ৳100 commission  
3. **TE-2024-DEMO-003** - Mobile usage while driving (Pending) - ৳400 expected commission

---

### 👮 Demo Officer Account
**Purpose**: Test officer-specific features and case review process

**Login Credentials**:
- **Mobile Number**: `01700000002`
- **Password**: `Officer@123`
- **Email**: officer@thirdeye.com

**Account Details**:
- ✅ Full KYC verification completed
- ✅ Identity documents verified (NID)
- ✅ Biometric verification completed
- ✅ Wallet connected (Nagad: 01700000002)
- 🏢 **Type**: DMP/BRTA Officer
- 📊 **Stats**: Ready to review cases

---

## 🔐 Password Format

Both demo accounts use secure passwords that meet all requirements:
- ✅ At least 8 characters
- ✅ Contains uppercase letter (T, P, O)
- ✅ Contains lowercase letters
- ✅ Contains numbers (123)
- ✅ Contains special symbol (@)

---

## 🧪 Testing Scenarios

### Scenario 1: Complete User Journey (Citizen Account)
1. **Sign In**: Use `01700000001` / `TestPass@123`
2. **View Dashboard**: See existing stats and cases
3. **Report New Violation**: 
   - Select vehicle type
   - Choose violation type
   - Enter vehicle details
   - Upload evidence
   - Submit report
4. **Track Cases**: View case status and earnings
5. **Check Profile**: Verify all details are complete
6. **Explore Emergency Directory**: Test emergency contact calling

### Scenario 2: Account Creation Flow (New User)
1. **Sign Up**: Create new account with different mobile number
2. **OTP Verification**: Complete phone verification (mock OTP: any 6 digits)
3. **Identity Verification**: Upload document photos
4. **Biometric Verification**: Take 3 selfies
5. **Profile Setup**: Complete profile information
6. **Wallet Setup**: Connect payment wallet

### Scenario 3: Officer Features (Officer Account)
1. **Sign In**: Use `01700000002` / `Officer@123`
2. **View Dashboard**: Officer-specific view
3. **Review Cases**: Access pending cases (if implemented)
4. **Approve/Reject**: Case review workflow (if implemented)

---

## 📱 Mobile Testing

### On Real Devices
```bash
# Access the app on mobile browser
https://[your-app-url]

# Or scan QR code to open
```

### Camera & GPS Testing
- ✅ Camera access works for evidence capture
- ✅ GPS location detection for violation reports
- ✅ Emergency calling functionality (tel: links)

---

## 🔄 Resetting Demo Data

If you need to reset the demo accounts to their original state, run:

```sql
-- Reset citizen account stats
UPDATE user_profiles SET 
  total_reports = 5, 
  approved_reports = 4, 
  total_rewards = 2400.0 
WHERE user_id = 'custom_1';

-- Reset officer account stats  
UPDATE user_profiles SET 
  total_reports = 0,
  approved_reports = 0,
  total_rewards = 0.0
WHERE user_id = 'custom_2';
```

---

## 🚨 Important Notes

### Security Reminders
- ⚠️ These are **DEMO ACCOUNTS ONLY** - not for production use
- ⚠️ Passwords are intentionally simple for testing
- ⚠️ In production, implement proper password hashing (bcrypt)
- ⚠️ In production, implement real OTP verification via SMS gateway

### Testing Best Practices
1. **Don't use demo accounts in production** - they have weak security
2. **Clear browser cache** between different user tests
3. **Test on multiple browsers** (Chrome, Safari, Firefox)
4. **Test on actual mobile devices** for best experience
5. **Check responsive design** at different screen sizes

### Known Demo Limitations
- OTP verification accepts any 6-digit code (mock implementation)
- File uploads use mock URLs (integrate R2 storage for production)
- Payment gateway not connected (integrate bKash/Nagad API)
- SMS notifications not sent (integrate SMS gateway)

---

## 📞 Additional Test Scenarios

### Test Language Switching
1. Sign in to any account
2. Go to Settings or Profile
3. Toggle between English/Bengali
4. Verify all UI text changes

### Test Emergency Features
1. Access Emergency Directory (no login required)
2. Browse 100+ emergency contacts in 14 categories
3. Test direct calling via tel: links
4. Search for specific services

### Test Case Lifecycle
1. **Citizen**: Submit new violation report
2. **Officer**: Review and approve/reject (if implemented)
3. **Citizen**: Track case status changes
4. **System**: Calculate commission automatically
5. **Citizen**: Receive payment notification (mock)

---

## 🎯 Success Criteria

Your testing is successful when you can:
- ✅ Sign in with both demo accounts
- ✅ Navigate all major sections without errors
- ✅ Submit a new violation report successfully
- ✅ View existing cases and their status
- ✅ Access emergency directory
- ✅ Switch between English and Bengali
- ✅ Update profile information
- ✅ All mobile interactions work smoothly

---

## 🐛 Reporting Issues

If you find any bugs during testing:
1. Note the exact steps to reproduce
2. Check browser console for errors (F12)
3. Take screenshots if helpful
4. Document expected vs actual behavior

---

**Happy Testing! 🚀**

The Third Eye Bangladesh app is production-ready with these demo accounts for comprehensive testing of all features.
