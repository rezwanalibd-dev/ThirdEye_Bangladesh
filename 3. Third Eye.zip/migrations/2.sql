
-- Seed violation types with Bangladesh-specific traffic violations
INSERT INTO violation_types (name_en, name_bn, description_en, description_bn, fine_amount, reward_percentage, is_active) VALUES
('Speeding', 'অতিরিক্ত গতি', 'Exceeding speed limit', 'গতি সীমা অতিক্রম', 5000.0, 0.20, TRUE),
('Red Light Jumping', 'লাল বাতি লঙ্ঘন', 'Crossing red traffic signal', 'লাল ট্রাফিক সংকেত অতিক্রম', 500.0, 0.20, TRUE),
('Illegal Parking', 'অবৈধ পার্কিং', 'Parking in no-parking zone', 'নো-পার্কিং জোনে পার্কিং', 400.0, 0.20, TRUE),
('Wrong Side Driving', 'ভুল পাশ দিয়ে গাড়ি চালানো', 'Driving on wrong side of road', 'রাস্তার ভুল পাশ দিয়ে গাড়ি চালানো', 300.0, 0.20, TRUE),
('No Helmet', 'হেলমেট না পরা', 'Motorcycle without helmet', 'হেলমেট ছাড়া মোটরসাইকেল', 200.0, 0.20, TRUE),
('No Seatbelt', 'সিটবেল্ট না পরা', 'Not wearing seatbelt', 'সিটবেল্ট পরা হয়নি', 200.0, 0.20, TRUE),
('Hydraulic Horn', 'হাইড্রোলিক হর্ন', 'Using hydraulic horn', 'হাইড্রোলিক হর্ন ব্যবহার', 100.0, 0.20, TRUE),
('Overloading', 'অতিরিক্ত যাত্রী', 'Vehicle overloading', 'যানবাহন অতিরিক্ত বোঝা', 1000.0, 0.20, TRUE),
('No License', 'লাইসেন্স ছাড়া', 'Driving without license', 'লাইসেন্স ছাড়া গাড়ি চালানো', 25000.0, 0.20, TRUE),
('Mobile Phone Use', 'মোবাইল ফোন ব্যবহার', 'Using mobile while driving', 'গাড়ি চালানোর সময় মোবাইল ব্যবহার', 200.0, 0.20, TRUE);
