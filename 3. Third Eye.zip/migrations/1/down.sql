
DROP INDEX idx_notifications_user_id;
DROP INDEX idx_payments_user_id;
DROP INDEX idx_payments_case_id;
DROP INDEX idx_cases_case_number;
DROP INDEX idx_cases_status;
DROP INDEX idx_cases_reporter_id;
DROP INDEX idx_user_profiles_user_id;
DROP TABLE notifications;
DROP TABLE payments;
DROP TABLE cases;
DROP TABLE violation_types;
DROP TABLE user_profiles;
