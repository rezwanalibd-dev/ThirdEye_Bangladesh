# Third Eye Mobile App Setup Guide

## Overview
This guide helps you prepare the Third Eye traffic violation reporting app for Android and iOS deployment.

## Prerequisites

### For Android Development:
- Android Studio (latest version)
- Android SDK (API level 21 or higher)
- Java 8 or higher
- Gradle

### For iOS Development:
- Xcode (latest version)
- iOS 13.0 or higher
- Apple Developer Account (for App Store deployment)
- CocoaPods

## Project Structure

```
third-eye-app/
├── android/                 # Android native project
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml
│   │   │   └── res/
│   │   └── build.gradle
│   └── build.gradle
├── ios/                     # iOS native project
│   ├── App/
│   │   ├── App/
│   │   │   └── Info.plist
│   │   └── App.xcodeproj
│   └── Podfile
├── dist/client/             # Web build output
├── src/                     # Source code
├── capacitor.config.ts      # Capacitor configuration
└── package.json
```

## Build and Deploy Steps

### 1. Initial Setup
```bash
# Install dependencies
npm install

# Build the web app
npm run build

# Sync with native platforms
npx cap sync
```

### 2. Android Deployment

#### Development Build:
```bash
# Open Android Studio
npx cap open android

# Or build from command line
cd android
./gradlew assembleDebug
```

#### Production Build:
```bash
cd android
./gradlew assembleRelease
```

**Generated APK Location:** `android/app/build/outputs/apk/`

### 3. iOS Deployment

#### Development Build:
```bash
# Open Xcode
npx cap open ios

# Build and run on simulator or device through Xcode
```

#### Production Build:
1. Open project in Xcode: `npx cap open ios`
2. Select "Generic iOS Device" or your connected device
3. Go to Product → Archive
4. Follow App Store submission process

## Key Configuration Files

### 1. Capacitor Config (`capacitor.config.ts`)
```typescript
export default {
  appId: 'com.thirdeye.trafficreporter',
  appName: 'Third Eye',
  webDir: 'dist/client',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Camera: {
      requestPermissions: true,
      saveToGallery: true
    },
    Geolocation: {
      requestPermissions: true
    }
  }
};
```

### 2. Android Manifest (`android/app/src/main/AndroidManifest.xml`)
- App permissions (Camera, Location, Storage)
- File provider configuration
- Network security config

### 3. iOS Info.plist (`ios/App/App/Info.plist`)
- Usage descriptions for permissions
- App configuration
- Supported orientations

## Required Permissions

### Android:
- `android.permission.CAMERA` - Camera access for photos/videos
- `android.permission.ACCESS_FINE_LOCATION` - GPS location
- `android.permission.ACCESS_COARSE_LOCATION` - Network location
- `android.permission.READ_EXTERNAL_STORAGE` - File access
- `android.permission.WRITE_EXTERNAL_STORAGE` - File saving
- `android.permission.INTERNET` - Network access

### iOS:
- `NSCameraUsageDescription` - Camera access
- `NSLocationWhenInUseUsageDescription` - Location access
- `NSPhotoLibraryUsageDescription` - Photo library access
- `NSMicrophoneUsageDescription` - Microphone for videos

## App Store Preparation

### Android (Google Play Store):
1. **Generate Signed APK:**
   - Create keystore file
   - Configure signing in `android/app/build.gradle`
   - Build release APK

2. **App Requirements:**
   - Target SDK version 33 or higher
   - Privacy policy URL
   - App content rating
   - Store listing assets (screenshots, descriptions)

### iOS (Apple App Store):
1. **Apple Developer Account Setup:**
   - Create App ID with required capabilities
   - Generate distribution certificate
   - Create provisioning profile

2. **App Store Connect Setup:**
   - Create app record
   - Upload screenshots and metadata
   - Set pricing and availability

## Testing Checklist

### Functionality Tests:
- [ ] User registration with OTP verification
- [ ] Identity document upload and verification
- [ ] Biometric verification (face capture)
- [ ] Camera access for violation reporting
- [ ] GPS location capture
- [ ] Photo/video evidence upload
- [ ] Case status tracking
- [ ] Push notifications
- [ ] Offline functionality (if applicable)

### Platform-Specific Tests:
- [ ] Android: Test on different screen sizes and Android versions
- [ ] iOS: Test on iPhone and iPad, different iOS versions
- [ ] Performance on low-end devices
- [ ] Battery usage optimization
- [ ] Memory management

## Publishing Steps

### Google Play Store:
1. Create developer account ($25 one-time fee)
2. Upload signed APK/AAB
3. Complete store listing
4. Submit for review (typically 1-3 days)

### Apple App Store:
1. Create Apple Developer account ($99/year)
2. Archive and upload via Xcode
3. Complete App Store Connect metadata
4. Submit for review (typically 1-7 days)

## Troubleshooting Common Issues

### Build Errors:
- **Gradle sync failed**: Update Android Studio and sync project
- **iOS build failed**: Update Xcode and clear derived data
- **Plugin not found**: Run `npx cap sync` after installing plugins

### Runtime Errors:
- **Camera not working**: Check permissions in device settings
- **Location not available**: Enable location services
- **Network errors**: Check CORS and API endpoints

### Performance Issues:
- **Slow app startup**: Optimize bundle size
- **Memory leaks**: Check for retained listeners and subscriptions
- **UI freezing**: Move heavy operations to background threads

## Deployment Automation (CI/CD)

### GitHub Actions Example:
```yaml
name: Build and Deploy
on:
  push:
    branches: [ main ]

jobs:
  build-android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
      - run: npm install
      - run: npm run build
      - run: npx cap sync android
      - name: Build Android APK
        run: cd android && ./gradlew assembleRelease
```

## Support and Resources

- **Capacitor Documentation**: https://capacitorjs.com/docs
- **Android Developer Guide**: https://developer.android.com
- **iOS Developer Guide**: https://developer.apple.com
- **App Store Guidelines**: https://developer.apple.com/app-store/guidelines/

## Contact
For technical support or questions about deployment, please contact the development team.
