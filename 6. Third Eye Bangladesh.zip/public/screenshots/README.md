# App Screenshots

Place promotional screenshots here for:

## PWA Manifest
- screen1.png (540x720px) - Main/Welcome screen
- screen2.png (540x720px) - Dashboard screen

## Google Play Store
Required:
- Phone: At least 2 screenshots (minimum 320px)
- 7-inch tablet: At least 1 screenshot (minimum 320px) 
- 10-inch tablet: At least 1 screenshot (minimum 320px)

Recommended size: 1080x1920px (portrait)

## Apple App Store
Required:
- iPhone: 6.5" display screenshots (1284x2778px)
- iPhone: 5.5" display screenshots (1242x2208px)
- iPad: 12.9" display screenshots (2048x2732px)

At least 3-5 screenshots recommended.

## Tips
- Show key features in action
- Use actual app UI (no mockups)
- Add captions/text overlays highlighting features
- Show the app in use for reporting violations
- Include the rewards/earnings screen
- Display the verification process
