# App Icons

Place your app icons in this directory with the following sizes:

- icon-72x72.png
- icon-96x96.png
- icon-128x128.png
- icon-144x144.png
- icon-152x152.png
- icon-192x192.png
- icon-384x384.png
- icon-512x512.png

You can generate these icons using tools like:
- https://www.pwabuilder.com/imageGenerator
- https://realfavicongenerator.net/
- Adobe Photoshop/Illustrator
- Figma

## Design Guidelines

- Use the Bangladesh flag colors: Green (#006A4E) and Red (#F42A41)
- Include an eye icon representing vigilance
- Keep the design simple and recognizable at small sizes
- Ensure proper padding around the icon (safe zone)
- Use PNG format with transparency
- Make icons suitable for both light and dark backgrounds
