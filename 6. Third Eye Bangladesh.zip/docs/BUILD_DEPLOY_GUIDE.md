# Third Eye Bangladesh - Build & Deployment Guide

This comprehensive guide covers the complete process of building and deploying the Third Eye Bangladesh app to production.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Development Setup](#development-setup)
3. [Firebase Configuration](#firebase-configuration)
4. [Building for Production](#building-for-production)
5. [Android Deployment](#android-deployment)
6. [iOS Deployment](#ios-deployment)
7. [Web Deployment](#web-deployment)
8. [Store Submission](#store-submission)
9. [CI/CD Pipeline](#cicd-pipeline)
10. [Monitoring & Analytics](#monitoring--analytics)

## Prerequisites

### Required Tools
```bash
# Flutter SDK (Latest Stable)
flutter --version  # Should be 3.16.0 or higher

# Android Development
Android Studio 2023.1 or higher
Android SDK 31+ 
Java 11 or higher

# iOS Development (macOS only)
Xcode 15.0 or higher
iOS 12.0+ deployment target
macOS 13.0 or higher

# Firebase CLI
npm install -g firebase-tools

# Additional Tools
Git 2.30+
Node.js 18+
```

### Development Environment
```bash
# Verify Flutter installation
flutter doctor -v

# Install dependencies
flutter pub get

# Run code analysis
flutter analyze

# Run tests
flutter test
```

## Development Setup

### 1. Clone Repository
```bash
git clone https://github.com/your-org/third-eye-bangladesh.git
cd third-eye-bangladesh
```

### 2. Environment Configuration
Create environment files for different stages:

#### .env.development
```bash
API_BASE_URL=https://api-dev.thirdeye.gov.bd
FIREBASE_PROJECT_ID=thirdeye-dev
SENTRY_DSN=your_dev_sentry_dsn
ANALYTICS_ENABLED=false
```

#### .env.production
```bash
API_BASE_URL=https://api.thirdeye.gov.bd
FIREBASE_PROJECT_ID=thirdeye-prod
SENTRY_DSN=your_prod_sentry_dsn
ANALYTICS_ENABLED=true
```

### 3. Firebase Projects Setup
```bash
# Login to Firebase
firebase login

# Set up development project
firebase use --add thirdeye-dev

# Set up production project  
firebase use --add thirdeye-prod

# Generate Firebase options
dart pub global activate flutterfire_cli
flutterfire configure
```

## Firebase Configuration

### 1. Enable Required Services
In Firebase Console, enable:
- Authentication (Phone, Email)
- Firestore Database
- Firebase Storage
- Cloud Functions
- Firebase Messaging
- Analytics
- Crashlytics

### 2. Security Rules

#### Firestore Rules (firestore.rules)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Reports are readable by creator and officers
    match /reports/{reportId} {
      allow read: if request.auth != null && 
        (resource.data.userId == request.auth.uid || 
         request.auth.token.officer == true);
      allow create: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow update: if request.auth != null && 
        request.auth.token.officer == true;
    }
    
    // KYC verifications only accessible by user and officers
    match /kycVerifications/{verificationId} {
      allow read: if request.auth != null &&
        (resource.data.userId == request.auth.uid ||
         request.auth.token.officer == true);
      allow create: if request.auth != null;
      allow update: if request.auth != null &&
        request.auth.token.officer == true;
    }
    
    // Officer dashboard access
    match /officers/{officerId} {
      allow read, write: if request.auth != null && 
        request.auth.token.officer == true;
    }
  }
}
```

#### Storage Rules (storage.rules)
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // User profile images
    match /profiles/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null && 
        request.auth.uid == userId;
    }
    
    // KYC documents
    match /kyc/{userId}/{allPaths=**} {
      allow read: if request.auth != null && 
        (request.auth.uid == userId || request.auth.token.officer == true);
      allow write: if request.auth != null && 
        request.auth.uid == userId;
    }
    
    // Evidence files
    match /evidence/{reportId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
  }
}
```

### 3. Cloud Functions Deployment
```bash
cd functions
npm install
firebase deploy --only functions
```

## Building for Production

### 1. Pre-build Checklist
```bash
# Update version in pubspec.yaml
version: 1.0.0+1

# Run full test suite
flutter test

# Code analysis
flutter analyze --no-fatal-infos

# Format code
dart format .

# Build runner (if using code generation)
flutter packages pub run build_runner build --delete-conflicting-outputs
```

### 2. Build Configuration

#### Android Configuration (android/app/build.gradle)
```gradle
android {
    compileSdkVersion 34
    ndkVersion "23.1.7779620"

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId "bd.gov.thirdeye"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
        multiDexEnabled true
    }

    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }

    buildTypes {
        release {
            signingConfig signingConfigs.release
            shrinkResources true
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

#### iOS Configuration (ios/Runner/Info.plist)
```xml
<key>CFBundleVersion</key>
<string>1</string>
<key>CFBundleShortVersionString</key>
<string>1.0.0</string>
<key>NSCameraUsageDescription</key>
<string>This app needs camera access to capture evidence photos</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>This app needs location access to tag violation reports</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>This app needs photo library access to select evidence images</string>
```

## Android Deployment

### 1. Generate Signing Key
```bash
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

### 2. Configure Signing (android/key.properties)
```properties
storePassword=your_keystore_password
keyPassword=your_key_password
keyAlias=upload
storeFile=../upload-keystore.jks
```

### 3. Build Release
```bash
# App Bundle (recommended for Play Store)
flutter build appbundle --release

# APK (for direct distribution)
flutter build apk --release --split-per-abi
```

### 4. Play Console Setup

#### App Information
- **App Name**: Third Eye Bangladesh
- **Package Name**: bd.gov.thirdeye
- **Category**: Maps & Navigation
- **Content Rating**: Everyone
- **Target Audience**: 18+

#### Store Listing
```
Short Description: 
Report traffic violations, earn rewards, and help make Bangladesh roads safer.

Full Description:
Third Eye Bangladesh is the official government platform for reporting traffic violations and social crimes. Join thousands of citizens in making our roads safer while earning rewards for verified reports.

Key Features:
• Report traffic violations with photo/video evidence
• Earn commission from collected fines
• Track case status in real-time
• Anonymous social crime reporting
• Officer verification system
• Secure KYC verification
• Bilingual support (English/Bangla)

Trusted by DMP and BRTA for official violation reporting.
```

#### App Assets
- **Icon**: 512x512 PNG
- **Feature Graphic**: 1024x500 PNG
- **Screenshots**: 
  - Phone: 16:9 or 16:10 ratio
  - Tablet: 3:2 or 4:3 ratio
  - Minimum 4 screenshots per device type

### 5. Release Management
```bash
# Internal testing track
gcloud alpha android-publisher releases create \
  --package-name bd.gov.thirdeye \
  --track internal \
  --app-bundle path/to/app.aab

# Production release
gcloud alpha android-publisher releases create \
  --package-name bd.gov.thirdeye \
  --track production \
  --app-bundle path/to/app.aab
```

## iOS Deployment

### 1. Apple Developer Account Setup
- Enroll in Apple Developer Program ($99/year)
- Create App ID: bd.gov.thirdeye
- Generate certificates and provisioning profiles

### 2. Xcode Configuration
```bash
# Open iOS project
open ios/Runner.xcworkspace

# Configure signing in Xcode:
# - Team: Select your development team
# - Bundle Identifier: bd.gov.thirdeye
# - Provisioning Profile: Automatic
```

### 3. Build for Release
```bash
# Build iOS archive
flutter build ios --release

# Or build from Xcode
# Product → Archive
```

### 4. App Store Connect Setup

#### App Information
- **Name**: Third Eye Bangladesh
- **Bundle ID**: bd.gov.thirdeye
- **SKU**: THIRDEYE-BD-001
- **Primary Language**: English
- **Category**: Navigation
- **Content Rights**: Contains third-party content

#### Version Information
```
Version: 1.0.0
Build: 1
Copyright: 2024 Government of Bangladesh
```

#### App Store Description
```
Tagline: Report • Earn • Save Lives

Description:
Make Bangladesh roads safer with Third Eye - the official government platform for citizen-reported traffic violations.

FEATURES:
• Quick violation reporting with GPS tagging
• Photo and video evidence capture
• Real-time case tracking
• Secure reward system
• Anonymous crime reporting
• Officer verification portal
• Bilingual interface

TRUSTED PLATFORM:
Official partnership with Dhaka Metropolitan Police (DMP) and Bangladesh Road Transport Authority (BRTA).

HOW IT WORKS:
1. Witness a traffic violation
2. Capture evidence safely
3. Submit report with location
4. Officers verify the violation
5. Earn commission from collected fines

Join thousands of citizens making our roads safer!
```

### 5. TestFlight Distribution
```bash
# Upload to App Store Connect
xcrun altool --upload-app \
  --type ios \
  --file "build/ios/ipa/Runner.ipa" \
  --username "your-apple-id@example.com" \
  --password "app-specific-password"
```

## Web Deployment

### 1. Build Web Version
```bash
# Build for web
flutter build web --release

# Optimize for PWA
flutter build web --release --pwa-strategy offline-first
```

### 2. Firebase Hosting
```bash
# Deploy to Firebase Hosting
firebase deploy --only hosting
```

#### firebase.json
```json
{
  "hosting": {
    "public": "build/web",
    "ignore": [
      "firebase.json",
      "**/.*",
      "**/node_modules/**"
    ],
    "rewrites": [
      {
        "source": "**",
        "destination": "/index.html"
      }
    ],
    "headers": [
      {
        "source": "/service-worker.js",
        "headers": [
          {
            "key": "Cache-Control",
            "value": "no-cache"
          }
        ]
      }
    ]
  }
}
```

### 3. Custom Domain Setup
```bash
# Add custom domain
firebase hosting:channel:create live
firebase hosting:channel:deploy live

# Configure DNS
# Add CNAME record: app.thirdeye.gov.bd → thirdeye-prod.web.app
```

## Store Submission

### 1. Pre-submission Checklist
- [ ] App tested on multiple devices
- [ ] All features working in release build
- [ ] Privacy policy and terms of service ready
- [ ] App store assets prepared
- [ ] Age rating completed
- [ ] Content guidelines compliant
- [ ] Government approvals obtained

### 2. App Store Review Guidelines

#### Content Policy Compliance
- No inappropriate content
- Accurate app description
- Proper use of government logos (with permission)
- Data privacy compliance
- Child safety measures

#### Technical Requirements
- App stability (crash-free rate > 99.5%)
- Performance optimization
- Accessibility compliance
- Proper permissions usage
- Network error handling

### 3. Review Process

#### Google Play Store
- **Timeline**: 1-3 days for new apps
- **Review Criteria**: Policy compliance, functionality, metadata
- **Common Rejections**: Crashes, policy violations, misleading content

#### Apple App Store  
- **Timeline**: 1-7 days
- **Review Criteria**: App Review Guidelines, functionality, design
- **Common Rejections**: UI issues, crashes, guideline violations

## CI/CD Pipeline

### 1. GitHub Actions Workflow

#### .github/workflows/build-and-deploy.yml
```yaml
name: Build and Deploy

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.16.0'
      - run: flutter pub get
      - run: flutter analyze
      - run: flutter test

  build-android:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      - uses: actions/setup-java@v3
        with:
          distribution: 'zulu'
          java-version: '11'
      
      - name: Setup signing
        run: |
          echo "${{ secrets.KEYSTORE }}" | base64 --decode > android/app/upload-keystore.jks
          echo "storePassword=${{ secrets.KEYSTORE_PASSWORD }}" >> android/key.properties
          echo "keyPassword=${{ secrets.KEY_PASSWORD }}" >> android/key.properties
          echo "keyAlias=${{ secrets.KEY_ALIAS }}" >> android/key.properties
          echo "storeFile=upload-keystore.jks" >> android/key.properties
      
      - run: flutter build appbundle --release
      
      - name: Upload to Play Store
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJsonPlainText: ${{ secrets.PLAY_STORE_JSON }}
          packageName: bd.gov.thirdeye
          releaseFiles: build/app/outputs/bundle/release/app-release.aab
          track: internal
          status: completed

  build-ios:
    needs: test
    runs-on: macos-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      - run: flutter build ios --release --no-codesign
      
      - name: Build and upload to TestFlight
        uses: apple-actions/import-codesign-certs@v1
        with:
          p12-file-base64: ${{ secrets.IOS_CERTIFICATE }}
          p12-password: ${{ secrets.IOS_CERTIFICATE_PASSWORD }}
      
      - run: |
          xcodebuild -workspace ios/Runner.xcworkspace \
            -scheme Runner \
            -configuration Release \
            -archivePath build/Runner.xcarchive \
            archive
      
      - run: |
          xcodebuild -exportArchive \
            -archivePath build/Runner.xcarchive \
            -exportPath build/ios/ipa \
            -exportOptionsPlist ios/ExportOptions.plist

  deploy-web:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      - run: flutter build web --release
      - uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT }}'
          channelId: live
          projectId: thirdeye-prod
```

### 2. Environment Secrets
Configure the following secrets in your CI/CD platform:

```bash
# Android
KEYSTORE                 # Base64 encoded keystore file
KEYSTORE_PASSWORD        # Keystore password
KEY_PASSWORD            # Key password
KEY_ALIAS               # Key alias
PLAY_STORE_JSON         # Play Store service account JSON

# iOS
IOS_CERTIFICATE         # Base64 encoded P12 certificate
IOS_CERTIFICATE_PASSWORD # Certificate password
IOS_PROVISIONING_PROFILE # Base64 encoded provisioning profile

# Firebase
FIREBASE_SERVICE_ACCOUNT # Firebase service account JSON
FIREBASE_TOKEN          # Firebase CLI token

# Other
SENTRY_DSN              # Error tracking DSN
ANALYTICS_KEY           # Analytics API key
```

## Monitoring & Analytics

### 1. Crash Reporting (Firebase Crashlytics)
```dart
// Initialize in main.dart
await Firebase.initializeApp();
FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;

// Log custom events
FirebaseCrashlytics.instance.log('User reported violation');
FirebaseCrashlytics.instance.recordError(
  error,
  stackTrace,
  reason: 'KYC verification failed',
);
```

### 2. Performance Monitoring
```dart
// Track custom traces
final trace = FirebasePerformance.instance.newTrace('report_submission');
await trace.start();
// ... perform operation
await trace.stop();

// Monitor network requests automatically
HttpMetric metric = FirebasePerformance.instance
    .newHttpMetric('https://api.thirdeye.gov.bd/reports', HttpMethod.Post);
await metric.start();
// ... make request
metric.responseCode = 200;
await metric.stop();
```

### 3. Analytics Events
```dart
// Track user actions
FirebaseAnalytics.instance.logEvent(
  name: 'report_submitted',
  parameters: {
    'report_type': 'traffic',
    'violation_type': 'red_light_jumping',
    'vehicle_type': 'motorbike',
  },
);

// Track user properties
FirebaseAnalytics.instance.setUserProperty(
  name: 'user_type',
  value: 'citizen',
);
```

### 4. Health Checks
```dart
// App health monitoring
class HealthCheck {
  static Future<Map<String, dynamic>> getStatus() async {
    return {
      'app_version': await PackageInfo.fromPlatform().version,
      'firebase_connected': await _checkFirebaseConnection(),
      'api_reachable': await _checkApiHealth(),
      'local_storage': await _checkLocalStorage(),
      'timestamp': DateTime.now().toIso8601String(),
    };
  }
}
```

## Production Maintenance

### 1. Regular Tasks
```bash
# Weekly
- Review crash reports and fix critical issues
- Monitor app performance metrics
- Update dependencies (security patches)
- Review user feedback and ratings

# Monthly  
- Update Firebase SDK and dependencies
- Performance optimization review
- Security audit
- Backup verification

# Quarterly
- Major feature releases
- UI/UX improvements based on user feedback  
- Platform SDK updates
- Compliance review
```

### 2. Rollback Procedures
```bash
# Android - Play Console
# 1. Go to Production track
# 2. Create new release with previous version
# 3. Set rollout to 100%

# iOS - App Store Connect
# 1. Go to App Store tab
# 2. Remove current version from sale
# 3. Submit previous version for review

# Web - Firebase Hosting
firebase hosting:clone thirdeye-prod:previous_version thirdeye-prod:live
```

### 3. Emergency Response
```bash
# Critical bug discovered
1. Immediately pause rollout (if active)
2. Revert to previous stable version
3. Fix issue in hotfix branch
4. Fast-track review process
5. Deploy hotfix
6. Monitor metrics closely

# Security vulnerability
1. Take app offline if necessary
2. Patch vulnerability immediately
3. Force app update if required
4. Notify users if data affected
5. Conduct security audit
```

## Compliance & Legal

### 1. Data Privacy (GDPR/Local Laws)
- User consent for data collection
- Data processing agreements
- Right to data deletion
- Data export functionality
- Regular privacy audits

### 2. Government Regulations
- Official logo usage permissions
- Data handling compliance
- User identity verification
- Financial transaction regulations
- Emergency services integration

### 3. App Store Policies
- Regular policy review
- Content moderation
- User-generated content guidelines
- Age rating accuracy
- Intellectual property compliance

This guide provides a comprehensive foundation for building and deploying the Third Eye Bangladesh app. Adapt the specific commands and configurations based on your infrastructure and requirements.
