# Third Eye Bangladesh - Sample Screen Specifications

## Screen Flow Overview
```
Welcome/Onboarding → Login → OTP Verification → KYC Verification → 
Dashboard → Report Creation → Case Tracking → Profile Management
```

## 1. Welcome Screen (Onboarding)

### Layout
```
┌─────────────────────────────────────┐
│  [Language Toggle: EN | বাং]         │
│                                     │
│           [App Logo]                │
│         Third Eye Bangladesh        │
│                                     │
│  [Carousel: Motivational Messages]  │
│                                     │
│     ● Report Traffic Violations     │
│     ● Earn Rewards                  │
│     ● Save Lives                    │
│                                     │
│    [Get Started Button]             │
│    [Officer Portal Link]            │
└─────────────────────────────────────┘
```

### Specifications
- **Background**: White with subtle gradient
- **Logo**: Centered, 120px height
- **Carousel**: Auto-advancing, 3 slides, 5-second intervals
- **Button**: Primary style, full width with 16px margins
- **Officer Link**: Secondary text style, smaller font

### Motivational Text (Bangla)
```
"প্রস্তুত কি ইতিবাচক পরিবর্তনের অংশ হতে? 
আপনার একটি রিপোর্টই অনেকগুলো জীবন বাঁচাতে পারে।"
```

## 2. Citizen Signup Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]    Create Account         │
│                                     │
│          [Progress: 1 of 4]         │
│                                     │
│  Full Name *                        │
│  [________________]                 │
│                                     │
│  Mobile Number *                    │
│  +88 [___________]                  │
│                                     │
│  Email (Optional)                   │
│  [________________]                 │
│                                     │
│  Password *                         │
│  [________________] 👁              │
│  [Password Strength Indicator]      │
│                                     │
│  Confirm Password *                 │
│  [________________] 👁              │
│                                     │
│    [Continue Button]                │
│                                     │
│  Already have account? [Login]      │
└─────────────────────────────────────┘
```

### Specifications
- **Progress Indicator**: Linear, shows 25% completion
- **Form Fields**: Standard text input style with validation
- **Password Field**: Toggle visibility, strength meter below
- **Continue Button**: Disabled until form is valid
- **Validation**: Real-time with clear error messages

### Validation Rules
- **Name**: Minimum 2 characters, letters and spaces only
- **Mobile**: 11 digits, starts with 01
- **Password**: 8+ characters, mixed case, number, symbol
- **Email**: Valid format (if provided)

## 3. OTP Verification Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]    Verify Phone           │
│                                     │
│          [✓ Icon]                   │
│                                     │
│  We've sent a code to               │
│  +88 01XXXXXXX89                    │
│                                     │
│  [_] [_] [_] [_] [_] [_]            │
│                                     │
│    Resend code in 01:45             │
│                                     │
│    [Verify Button]                  │
│                                     │
│  Didn't receive code?               │
│  [Resend via SMS] [Call me]         │
└─────────────────────────────────────┘
```

### Specifications
- **OTP Input**: 6 individual boxes, auto-focus next
- **Timer**: Countdown from 2:00, enable resend when expired
- **Verification**: Auto-submit when 6 digits entered
- **Masked Number**: Show first 2 and last 2 digits only

## 4. KYC Verification Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]    KYC Verification       │
│                                     │
│          [Progress: 2 of 4]         │
│                                     │
│  Document Type                      │
│  ┌──┐ ┌──┐ ┌──┐                    │
│  │📄│ │🚗│ │✈️│                    │
│  │ID│ │DL│ │PP│                    │
│  └──┘ └──┘ └──┘                    │
│                                     │
│  NID Number                         │
│  [________________]                 │
│                                     │
│  Upload Photos                      │
│  ┌─────────┐ ┌─────────┐            │
│  │ Front   │ │ Back    │            │
│  │ Photo   │ │ Photo   │            │
│  │ [📷]    │ │ [📷]    │            │
│  └─────────┘ └─────────┘            │
│                                     │
│    [Continue Button]                │
│                                     │
│  Skip for now                       │
└─────────────────────────────────────┘
```

### Specifications
- **Document Selection**: Radio button groups with icons
- **Photo Upload**: Camera/gallery picker with preview
- **Image Guidelines**: Overlay showing proper positioning
- **Progress**: Updates to 50% when completed

### Three Upload Boxes (As Required)
```
Box 1: "Click to upload NID front & back photo"
Box 2: "Click to upload Driving License front & back photo"  
Box 3: "Click to upload Passport Information Page"
```

## 5. Biometric Verification Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]    Biometric Verify       │
│                                     │
│          [Progress: 3 of 4]         │
│                                     │
│  Take 3 Selfie Photos               │
│                                     │
│      ○                              │
│   Face Guide                        │
│     Overlay                         │
│                                     │
│  ┌─────┐ ┌─────┐ ┌─────┐            │
│  │ 📷  │ │ 📷  │ │ 📷  │            │
│  │Front│ │Left │ │Right│            │
│  │ [✓] │ │ [ ] │ │ [ ] │            │
│  └─────┘ └─────┘ └─────┘            │
│                                     │
│  "Look straight at the camera"      │
│                                     │
│    [Take Photo Button]              │
│                                     │
│    [Continue Button]                │
└─────────────────────────────────────┘
```

### Specifications
- **Face Guide**: Circular overlay showing ideal positioning
- **Photo States**: Empty, captured, verified
- **Instructions**: Change based on current photo (front/left/right)
- **Auto-advance**: Move to next photo after successful capture

## 6. Wallet Setup Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]    Wallet Setup           │
│                                     │
│          [Progress: 4 of 4]         │
│                                     │
│  Select Payment Method              │
│                                     │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │bKash │ │Nagad │ │Rocket│         │
│  │  💳  │ │  💳  │ │  💳  │         │
│  └──────┘ └──────┘ └──────┘         │
│                                     │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │ Upay │ │mCash │ │CellFin│        │
│  │  💳  │ │  💳  │ │  💳  │         │
│  └──────┘ └──────┘ └──────┘         │
│                                     │
│  Account Number                     │
│  [________________]                 │
│                                     │
│  Verify with OTP                    │
│  [_] [_] [_] [_]                   │
│                                     │
│    [Complete Setup]                 │
└─────────────────────────────────────┘
```

### Specifications
- **Payment Grid**: 2x3 grid with provider logos
- **Selection**: Single select with visual feedback
- **OTP Verification**: 4-digit code for wallet verification
- **Completion**: Progress shows 100%

## 7. Dashboard Screen (Citizen)

### Layout
```
┌─────────────────────────────────────┐
│  Third Eye Bangladesh        [🔔][⚙️]│
│                                     │
│  [Motivational Carousel]            │
│                                     │
│  Quick Actions                      │
│  ┌─────────┐ ┌─────────┐            │
│  │ Traffic │ │ Social  │            │
│  │Violation│ │ Crime   │            │
│  │   🚦    │ │   🚨    │            │
│  └─────────┘ └─────────┘            │
│                                     │
│  ┌─────────┐ ┌─────────┐            │
│  │  Case   │ │Emergency│            │
│  │ Search  │ │Contacts │            │
│  │   🔍    │ │   📞    │            │
│  └─────────┘ └─────────┘            │
│                                     │
│  Recent Reports                     │
│  ┌─────────────────────────────────┐ │
│  │ Red Light Jump • Pending        │ │
│  │ Case: TE-2024-1201-0001        │ │
│  │ 2 hours ago              [→]   │ │
│  └─────────────────────────────────┘ │
│                                     │
│  [Home][Reports][Rewards][Profile]  │
└─────────────────────────────────────┘
```

### Specifications
- **Header**: App name, notification bell, settings gear
- **Carousel**: Auto-rotating motivational messages
- **Action Grid**: 2x2 grid with clear icons and labels
- **Recent Reports**: List with status indicators
- **Bottom Navigation**: 4 tabs with active state

## 8. Traffic Report Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]   Report Traffic          │
│                                     │
│  Vehicle Type *                     │
│  [Motorbike ▼]                     │
│                                     │
│  Violation Type *                   │
│  [Red Light Jumping ▼]             │
│                                     │
│  Vehicle Number (Optional)          │
│  [________________]                 │
│                                     │
│  Location                           │
│  📍 Dhanmondi 27, Dhaka           │
│  [Use Current] [Select Other]      │
│                                     │
│  Evidence                           │
│  ┌─────────┐ ┌─────────┐            │
│  │  Photo  │ │ Video   │            │
│  │  [📷]   │ │ [🎥]    │            │
│  └─────────┘ └─────────┘            │
│                                     │
│  Description (Optional)             │
│  [________________________]       │
│  [________________________]       │
│                                     │
│    [Submit Report]                  │
└─────────────────────────────────────┘
```

### Specifications
- **Dropdowns**: Filtered based on vehicle type
- **Location**: Auto-detected with manual override
- **Media Upload**: Support photos and short videos
- **Validation**: Required fields marked with asterisk

### Violation Types by Vehicle
```
Motorbike: Red Light, Wrong Side, No Helmet, Footpath Driving
Car: Red Light, Wrong Side, Speeding, No Seatbelt
Bus: Overloading, Wrong Lane, Speeding
```

## 9. Case Status Screen

### Layout
```
┌─────────────────────────────────────┐
│  [← Back]   Case Details            │
│                                     │
│  Case: TE-2024-1201-0001           │
│  Status: Under Review              │
│                                     │
│  Timeline                           │
│  ● Submitted        Dec 1, 2:30 PM │
│  ● Under Review     Dec 1, 4:15 PM │
│  ○ DMP Verification    Pending     │
│  ○ Fine Collection     Pending     │
│  ○ Reward Paid         Pending     │
│                                     │
│  Report Details                     │
│  Violation: Red Light Jumping       │
│  Vehicle: Motorbike                 │
│  Location: Dhanmondi 27             │
│  Time: Dec 1, 2024 2:30 PM        │
│                                     │
│  Evidence                           │
│  [📷 Photo 1] [📷 Photo 2]         │
│                                     │
│  Expected Reward: ৳200              │
│                                     │
│  [Share Case] [Download PDF]       │
└─────────────────────────────────────┘
```

### Specifications
- **Timeline**: Visual progress indicator
- **Status Colors**: Green (completed), Blue (in progress), Gray (pending)
- **Evidence**: Thumbnail gallery with full-screen view
- **Actions**: Share and download functionality

## 10. Officer Dashboard Screen

### Layout
```
┌─────────────────────────────────────┐
│  DMP Officer Portal         [Logout]│
│                                     │
│  Officer: Md. Rahman               │
│  Badge: DMP-2024-157               │
│                                     │
│  Statistics                         │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │ 45   │ │ 12   │ │ 3    │         │
│  │Pending││Reviewed││Rejected│       │
│  └──────┘ └──────┘ └──────┘         │
│                                     │
│  Pending Cases                      │
│  ┌─────────────────────────────────┐ │
│  │ 🚦 Red Light • High Priority    │ │
│  │ TE-2024-1201-0001              │ │
│  │ Dhanmondi 27 • 2 hours ago    │ │
│  │ [View Details] [Quick Approve] │ │
│  └─────────────────────────────────┘ │
│                                     │
│  [Filter by Type] [Sort by Date]   │
└─────────────────────────────────────┘
```

### Specifications
- **Officer Info**: Name and badge clearly displayed
- **Stats Cards**: Quick overview with color coding
- **Case List**: Sortable and filterable
- **Quick Actions**: Approve/reject without full details view

## Responsive Considerations

### Mobile (< 768px)
- Single column layouts
- Full-width buttons
- Larger touch targets (minimum 44px)
- Collapsed navigation

### Tablet (768px - 1024px)
- Two-column layouts where appropriate
- Side navigation panels
- Larger content areas

### Desktop (> 1024px)
- Multi-column dashboards
- Persistent side navigation
- Keyboard shortcuts
- Mouse hover states

## Accessibility Features

### Screen Reader Support
- Semantic HTML elements
- ARIA labels on interactive elements
- Skip navigation links
- Heading hierarchy

### Keyboard Navigation
- Tab order follows logical flow
- Enter and Space activate buttons
- Escape closes modals
- Arrow keys navigate lists

### Visual Accessibility
- High contrast mode support
- Focus indicators clearly visible
- Color not sole indicator of state
- Scalable text up to 200%
