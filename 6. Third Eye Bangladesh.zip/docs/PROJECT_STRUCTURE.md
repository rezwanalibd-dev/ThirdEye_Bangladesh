# Third Eye Bangladesh - Project Structure & UI Specification

## Project Overview
Third Eye is a cross-platform traffic violation reporting app for Bangladesh that enables citizens to report violations, earn rewards, and contribute to road safety. The app features bilingual support (English/Bangla), KYC verification, officer portals, and mobile wallet integration.

## Complete Project Structure

```
third_eye_bangladesh/
├── android/                     # Android native files
├── ios/                        # iOS native files  
├── web/                        # Web PWA files
├── assets/
│   ├── images/
│   │   ├── app_icon.png
│   │   ├── splash.png
│   │   ├── logo.png
│   │   ├── dmp_logo.png
│   │   └── brta_logo.png
│   ├── icons/
│   │   ├── traffic_icons/
│   │   ├── violation_icons/
│   │   └── ui_icons/
│   ├── fonts/
│   │   ├── Kalpurush.ttf
│   │   ├── SolaimanLipi.ttf
│   │   └── Inter.ttf
│   └── animations/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── firebase_options.dart
│   ├── models/
│   │   ├── user_model.dart
│   │   ├── report_model.dart
│   │   ├── violation_model.dart
│   │   └── payment_model.dart
│   ├── providers/
│   │   ├── auth_provider.dart
│   │   ├── language_provider.dart
│   │   ├── report_provider.dart
│   │   ├── location_provider.dart
│   │   └── payment_provider.dart
│   ├── services/
│   │   ├── auth_service.dart
│   │   ├── report_service.dart
│   │   ├── payment_service.dart
│   │   ├── location_service.dart
│   │   ├── storage_service.dart
│   │   └── notification_service.dart
│   ├── screens/
│   │   ├── auth/
│   │   │   ├── login_screen.dart
│   │   │   ├── signup_screen.dart
│   │   │   ├── otp_verification_screen.dart
│   │   │   └── forgot_password_screen.dart
│   │   ├── onboarding/
│   │   │   ├── welcome_screen.dart
│   │   │   └── tutorial_screen.dart
│   │   ├── kyc/
│   │   │   ├── kyc_verification_screen.dart
│   │   │   ├── document_upload_screen.dart
│   │   │   └── biometric_screen.dart
│   │   ├── dashboard/
│   │   │   ├── home_screen.dart
│   │   │   ├── citizen_dashboard.dart
│   │   │   └── officer_dashboard.dart
│   │   ├── report/
│   │   │   ├── report_traffic_screen.dart
│   │   │   ├── report_crime_screen.dart
│   │   │   ├── case_details_screen.dart
│   │   │   └── case_tracking_screen.dart
│   │   ├── profile/
│   │   │   ├── profile_screen.dart
│   │   │   ├── wallet_screen.dart
│   │   │   └── settings_screen.dart
│   │   └── officer/
│   │       ├── officer_login_screen.dart
│   │       ├── verification_dashboard.dart
│   │       └── case_review_screen.dart
│   ├── widgets/
│   │   ├── common/
│   │   │   ├── custom_app_bar.dart
│   │   │   ├── custom_button.dart
│   │   │   ├── custom_text_field.dart
│   │   │   ├── loading_widget.dart
│   │   │   └── error_widget.dart
│   │   ├── cards/
│   │   │   ├── violation_card.dart
│   │   │   ├── report_card.dart
│   │   │   └── stats_card.dart
│   │   ├── dialogs/
│   │   │   ├── confirmation_dialog.dart
│   │   │   └── info_dialog.dart
│   │   └── forms/
│   │       ├── report_form.dart
│   │       └── kyc_form.dart
│   ├── utils/
│   │   ├── constants.dart
│   │   ├── theme.dart
│   │   ├── validators.dart
│   │   ├── helpers.dart
│   │   └── app_localizations.dart
│   └── i18n/
│       ├── app_en.json
│       └── app_bn.json
├── functions/                   # Firebase Cloud Functions
│   ├── index.js
│   ├── package.json
│   ├── verifyKyc.js
│   ├── processPayment.js
│   └── sendNotification.js
├── firestore.rules
├── storage.rules
├── firebase.json
├── pubspec.yaml
├── README.md
└── DEPLOYMENT.md
```

## Key Architecture Decisions

### State Management
- **Provider Pattern**: Chosen for simplicity and wide community support
- Separate providers for different concerns (auth, language, reports, etc.)
- Clean separation between UI and business logic

### Folder Organization
- **Screens**: Grouped by feature (auth, kyc, report, etc.)
- **Widgets**: Organized by type (common, cards, dialogs, forms)
- **Services**: External API interactions and business logic
- **Models**: Data structures and serialization
- **Utils**: Shared utilities and constants

### Internationalization
- JSON-based translation files for easy maintenance
- Separate files for English (app_en.json) and Bangla (app_bn.json)
- Dynamic language switching with Provider
