# Third Eye Bangladesh - UI Design Specification

## Design Philosophy
"Trusted, Professional, Accessible" - The UI should inspire confidence while being accessible to users of all technical backgrounds.

## Color Palette

### Primary Colors
```
Bangladesh Green: #006A4E (Primary brand color)
Bangladesh Red:   #F42A41 (Accent/Alert color)
Golden Yellow:    #FFD700 (Rewards/Success color)
```

### Secondary Colors
```
Background:       #F8FAFC (Light ash background)
Surface:          #FFFFFF (Card/surface color)
Text Primary:     #1F2937 (Dark text)
Text Secondary:   #6B7280 (Muted text)
Border:           #E5E7EB (Border color)
```

### Status Colors
```
Success:          #10B981 (Success states)
Warning:          #F59E0B (Warning states)
Error:            #EF4444 (Error states)
Info:             #3B82F6 (Information)
```

## Typography

### Font Stack
```
English Primary:   Inter (Google Fonts)
English Secondary: Roboto (fallback)
Bangla Primary:    Kalpurush
Bangla Secondary:  SolaimanLipi (fallback)
```

### Font Sizes & Weights
```
Display Large:     32px / Bold (Page titles)
Display Medium:    28px / Bold (Section headers)
Headline Large:    24px / SemiBold (Card titles)
Headline Medium:   20px / SemiBold (Subsections)
Body Large:        18px / Regular (Primary content)
Body Medium:       16px / Regular (Standard text)
Body Small:        14px / Regular (Secondary text)
Caption:           12px / Regular (Helper text)
```

### Line Heights
```
Display:          1.2
Headline:         1.3
Body:             1.5
Caption:          1.4
```

## Spacing System
```
xs:  4px   (Micro spacing)
sm:  8px   (Small spacing)
md:  16px  (Medium spacing - base unit)
lg:  24px  (Large spacing)
xl:  32px  (Extra large spacing)
2xl: 48px  (Section spacing)
3xl: 64px  (Page spacing)
```

## Component Specifications

### Buttons
```
Primary Button:
- Background: #006A4E
- Text: #FFFFFF
- Height: 48px (mobile) / 40px (desktop)
- Border Radius: 8px
- Font: 16px SemiBold
- Min Width: 120px

Secondary Button:
- Background: transparent
- Border: 1px solid #006A4E
- Text: #006A4E
- Same dimensions as primary

Icon Button:
- Size: 40x40px
- Border Radius: 20px (circular)
- Background: rgba(0,106,78,0.1) on hover
```

### Form Fields
```
Text Input:
- Height: 48px
- Border: 1px solid #E5E7EB
- Border Radius: 8px
- Focus Border: #006A4E
- Padding: 12px 16px
- Font: 16px Regular

Dropdown:
- Same as text input
- Chevron icon on right
- Menu border radius: 8px
```

### Cards
```
Standard Card:
- Background: #FFFFFF
- Border: none
- Border Radius: 12px
- Shadow: 0 1px 3px rgba(0,0,0,0.1)
- Padding: 20px

Report Card:
- Same as standard
- Status indicator on left border
- Icon in top-right corner
```

### Navigation
```
Tab Bar Height: 60px
Tab Item:
- Active: #006A4E background, white text
- Inactive: transparent background, #6B7280 text
- Icon size: 24px
- Font: 14px Medium

App Bar:
- Height: 56px
- Background: #006A4E
- Title: 20px SemiBold, white
- Icons: 24px, white
```

## Icon System

### Icon Set
- **Primary**: Material Icons (Google)
- **Custom**: SVG icons for Bangladesh-specific elements
- **Size Standards**: 16px, 20px, 24px, 32px

### Key Icons
```
App Icon:         Custom eye symbol with road elements
Traffic:          🚦 Material traffic light
Camera:           📷 Material camera
Location:         📍 Material location pin
Wallet:           💰 Material wallet
Verification:     ✓ Material check circle
Warning:          ⚠️ Material warning
Emergency:        🚨 Material emergency
```

## Responsive Breakpoints
```
Mobile:           < 768px
Tablet:           768px - 1024px
Desktop:          > 1024px
```

## Accessibility Guidelines

### Color Contrast
- All text meets WCAG AA standards (4.5:1 ratio minimum)
- Interactive elements have 3:1 ratio minimum
- Focus indicators are clearly visible

### Touch Targets
- Minimum size: 44x44px
- Adequate spacing between interactive elements
- Clear visual feedback on interaction

### Typography
- Scalable font sizes
- Support for system font scaling
- High contrast mode support

## Language-Specific Considerations

### Bangla Text Rendering
- Ensure proper Unicode support
- Test complex character combinations
- Adequate line spacing for diacritics
- Right-to-left text support where needed

### Layout Adaptation
- Text expansion: Bangla text often 20-30% longer
- Icon positions remain consistent
- Button widths adjust automatically
- Maintain visual hierarchy in both languages

## Dark Mode Support
```
Background:       #1F2937
Surface:          #374151
Text Primary:     #F9FAFB
Text Secondary:   #D1D5DB
Border:           #4B5563
Primary:          #10B981 (adjusted for contrast)
```

## Animation Guidelines
```
Duration:         200ms (micro), 300ms (standard), 500ms (complex)
Easing:           cubic-bezier(0.4, 0, 0.2, 1) (Material standard)
Properties:       opacity, transform, color
Performance:      Use transform and opacity for 60fps animations
```
