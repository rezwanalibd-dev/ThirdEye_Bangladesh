# Third Eye Bangladesh - Assets Directory

This directory contains all the visual assets needed for the Third Eye Bangladesh app.

## Directory Structure

```
assets/
├── images/
│   ├── app_icon.png          # App icon (512x512)
│   ├── splash.png            # Splash screen background
│   ├── logo.png              # Main app logo
│   ├── dmp_logo.png          # Dhaka Metropolitan Police logo
│   ├── brta_logo.png         # Bangladesh Road Transport Authority logo
│   ├── hero_bg.jpg           # Hero section background
│   └── placeholder.png        # Placeholder image for missing content
├── icons/
│   ├── traffic_icons/        # Traffic-related icons
│   ├── violation_icons/      # Violation type icons
│   ├── ui_icons/            # General UI icons
│   └── payment_icons/       # Payment method icons
├── fonts/
│   ├── Kalpurush.ttf        # Primary Bangla font
│   ├── SolaimanLipi.ttf     # Secondary Bangla font
│   └── Inter.ttf            # English font (backup)
└── animations/
    ├── loading.json         # Lottie loading animation
    ├── success.json         # Success animation
    └── error.json           # Error animation
```

## Asset Specifications

### App Icon
- **Format**: PNG
- **Size**: 512x512px (for adaptive icon)
- **Background**: Transparent
- **Design**: Stylized eye with road elements
- **Colors**: Use app primary colors (#006A4E, #FFD700)

### Splash Screen
- **Format**: PNG/JPG
- **Size**: 1080x1920px (9:16 ratio)
- **Design**: Clean, minimal with app logo centered
- **Background**: Light gradient from #F8FAFC to #FFFFFF

### Logos
- **Main Logo**: 200x60px, horizontal layout
- **DMP Logo**: Official logo with proper permissions
- **BRTA Logo**: Official logo with proper permissions
- **Format**: PNG with transparent background

### Icons
- **Format**: SVG (preferred) or PNG
- **Sizes**: 24x24, 32x32, 48x48px
- **Style**: Material Design guidelines
- **Colors**: Single color (tintable)

## Traffic Icons

### Violation Types
```
red_light.svg         # Red light jumping
wrong_side.svg        # Wrong side driving
speeding.svg          # Over speeding
mobile_phone.svg      # Using mobile while driving
no_helmet.svg         # Not wearing helmet
parking.svg           # Illegal parking
footpath.svg          # Driving on footpath
overloading.svg       # Vehicle overloading
no_license.svg        # Driving without license
no_seatbelt.svg       # Not wearing seatbelt
```

### Vehicle Types
```
motorbike.svg         # Motorbike/motorcycle
car.svg               # Private car
bus.svg               # Bus
truck.svg             # Truck
cng.svg               # CNG auto-rickshaw
rickshaw.svg          # E-rickshaw
```

## UI Icons

### Navigation
```
home.svg              # Home tab
reports.svg           # Reports tab
rewards.svg           # Rewards tab
profile.svg           # Profile tab
settings.svg          # Settings
back_arrow.svg        # Back navigation
menu.svg              # Menu/hamburger
```

### Actions
```
camera.svg            # Camera/photo capture
video.svg             # Video recording
location.svg          # GPS location
upload.svg            # File upload
download.svg          # Download
share.svg             # Share
edit.svg              # Edit
delete.svg            # Delete
search.svg            # Search
filter.svg            # Filter
sort.svg              # Sort
refresh.svg           # Refresh
```

### Status
```
pending.svg           # Pending status
in_progress.svg       # In progress
verified.svg          # Verified/approved
rejected.svg          # Rejected
completed.svg         # Completed
warning.svg           # Warning
error.svg             # Error
success.svg           # Success
info.svg              # Information
```

## Payment Icons

### Mobile Wallets
```
bkash.svg            # bKash logo
nagad.svg            # Nagad logo
rocket.svg           # Rocket logo
upay.svg             # Upay logo
mcash.svg            # mCash logo
cellfin.svg          # CellFin logo
surecash.svg         # SureCash logo
```

## Fonts

### Kalpurush.ttf
- **Purpose**: Primary Bangla font
- **License**: Open Font License (OFL)
- **Coverage**: Full Bengali Unicode range
- **Usage**: All Bangla text in the app

### SolaimanLipi.ttf
- **Purpose**: Fallback Bangla font
- **License**: GNU General Public License
- **Coverage**: Bengali Unicode with additional characters
- **Usage**: Fallback when Kalpurush is not available

### Inter.ttf
- **Purpose**: English text
- **License**: Open Font License (OFL)
- **Coverage**: Latin characters with international support
- **Usage**: All English text, fallback for system fonts

## Animations

### Lottie Animations
All animations should be created in Lottie format for better performance and scalability.

#### loading.json
- **Duration**: 1.5 seconds, looping
- **Style**: Minimal spinner or progress indicator
- **Colors**: App primary colors
- **Size**: Keep under 50KB

#### success.json
- **Duration**: 2 seconds, single play
- **Style**: Checkmark animation with celebration
- **Colors**: Success green (#10B981)
- **Usage**: Form submissions, successful actions

#### error.json
- **Duration**: 2 seconds, single play
- **Style**: Alert or warning animation
- **Colors**: Error red (#EF4444)
- **Usage**: Error states, failed validations

## Image Guidelines

### Quality Standards
- **Resolution**: Minimum 2x for retina displays
- **Compression**: Optimize for web without quality loss
- **Format**: 
  - PNG for icons and graphics with transparency
  - JPG for photos and complex images
  - SVG for scalable graphics
  - WebP for better compression (with fallbacks)

### Color Profile
- **Color Space**: sRGB
- **Bit Depth**: 8-bit minimum
- **ICC Profile**: Embed sRGB profile

### File Naming
- Use lowercase letters
- Separate words with underscores
- Include size suffix when needed (e.g., `icon_24.png`)
- Use descriptive names

### Accessibility
- **Alt Text**: Provide meaningful descriptions
- **Color Contrast**: Ensure sufficient contrast ratios
- **Scalability**: Icons should be readable at small sizes
- **High Contrast**: Test in high contrast mode

## Usage in Code

### Flutter Implementation
```dart
// Images
Image.asset('assets/images/logo.png')

// Icons
Icon(Icons.home) // Material icons
SvgPicture.asset('assets/icons/ui_icons/camera.svg')

// Fonts
TextStyle(fontFamily: 'Kalpurush') // For Bangla text
TextStyle(fontFamily: 'Inter') // For English text

// Animations
Lottie.asset('assets/animations/loading.json')
```

### Asset Declaration (pubspec.yaml)
```yaml
flutter:
  assets:
    - assets/images/
    - assets/icons/
    - assets/animations/
  fonts:
    - family: Kalpurush
      fonts:
        - asset: assets/fonts/Kalpurush.ttf
    - family: SolaimanLipi
      fonts:
        - asset: assets/fonts/SolaimanLipi.ttf
    - family: Inter
      fonts:
        - asset: assets/fonts/Inter.ttf
```

## Asset Generation Tools

### Recommended Tools
- **Icon Generation**: Figma, Sketch, Adobe Illustrator
- **Image Optimization**: ImageOptim, TinyPNG, Squoosh
- **Animation**: Lottie (After Effects), Rive
- **Font Subsetting**: Glyphhanger, FontTools

### Build Scripts
Create scripts to automatically optimize assets during build:
- Compress images
- Generate multiple resolutions
- Optimize SVGs
- Subset fonts for used characters

## Legal Considerations

### Government Logos
- DMP and BRTA logos require official permission
- Include proper attribution
- Follow brand guidelines
- Get written consent for usage

### Font Licenses
- Kalpurush: OFL license allows commercial use
- SolaimanLipi: GPL license allows free distribution
- Inter: OFL license allows modification and distribution

### Icon Licenses
- Material Icons: Apache License 2.0
- Custom icons: Ensure proper licensing
- Third-party icons: Check individual licenses

## Maintenance

### Version Control
- Track all asset changes
- Use descriptive commit messages
- Maintain asset changelog
- Archive old versions

### Regular Updates
- Optimize assets periodically
- Update logos when official versions change
- Review accessibility compliance
- Test across different devices and resolutions
