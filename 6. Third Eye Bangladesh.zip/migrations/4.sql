
-- Insert demo citizen account
INSERT INTO users (
  uid, phone_number, email, full_name, user_type, is_verified, password_hash,
  nid_number, driving_license, payment_method, wallet_number, is_wallet_verified,
  is_biometric_verified, total_reports, approved_reports, total_rewards, pending_rewards
) VALUES (
  'demo_citizen_001',
  '+8801712345678',
  'demo@thirdeye.gov.bd',
  'Rahman Ahmed',
  'citizen',
  TRUE,
  'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', -- password: demo123
  '1234567890',
  'DL-123456',
  'bKash',
  '01712345678',
  TRUE,
  TRUE,
  5,
  3,
  1800.0,
  400.0
);

-- Insert demo officer account
INSERT INTO users (
  uid, phone_number, email, full_name, user_type, is_verified, password_hash,
  badge_number, rank, department
) VALUES (
  'demo_officer_001',
  '+8801812345678',
  'officer@dmp.gov.bd',
  'Inspector Rahman',
  'officer',
  TRUE,
  'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', -- password: demo123
  'DMP-2024-157',
  'Inspector',
  'Traffic Division'
);

-- Insert sample reports for demo citizen
INSERT INTO reports (
  case_number, user_id, report_type, violation_type, vehicle_type, vehicle_number,
  description, latitude, longitude, address, status, is_anonymous,
  estimated_fine, commission, created_at
) VALUES
  -- Pending report
  ('TE-2024-1105-001', 'demo_citizen_001', 'traffic', 'Red Light Jumping', 'Motorbike', 'Dhaka-Metro-12-3456',
   'Rider jumped red light at busy intersection', 23.7808, 90.4106, 'Dhanmondi 27, Dhaka',
   'pending', FALSE, 5000, 1000, datetime('now', '-2 hours')),
  
  -- Under review report
  ('TE-2024-1104-015', 'demo_citizen_001', 'traffic', 'Wrong Side Driving', 'Car', 'Dhaka-Metro-Ka-7890',
   'Car driving on wrong side near diplomatic zone', 23.7925, 90.4078, 'Gulshan 2, Dhaka',
   'under_review', FALSE, 3000, 600, datetime('now', '-1 day')),
  
  -- Approved report with reward
  ('TE-2024-1103-008', 'demo_citizen_001', 'traffic', 'No Helmet', 'Motorbike', 'Dhaka-Metro-Ba-5678',
   'Rider without helmet on main road', 23.8759, 90.3795, 'Uttara Sector 7, Dhaka',
   'approved', FALSE, 1000, 200, datetime('now', '-2 days')),
  
  -- Rejected report
  ('TE-2024-1102-022', 'demo_citizen_001', 'traffic', 'Illegal Parking', 'Car', 'Dhaka-Metro-Ga-1234',
   'Car parked in no parking zone', 23.7104, 90.4074, 'Wari, Dhaka',
   'rejected', FALSE, 2000, 400, datetime('now', '-3 days')),
  
  -- Anonymous social crime report
  ('TE-2024-1101-033', 'anonymous', 'social_crime', 'Theft', NULL, NULL,
   'Witnessed theft incident at market area', 23.7461, 90.3742, 'Mirpur 10, Dhaka',
   'under_review', TRUE, NULL, NULL, datetime('now', '-4 days'));

-- Insert sample attachments for reports
INSERT INTO report_attachments (report_id, file_url, file_type) VALUES
  (1, 'https://example.com/evidence1.jpg', 'image'),
  (1, 'https://example.com/evidence1_video.mp4', 'video'),
  (2, 'https://example.com/evidence2.jpg', 'image'),
  (2, 'https://example.com/evidence2b.jpg', 'image'),
  (2, 'https://example.com/evidence2c.jpg', 'image'),
  (3, 'https://example.com/evidence3.jpg', 'image'),
  (4, 'https://example.com/evidence4.jpg', 'image'),
  (4, 'https://example.com/evidence4b.jpg', 'image'),
  (5, 'https://example.com/evidence5.jpg', 'image');

-- Insert some additional pending reports for officer review
INSERT INTO reports (
  case_number, user_id, report_type, violation_type, vehicle_type, vehicle_number,
  description, latitude, longitude, address, status, is_anonymous,
  estimated_fine, commission, created_at
) VALUES
  ('TE-2024-1105-002', 'demo_citizen_001', 'traffic', 'Speeding', 'Car', 'Dhaka-Metro-Kha-9999',
   'Car speeding in school zone', 23.7644, 90.3611, 'Mohammadpur, Dhaka',
   'pending', FALSE, 5000, 1000, datetime('now', '-1 hour')),
  
  ('TE-2024-1105-003', 'demo_citizen_001', 'traffic', 'Using Mobile Phone', 'Bus', 'Dhaka-Metro-Gha-5555',
   'Bus driver using mobile phone while driving', 23.8103, 90.4125, 'Banani, Dhaka',
   'pending', FALSE, 5000, 1000, datetime('now', '-30 minutes'));

-- Insert sample attachments for new reports
INSERT INTO report_attachments (report_id, file_url, file_type) VALUES
  (6, 'https://example.com/evidence6.jpg', 'image'),
  (7, 'https://example.com/evidence7.jpg', 'image'),
  (7, 'https://example.com/evidence7b.jpg', 'image');
