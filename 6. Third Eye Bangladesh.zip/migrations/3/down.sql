
DROP INDEX idx_otp_code;
DROP INDEX idx_otp_phone;
DROP TABLE otp_verifications;
DROP INDEX idx_attachments_report_id;
DROP TABLE report_attachments;
