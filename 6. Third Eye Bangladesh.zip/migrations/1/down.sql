
DROP INDEX idx_users_user_type;
DROP INDEX idx_users_phone;
DROP INDEX idx_users_uid;
DROP TABLE users;
