
-- Reports table for traffic violations and social crimes
CREATE TABLE reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_number TEXT UNIQUE NOT NULL,
  user_id TEXT NOT NULL,
  report_type TEXT NOT NULL, -- 'traffic' or 'social_crime'
  violation_type TEXT NOT NULL,
  
  -- Vehicle information (for traffic reports)
  vehicle_type TEXT,
  vehicle_number TEXT,
  
  -- Location and details
  description TEXT,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  address TEXT NOT NULL,
  
  -- Status and review
  status TEXT DEFAULT 'pending', -- 'pending', 'under_review', 'verified', 'approved', 'rejected', 'fine_collected', 'reward_paid'
  is_anonymous BOOLEAN DEFAULT FALSE,
  
  -- Financial information
  estimated_fine REAL,
  commission REAL, -- 20% of fine
  
  -- Review information
  officer_id TEXT,
  officer_comments TEXT,
  reviewed_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reports_user_id ON reports(user_id);
CREATE INDEX idx_reports_status ON reports(status);
CREATE INDEX idx_reports_case_number ON reports(case_number);
CREATE INDEX idx_reports_type ON reports(report_type);
CREATE INDEX idx_reports_created_at ON reports(created_at);
