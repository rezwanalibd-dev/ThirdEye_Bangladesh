
DROP INDEX idx_reports_created_at;
DROP INDEX idx_reports_type;
DROP INDEX idx_reports_case_number;
DROP INDEX idx_reports_status;
DROP INDEX idx_reports_user_id;
DROP TABLE reports;
