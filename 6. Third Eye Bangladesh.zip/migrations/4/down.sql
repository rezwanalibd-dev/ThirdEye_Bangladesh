
-- Remove demo reports and attachments
DELETE FROM report_attachments WHERE report_id IN (
  SELECT id FROM reports WHERE user_id IN ('demo_citizen_001', 'anonymous')
);

DELETE FROM reports WHERE user_id IN ('demo_citizen_001', 'anonymous');

-- Remove demo users
DELETE FROM users WHERE uid IN ('demo_citizen_001', 'demo_officer_001');
