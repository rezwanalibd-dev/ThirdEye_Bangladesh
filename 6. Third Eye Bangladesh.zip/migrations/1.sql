
-- Users table for both citizens and officers
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT UNIQUE NOT NULL,
  phone_number TEXT UNIQUE NOT NULL,
  email TEXT,
  full_name TEXT NOT NULL,
  user_type TEXT DEFAULT 'citizen',
  is_verified BOOLEAN DEFAULT FALSE,
  password_hash TEXT,
  
  -- KYC Information
  nid_number TEXT,
  driving_license TEXT,
  passport_number TEXT,
  document_urls TEXT, -- JSON array of document URLs
  
  -- Biometric Information
  selfie_urls TEXT, -- JSON array of selfie URLs
  is_biometric_verified BOOLEAN DEFAULT FALSE,
  
  -- Wallet Information
  payment_method TEXT,
  wallet_number TEXT,
  is_wallet_verified BOOLEAN DEFAULT FALSE,
  
  -- Statistics
  total_reports INTEGER DEFAULT 0,
  approved_reports INTEGER DEFAULT 0,
  total_rewards REAL DEFAULT 0.0,
  pending_rewards REAL DEFAULT 0.0,
  
  -- Officer specific fields
  badge_number TEXT,
  rank TEXT,
  department TEXT,
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_uid ON users(uid);
CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_user_type ON users(user_type);
