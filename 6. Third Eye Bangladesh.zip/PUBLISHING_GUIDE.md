# Third Eye Bangladesh - Complete Publishing Guide

This comprehensive guide covers publishing the Third Eye Bangladesh app to both Google Play Store (Android) and Apple App Store (iOS).

## Table of Contents

1. [Project Structure Overview](#project-structure-overview)
2. [Pre-Publishing Checklist](#pre-publishing-checklist)
3. [Android Publishing (Google Play Store)](#android-publishing-google-play-store)
4. [iOS Publishing (Apple App Store)](#ios-publishing-apple-app-store)
5. [Web Deployment (Cloudflare)](#web-deployment-cloudflare)
6. [Post-Publishing Tasks](#post-publishing-tasks)

---

## Project Structure Overview

```
third-eye-bangladesh/
├── flutter_mobile_app/          # Mobile app (Android & iOS)
│   ├── android/                 # Android platform code
│   ├── ios/                     # iOS platform code
│   ├── lib/                     # Flutter application code
│   │   ├── main.dart           # App entry point
│   │   ├── models/             # Data models
│   │   ├── providers/          # State management
│   │   ├── screens/            # UI screens
│   │   ├── services/           # API services
│   │   ├── utils/              # Utilities
│   │   └── widgets/            # Reusable widgets
│   └── pubspec.yaml            # Flutter dependencies
├── src/                        # Web application
│   ├── react-app/              # React frontend
│   │   ├── components/         # React components
│   │   ├── pages/              # Page components
│   │   └── main.tsx            # React entry
│   └── worker/                 # Cloudflare Worker backend
│       ├── index.ts            # Worker entry
│       └── routes/             # API routes
├── docs/                       # Documentation
│   ├── BUILD_DEPLOY_GUIDE.md
│   ├── PROJECT_STRUCTURE.md
│   └── UI_SPECIFICATION.md
├── DEMO_ACCOUNTS.md           # Demo credentials
├── TESTING_GUIDE.md           # Testing instructions
└── PUBLISHING_GUIDE.md        # This file
```

---

## Pre-Publishing Checklist

### ✅ Required Preparations

#### 1. Legal & Compliance
- [ ] Privacy Policy written and hosted
- [ ] Terms of Service written and hosted
- [ ] Data protection compliance reviewed
- [ ] Government partnership agreements signed
- [ ] DMP/BRTA official approvals obtained

#### 2. App Store Assets
- [ ] App icon (1024x1024 PNG) created
- [ ] Feature graphic (1024x500 PNG) created
- [ ] Screenshots prepared (minimum 4 per device type)
- [ ] App description written in English and Bangla
- [ ] Keywords researched and selected
- [ ] Promotional video created (optional but recommended)

#### 3. Testing Completed
- [ ] All features tested on multiple devices
- [ ] KYC verification flow tested
- [ ] Biometric verification tested
- [ ] Payment/wallet integration tested
- [ ] Report submission tested
- [ ] Officer dashboard tested
- [ ] Crash-free rate > 99%
- [ ] Performance benchmarks met

#### 4. Backend Services
- [ ] Cloudflare Worker deployed
- [ ] Database migrations completed
- [ ] API endpoints tested
- [ ] Error handling verified
- [ ] Rate limiting configured
- [ ] Monitoring/analytics set up

---

## Android Publishing (Google Play Store)

### Step 1: Prepare Development Environment

```bash
# Install Flutter
flutter --version  # Should be 3.16.0+

# Navigate to Flutter project
cd flutter_mobile_app

# Get dependencies
flutter pub get

# Run tests
flutter test

# Check for issues
flutter analyze
```

### Step 2: Configure Android Build

#### Update `android/app/build.gradle`

```gradle
android {
    compileSdkVersion 34
    
    defaultConfig {
        applicationId "bd.gov.thirdeye"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
    
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
        }
    }
}
```

### Step 3: Generate Signing Key

```bash
# Generate upload keystore
keytool -genkey -v -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload

# Answer the prompts:
# - Enter keystore password: [CREATE_STRONG_PASSWORD]
# - Re-enter password: [SAME_PASSWORD]
# - What is your first and last name?: Bangladesh Government
# - What is your organizational unit?: DMP
# - What is your organization?: Government of Bangladesh
# - What is your City or Locality?: Dhaka
# - What is your State or Province?: Dhaka Division
# - What is your country code?: BD
# - Is correct?: yes
# - Enter key password: [SAME_OR_DIFFERENT_PASSWORD]
```

### Step 4: Configure Signing Properties

Create `android/key.properties`:

```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=upload
storeFile=/path/to/upload-keystore.jks
```

**IMPORTANT:** Never commit `key.properties` or the keystore file to version control!

Add to `android/.gitignore`:
```
key.properties
*.jks
*.keystore
```

### Step 5: Build Release APK/AAB

```bash
# Build App Bundle (recommended for Play Store)
flutter build appbundle --release

# Output: build/app/outputs/bundle/release/app-release.aab

# OR build APK for direct distribution
flutter build apk --release --split-per-abi

# Output: 
# - build/app/outputs/apk/release/app-armeabi-v7a-release.apk
# - build/app/outputs/apk/release/app-arm64-v8a-release.apk
# - build/app/outputs/apk/release/app-x86_64-release.apk
```

### Step 6: Test Release Build

```bash
# Install on connected device
flutter install --release

# Test all critical features:
# - Login/Signup flow
# - KYC verification
# - Report submission
# - Payment integration
# - Push notifications
```

### Step 7: Create Google Play Console Account

1. Go to https://play.google.com/console
2. Sign up ($25 one-time fee)
3. Accept Developer Distribution Agreement
4. Complete account details

### Step 8: Create App in Play Console

1. Click "Create app"
2. Fill in details:
   - **App name:** Third Eye Bangladesh
   - **Default language:** English (US)
   - **App or game:** App
   - **Free or paid:** Free
3. Accept declarations
4. Click "Create app"

### Step 9: Complete Store Listing

#### Main Store Listing

**App details:**
- **App name:** Third Eye Bangladesh
- **Short description:** Report traffic violations, earn rewards, save lives
- **Full description:**
```
Third Eye Bangladesh is the official government platform for reporting traffic violations and social crimes. Join thousands of citizens in making our roads safer while earning rewards for verified reports.

Key Features:
• Report traffic violations with photo/video evidence
• Earn commission from collected fines (20%)
• Track case status in real-time
• Anonymous social crime reporting
• Officer verification system
• Secure KYC verification
• Bilingual support (English/Bangla)
• Mobile wallet integration

Trusted Partnership:
Official collaboration with Dhaka Metropolitan Police (DMP) and Bangladesh Road Transport Authority (BRTA).

How It Works:
1. Witness a traffic violation
2. Capture clear evidence safely
3. Submit report with GPS location
4. Officers verify the violation
5. Earn commission from collected fines

Make a difference in your community. Download Third Eye Bangladesh today!
```

**App icon:** Upload 512x512 PNG (with transparency)

**Feature graphic:** Upload 1024x500 PNG

**Screenshots:**
- Phone (minimum 2, maximum 8): 16:9 ratio
- 7-inch tablet (minimum 1): 3:2 or 4:3 ratio
- 10-inch tablet (minimum 1): 3:2 or 4:3 ratio

**Categorization:**
- **App category:** Maps & Navigation
- **Tags:** traffic, safety, reporting, rewards, government

**Contact details:**
- **Email:** support@thirdeye.gov.bd
- **Phone:** +880-XXX-XXXXXXX
- **Website:** https://thirdeye.gov.bd

**Privacy policy URL:** https://thirdeye.gov.bd/privacy

### Step 10: Content Rating

1. Click "Start questionnaire"
2. Select category: "Government"
3. Answer questions about content
4. Submit for rating
5. Apply rating to release

### Step 11: App Content

Complete all required declarations:
- [ ] Privacy policy
- [ ] App access
- [ ] Ads
- [ ] Content ratings
- [ ] Target audience
- [ ] News apps
- [ ] COVID-19 contact tracing and status apps
- [ ] Data safety

**Data Safety Section:**
```
Data Collection:
✓ Location - Approximate and Precise (for violation reporting)
✓ Personal info - Name, Email, Phone (for account creation)
✓ Photos and videos (evidence for reports)
✓ Financial info - User payment info (for reward distribution)

Data Sharing:
✓ Location shared with law enforcement
✓ Evidence shared with DMP/BRTA officers
✓ Personal info shared for verification purposes

Data Security:
✓ Data encrypted in transit
✓ Data encrypted at rest
✓ Users can request data deletion
✓ Data handling follows industry standards
```

### Step 12: Create Production Release

1. Go to "Production" > "Create new release"
2. Upload app bundle: `app-release.aab`
3. Add release notes:

**English:**
```
Initial release of Third Eye Bangladesh

Features:
• Report traffic violations with evidence
• Real-time case tracking
• Secure KYC verification
• Mobile wallet integration
• Bilingual interface (English/Bangla)
• Officer verification portal

Join us in making Bangladesh roads safer!
```

**Bangla (বাংলা):**
```
থার্ড আই বাংলাদেশের প্রথম সংস্করণ

বৈশিষ্ট্য:
• প্রমাণসহ ট্রাফিক লঙ্ঘন রিপোর্ট
• রিয়েল-টাইম কেস ট্র্যাকিং
• সুরক্ষিত KYC যাচাইকরণ
• মোবাইল ওয়ালেট সংযোগ
• দ্বিভাষিক ইন্টারফেস
• অফিসার যাচাইকরণ পোর্টাল

বাংলাদেশের রাস্তা নিরাপদ করতে আমাদের সাথে যোগ দিন!
```

4. Set rollout percentage (start with 20% for gradual rollout)
5. Review and roll out to production

### Step 13: Monitor Release

1. Check "Production" dashboard for:
   - Install/uninstall stats
   - Crash reports
   - ANR (Application Not Responding) rate
   - User ratings and reviews

2. Respond to reviews within 24-48 hours

3. Monitor Firebase Crashlytics for crashes

4. Gradually increase rollout: 20% → 50% → 100%

---

## iOS Publishing (Apple App Store)

### Step 1: Apple Developer Account Setup

1. Go to https://developer.apple.com
2. Enroll in Apple Developer Program ($99/year)
3. Complete enrollment (may take 24-48 hours)
4. Accept agreements

### Step 2: Create App ID

1. Go to Certificates, Identifiers & Profiles
2. Click "Identifiers" > "+"
3. Select "App IDs" > Continue
4. Configure:
   - **Description:** Third Eye Bangladesh
   - **Bundle ID:** bd.gov.thirdeye
   - **Capabilities:** 
     - ✓ Push Notifications
     - ✓ Maps
     - ✓ In-App Purchase (if needed)
     - ✓ Associated Domains

### Step 3: Generate Certificates

```bash
# Generate CSR on Mac
# Open Keychain Access > Certificate Assistant > Request from CA
# Email: developer@thirdeye.gov.bd
# Common Name: Third Eye Bangladesh
# Save to disk

# Upload CSR to developer.apple.com
# Download generated certificate
# Double-click to install in Keychain
```

### Step 4: Create Provisioning Profile

1. Go to Profiles > "+"
2. Select "App Store"
3. Select App ID: bd.gov.thirdeye
4. Select Certificate
5. Download and install profile

### Step 5: Configure Xcode Project

```bash
# Open iOS project in Xcode
cd flutter_mobile_app
open ios/Runner.xcworkspace
```

In Xcode:
1. Select Runner in Project Navigator
2. General tab:
   - **Display Name:** Third Eye Bangladesh
   - **Bundle Identifier:** bd.gov.thirdeye
   - **Version:** 1.0.0
   - **Build:** 1
3. Signing & Capabilities:
   - **Team:** Select your team
   - **Provisioning Profile:** Select profile
   - Enable "Automatically manage signing"

### Step 6: Update Info.plist

Add required permissions in `ios/Runner/Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>This app needs camera access to capture evidence photos and videos</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>This app needs photo library access to select evidence images</string>

<key>NSLocationWhenInUseUsageDescription</key>
<string>This app needs location access to tag violation reports accurately</string>

<key>NSLocationAlwaysUsageDescription</key>
<string>This app needs location access to tag violation reports accurately</string>

<key>NSMicrophoneUsageDescription</key>
<string>This app needs microphone access to record video evidence</string>
```

### Step 7: Build iOS Release

```bash
# Clean build
flutter clean

# Get dependencies
flutter pub get

# Build iOS
flutter build ios --release

# Or build from Xcode:
# Product > Archive
```

### Step 8: Create App in App Store Connect

1. Go to https://appstoreconnect.apple.com
2. Click "My Apps" > "+"
3. Fill in details:
   - **Name:** Third Eye Bangladesh
   - **Bundle ID:** bd.gov.thirdeye
   - **SKU:** THIRDEYE-BD-001
   - **User Access:** Full Access

### Step 9: Prepare App Information

**App Information:**
- **Subtitle:** Report • Earn • Save Lives
- **Category:** Navigation
- **Content Rights:** Contains third-party content
- **Age Rating:** 17+ (due to crime reporting)

**Pricing and Availability:**
- **Price:** Free
- **Availability:** Bangladesh (or worldwide)

**Privacy Policy URL:** https://thirdeye.gov.bd/privacy
**Support URL:** https://thirdeye.gov.bd/support

### Step 10: Prepare App Store Listing

**Description:**
```
Make Bangladesh roads safer with Third Eye - the official government platform for citizen-reported traffic violations.

FEATURES:
• Quick violation reporting with GPS tagging
• Photo and video evidence capture
• Real-time case tracking
• Secure reward system
• Anonymous crime reporting
• Officer verification portal
• Bilingual interface (English/Bangla)

TRUSTED PLATFORM:
Official partnership with Dhaka Metropolitan Police (DMP) and Bangladesh Road Transport Authority (BRTA).

HOW IT WORKS:
1. Witness a traffic violation
2. Capture evidence safely
3. Submit report with location
4. Officers verify the violation
5. Earn commission from collected fines

Join thousands of citizens making our roads safer!

SUPPORT:
Email: support@thirdeye.gov.bd
Website: thirdeye.gov.bd
```

**Keywords:** traffic,safety,reporting,police,bangladesh,violations,dmp,brta,rewards

**Promotional Text:**
```
Official government app for reporting traffic violations. Earn rewards while making Bangladesh roads safer. Trusted by DMP and BRTA.
```

**Screenshots:**
- 6.5" Display (iPhone 14 Pro Max): 1284 x 2778
- 5.5" Display (iPhone 8 Plus): 1242 x 2208
- iPad Pro (12.9"): 2048 x 2732

Minimum 1 screenshot per device size, maximum 10

### Step 11: Upload Build with Xcode

```bash
# Archive in Xcode
# Product > Archive

# In Organizer:
# 1. Select archive
# 2. Click "Distribute App"
# 3. Select "App Store Connect"
# 4. Upload
# 5. Wait for processing (10-60 minutes)
```

Or use command line:
```bash
xcrun altool --upload-app \
  --type ios \
  --file "build/ios/ipa/Runner.ipa" \
  --username "developer@thirdeye.gov.bd" \
  --password "app-specific-password"
```

### Step 12: Submit for Review

1. In App Store Connect, select uploaded build
2. Fill in "What's New in This Version":
```
Initial release of Third Eye Bangladesh

• Report traffic violations with evidence
• Real-time case tracking  
• Secure KYC verification
• Mobile wallet integration
• Bilingual support (English/Bangla)
• Officer verification portal

Join us in making Bangladesh roads safer!
```

3. App Review Information:
   - **First Name:** [Your Name]
   - **Last Name:** [Your Last Name]
   - **Phone:** +880-XXX-XXXXXXX
   - **Email:** review@thirdeye.gov.bd
   - **Demo Account:**
     - Username: demo@thirdeye.gov.bd
     - Password: demo123
   - **Notes:** Government partnership documentation available at [URL]

4. Click "Submit for Review"

### Step 13: App Review Process

**Timeline:** 1-7 days

**Status Updates:**
- Waiting for Review
- In Review
- Pending Developer Release
- Ready for Sale

**If Rejected:**
1. Read rejection reason carefully
2. Fix issues
3. Respond in Resolution Center
4. Resubmit

---

## Web Deployment (Cloudflare)

### Step 1: Build Web Application

```bash
# Navigate to root
cd /path/to/third-eye-bangladesh

# Install dependencies
npm install

# Build
npm run build

# Output: dist/ folder
```

### Step 2: Deploy to Cloudflare

```bash
# Deploy worker
npm run deploy

# Or manually with wrangler
npx wrangler deploy
```

### Step 3: Configure Custom Domain

1. Go to Cloudflare Dashboard
2. Select your domain
3. Add DNS record:
   - Type: CNAME
   - Name: app
   - Target: thirdeye-prod.workers.dev

### Step 4: Enable SSL/HTTPS

1. SSL/TLS > Overview
2. Select "Full (strict)"
3. Wait for certificate provisioning

### Step 5: Configure Analytics

1. Enable Web Analytics
2. Add tracking code to index.html
3. Monitor traffic and performance

---

## Post-Publishing Tasks

### 1. Marketing & Promotion

- [ ] Submit press release to major news outlets
- [ ] Create social media accounts
- [ ] Launch marketing campaign
- [ ] Partner with influencers
- [ ] Create tutorial videos

### 2. User Support

- [ ] Set up support email: support@thirdeye.gov.bd
- [ ] Create FAQ page
- [ ] Set up helpdesk/ticketing system
- [ ] Train support team
- [ ] Monitor app reviews and respond

### 3. Monitoring & Analytics

- [ ] Set up Firebase Analytics
- [ ] Configure Crashlytics
- [ ] Set up performance monitoring
- [ ] Create analytics dashboards
- [ ] Set up alerts for critical issues

### 4. Continuous Updates

- [ ] Monitor crash reports weekly
- [ ] Release updates monthly
- [ ] Add new features based on feedback
- [ ] Improve based on analytics
- [ ] Maintain 99.5%+ crash-free rate

### 5. Legal & Compliance

- [ ] Regular privacy policy reviews
- [ ] Security audits quarterly
- [ ] Compliance with data protection laws
- [ ] Government partnership renewals
- [ ] Legal documentation updates

---

## Troubleshooting Common Issues

### Android Build Errors

**Issue:** `Execution failed for task ':app:lintVitalRelease'`
**Solution:**
```gradle
android {
    lintOptions {
        checkReleaseBuilds false
        abortOnError false
    }
}
```

**Issue:** `Duplicate class found`
**Solution:** Check for duplicate dependencies in `build.gradle`

### iOS Build Errors

**Issue:** `Code signing error`
**Solution:** 
1. Delete derived data
2. Clean build folder
3. Re-download provisioning profiles

**Issue:** `Missing required icon`
**Solution:** Ensure all icon sizes are present in Assets.xcassets

### App Store Rejection Reasons

**Common:** Missing privacy policy
**Fix:** Add privacy policy URL in app metadata

**Common:** Incomplete functionality
**Fix:** Ensure all advertised features work

**Common:** Government claims require documentation
**Fix:** Provide official partnership documentation

---

## Support & Resources

### Official Documentation
- Flutter: https://flutter.dev/docs
- Play Console: https://support.google.com/googleplay/android-developer
- App Store Connect: https://developer.apple.com/app-store-connect

### Community Support
- Flutter Discord: https://discord.gg/flutter
- Stack Overflow: Tag with `flutter`, `android`, `ios`
- GitHub Issues: Create issues in project repository

### Contact
- **Technical Support:** tech@thirdeye.gov.bd
- **Business Inquiries:** business@thirdeye.gov.bd
- **Press:** press@thirdeye.gov.bd

---

**Last Updated:** November 12, 2024
**Version:** 1.0.0
**Next Review:** December 12, 2024
