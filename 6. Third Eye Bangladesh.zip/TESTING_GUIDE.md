# Third Eye Bangladesh - Testing Guide

Complete guide for testing all features of the application before publishing.

## 📋 Table of Contents
1. [Setup](#setup)
2. [Demo Accounts](#demo-accounts)
3. [Feature Testing](#feature-testing)
4. [API Testing](#api-testing)
5. [Common Issues](#common-issues)

---

## 🔧 Setup

### Prerequisites
- Node.js 18+ installed
- Database migrations run successfully
- Development server running on localhost:5173

### Start Development Server
```bash
# Install dependencies
npm install

# Run database migrations
npm run migrate

# Start dev server
npm run dev
```

The app will be available at: `http://localhost:5173`

---

## 🔐 Demo Accounts

### Citizen Account
**Login:** `01712345678` or `demo@thirdeye.gov.bd`  
**Password:** `demo123`

**What to Test:**
- Complete user journey from login to report submission
- Case tracking and status updates
- Reward balance and payment integration
- Profile management and KYC

### Officer Account
**Login:** `01812345678` or `officer@dmp.gov.bd`  
**Password:** `demo123`

**What to Test:**
- Officer dashboard and statistics
- Report review workflow
- Approval/rejection with comments
- Priority filtering

See [DEMO_ACCOUNTS.md](DEMO_ACCOUNTS.md) for complete details.

---

## ✅ Feature Testing

### 1. Authentication Flow

#### Test Signup (New User)
1. Navigate to `/signup`
2. Fill in all required fields:
   - Full Name: "Test User"
   - Phone: "01999999999"
   - Email: "test@example.com"
   - Password: "Test123!"
3. Click "Sign Up"
4. Check that OTP is sent (logged in console)
5. Enter OTP on verification page
6. Verify redirect to dashboard

**Expected Result:** ✅ User created and logged in

#### Test Login (Existing User)
1. Navigate to `/login`
2. Enter demo credentials
3. Click "Login"
4. Verify redirect to appropriate dashboard

**Expected Result:** ✅ Successful login with session token

---

### 2. Traffic Violation Reporting

#### Citizen Report Submission
1. Login as citizen
2. Click "Report Traffic Violation"
3. Fill in report details:
   - Vehicle Type: "Car"
   - Violation: "Red Light Jumping"
   - Vehicle Number: "Dhaka-Metro-Ka-1234"
   - Description: "Jumped red light at intersection"
4. Capture location (or use test coordinates)
5. Upload evidence photos (2-3 images)
6. Submit report

**Expected Result:** ✅ Case number generated, reward calculated

**Check Database:**
```sql
SELECT * FROM reports ORDER BY created_at DESC LIMIT 1;
SELECT * FROM report_attachments WHERE report_id = (SELECT MAX(id) FROM reports);
```

---

### 3. Social Crime Reporting

#### Anonymous Crime Report
1. Login as citizen
2. Click "Report Social Crime"
3. Select crime type: "Theft"
4. Add description
5. Set location
6. Upload evidence (1-2 images)
7. Ensure "Report Anonymously" is checked
8. Submit report

**Expected Result:** ✅ Anonymous report created, no reward calculation

---

### 4. Case Tracking

#### Track Report Status
1. Login as citizen
2. Navigate to "Case Tracking"
3. Search for case: "TE-2024-1105-001"
4. View case details:
   - Timeline with progress
   - Evidence gallery
   - Expected reward
   - Current status

**Expected Result:** ✅ Complete case information displayed

#### Check Multiple Reports
1. View "My Reports" list
2. Verify different status badges:
   - 🟡 Pending (yellow)
   - 🔵 Under Review (blue)
   - 🟢 Approved (green)
   - 🔴 Rejected (red)
3. Click each report to view details

**Expected Result:** ✅ All reports show correct status and information

---

### 5. Officer Dashboard

#### Review Pending Reports
1. Login as officer
2. View dashboard statistics:
   - Total pending reports
   - Reports reviewed today
   - Approved/rejected counts
3. Click on pending report
4. Review evidence photos
5. Add officer comments
6. Approve or reject

**Expected Result:** ✅ Report status updated, citizen stats updated

#### Priority Filtering
1. Use priority filter dropdown
2. Select "High Priority"
3. Verify only high-priority reports shown
4. Test "Medium" and "Low" filters

**Expected Result:** ✅ Correct filtering applied

---

### 6. Wallet Integration

#### Setup Wallet (New User)
1. Navigate to wallet setup
2. Select payment method: "bKash"
3. Enter wallet number: "01711111111"
4. Click "Send OTP"
5. Enter OTP (check console)
6. Verify wallet

**Expected Result:** ✅ Wallet verified, ready for payments

#### Check Rewards
1. Login as citizen with approved reports
2. View dashboard statistics
3. Check "Pending Rewards" amount
4. Verify calculation: Fine × 20%

**Expected Result:** ✅ Correct reward amounts displayed

---

### 7. KYC Verification

#### Upload Documents
1. Navigate to KYC verification
2. Enter NID number: "1234567890123"
3. Upload NID photos (front/back)
4. Add driving license (optional)
5. Submit for verification

**Expected Result:** ✅ Documents stored, pending verification

#### Biometric Verification
1. Navigate to biometric verification
2. Capture selfie photo
3. Submit for face matching
4. Wait for verification

**Expected Result:** ✅ Biometric verification completed

---

### 8. Language Toggle

#### Switch Languages
1. Click language toggle (EN/বাং)
2. Verify all text changes to Bangla
3. Check:
   - Navigation labels
   - Button text
   - Status labels
   - Error messages
4. Switch back to English

**Expected Result:** ✅ Complete UI translation works

---

## 🔌 API Testing

### Test Authentication Endpoints

#### Signup
```bash
curl -X POST http://localhost:5173/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "fullName": "Test User",
    "phoneNumber": "01999999999",
    "email": "test@example.com",
    "password": "Test123!",
    "userType": "citizen"
  }'
```

**Expected:** `{ "success": true, "debug": { "otpCode": "123456" } }`

#### Verify OTP
```bash
curl -X POST http://localhost:5173/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "phoneNumber": "01999999999",
    "otpCode": "123456",
    "purpose": "signup"
  }'
```

**Expected:** Session token and user object

#### Login
```bash
curl -X POST http://localhost:5173/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "phoneEmail": "demo@thirdeye.gov.bd",
    "password": "demo123"
  }'
```

**Expected:** Session token and user object

---

### Test Report Endpoints

#### Submit Traffic Report
```bash
curl -X POST http://localhost:5173/api/reports/traffic \
  -H "Authorization: Bearer <session_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "vehicleType": "Car",
    "violationType": "Red Light Jumping",
    "vehicleNumber": "Dhaka-Metro-Ka-1234",
    "description": "Jumped red light",
    "latitude": 23.7808,
    "longitude": 90.4106,
    "address": "Dhanmondi 27, Dhaka",
    "imageUrls": ["https://example.com/img1.jpg"],
    "isAnonymous": false
  }'
```

**Expected:** Case number and reward amount

#### Get User Reports
```bash
curl http://localhost:5173/api/reports/user/demo_citizen_001 \
  -H "Authorization: Bearer <session_token>"
```

**Expected:** Array of user's reports

#### Track Case
```bash
curl http://localhost:5173/api/reports/case/TE-2024-1105-001 \
  -H "Authorization: Bearer <session_token>"
```

**Expected:** Complete report details with timeline

---

### Test Officer Endpoints

#### Get Pending Reports
```bash
curl http://localhost:5173/api/officers/pending-reports \
  -H "Authorization: Bearer <officer_session_token>"
```

**Expected:** Array of pending reports

#### Review Report
```bash
curl -X PUT http://localhost:5173/api/officers/review/1 \
  -H "Authorization: Bearer <officer_session_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "approve",
    "comments": "Evidence is clear, violation confirmed"
  }'
```

**Expected:** Success message, user stats updated

---

## 🐛 Common Issues

### Issue: OTP Not Received
**Solution:** Check browser console, OTP is logged in dev mode

### Issue: Session Token Invalid
**Solution:** Login again to get fresh token, tokens expire

### Issue: Report Submission Fails
**Solution:** 
1. Check network tab for API errors
2. Verify all required fields are filled
3. Ensure valid coordinates provided

### Issue: Evidence Photos Not Uploading
**Solution:**
1. Check file size (max 5MB per image)
2. Verify supported formats (jpg, jpeg, png)
3. Check R2 bucket configuration

### Issue: Case Not Found
**Solution:**
1. Verify case number format: TE-YYYY-MMDD-XXX
2. Check if case exists in database
3. Ensure user has permission to view

### Issue: Officer Can't Review Reports
**Solution:**
1. Verify officer account type in database
2. Check session token includes userType: 'officer'
3. Ensure authorization header is sent

### Issue: Language Toggle Not Working
**Solution:**
1. Clear browser cache
2. Check language provider is mounted
3. Verify translation files exist

---

## 📊 Database Verification

### Check User Stats After Approval
```sql
SELECT 
  full_name,
  total_reports,
  approved_reports,
  pending_rewards,
  total_rewards
FROM users 
WHERE uid = 'demo_citizen_001';
```

### View All Reports by Status
```sql
SELECT 
  case_number,
  violation_type,
  status,
  created_at
FROM reports
ORDER BY created_at DESC;
```

### Check Evidence Attachments
```sql
SELECT 
  r.case_number,
  ra.file_type,
  ra.file_url
FROM reports r
JOIN report_attachments ra ON r.id = ra.report_id
WHERE r.case_number = 'TE-2024-1105-001';
```

---

## ✨ Success Criteria

Before publishing, ensure all these tests pass:

- [ ] Can signup new user with OTP
- [ ] Can login existing user
- [ ] Can submit traffic violation report
- [ ] Can submit anonymous social crime report
- [ ] Can track case status
- [ ] Case timeline updates correctly
- [ ] Evidence photos upload successfully
- [ ] Officer can review and approve reports
- [ ] User stats update after approval
- [ ] Rewards calculated correctly
- [ ] Wallet setup and verification works
- [ ] KYC document upload works
- [ ] Language toggle switches all UI text
- [ ] All API endpoints respond correctly
- [ ] Database schema supports all features
- [ ] Error messages are user-friendly

---

## 📞 Support

For testing assistance:
- Check browser console for errors
- Review API logs in terminal
- Verify database migrations ran
- Check [DEMO_ACCOUNTS.md](DEMO_ACCOUNTS.md) for credentials

Happy Testing! 🚀
