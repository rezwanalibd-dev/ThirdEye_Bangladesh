# Third Eye Bangladesh - Pre-Publishing Verification Checklist

Complete this checklist before submitting your app to Google Play Store or Apple App Store.

## 📋 Table of Contents

1. [Code Quality Verification](#code-quality-verification)
2. [Functionality Testing](#functionality-testing)
3. [UI/UX Verification](#uiux-verification)
4. [Security Audit](#security-audit)
5. [Performance Testing](#performance-testing)
6. [Legal & Compliance](#legal--compliance)
7. [Store Submission Readiness](#store-submission-readiness)

---

## ✅ Code Quality Verification

### Mobile App (Flutter)

#### Build Verification
```bash
cd flutter_mobile_app

# Clean project
flutter clean

# Get dependencies
flutter pub get

# Check for issues
flutter analyze --no-fatal-infos

# Run tests
flutter test

# Build debug (should complete without errors)
flutter build apk --debug

# Build release Android
flutter build appbundle --release

# Build release iOS (on macOS only)
flutter build ios --release
```

**Expected Results:**
- [ ] `flutter analyze` shows 0 errors
- [ ] All tests pass
- [ ] Debug build completes successfully
- [ ] Release builds complete successfully
- [ ] No deprecation warnings

#### Code Review Checklist
- [ ] No hardcoded API keys or secrets
- [ ] All TODO comments resolved or documented
- [ ] Console.log/print statements removed from production code
- [ ] Error handling implemented for all API calls
- [ ] Loading states implemented for async operations
- [ ] Proper null safety checks
- [ ] Constants used instead of magic numbers
- [ ] Code follows Flutter style guide

### Web App (React/TypeScript)

#### Build Verification
```bash
# Install dependencies
npm install

# Type checking
npx tsc --noEmit

# Lint check
npm run lint

# Build production
npm run build

# Preview build
npm run preview
```

**Expected Results:**
- [ ] TypeScript compilation successful
- [ ] No linting errors
- [ ] Production build completes
- [ ] Preview works correctly
- [ ] No console errors in browser

#### Code Review Checklist
- [ ] No TypeScript 'any' types (or properly justified)
- [ ] All imports properly resolved
- [ ] Unused imports removed
- [ ] Component props properly typed
- [ ] Error boundaries implemented
- [ ] Accessibility attributes added
- [ ] Responsive design verified

### Backend (Cloudflare Worker)

#### API Verification
```bash
# Deploy to preview
npm run deploy

# Test endpoints
curl -X GET https://your-worker.workers.dev/api/health
curl -X POST https://your-worker.workers.dev/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"01712345678","password":"demo123"}'
```

**Expected Results:**
- [ ] Worker deploys successfully
- [ ] Health check returns 200
- [ ] All API endpoints respond correctly
- [ ] Database queries execute properly
- [ ] Error responses are properly formatted

---

## 🧪 Functionality Testing

### Authentication Flow

#### Signup Process
- [ ] Can enter full name (min 2 characters)
- [ ] Phone number validation works (+88 01XXXXXXXXX)
- [ ] Email validation works (optional field)
- [ ] Password strength indicator shows correctly
- [ ] Password confirmation validation works
- [ ] OTP is sent successfully
- [ ] Can verify OTP (or skip in dev mode)
- [ ] Account is created in database
- [ ] User is redirected to KYC verification

**Test Cases:**
```
✓ Valid signup: Full name, valid phone, strong password
✓ Invalid phone: Shows error message
✓ Weak password: Shows strength indicator
✓ Password mismatch: Shows error
✓ OTP verification: Accepts valid code
✓ OTP resend: Can request new code
```

#### Login Process
- [ ] Can login with phone number
- [ ] Can login with email
- [ ] Password visibility toggle works
- [ ] "Forgot Password" link works
- [ ] Invalid credentials show error
- [ ] Successful login redirects to dashboard
- [ ] Session is maintained across page refresh

**Test Cases:**
```
✓ Login with demo account: 01712345678 / demo123
✓ Login with wrong password: Shows error
✓ Login with non-existent user: Shows error
✓ Session persistence: Refresh page, still logged in
```

#### OTP Verification
- [ ] 6-digit OTP input works
- [ ] Auto-advances between digits
- [ ] Countdown timer works (2 minutes)
- [ ] Resend OTP enables after countdown
- [ ] Can verify correct OTP
- [ ] Invalid OTP shows error
- [ ] Loading state during verification

### KYC Verification

#### Document Upload
- [ ] Can select document type (NID/License/Passport)
- [ ] Can enter document number
- [ ] Can take photo from camera
- [ ] Can upload from gallery
- [ ] Multiple photos supported (front/back)
- [ ] Image preview shows correctly
- [ ] Can remove uploaded images
- [ ] Document validation works
- [ ] Progress saved if incomplete

**Test Cases:**
```
✓ Upload NID: Front and back photos
✓ Upload License: Both sides
✓ Upload Passport: Info page
✓ Invalid format: Shows error
✓ File too large: Shows size error
```

#### Biometric Verification
- [ ] Camera initializes correctly
- [ ] Face guide overlay shows
- [ ] Can capture selfie (front)
- [ ] Can capture selfie (left side)
- [ ] Can capture selfie (right side)
- [ ] All 3 photos required
- [ ] Can retake photos
- [ ] Progress indicator updates
- [ ] Completes and redirects

### Wallet Setup

#### Payment Method Selection
- [ ] All wallet options display (bKash, Nagad, Rocket, etc.)
- [ ] Can select wallet type
- [ ] Wallet number validation works
- [ ] OTP sent to wallet number
- [ ] Can verify wallet OTP
- [ ] Wallet is marked as verified
- [ ] Redirects to dashboard on completion

**Test Cases:**
```
✓ Setup bKash: Valid number, OTP verification
✓ Setup Nagad: Complete flow
✓ Invalid wallet number: Shows error
✓ Wrong OTP: Shows error message
```

### Report Traffic Violation

#### Form Validation
- [ ] Vehicle type dropdown works
- [ ] Violation type dropdown works
- [ ] Vehicle number field (optional)
- [ ] Description field (optional)
- [ ] Location automatically detected
- [ ] Can manually refresh location
- [ ] At least one evidence required
- [ ] Fine amount calculated correctly
- [ ] Commission (20%) shown

#### Evidence Capture
- [ ] "Take Photo" opens camera
- [ ] "Record Video" opens camera
- [ ] "Upload Photo" opens gallery
- [ ] "Upload Video" opens gallery
- [ ] Multiple evidence files supported
- [ ] Can remove evidence
- [ ] Preview evidence before submit
- [ ] File size validation

#### Submission
- [ ] Submit button enabled when valid
- [ ] Loading state during submission
- [ ] Case number generated
- [ ] Success message shows
- [ ] Redirects to case tracking
- [ ] Report saved in database
- [ ] Evidence uploaded successfully

**Test Cases:**
```
✓ Submit with photo: Vehicle type, violation, 1 photo
✓ Submit with video: Complete form with video
✓ Submit with multiple evidence: 2 photos, 1 video
✓ Submit without evidence: Shows error
✓ Submit without location: Shows error
```

### Report Social Crime

#### Form Validation
- [ ] Crime type dropdown works (Bangla text correct)
- [ ] Description field works
- [ ] Location detected
- [ ] Evidence required
- [ ] Anonymous option works
- [ ] Submit button validation

#### Anonymous Reporting
- [ ] "আপনার পরিচয় গোপন রেখে রিপোর্ট করুন" text shows
- [ ] Anonymous toggle works
- [ ] User ID hidden when anonymous
- [ ] No reward calculated for anonymous
- [ ] Case number still generated

**Test Cases:**
```
✓ Report theft: With evidence, anonymous
✓ Report violence: With video evidence
✓ Report corruption: Non-anonymous
✓ Verify anonymous: User ID not stored
```

### Case Tracking

#### Search & Display
- [ ] Can search by case number
- [ ] Can search by vehicle number
- [ ] Shows all user's reports
- [ ] Status badges show correctly:
  - 🟡 Pending (yellow)
  - 🔵 Under Review (blue)
  - 🟢 Approved (green)
  - 🔴 Rejected (red)
- [ ] Timeline shows progress
- [ ] Evidence gallery displays
- [ ] Expected reward shows

**Test Cases:**
```
✓ Search case: TE-2024-1105-001
✓ View all reports: Shows list
✓ Click report: Shows details
✓ Timeline: Shows all steps
✓ Evidence: Shows all images/videos
```

### Officer Dashboard

#### Report Review
- [ ] Pending reports list shows
- [ ] Can filter by priority
- [ ] Can view report details
- [ ] Evidence displays correctly
- [ ] Can add officer comments
- [ ] Can approve report
- [ ] Can reject report
- [ ] Statistics update

**Test Cases:**
```
✓ Login as officer: 01812345678 / demo123
✓ View pending: Shows all pending
✓ Approve report: Status updates
✓ Reject report: Requires comment
✓ Statistics: Updates in real-time
```

### Profile Management

#### Profile Editing
- [ ] Can upload profile picture
- [ ] Camera upload works
- [ ] Gallery upload works
- [ ] Can edit full name
- [ ] Can edit email
- [ ] Can update phone (requires OTP)
- [ ] Changes saved to database
- [ ] Success message shows

#### Password Change
- [ ] OTP sent to phone/email
- [ ] Can enter OTP
- [ ] Can enter new password
- [ ] Password strength indicator works
- [ ] Confirm password validation
- [ ] Password updated successfully
- [ ] Must re-login after change

#### Notification Settings
- [ ] Push notification toggle works
- [ ] Email notification toggle works
- [ ] SMS notification toggle works
- [ ] Report updates toggle works
- [ ] Reward updates toggle works
- [ ] Settings saved

#### Privacy & Security
- [ ] Can view active sessions
- [ ] Can logout from devices
- [ ] Two-factor auth option
- [ ] Data export request
- [ ] Privacy settings saved

#### Account Management
- [ ] Can deactivate account temporarily
- [ ] Deactivation requires confirmation
- [ ] Can permanently delete account
- [ ] Deletion requires password
- [ ] Account deleted from database
- [ ] All data removed

### Language Toggle

#### Switching Languages
- [ ] English/Bangla toggle works
- [ ] All UI text translates
- [ ] Button labels translate
- [ ] Form placeholders translate
- [ ] Error messages translate
- [ ] Success messages translate
- [ ] Dropdown options translate
- [ ] Language preference saved

**Test Screens:**
```
✓ Welcome screen: Both languages
✓ Login screen: Both languages
✓ Dashboard: Both languages
✓ Report forms: Both languages
✓ Profile: Both languages
```

### Mobile App Install Guide

#### App Installation
- [ ] Modal opens correctly
- [ ] Platform selection works
- [ ] Android instructions show
- [ ] iOS instructions show
- [ ] QR codes display
- [ ] Download links work
- [ ] Play Store link correct
- [ ] App Store link correct
- [ ] Installation steps clear
- [ ] Close button works

---

## 🎨 UI/UX Verification

### Visual Design

#### Branding
- [ ] Bangladesh green (#006A4E) used consistently
- [ ] Bangladesh red (#F42A41) used appropriately
- [ ] Golden yellow (#FFD700) for rewards/premium
- [ ] Logo displays correctly
- [ ] App icon matches branding
- [ ] Splash screen displays

#### Typography
- [ ] Headings are clear and readable
- [ ] Body text has good contrast
- [ ] Bangla fonts render correctly (Kalpurush/SolaimanLipi)
- [ ] Font sizes appropriate for mobile
- [ ] Line height comfortable for reading

#### Layout
- [ ] Responsive on different screen sizes
- [ ] Works on small phones (320px width)
- [ ] Works on tablets
- [ ] Works on large phones
- [ ] No horizontal scroll
- [ ] Touch targets minimum 44x44px

#### Components
- [ ] Buttons have proper padding
- [ ] Input fields have clear labels
- [ ] Dropdowns are easy to tap
- [ ] Cards have proper spacing
- [ ] Icons are recognizable
- [ ] Loading spinners show

### User Experience

#### Navigation
- [ ] Bottom navigation works
- [ ] Back buttons work correctly
- [ ] Breadcrumbs show current location
- [ ] Deep linking works
- [ ] Can navigate with browser back/forward

#### Forms
- [ ] Auto-focus on first field
- [ ] Tab order is logical
- [ ] Enter key submits forms
- [ ] Error messages inline
- [ ] Success messages clear
- [ ] Required fields marked with *

#### Feedback
- [ ] Loading states for async actions
- [ ] Success messages after actions
- [ ] Error messages are helpful
- [ ] Confirmation dialogs for destructive actions
- [ ] Progress indicators for multi-step processes

#### Accessibility
- [ ] Screen reader compatible
- [ ] Keyboard navigation works
- [ ] Color contrast meets WCAG AA
- [ ] Alt text on images
- [ ] Focus indicators visible
- [ ] Form labels associated

---

## 🔒 Security Audit

### Authentication Security
- [ ] Passwords hashed (not plain text)
- [ ] Session tokens properly generated
- [ ] Token expiration implemented
- [ ] Secure password reset flow
- [ ] Rate limiting on login attempts
- [ ] No credentials in logs

### Data Security
- [ ] HTTPS enforced
- [ ] API endpoints authenticated
- [ ] User data encrypted at rest
- [ ] File uploads validated
- [ ] SQL injection prevention
- [ ] XSS prevention
- [ ] CSRF protection

### Privacy
- [ ] No unnecessary permissions requested
- [ ] Location only when needed
- [ ] Camera only when needed
- [ ] Data collection disclosed
- [ ] Privacy policy linked
- [ ] User consent obtained

### Code Security
- [ ] No API keys in code
- [ ] Environment variables used
- [ ] Secrets properly managed
- [ ] Dependencies up to date
- [ ] No known vulnerabilities
- [ ] Security headers set

---

## ⚡ Performance Testing

### Mobile App Performance

#### Startup Time
- [ ] Cold start < 3 seconds
- [ ] Hot start < 1 second
- [ ] Splash screen shows immediately

#### Screen Transitions
- [ ] Screen transitions smooth (60fps)
- [ ] No jank during animations
- [ ] List scrolling smooth

#### Network Performance
- [ ] API calls < 2 seconds
- [ ] Image loading optimized
- [ ] Caching implemented
- [ ] Offline mode works

#### Memory Usage
- [ ] No memory leaks
- [ ] Images properly disposed
- [ ] Listeners cleaned up
- [ ] App size < 50MB

### Web App Performance

#### Load Time
- [ ] First contentful paint < 1.5s
- [ ] Time to interactive < 3s
- [ ] Lighthouse score > 90

#### Bundle Size
- [ ] Main bundle < 200KB
- [ ] Code splitting implemented
- [ ] Lazy loading for routes
- [ ] Images optimized

#### Runtime Performance
- [ ] No layout thrashing
- [ ] Smooth animations
- [ ] Efficient re-renders
- [ ] No console errors

---

## 📜 Legal & Compliance

### Required Documentation
- [ ] Privacy Policy written and hosted
- [ ] Terms of Service written and hosted
- [ ] GDPR compliance documented
- [ ] Data processing agreements
- [ ] Cookie policy (if applicable)

### Government Requirements
- [ ] DMP partnership agreement signed
- [ ] BRTA collaboration documented
- [ ] Logo usage permissions obtained
- [ ] Official endorsement letters
- [ ] Legal review completed

### User Agreements
- [ ] Terms accepted during signup
- [ ] Privacy policy accessible
- [ ] Contact information provided
- [ ] Support email active
- [ ] Complaint process documented

---

## 🏪 Store Submission Readiness

### Google Play Store

#### Required Assets
- [ ] App icon (512x512 PNG)
- [ ] Feature graphic (1024x500 PNG)
- [ ] Phone screenshots (minimum 4)
  - [ ] Login screen
  - [ ] Dashboard
  - [ ] Report screen
  - [ ] Case tracking
- [ ] 7-inch tablet screenshots (minimum 1)
- [ ] 10-inch tablet screenshots (minimum 1)

#### Store Listing
- [ ] App name (max 50 characters)
- [ ] Short description (max 80 characters)
- [ ] Full description (max 4000 characters)
- [ ] App category selected
- [ ] Content rating completed
- [ ] Privacy policy URL provided
- [ ] Support email provided
- [ ] Website URL provided

#### Release Details
- [ ] App bundle uploaded (.aab)
- [ ] Version code set
- [ ] Version name set
- [ ] Release notes written
- [ ] Target API level correct (34+)

#### Compliance
- [ ] Data safety form completed
- [ ] App content declarations
- [ ] Target audience set
- [ ] Content ratings obtained
- [ ] Government app declaration

### Apple App Store

#### Required Assets
- [ ] App icon (1024x1024 PNG)
- [ ] iPhone 6.5" screenshots (minimum 1)
- [ ] iPhone 5.5" screenshots (minimum 1)
- [ ] iPad Pro 12.9" screenshots (minimum 1)

#### App Information
- [ ] App name
- [ ] Subtitle
- [ ] Description
- [ ] Keywords
- [ ] Support URL
- [ ] Marketing URL
- [ ] Privacy policy URL

#### Build Details
- [ ] Archive uploaded
- [ ] Version number
- [ ] Build number
- [ ] Release notes
- [ ] Copyright information

#### Review Information
- [ ] Demo account credentials
- [ ] Notes for reviewer
- [ ] Contact information
- [ ] Government documentation

---

## 🎯 Final Verification

### Pre-Submission Checklist

#### Code Quality
- [ ] All tests passing
- [ ] No console errors
- [ ] No compiler warnings
- [ ] Code reviewed
- [ ] Documentation complete

#### Functionality
- [ ] All features working
- [ ] No critical bugs
- [ ] Performance acceptable
- [ ] User flows tested
- [ ] Edge cases handled

#### Content
- [ ] All text proofread
- [ ] Translations verified
- [ ] Images optimized
- [ ] Videos compressed
- [ ] Links working

#### Legal
- [ ] Privacy policy approved
- [ ] Terms reviewed
- [ ] Compliance verified
- [ ] Permissions obtained
- [ ] Contracts signed

#### Store Assets
- [ ] All images uploaded
- [ ] Descriptions written
- [ ] Screenshots captured
- [ ] Videos created
- [ ] Metadata complete

---

## 🚀 Submission Day Checklist

### 24 Hours Before
- [ ] Final testing on real devices
- [ ] Review all store listings
- [ ] Verify all links work
- [ ] Check demo accounts
- [ ] Prepare support team
- [ ] Monitor server capacity

### Submission Day
- [ ] Upload builds
- [ ] Fill out all forms
- [ ] Submit for review
- [ ] Notify stakeholders
- [ ] Monitor review status
- [ ] Prepare for questions

### Post-Submission
- [ ] Monitor crash reports
- [ ] Watch user reviews
- [ ] Respond to feedback
- [ ] Track install metrics
- [ ] Plan first update

---

## 📞 Support Contacts

### Technical Issues
- **Development Team:** dev@thirdeye.gov.bd
- **DevOps:** devops@thirdeye.gov.bd

### Store Submission
- **Play Console:** android@thirdeye.gov.bd
- **App Store Connect:** ios@thirdeye.gov.bd

### Business
- **Project Manager:** pm@thirdeye.gov.bd
- **Legal:** legal@thirdeye.gov.bd

---

**Last Updated:** November 12, 2024
**Next Review:** Before each major release
