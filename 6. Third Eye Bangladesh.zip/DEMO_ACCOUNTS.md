# Third Eye Bangladesh - Demo Accounts

This document contains demo account credentials for testing the application in development mode.

## 🔐 Demo Accounts

### Citizen Account
Use this account to test citizen features like reporting violations and tracking cases.

**Login Credentials:**
- **Phone/Email:** `01712345678` or `demo@thirdeye.gov.bd`
- **Password:** `demo123`

**Account Features:**
- ✅ Fully verified account
- ✅ KYC completed (NID: 1234567890)
- ✅ Biometric verification done
- ✅ Wallet setup (bKash: 01712345678)
- 📊 5 total reports submitted
- ✅ 3 approved reports
- 💰 ৳1,800 total rewards earned
- ⏳ ৳400 pending rewards

**Sample Reports:**
1. **Pending Report** (2 hours ago)
   - Case: TE-2024-1105-001
   - Type: Red Light Jumping
   - Vehicle: Motorbike
   - Location: Dhanmondi 27
   - Expected Reward: ৳1,000

2. **Under Review** (1 day ago)
   - Case: TE-2024-1104-015
   - Type: Wrong Side Driving
   - Vehicle: Car
   - Location: Gulshan 2
   - Expected Reward: ৳600

3. **Approved** (2 days ago)
   - Case: TE-2024-1103-008
   - Type: No Helmet
   - Vehicle: Motorbike
   - Location: Uttara Sector 7
   - Reward Paid: ৳200

4. **Rejected** (3 days ago)
   - Case: TE-2024-1102-022
   - Type: Illegal Parking
   - Vehicle: Car
   - Location: Wari

---

### Officer Account
Use this account to test DMP officer features like reviewing and approving reports.

**Login Credentials:**
- **Phone/Email:** `01812345678` or `officer@dmp.gov.bd`
- **Password:** `demo123`

**Account Details:**
- 👮 Inspector Rahman
- 🔖 Badge: DMP-2024-157
- 🏢 Department: Traffic Division
- ✅ Fully verified officer account

**Dashboard Features:**
- View all pending reports
- Filter by priority (high/medium/low)
- Quick approve/reject actions
- View detailed evidence
- Add officer comments
- Track reviewed reports

---

## 🚀 How to Use Demo Accounts

### For Web Application

1. **Login Page:**
   - Navigate to `/login`
   - Toggle between "Citizen Login" and "Officer Login"
   - Enter the credentials above
   - Click "Login"

2. **Test Citizen Features:**
   - View dashboard with statistics
   - See recent reports in various states
   - Report new traffic violations
   - Report social crimes (anonymous)
   - Track case status by case number
   - View expected rewards

3. **Test Officer Features:**
   - Access officer dashboard
   - Review pending cases
   - Filter by priority
   - Approve/reject reports with comments
   - View evidence photos/videos
   - Track daily statistics

### For Flutter Mobile App

1. **Login Screen:**
   - Open the app
   - Select "Login" instead of "Sign Up"
   - Choose "Citizen" or "Officer"
   - Enter phone number: `01712345678` or `01812345678`
   - Enter password: `demo123`
   - Tap "Login"

2. **Features to Test:**
   - Dashboard with quick actions
   - Report traffic violations with camera
   - View case tracking with timeline
   - Check reward balance
   - Emergency contacts
   - Language toggle (English/Bangla)

---

## 📊 Sample Data Overview

### Reports Status Distribution
- **Pending:** 3 reports (awaiting officer review)
- **Under Review:** 2 reports (being investigated)
- **Approved:** 1 report (reward approved)
- **Rejected:** 1 report (invalid/insufficient evidence)

### Violation Types Covered
- Red Light Jumping
- Wrong Side Driving
- No Helmet
- Illegal Parking
- Speeding
- Using Mobile Phone
- Social Crime (Theft)

### Evidence Attachments
- Images (1-3 per report)
- Videos (1 per selected reports)
- All properly linked in database

---

## 🧪 Testing Checklist

### Citizen Features
- [ ] Login with phone number
- [ ] Login with email
- [ ] View dashboard statistics
- [ ] Submit traffic violation report
- [ ] Submit anonymous social crime report
- [ ] Upload evidence (photos/videos)
- [ ] Track case by case number
- [ ] View report timeline
- [ ] Check pending rewards
- [ ] View approved reports
- [ ] Change language to Bangla

### Officer Features
- [ ] Login to officer portal
- [ ] View dashboard statistics
- [ ] See all pending reports
- [ ] Filter by priority
- [ ] Review report details
- [ ] View evidence attachments
- [ ] Approve a report
- [ ] Reject a report
- [ ] Add officer comments
- [ ] Track daily review count

### Integration Tests
- [ ] Report submission → Database
- [ ] Officer review → Status update
- [ ] Approval → Reward calculation
- [ ] Case tracking → Timeline display
- [ ] Evidence upload → Attachment links
- [ ] User stats update after approval

---

## 🔧 Development Mode Notes

**Password Hashing:**
The demo accounts use SHA-256 hashing. The password "demo123" hashes to:
```
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

**Session Management:**
Sessions are handled via base64-encoded tokens containing:
- User ID (uid)
- User type (citizen/officer)
- Timestamp

**API Testing:**
All API endpoints can be tested using the demo accounts. Include the session token in the Authorization header:
```
Authorization: Bearer <session_token>
```

---

## 📝 Important Notes

1. **Demo Data:** This data is for testing only and should be cleared before production deployment.

2. **Password Security:** In production, use proper password hashing with salt (bcrypt, argon2, etc.) instead of simple SHA-256.

3. **OTP in Dev Mode:** When testing OTP flows, the OTP code is logged to console for easy testing.

4. **Evidence URLs:** Sample evidence URLs are placeholders. In testing, upload real images to see full functionality.

5. **Geolocation:** Use actual device location or manually enter coordinates for realistic testing.

---

## 🆘 Support

If you encounter issues with demo accounts:
1. Check that the database migration ran successfully
2. Verify the session token is being sent correctly
3. Check browser console for detailed error messages
4. Review API logs for backend issues

---

## 🔄 Reset Demo Data

To reset demo data to initial state, run the down migration and then the up migration again:
```sql
-- This will delete all demo data and recreate it fresh
```

Happy Testing! 🎉
