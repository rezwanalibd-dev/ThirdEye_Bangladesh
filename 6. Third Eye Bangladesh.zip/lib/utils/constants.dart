class AppConstants {
  // App Information
  static const String appName = 'Third Eye Bangladesh';
  static const String appTagline = 'Report Traffic Violations • Earn Rewards • Save Lives';
  static const String appVersion = '1.0.0';

  // Colors (hex values for reference)
  static const String primaryColorHex = '#006A4E';
  static const String secondaryColorHex = '#F42A41';
  static const String accentColorHex = '#FFD700';

  // API Endpoints
  static const String baseUrl = 'https://api.thirdeye.gov.bd';
  static const String authEndpoint = '/auth';
  static const String reportsEndpoint = '/reports';
  static const String verificationsEndpoint = '/verifications';

  // Storage Paths
  static const String documentsPath = 'documents/';
  static const String evidencePath = 'evidence/';
  static const String profilesPath = 'profiles/';

  // Vehicle Types
  static const List<String> vehicleTypes = [
    'Motorbike',
    'Car',
    'Bus',
    'Truck',
    'CNG',
    'E-rickshaw',
  ];

  // Universal Violation Types
  static const List<String> universalViolations = [
    'Red Light Jumping',
    'Wrong Side Driving',
    'Speeding',
    'Using Mobile Phone',
    'Illegal Parking',
    'No License',
  ];

  // Vehicle-Specific Violations
  static const Map<String, List<String>> vehicleSpecificViolations = {
    'Motorbike': ['Driving on a Footpath', 'No Helmet'],
    'CNG': ['Driving on a Footpath', 'Overloading'],
    'E-rickshaw': ['Driving on a Footpath', 'Overloading'],
    'Bus': ['Overloading', 'Wrong Lane'],
    'Truck': ['Overloading', 'Wrong Lane'],
  };

  // Social Crime Types
  static const List<String> socialCrimeTypes = [
    'Theft',
    'Fight',
    'Youth Gang',
    'Corruption',
    'Bribery',
    'Robbery',
    'Social Violence',
    'Rape',
    'Murder',
    'Drug Abuse',
    'Sexual Harassment',
    'Extortion',
  ];

  // Payment Methods (Mobile Wallets)
  static const List<String> paymentMethods = [
    'bKash',
    'Nagad',
    'Rocket',
    'Upay',
    'mCash',
    'CellFin',
    'SureCash',
    'TrustMoney',
  ];

  // Emergency Contacts
  static const Map<String, String> emergencyContacts = {
    'National Emergency': '999',
    'Fire Service': '998',
    'Police': '999',
    'Ambulance': '999',
    'DMP Control Room': '01199936311',
    'RAB Control Room': '01777798911',
  };

  // Fine Amounts (in BDT)
  static const Map<String, Map<String, double>> violationFines = {
    'Motorbike': {
      'Red Light Jumping': 5000,
      'Wrong Side Driving': 3000,
      'Speeding': 5000,
      'Using Mobile Phone': 2000,
      'Illegal Parking': 2000,
      'No License': 5000,
      'Driving on a Footpath': 3000,
      'No Helmet': 1000,
    },
    'Car': {
      'Red Light Jumping': 5000,
      'Wrong Side Driving': 3000,
      'Speeding': 5000,
      'Using Mobile Phone': 2000,
      'Illegal Parking': 4000,
      'No License': 25000,
      'No Seatbelt': 1000,
    },
    'Bus': {
      'Red Light Jumping': 10000,
      'Wrong Side Driving': 5000,
      'Speeding': 10000,
      'Using Mobile Phone': 5000,
      'Illegal Parking': 5000,
      'No License': 50000,
      'Overloading': 10000,
      'Wrong Lane': 5000,
    },
    'Truck': {
      'Red Light Jumping': 10000,
      'Wrong Side Driving': 5000,
      'Speeding': 10000,
      'Using Mobile Phone': 5000,
      'Illegal Parking': 5000,
      'No License': 50000,
      'Overloading': 20000,
      'Wrong Lane': 5000,
    },
    'CNG': {
      'Red Light Jumping': 3000,
      'Wrong Side Driving': 2000,
      'Speeding': 3000,
      'Using Mobile Phone': 1000,
      'Illegal Parking': 2000,
      'No License': 10000,
      'Driving on a Footpath': 2000,
      'Overloading': 1000,
    },
    'E-rickshaw': {
      'Red Light Jumping': 2000,
      'Wrong Side Driving': 1500,
      'Speeding': 2000,
      'Using Mobile Phone': 1000,
      'Illegal Parking': 1000,
      'No License': 5000,
      'Driving on a Footpath': 1500,
      'Overloading': 500,
    },
  };

  // Commission Rates
  static const double defaultCommissionRate = 0.20; // 20%
  static const Map<String, double> commissionRates = {
    'traffic': 0.20,
    'social_crime': 0.15,
  };

  // Verification Thresholds
  static const double faceMatchThreshold = 0.62;
  static const int maxRetryAttempts = 3;
  static const int otpValidityMinutes = 2;

  // File Upload Limits
  static const int maxImageSize = 5 * 1024 * 1024; // 5MB
  static const int maxVideoSize = 50 * 1024 * 1024; // 50MB
  static const List<String> allowedImageFormats = ['jpg', 'jpeg', 'png'];
  static const List<String> allowedVideoFormats = ['mp4', 'mov', 'avi'];

  // Case Number Format
  static const String caseNumberPrefix = 'TE';
  static const String caseNumberFormat = 'TE-YYYY-MM-DD-XXXXX';

  // Status Types
  static const List<String> reportStatuses = [
    'pending',
    'under_review',
    'verified',
    'approved',
    'rejected',
    'fine_collected',
    'reward_paid',
  ];

  // User Types
  static const List<String> userTypes = [
    'citizen',
    'dmp_officer',
    'brta_officer',
    'admin',
  ];

  // Validation Rules
  static const int minPasswordLength = 8;
  static const int maxNameLength = 50;
  static const int minNameLength = 2;
  static const String phoneNumberPattern = r'^01[3-9]\d{8}$';
  static const String emailPattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
  static const String nidPattern = r'^\d{10}|\d{13}|\d{17}$';

  // App Store Links
  static const String playStoreUrl = 'https://play.google.com/store/apps/details?id=bd.gov.thirdeye';
  static const String appStoreUrl = 'https://apps.apple.com/app/third-eye-bangladesh/id1234567890';

  // Support & Legal
  static const String supportEmail = 'support@thirdeye.gov.bd';
  static const String privacyPolicyUrl = 'https://thirdeye.gov.bd/privacy';
  static const String termsOfServiceUrl = 'https://thirdeye.gov.bd/terms';
  static const String helpCenterUrl = 'https://help.thirdeye.gov.bd';

  // Social Media
  static const String facebookUrl = 'https://facebook.com/ThirdEyeBangladesh';
  static const String twitterUrl = 'https://twitter.com/ThirdEyeBD';

  // Animation Durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration standardAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);

  // Timeouts
  static const Duration apiTimeout = Duration(seconds: 30);
  static const Duration uploadTimeout = Duration(minutes: 5);

  // Utility Methods
  static List<String> getViolationsForVehicle(String vehicleType) {
    List<String> violations = List.from(universalViolations);
    if (vehicleSpecificViolations.containsKey(vehicleType)) {
      violations.addAll(vehicleSpecificViolations[vehicleType]!);
    }
    return violations;
  }

  static double getFineAmount(String vehicleType, String violation) {
    return violationFines[vehicleType]?[violation] ?? 1000.0;
  }

  static double calculateReward(double fineAmount, String reportType) {
    double commissionRate = commissionRates[reportType] ?? defaultCommissionRate;
    return fineAmount * commissionRate;
  }

  static String generateCaseNumber() {
    final now = DateTime.now();
    final timestamp = now.millisecondsSinceEpoch.toString().substring(8);
    return '$caseNumberPrefix-${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}-$timestamp';
  }

  static bool isValidPhoneNumber(String phone) {
    return RegExp(phoneNumberPattern).hasMatch(phone);
  }

  static bool isValidEmail(String email) {
    return RegExp(emailPattern).hasMatch(email);
  }

  static bool isValidNID(String nid) {
    return RegExp(nidPattern).hasMatch(nid);
  }

  // Motivational Messages
  static const Map<String, List<String>> motivationalMessages = {
    'en': [
      'Ready to Make a Difference?\nEvery report you make helps save lives. When you witness a traffic violation, you have the power to prevent accidents and protect your community.\n\nYour voice matters. Together, we can build a safer, more liveable city where roads are respected and lives are valued.',
      'Stand Against Social Crimes\nYour courage can save lives. In our society, silence enables injustice. When you witness violence, murder, theft, fighting, corruption, extortion, robbery, drug abuse, sexual harassment, or youth gang activities—your voice becomes the shield that protects the vulnerable.',
    ],
    'bn': [
      'প্রস্তুত কি ইতিবাচক পরিবর্তনের অংশ হতে?\nআপনার একটি রিপোর্টই অনেকগুলো জীবন বাঁচাতে পারে। ট্রাফিক আইন লঙ্ঘন দেখামাত্রই আপনার রিপোর্ট হতে পারে দুর্ঘটনা প্রতিরোধের প্রথম ধাপ, আপনার সচেতনতাই হয়ে উঠতে পারে সম্প্রদায়ের নিরাপত্তার রক্ষাকবচ।\n\nআপনার ভূমিকা অপরিসীম। আসুন আমরা হাতে হাত মিলিয়ে গড়ে তুলি একটি নিরাপদ, বাসযোগ্য নগরী – যেখানে রাস্তা-ঘাট হবে শৃঙ্খলিত, প্রতিটি জীবন হবে মূল্যবান।',
      'সামাজিক অপরাধের বিরুদ্ধে রুখে দাঁড়ান\nআপনার একটু সাহসই অনেকগুলো জীবন বাঁচাতে পারে। আমাদের সমাজে নীরবতাই অপরাধকে দেয় বাড়তি প্রেরণা। যখনই আপনি প্রত্যক্ষ করেন সহিংসতা, হত্যা, চুরি, মারামারি, দুর্নীতি, চাঁদাবাজি, ডাকাতি, মাদক গ্রহণ, যৌন হয়রানি বা কিশোর গ্যাংয়ের উৎপাত – তখনই আপনার কণ্ঠস্বরই হয়ে উঠতে পারে নির্যাতিত মানুষের প্রধান আশ্রয়।',
    ],
  };

  // Trust Platform Text
  static const Map<String, String> trustPlatformText = {
    'en': 'Trusted & Verified Platform\nOfficial collaboration with Bangladesh government agencies\nDMP Verified\nOfficial police partnership\nSecure Platform\nEnd-to-end encryption\nCommunity Driven\nCitizen empowerment',
    'bn': 'বিশ্বস্ত প্ল্যাটফর্ম\nসরকারি সংস্থার সহযোগিতায়\nডিএমপি অনুমোদিত\nপ্রাতিষ্ঠানিক পুলিশ অংশীদারিত্ব\nসুরক্ষিত সিস্টেম\nপূর্ণাঙ্গ এনক্রিপশন\nনাগরিক পরিচালিত\nসাধারণ মানুষের ক্ষমতায়ন',
  };
}

// Enums for better type safety
enum ReportStatus {
  pending,
  underReview,
  verified,
  approved,
  rejected,
  fineCollected,
  rewardPaid,
}

enum UserType {
  citizen,
  dmpOfficer,
  brtaOfficer,
  admin,
}

enum ReportType {
  traffic,
  socialCrime,
}

enum PaymentStatus {
  pending,
  processing,
  completed,
  failed,
  cancelled,
}

enum VerificationStatus {
  pending,
  inProgress,
  passed,
  failed,
  expired,
}
