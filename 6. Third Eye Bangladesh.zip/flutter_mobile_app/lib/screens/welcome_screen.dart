import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../utils/app_localizations.dart';
import '../widgets/language_toggle.dart';
import '../widgets/feature_card.dart';
import '../widgets/motivational_carousel.dart';
import 'login_screen.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              // Language Toggle
              Align(
                alignment: Alignment.topRight,
                child: LanguageToggle(),
              ),
              
              SizedBox(height: 20),
              
              // App Logo and Title
              _buildHeader(localizations),
              
              SizedBox(height: 30),
              
              // Motivational Carousel
              MotivationalCarousel(),
              
              SizedBox(height: 30),
              
              // Key Features
              _buildFeatures(localizations),
              
              SizedBox(height: 30),
              
              // Trust Badge
              _buildTrustBadge(localizations),
              
              SizedBox(height: 30),
              
              // Action Buttons
              _buildActionButtons(context, localizations),
              
              SizedBox(height: 20),
              
              // Government Partnership
              _buildGovernmentPartnership(languageProvider.isEnglish),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(AppLocalizations localizations) {
    return Column(
      children: [
        // App Icon
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF006A4E), Color(0xFF008B5A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Color(0xFF006A4E).withOpacity(0.3),
                blurRadius: 15,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Icon(
            Icons.remove_red_eye,
            size: 50,
            color: Colors.white,
          ),
        ),
        
        SizedBox(height: 20),
        
        // App Name
        Text(
          localizations.appName,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Color(0xFF006A4E),
          ),
          textAlign: TextAlign.center,
        ),
        
        SizedBox(height: 8),
        
        // Tagline
        Text(
          localizations.tagline,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
            height: 1.4,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildFeatures(AppLocalizations localizations) {
    final features = [
      {
        'icon': Icons.report_problem,
        'title': localizations.reportTraffic,
        'description': 'Capture evidence and report violations safely',
      },
      {
        'icon': Icons.monetization_on,
        'title': localizations.earnRewards,
        'description': 'Get commission from collected fines',
      },
      {
        'icon': Icons.health_and_safety,
        'title': localizations.saveLives,
        'description': 'Help make Bangladesh roads safer',
      },
    ];

    return Column(
      children: features.map((feature) => 
        Padding(
          padding: EdgeInsets.only(bottom: 12),
          child: FeatureCard(
            icon: feature['icon'] as IconData,
            title: feature['title'] as String,
            description: feature['description'] as String,
          ),
        ),
      ).toList(),
    );
  }

  Widget _buildTrustBadge(AppLocalizations localizations) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.verified,
                color: Color(0xFF006A4E),
                size: 20,
              ),
              SizedBox(width: 8),
              Text(
                localizations.trustedBy,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF006A4E),
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('DMP Verified', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
              Text(' • ', style: TextStyle(color: Colors.grey[600])),
              Text('Secure Platform', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
              Text(' • ', style: TextStyle(color: Colors.grey[600])),
              Text('End-to-End Encryption', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, AppLocalizations localizations) {
    return Column(
      children: [
        // Get Started Button
        Container(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: () => _navigateToLogin(context),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  localizations.getStarted,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(width: 8),
                Icon(Icons.arrow_forward, size: 20),
              ],
            ),
          ),
        ),
        
        SizedBox(height: 12),
        
        // Officer Portal Button
        Container(
          width: double.infinity,
          height: 48,
          child: OutlinedButton(
            onPressed: () => _navigateToOfficerPortal(context),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.badge, size: 18),
                SizedBox(width: 8),
                Text(
                  localizations.officerPortal,
                  style: TextStyle(fontSize: 14),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGovernmentPartnership(bool isEnglish) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Column(
        children: [
          Text(
            isEnglish ? 'Official Partnership With' : 'সরকারি অংশীদারিত্বে',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[500],
            ),
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildPartnerLogo('DMP', Colors.blue),
              SizedBox(width: 40),
              _buildPartnerLogo('BRTA', Colors.red),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPartnerLogo(String name, Color color) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            Icons.shield,
            color: color,
            size: 28,
          ),
        ),
        SizedBox(height: 8),
        Text(
          name,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  void _navigateToLogin(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  void _navigateToOfficerPortal(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => LoginScreen(isOfficer: true)),
    );
  }
}
