import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../utils/app_localizations.dart';
import 'kyc_verification_screen.dart';
import 'dashboard_screen.dart';

class OTPVerificationScreen extends StatefulWidget {
  final String phoneNumber;
  final String? fullName;
  final String? email;
  final String? userType;
  final bool isLogin;

  const OTPVerificationScreen({
    Key? key,
    required this.phoneNumber,
    this.fullName,
    this.email,
    this.userType,
    required this.isLogin,
  }) : super(key: key);

  @override
  _OTPVerificationScreenState createState() => _OTPVerificationScreenState();
}

class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  final List<TextEditingController> _otpControllers = List.generate(6, (index) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (index) => FocusNode());
  
  int _countdown = 120; // 2 minutes
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _startCountdown();
    _setupOTPListeners();
  }

  void _startCountdown() {
    Future.delayed(Duration(seconds: 1), () {
      if (mounted && _countdown > 0) {
        setState(() {
          _countdown--;
        });
        _startCountdown();
      } else if (mounted) {
        setState(() {
          _canResend = true;
        });
      }
    });
  }

  void _setupOTPListeners() {
    for (int i = 0; i < _otpControllers.length; i++) {
      _otpControllers[i].addListener(() {
        if (_otpControllers[i].text.length == 1 && i < _otpControllers.length - 1) {
          _focusNodes[i + 1].requestFocus();
        }
        
        // Auto verify when last digit is entered
        if (i == _otpControllers.length - 1 && _otpControllers[i].text.length == 1) {
          _verifyOTP();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Header
              Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(Icons.arrow_back),
                  ),
                ],
              ),
              
              SizedBox(height: 40),
              
              // Header Section
              _buildHeader(localizations),
              
              SizedBox(height: 40),
              
              // Phone Number Display
              _buildPhoneDisplay(),
              
              SizedBox(height: 40),
              
              // OTP Input Fields
              _buildOTPFields(),
              
              SizedBox(height: 30),
              
              // Countdown Timer
              _buildCountdownTimer(),
              
              SizedBox(height: 20),
              
              // Resend Button
              _buildResendButton(authProvider),
              
              SizedBox(height: 40),
              
              // Verify Button
              _buildVerifyButton(context, authProvider, localizations),
              
              // Error Message
              if (authProvider.errorMessage != null)
                Container(
                  margin: EdgeInsets.only(top: 16),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red[200]!),
                  ),
                  child: Text(
                    authProvider.errorMessage!,
                    style: TextStyle(color: Colors.red[700]),
                    textAlign: TextAlign.center,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(AppLocalizations localizations) {
    return Column(
      children: [
        // Icon
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF006A4E), Color(0xFF008B5A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(
            Icons.verified_user,
            size: 40,
            color: Colors.white,
          ),
        ),
        
        SizedBox(height: 20),
        
        // Title
        Text(
          localizations.otpVerification,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        
        SizedBox(height: 8),
        
        // Subtitle
        Text(
          'Step ${widget.isLogin ? '1' : '2'} of ${widget.userType == 'citizen' ? '4' : '2'}',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildPhoneDisplay() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            'We sent a verification code to',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 4),
          Text(
            '+88 ${widget.phoneNumber}',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF006A4E),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOTPFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: List.generate(6, (index) {
        return Container(
          width: 50,
          height: 60,
          child: TextFormField(
            controller: _otpControllers[index],
            focusNode: _focusNodes[index],
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            maxLength: 1,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
            decoration: InputDecoration(
              counterText: '',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Color(0xFF006A4E), width: 2),
              ),
            ),
            onChanged: (value) {
              if (value.length == 1 && index < 5) {
                _focusNodes[index + 1].requestFocus();
              } else if (value.isEmpty && index > 0) {
                _focusNodes[index - 1].requestFocus();
              }
            },
          ),
        );
      }),
    );
  }

  Widget _buildCountdownTimer() {
    String minutes = (_countdown ~/ 60).toString().padLeft(2, '0');
    String seconds = (_countdown % 60).toString().padLeft(2, '0');
    
    return Text(
      _canResend ? 'You can resend the code now' : 'Resend code in $minutes:$seconds',
      style: TextStyle(
        fontSize: 14,
        color: _canResend ? Color(0xFF006A4E) : Colors.grey[600],
        fontWeight: _canResend ? FontWeight.w600 : FontWeight.normal,
      ),
    );
  }

  Widget _buildResendButton(AuthProvider authProvider) {
    return TextButton(
      onPressed: _canResend && !authProvider.isLoading ? _resendOTP : null,
      child: authProvider.isLoading
        ? SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: Color(0xFF006A4E),
            ),
          )
        : Text(
            'Resend OTP',
            style: TextStyle(
              color: _canResend ? Color(0xFF006A4E) : Colors.grey,
              fontWeight: FontWeight.w600,
            ),
          ),
    );
  }

  Widget _buildVerifyButton(BuildContext context, AuthProvider authProvider, AppLocalizations localizations) {
    return Container(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: authProvider.isLoading ? null : _verifyOTP,
        child: authProvider.isLoading
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : Text(
              localizations.verify,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
      ),
    );
  }

  Future<void> _verifyOTP() async {
    String otp = _otpControllers.map((controller) => controller.text).join();
    
    if (otp.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter the complete 6-digit code'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    bool success = await authProvider.verifyOTP(otp);
    
    if (success) {
      // Navigate based on user type and whether it's login or signup
      if (widget.isLogin) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => DashboardScreen()),
        );
      } else {
        // For signup, go to next step based on user type
        if (widget.userType == 'citizen') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => KYCVerificationScreen()),
          );
        } else {
          // Officers go directly to dashboard
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DashboardScreen()),
          );
        }
      }
    }
  }

  Future<void> _resendOTP() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.sendOTP(widget.phoneNumber);
    
    if (authProvider.errorMessage == null) {
      setState(() {
        _countdown = 120;
        _canResend = false;
      });
      _startCountdown();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('OTP resent successfully'),
          backgroundColor: Color(0xFF006A4E),
        ),
      );
    }
  }

  @override
  void dispose() {
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }
}
