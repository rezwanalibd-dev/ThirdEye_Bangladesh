import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:io';
import '../utils/app_localizations.dart';
import 'dashboard_screen.dart';

class BiometricVerificationScreen extends StatefulWidget {
  @override
  _BiometricVerificationScreenState createState() => _BiometricVerificationScreenState();
}

class _BiometricVerificationScreenState extends State<BiometricVerificationScreen> {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  bool _isCameraInitialized = false;
  
  List<File?> _selfieImages = [null, null, null]; // Front, Left, Right
  int _currentSelfieIndex = 0;
  bool _isCapturing = false;

  final List<String> _selfieLabels = ['Front Face', 'Left Side', 'Right Side'];
  final List<String> _selfieInstructions = [
    'Look straight at the camera',
    'Turn your head to the left',
    'Turn your head to the right'
  ];

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras != null && _cameras!.isNotEmpty) {
        // Use front camera for selfies
        final frontCamera = _cameras!.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
          orElse: () => _cameras!.first,
        );
        
        _controller = CameraController(
          frontCamera,
          ResolutionPreset.medium,
        );
        
        await _controller!.initialize();
        setState(() {
          _isCameraInitialized = true;
        });
      }
    } catch (e) {
      print('Error initializing camera: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              color: Colors.white,
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: Icon(Icons.arrow_back),
                      ),
                    ],
                  ),
                  _buildHeader(localizations),
                ],
              ),
            ),
            
            // Camera Preview
            Expanded(
              child: _isCameraInitialized
                  ? _buildCameraPreview()
                  : _buildCameraLoading(),
            ),
            
            // Controls
            Container(
              color: Colors.white,
              padding: EdgeInsets.all(20),
              child: _buildControls(context, localizations),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(AppLocalizations localizations) {
    return Column(
      children: [
        // Progress Indicator
        Row(
          children: List.generate(3, (index) {
            bool isCompleted = _selfieImages[index] != null;
            bool isCurrent = index == _currentSelfieIndex;
            
            return Expanded(
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 4),
                height: 4,
                decoration: BoxDecoration(
                  color: isCompleted 
                      ? Colors.green 
                      : isCurrent 
                          ? Color(0xFF006A4E)
                          : Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            );
          }),
        ),
        
        SizedBox(height: 20),
        
        // Title
        Text(
          'Biometric Verification',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        
        SizedBox(height: 8),
        
        // Subtitle
        Text(
          'Step 4 of 4 - Take 3 Selfie Photos',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
        
        SizedBox(height: 16),
        
        // Current Instruction
        Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Color(0xFF006A4E).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Text(
                _selfieLabels[_currentSelfieIndex],
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF006A4E),
                ),
              ),
              SizedBox(height: 4),
              Text(
                _selfieInstructions[_currentSelfieIndex],
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[700],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCameraPreview() {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Camera Preview
        CameraPreview(_controller!),
        
        // Face Guide Overlay
        Center(
          child: Container(
            width: 250,
            height: 350,
            decoration: BoxDecoration(
              border: Border.all(
                color: Colors.white.withOpacity(0.8),
                width: 2,
              ),
              borderRadius: BorderRadius.circular(125),
            ),
          ),
        ),
        
        // Captured Images Preview
        Positioned(
          top: 20,
          right: 20,
          child: Column(
            children: List.generate(3, (index) {
              return Container(
                margin: EdgeInsets.only(bottom: 8),
                width: 60,
                height: 80,
                decoration: BoxDecoration(
                  color: _selfieImages[index] != null 
                      ? Colors.transparent 
                      : Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: index == _currentSelfieIndex 
                        ? Colors.white 
                        : Colors.grey,
                    width: 2,
                  ),
                ),
                child: _selfieImages[index] != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(
                          _selfieImages[index]!,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Center(
                        child: Icon(
                          index == 0 ? Icons.face : 
                          index == 1 ? Icons.face_retouching_natural : 
                          Icons.face,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
              );
            }),
          ),
        ),
      ],
    );
  }

  Widget _buildCameraLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: Color(0xFF006A4E),
          ),
          SizedBox(height: 16),
          Text(
            'Initializing camera...',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls(BuildContext context, AppLocalizations localizations) {
    return Column(
      children: [
        // Selfie Status
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(3, (index) {
            bool isCompleted = _selfieImages[index] != null;
            bool isCurrent = index == _currentSelfieIndex;
            
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isCompleted 
                    ? Colors.green 
                    : isCurrent 
                        ? Color(0xFF006A4E)
                        : Colors.grey[300],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    isCompleted ? Icons.check : Icons.camera_alt,
                    color: Colors.white,
                    size: 16,
                  ),
                  SizedBox(width: 4),
                  Text(
                    _selfieLabels[index],
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            );
          }),
        ),
        
        SizedBox(height: 24),
        
        // Action Buttons
        Row(
          children: [
            if (_currentSelfieIndex > 0)
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _currentSelfieIndex--;
                    });
                  },
                  child: Text('Previous'),
                ),
              ),
            
            if (_currentSelfieIndex > 0) SizedBox(width: 16),
            
            Expanded(
              flex: 2,
              child: Container(
                height: 56,
                child: ElevatedButton(
                  onPressed: _isCapturing ? null : _takeSelfie,
                  child: _isCapturing
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.camera_alt, size: 20),
                            SizedBox(width: 8),
                            Text(
                              _selfieImages[_currentSelfieIndex] != null 
                                  ? 'Retake' 
                                  : 'Capture',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                ),
              ),
            ),
            
            if (_currentSelfieIndex < 2 && _selfieImages[_currentSelfieIndex] != null)
              SizedBox(width: 16),
            
            if (_currentSelfieIndex < 2 && _selfieImages[_currentSelfieIndex] != null)
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _currentSelfieIndex++;
                    });
                  },
                  child: Text('Next'),
                ),
              ),
          ],
        ),
        
        SizedBox(height: 16),
        
        // Complete Button
        if (_selfieImages.every((image) => image != null))
          Container(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () => _completeVerification(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
              child: Text(
                'Complete Verification',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Future<void> _takeSelfie() async {
    if (!_isCameraInitialized || _controller == null) return;

    setState(() {
      _isCapturing = true;
    });

    try {
      final XFile photo = await _controller!.takePicture();
      setState(() {
        _selfieImages[_currentSelfieIndex] = File(photo.path);
        _isCapturing = false;
      });

      // Auto-advance to next selfie if not the last one
      if (_currentSelfieIndex < 2) {
        Future.delayed(Duration(milliseconds: 500), () {
          setState(() {
            _currentSelfieIndex++;
          });
        });
      }
    } catch (e) {
      setState(() {
        _isCapturing = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to capture photo: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _completeVerification(BuildContext context) {
    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Biometric verification completed successfully!'),
        backgroundColor: Colors.green,
      ),
    );

    // Navigate to dashboard
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => DashboardScreen()),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }
}
