import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../utils/app_localizations.dart';
import 'biometric_verification_screen.dart';

class KYCVerificationScreen extends StatefulWidget {
  @override
  _KYCVerificationScreenState createState() => _KYCVerificationScreenState();
}

class _KYCVerificationScreenState extends State<KYCVerificationScreen> {
  final _formKey = GlobalKey<FormState>();
  final ImagePicker _picker = ImagePicker();
  
  String _selectedDocumentType = 'nid';
  final TextEditingController _nidController = TextEditingController();
  final TextEditingController _licenseController = TextEditingController();
  final TextEditingController _passportController = TextEditingController();
  
  File? _nidFrontImage;
  File? _nidBackImage;
  File? _licenseFrontImage;
  File? _licenseBackImage;
  File? _passportImage;
  
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(Icons.arrow_back),
                    ),
                  ],
                ),
                
                SizedBox(height: 20),
                
                // Header Section
                _buildHeader(localizations),
                
                SizedBox(height: 30),
                
                // Document Type Selection
                _buildDocumentTypeSelection(),
                
                SizedBox(height: 30),
                
                // Document Number Input
                _buildDocumentNumberInput(),
                
                SizedBox(height: 30),
                
                // Photo Upload Section
                _buildPhotoUploadSection(),
                
                SizedBox(height: 40),
                
                // Continue Button
                _buildContinueButton(context, localizations),
                
                SizedBox(height: 16),
                
                // Skip Option
                _buildSkipOption(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(AppLocalizations localizations) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Icon
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF006A4E), Color(0xFF008B5A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(
            Icons.assignment,
            size: 40,
            color: Colors.white,
          ),
        ),
        
        SizedBox(height: 20),
        
        // Title
        Text(
          localizations.kycVerification,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        
        SizedBox(height: 8),
        
        // Subtitle
        Text(
          'Step 3 of 4 - Document Verification',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildDocumentTypeSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Select Document Type *',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 16),
        Row(
          children: [
            _buildDocumentOption('nid', 'NID', Icons.credit_card),
            SizedBox(width: 12),
            _buildDocumentOption('license', 'License', Icons.directions_car),
            SizedBox(width: 12),
            _buildDocumentOption('passport', 'Passport', Icons.airplanemode_active),
          ],
        ),
      ],
    );
  }

  Widget _buildDocumentOption(String type, String label, IconData icon) {
    bool isSelected = _selectedDocumentType == type;
    
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedDocumentType = type;
          });
        },
        child: Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isSelected ? Color(0xFF006A4E).withOpacity(0.1) : Colors.grey[50],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? Color(0xFF006A4E) : Colors.grey[300]!,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: isSelected ? Color(0xFF006A4E) : Colors.grey[600],
                size: 24,
              ),
              SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Color(0xFF006A4E) : Colors.grey[600],
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDocumentNumberInput() {
    String label;
    String hint;
    TextEditingController controller;
    
    switch (_selectedDocumentType) {
      case 'nid':
        label = 'NID Number *';
        hint = 'Enter your NID number';
        controller = _nidController;
        break;
      case 'license':
        label = 'Driving License Number *';
        hint = 'Enter your license number';
        controller = _licenseController;
        break;
      case 'passport':
        label = 'Passport Number *';
        hint = 'Enter your passport number';
        controller = _passportController;
        break;
      default:
        label = 'Document Number *';
        hint = 'Enter document number';
        controller = _nidController;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          decoration: InputDecoration(
            hintText: hint,
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'This field is required';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildPhotoUploadSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Upload Document Photos *',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 16),
        
        if (_selectedDocumentType == 'nid') ...[
          Row(
            children: [
              Expanded(
                child: _buildUploadBox(
                  'NID Front Photo',
                  _nidFrontImage,
                  () => _pickImage('nid_front'),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: _buildUploadBox(
                  'NID Back Photo',
                  _nidBackImage,
                  () => _pickImage('nid_back'),
                ),
              ),
            ],
          ),
        ] else if (_selectedDocumentType == 'license') ...[
          Row(
            children: [
              Expanded(
                child: _buildUploadBox(
                  'License Front Photo',
                  _licenseFrontImage,
                  () => _pickImage('license_front'),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: _buildUploadBox(
                  'License Back Photo',
                  _licenseBackImage,
                  () => _pickImage('license_back'),
                ),
              ),
            ],
          ),
        ] else if (_selectedDocumentType == 'passport') ...[
          _buildUploadBox(
            'Passport Information Page',
            _passportImage,
            () => _pickImage('passport'),
          ),
        ],
      ],
    );
  }

  Widget _buildUploadBox(String label, File? image, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 120,
        decoration: BoxDecoration(
          color: image != null ? Colors.green[50] : Colors.grey[50],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: image != null ? Colors.green : Colors.grey[300]!,
            width: image != null ? 2 : 1,
          ),
        ),
        child: image != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  image,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: double.infinity,
                ),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.camera_alt,
                    size: 32,
                    color: Colors.grey[400],
                  ),
                  SizedBox(height: 8),
                  Text(
                    label,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildContinueButton(BuildContext context, AppLocalizations localizations) {
    return Container(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _isLoading ? null : () => _handleContinue(context),
        child: _isLoading
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : Text(
              localizations.continueText,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
      ),
    );
  }

  Widget _buildSkipOption(BuildContext context) {
    return Center(
      child: TextButton(
        onPressed: () => _navigateToNext(context),
        child: Text(
          'Skip for now',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(String type) async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 80,
      );

      if (image != null) {
        setState(() {
          switch (type) {
            case 'nid_front':
              _nidFrontImage = File(image.path);
              break;
            case 'nid_back':
              _nidBackImage = File(image.path);
              break;
            case 'license_front':
              _licenseFrontImage = File(image.path);
              break;
            case 'license_back':
              _licenseBackImage = File(image.path);
              break;
            case 'passport':
              _passportImage = File(image.path);
              break;
          }
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to pick image: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _handleContinue(BuildContext context) {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Validate document photos
    bool hasRequiredPhotos = false;
    
    switch (_selectedDocumentType) {
      case 'nid':
        hasRequiredPhotos = _nidFrontImage != null && _nidBackImage != null;
        break;
      case 'license':
        hasRequiredPhotos = _licenseFrontImage != null && _licenseBackImage != null;
        break;
      case 'passport':
        hasRequiredPhotos = _passportImage != null;
        break;
    }

    if (!hasRequiredPhotos) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please upload all required document photos'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simulate upload process
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        _isLoading = false;
      });
      _navigateToNext(context);
    });
  }

  void _navigateToNext(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BiometricVerificationScreen()),
    );
  }

  @override
  void dispose() {
    _nidController.dispose();
    _licenseController.dispose();
    _passportController.dispose();
    super.dispose();
  }
}
