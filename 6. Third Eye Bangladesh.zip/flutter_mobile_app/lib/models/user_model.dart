class UserModel {
  final String uid;
  final String phoneNumber;
  final String? email;
  final String fullName;
  final String userType; // 'citizen', 'dmp_officer', 'brta_officer'
  final bool isVerified;
  final DateTime createdAt;
  final DateTime? updatedAt;

  // KYC Information
  final String? nidNumber;
  final String? drivingLicense;
  final String? passportNumber;
  final List<String>? documentUrls;

  // Biometric Information
  final List<String>? selfieUrls;
  final bool isBiometricVerified;

  // Wallet Information
  final String? paymentMethod;
  final String? walletNumber;
  final bool isWalletVerified;
  
  // Statistics
  final int totalReports;
  final int approvedReports;
  final double totalRewards;
  final double pendingRewards;

  UserModel({
    required this.uid,
    required this.phoneNumber,
    this.email,
    required this.fullName,
    required this.userType,
    required this.isVerified,
    required this.createdAt,
    this.updatedAt,
    this.nidNumber,
    this.drivingLicense,
    this.passportNumber,
    this.documentUrls,
    this.selfieUrls,
    this.isBiometricVerified = false,
    this.paymentMethod,
    this.walletNumber,
    this.isWalletVerified = false,
    this.totalReports = 0,
    this.approvedReports = 0,
    this.totalRewards = 0.0,
    this.pendingRewards = 0.0,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '',
      email: map['email'],
      fullName: map['fullName'] ?? '',
      userType: map['userType'] ?? 'citizen',
      isVerified: map['isVerified'] ?? false,
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.tryParse(map['updatedAt']) : null,
      nidNumber: map['nidNumber'],
      drivingLicense: map['drivingLicense'],
      passportNumber: map['passportNumber'],
      documentUrls: List<String>.from(map['documentUrls'] ?? []),
      selfieUrls: List<String>.from(map['selfieUrls'] ?? []),
      isBiometricVerified: map['isBiometricVerified'] ?? false,
      paymentMethod: map['paymentMethod'],
      walletNumber: map['walletNumber'],
      isWalletVerified: map['isWalletVerified'] ?? false,
      totalReports: map['totalReports'] ?? 0,
      approvedReports: map['approvedReports'] ?? 0,
      totalRewards: (map['totalRewards'] ?? 0).toDouble(),
      pendingRewards: (map['pendingRewards'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'phoneNumber': phoneNumber,
      'email': email,
      'fullName': fullName,
      'userType': userType,
      'isVerified': isVerified,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'nidNumber': nidNumber,
      'drivingLicense': drivingLicense,
      'passportNumber': passportNumber,
      'documentUrls': documentUrls,
      'selfieUrls': selfieUrls,
      'isBiometricVerified': isBiometricVerified,
      'paymentMethod': paymentMethod,
      'walletNumber': walletNumber,
      'isWalletVerified': isWalletVerified,
      'totalReports': totalReports,
      'approvedReports': approvedReports,
      'totalRewards': totalRewards,
      'pendingRewards': pendingRewards,
    };
  }

  // Check if user can submit reports
  bool get canSubmitReports {
    return isVerified && phoneNumber.isNotEmpty;
  }

  // Get completion percentage
  double get profileCompletion {
    double completion = 0.4; // Base for phone + name
    if (email != null && email!.isNotEmpty) completion += 0.1;
    if (nidNumber != null || drivingLicense != null || passportNumber != null) completion += 0.2;
    if (isBiometricVerified) completion += 0.2;
    if (isWalletVerified) completion += 0.1;
    return completion;
  }
}
