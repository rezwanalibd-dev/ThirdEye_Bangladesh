class ReportModel {
  final String id;
  final String userId;
  final String reportType; // 'traffic' or 'social_crime'
  final String violationType;
  final String? vehicleType;
  final String? vehicleNumber;
  final String? description;
  final List<String> imageUrls;
  final List<String> videoUrls;
  final double latitude;
  final double longitude;
  final String address;
  final DateTime timestamp;
  final String status; // 'pending', 'under_review', 'approved', 'rejected'
  final bool isAnonymous; // True for social crimes
  final String? officerComments;
  final DateTime? reviewedAt;
  final double? estimatedFine;
  final double? commission;
  final String caseNumber;

  ReportModel({
    required this.id,
    required this.userId,
    required this.reportType,
    required this.violationType,
    this.vehicleType,
    this.vehicleNumber,
    this.description,
    required this.imageUrls,
    this.videoUrls = const [],
    required this.latitude,
    required this.longitude,
    required this.address,
    required this.timestamp,
    this.status = 'pending',
    this.isAnonymous = false,
    this.officerComments,
    this.reviewedAt,
    this.estimatedFine,
    this.commission,
    required this.caseNumber,
  });

  factory ReportModel.fromMap(Map<String, dynamic> map) {
    return ReportModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      reportType: map['reportType'] ?? 'traffic',
      violationType: map['violationType'] ?? '',
      vehicleType: map['vehicleType'],
      vehicleNumber: map['vehicleNumber'],
      description: map['description'],
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      videoUrls: List<String>.from(map['videoUrls'] ?? []),
      latitude: (map['latitude'] ?? 0.0).toDouble(),
      longitude: (map['longitude'] ?? 0.0).toDouble(),
      address: map['address'] ?? '',
      timestamp: DateTime.tryParse(map['timestamp'] ?? '') ?? DateTime.now(),
      status: map['status'] ?? 'pending',
      isAnonymous: map['isAnonymous'] ?? false,
      officerComments: map['officerComments'],
      reviewedAt: map['reviewedAt'] != null ? DateTime.tryParse(map['reviewedAt']) : null,
      estimatedFine: map['estimatedFine']?.toDouble(),
      commission: map['commission']?.toDouble(),
      caseNumber: map['caseNumber'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'reportType': reportType,
      'violationType': violationType,
      'vehicleType': vehicleType,
      'vehicleNumber': vehicleNumber,
      'description': description,
      'imageUrls': imageUrls,
      'videoUrls': videoUrls,
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
      'timestamp': timestamp.toIso8601String(),
      'status': status,
      'isAnonymous': isAnonymous,
      'officerComments': officerComments,
      'reviewedAt': reviewedAt?.toIso8601String(),
      'estimatedFine': estimatedFine,
      'commission': commission,
      'caseNumber': caseNumber,
    };
  }

  // Generate case number format: TE-YYYY-MMDD-XXXX
  static String generateCaseNumber() {
    final now = DateTime.now();
    final year = now.year.toString();
    final month = now.month.toString().padLeft(2, '0');
    final day = now.day.toString().padLeft(2, '0');
    final random = (DateTime.now().millisecondsSinceEpoch % 10000).toString().padLeft(4, '0');
    return 'TE-$year-$month$day-$random';
  }

  // Get status color
  String get statusColor {
    switch (status) {
      case 'pending':
        return '#FFA726'; // Orange
      case 'under_review':
        return '#42A5F5'; // Blue
      case 'approved':
        return '#66BB6A'; // Green
      case 'rejected':
        return '#EF5350'; // Red
      default:
        return '#757575'; // Grey
    }
  }

  // Get status display text
  String getStatusText(String language) {
    if (language == 'bn') {
      switch (status) {
        case 'pending':
          return 'অপেক্ষমাণ';
        case 'under_review':
          return 'পর্যালোচনাধীন';
        case 'approved':
          return 'অনুমোদিত';
        case 'rejected':
          return 'প্রত্যাখ্যাত';
        default:
          return 'অজানা';
      }
    } else {
      switch (status) {
        case 'pending':
          return 'Pending';
        case 'under_review':
          return 'Under Review';
        case 'approved':
          return 'Approved';
        case 'rejected':
          return 'Rejected';
        default:
          return 'Unknown';
      }
    }
  }

  // Calculate estimated commission
  double getEstimatedCommission() {
    if (estimatedFine != null) {
      return estimatedFine! * 0.20; // 20% commission
    }
    return 0.0;
  }
}
