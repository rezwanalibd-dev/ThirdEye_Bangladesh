import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageProvider with ChangeNotifier {
  bool _isEnglish = true;
  String _currentLanguage = 'en';

  bool get isEnglish => _isEnglish;
  String get currentLanguage => _currentLanguage;
  Locale get currentLocale => _isEnglish ? Locale('en', 'US') : Locale('bn', 'BD');

  LanguageProvider() {
    _loadLanguagePreference();
  }

  void _loadLanguagePreference() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isEnglish = prefs.getBool('isEnglish') ?? true;
      _currentLanguage = _isEnglish ? 'en' : 'bn';
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading language preference: $e');
    }
  }

  void toggleLanguage() {
    _isEnglish = !_isEnglish;
    _currentLanguage = _isEnglish ? 'en' : 'bn';
    _saveLanguagePreference();
    notifyListeners();
  }

  void setLanguage(bool isEnglish) {
    _isEnglish = isEnglish;
    _currentLanguage = isEnglish ? 'en' : 'bn';
    _saveLanguagePreference();
    notifyListeners();
  }

  void _saveLanguagePreference() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isEnglish', _isEnglish);
    } catch (e) {
      debugPrint('Error saving language preference: $e');
    }
  }
}
