import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Listen to auth state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Send OTP to phone number
  Future<String> sendOTP(String phoneNumber) async {
    try {
      String formattedNumber = phoneNumber.startsWith('+88') 
          ? phoneNumber 
          : '+88$phoneNumber';

      String verificationId = '';
      
      await _auth.verifyPhoneNumber(
        phoneNumber: formattedNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Auto-verification completed
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          throw Exception('Verification failed: ${e.message}');
        },
        codeSent: (String vId, int? resendToken) {
          verificationId = vId;
        },
        codeAutoRetrievalTimeout: (String vId) {
          verificationId = vId;
        },
        timeout: const Duration(seconds: 60),
      );
      
      return verificationId;
    } catch (e) {
      throw Exception('Failed to send OTP: $e');
    }
  }

  // Verify OTP and create/login user
  Future<UserModel> verifyOTPAndSignIn({
    required String verificationId,
    required String smsCode,
    String? fullName,
    String? email,
    String userType = 'citizen',
  }) async {
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );

      UserCredential userCredential = await _auth.signInWithCredential(credential);
      User? user = userCredential.user;

      if (user != null) {
        // Check if user exists in Firestore
        DocumentSnapshot userDoc = await _firestore
            .collection('users')
            .doc(user.uid)
            .get();

        UserModel userModel;
        
        if (userDoc.exists) {
          // Existing user - return user data
          userModel = UserModel.fromMap(userDoc.data() as Map<String, dynamic>);
        } else {
          // New user - create profile
          if (fullName == null) {
            throw Exception('Full name is required for new users');
          }
          
          userModel = UserModel(
            uid: user.uid,
            phoneNumber: user.phoneNumber ?? '',
            email: email,
            fullName: fullName,
            userType: userType,
            isVerified: true,
            createdAt: DateTime.now(),
          );

          // Save to Firestore
          await _firestore
              .collection('users')
              .doc(user.uid)
              .set(userModel.toMap());
        }

        return userModel;
      } else {
        throw Exception('Authentication failed');
      }
    } catch (e) {
      throw Exception('OTP verification failed: $e');
    }
  }

  // Update user profile
  Future<void> updateUserProfile(UserModel user) async {
    try {
      await _firestore
          .collection('users')
          .doc(user.uid)
          .update({
        ...user.toMap(),
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('Failed to update profile: $e');
    }
  }

  // Get user profile
  Future<UserModel?> getUserProfile(String uid) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection('users')
          .doc(uid)
          .get();

      if (doc.exists) {
        return UserModel.fromMap(doc.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get user profile: $e');
    }
  }

  // Sign out
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // Check if phone number exists
  Future<bool> checkPhoneExists(String phoneNumber) async {
    try {
      String formattedNumber = phoneNumber.startsWith('+88') 
          ? phoneNumber 
          : '+88$phoneNumber';

      QuerySnapshot query = await _firestore
          .collection('users')
          .where('phoneNumber', isEqualTo: formattedNumber)
          .limit(1)
          .get();

      return query.docs.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  // Update KYC status
  Future<void> updateKYCStatus({
    required String uid,
    String? nidNumber,
    String? drivingLicense,
    String? passportNumber,
    List<String>? documentUrls,
  }) async {
    try {
      Map<String, dynamic> updates = {
        'updatedAt': DateTime.now().toIso8601String(),
      };

      if (nidNumber != null) updates['nidNumber'] = nidNumber;
      if (drivingLicense != null) updates['drivingLicense'] = drivingLicense;
      if (passportNumber != null) updates['passportNumber'] = passportNumber;
      if (documentUrls != null) updates['documentUrls'] = documentUrls;

      await _firestore
          .collection('users')
          .doc(uid)
          .update(updates);
    } catch (e) {
      throw Exception('Failed to update KYC: $e');
    }
  }

  // Update biometric verification
  Future<void> updateBiometricStatus({
    required String uid,
    required List<String> selfieUrls,
  }) async {
    try {
      await _firestore
          .collection('users')
          .doc(uid)
          .update({
        'selfieUrls': selfieUrls,
        'isBiometricVerified': true,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('Failed to update biometric status: $e');
    }
  }

  // Update wallet information
  Future<void> updateWalletInfo({
    required String uid,
    required String paymentMethod,
    required String walletNumber,
  }) async {
    try {
      await _firestore
          .collection('users')
          .doc(uid)
          .update({
        'paymentMethod': paymentMethod,
        'walletNumber': walletNumber,
        'isWalletVerified': true,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('Failed to update wallet info: $e');
    }
  }
}
