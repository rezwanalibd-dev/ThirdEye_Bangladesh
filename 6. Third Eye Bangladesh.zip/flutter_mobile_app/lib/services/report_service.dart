import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import '../models/report_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';

class ReportService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Submit a new traffic violation report
  Future<String> submitTrafficReport({
    required String userId,
    required String violationType,
    required String vehicleType,
    String? vehicleNumber,
    String? description,
    required List<String> imageUrls,
    List<String> videoUrls = const [],
    required double latitude,
    required double longitude,
    required String address,
  }) async {
    try {
      final reportId = DateTime.now().millisecondsSinceEpoch.toString();
      final caseNumber = ReportModel.generateCaseNumber();
      
      // Calculate estimated fine
      final estimatedFine = AppConstants.getFineAmount(vehicleType, violationType).toDouble();
      
      final report = ReportModel(
        id: reportId,
        userId: userId,
        reportType: 'traffic',
        violationType: violationType,
        vehicleType: vehicleType,
        vehicleNumber: vehicleNumber,
        description: description,
        imageUrls: imageUrls,
        videoUrls: videoUrls,
        latitude: latitude,
        longitude: longitude,
        address: address,
        timestamp: DateTime.now(),
        status: 'pending',
        isAnonymous: false,
        estimatedFine: estimatedFine,
        commission: estimatedFine * 0.20,
        caseNumber: caseNumber,
      );

      await _firestore
          .collection('reports')
          .doc(reportId)
          .set(report.toMap());

      // Update user's report count
      await _updateUserReportCount(userId);

      return caseNumber;
    } catch (e) {
      throw Exception('Failed to submit report: $e');
    }
  }

  // Submit a social crime report
  Future<String> submitSocialCrimeReport({
    required String userId,
    required String crimeType,
    String? description,
    required List<String> imageUrls,
    List<String> videoUrls = const [],
    required double latitude,
    required double longitude,
    required String address,
    bool isAnonymous = true,
  }) async {
    try {
      final reportId = DateTime.now().millisecondsSinceEpoch.toString();
      final caseNumber = ReportModel.generateCaseNumber();
      
      final report = ReportModel(
        id: reportId,
        userId: isAnonymous ? 'anonymous' : userId,
        reportType: 'social_crime',
        violationType: crimeType,
        description: description,
        imageUrls: imageUrls,
        videoUrls: videoUrls,
        latitude: latitude,
        longitude: longitude,
        address: address,
        timestamp: DateTime.now(),
        status: 'pending',
        isAnonymous: isAnonymous,
        caseNumber: caseNumber,
      );

      await _firestore
          .collection('reports')
          .doc(reportId)
          .set(report.toMap());

      if (!isAnonymous) {
        await _updateUserReportCount(userId);
      }

      return caseNumber;
    } catch (e) {
      throw Exception('Failed to submit crime report: $e');
    }
  }

  // Get user's reports
  Stream<List<ReportModel>> getUserReports(String userId) {
    return _firestore
        .collection('reports')
        .where('userId', isEqualTo: userId)
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ReportModel.fromMap(doc.data()))
            .toList());
  }

  // Get report by case number
  Future<ReportModel?> getReportByCaseNumber(String caseNumber) async {
    try {
      QuerySnapshot query = await _firestore
          .collection('reports')
          .where('caseNumber', isEqualTo: caseNumber)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        return ReportModel.fromMap(query.docs.first.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to find report: $e');
    }
  }

  // Get all pending reports for officers
  Stream<List<ReportModel>> getPendingReports() {
    return _firestore
        .collection('reports')
        .where('status', isEqualTo: 'pending')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ReportModel.fromMap(doc.data()))
            .toList());
  }

  // Update report status (officer action)
  Future<void> updateReportStatus({
    required String reportId,
    required String status,
    String? officerComments,
  }) async {
    try {
      Map<String, dynamic> updates = {
        'status': status,
        'reviewedAt': DateTime.now().toIso8601String(),
      };

      if (officerComments != null) {
        updates['officerComments'] = officerComments;
      }

      await _firestore
          .collection('reports')
          .doc(reportId)
          .update(updates);

      // If approved, update user's approved count and pending rewards
      if (status == 'approved') {
        await _updateUserApprovedCount(reportId);
      }
    } catch (e) {
      throw Exception('Failed to update report status: $e');
    }
  }

  // Get current location
  Future<Position> getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are disabled');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception('Location permissions are permanently denied');
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  // Get address from coordinates (simplified)
  Future<String> getAddressFromCoordinates(double latitude, double longitude) async {
    // This would typically use a geocoding service
    // For now, return a formatted string
    return 'Lat: ${latitude.toStringAsFixed(6)}, Lng: ${longitude.toStringAsFixed(6)}';
  }

  // Private helper methods
  Future<void> _updateUserReportCount(String userId) async {
    try {
      await _firestore
          .collection('users')
          .doc(userId)
          .update({
        'totalReports': FieldValue.increment(1),
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      // Handle error silently or log
    }
  }

  Future<void> _updateUserApprovedCount(String reportId) async {
    try {
      // Get the report to find the user
      DocumentSnapshot reportDoc = await _firestore
          .collection('reports')
          .doc(reportId)
          .get();

      if (reportDoc.exists) {
        ReportModel report = ReportModel.fromMap(reportDoc.data() as Map<String, dynamic>);
        
        if (!report.isAnonymous && report.userId != 'anonymous') {
          double commission = report.commission ?? 0.0;
          
          await _firestore
              .collection('users')
              .doc(report.userId)
              .update({
            'approvedReports': FieldValue.increment(1),
            'pendingRewards': FieldValue.increment(commission),
            'updatedAt': DateTime.now().toIso8601String(),
          });
        }
      }
    } catch (e) {
      // Handle error silently or log
    }
  }

  // Get report statistics
  Future<Map<String, int>> getReportStatistics() async {
    try {
      QuerySnapshot allReports = await _firestore.collection('reports').get();
      
      Map<String, int> stats = {
        'total': allReports.docs.length,
        'pending': 0,
        'approved': 0,
        'rejected': 0,
        'traffic': 0,
        'crime': 0,
      };

      for (var doc in allReports.docs) {
        ReportModel report = ReportModel.fromMap(doc.data() as Map<String, dynamic>);
        
        stats[report.status] = (stats[report.status] ?? 0) + 1;
        
        if (report.reportType == 'traffic') {
          stats['traffic'] = stats['traffic']! + 1;
        } else {
          stats['crime'] = stats['crime']! + 1;
        }
      }

      return stats;
    } catch (e) {
      return {
        'total': 0,
        'pending': 0,
        'approved': 0,
        'rejected': 0,
        'traffic': 0,
        'crime': 0,
      };
    }
  }
}
