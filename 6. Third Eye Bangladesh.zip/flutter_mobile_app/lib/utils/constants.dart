class AppConstants {
  static const String appName = 'Third Eye Bangladesh';
  static const String appTagline = 'Report Traffic Violations • Earn Rewards • Save Lives';
  
  // Vehicle Types
  static const List<String> vehicleTypes = [
    'Motorbike',
    'Car',
    'Bus',
    'Truck',
    'CNG Auto-rickshaw',
    'E-rickshaw',
  ];
  
  // Universal Violations
  static const List<String> universalViolations = [
    'Red Light Jumping',
    'Wrong Side Driving',
    'Speeding',
    'Using Mobile Phone',
    'Illegal Parking',
    'No License',
    'No Seatbelt',
  ];
  
  // Vehicle-specific violations
  static const Map<String, List<String>> vehicleSpecificViolations = {
    'Motorbike': ['No Helmet', 'Driving on Footpath'],
    'CNG Auto-rickshaw': ['Driving on Footpath', 'Overloading'],
    'E-rickshaw': ['Driving on Footpath', 'Overloading'],
  };
  
  // Payment Methods
  static const List<String> paymentMethods = [
    'bKash',
    'Nagad',
    'Rocket',
    'Upay',
    'mCash',
    'CellFin',
    'SureCash',
  ];
  
  // Bangladesh Traffic Fines (in BDT)
  static const Map<String, Map<String, int>> violationFines = {
    'Motorbike': {
      'Red Light Jumping': 5000,
      'Wrong Side Driving': 3000,
      'Speeding': 5000,
      'Using Mobile Phone': 2000,
      'Illegal Parking': 2000,
      'No License': 5000,
      'No Helmet': 1000,
      'Driving on Footpath': 3000,
    },
    'Car': {
      'Red Light Jumping': 5000,
      'Wrong Side Driving': 3000,
      'Speeding': 5000,
      'Using Mobile Phone': 2000,
      'Illegal Parking': 4000,
      'No License': 25000,
      'No Seatbelt': 1000,
    },
    'Bus': {
      'Red Light Jumping': 10000,
      'Wrong Side Driving': 5000,
      'Speeding': 10000,
      'Using Mobile Phone': 5000,
      'Illegal Parking': 5000,
      'No License': 50000,
      'Overloading': 10000,
    },
    'Truck': {
      'Red Light Jumping': 10000,
      'Wrong Side Driving': 5000,
      'Speeding': 10000,
      'Using Mobile Phone': 5000,
      'Illegal Parking': 5000,
      'No License': 50000,
      'Overloading': 20000,
    },
    'CNG Auto-rickshaw': {
      'Red Light Jumping': 3000,
      'Wrong Side Driving': 2000,
      'Speeding': 3000,
      'Using Mobile Phone': 1000,
      'Illegal Parking': 2000,
      'No License': 10000,
      'Driving on Footpath': 2000,
      'Overloading': 1000,
    },
    'E-rickshaw': {
      'Red Light Jumping': 2000,
      'Wrong Side Driving': 1500,
      'Speeding': 2000,
      'Using Mobile Phone': 1000,
      'Illegal Parking': 1000,
      'No License': 5000,
      'Driving on Footpath': 1500,
      'Overloading': 500,
    },
  };
  
  // Emergency Numbers
  static const Map<String, String> emergencyNumbers = {
    'Police': '999',
    'Fire Service': '16163',
    'Ambulance': '199',
    'Women & Child Helpline': '109',
  };
  
  // Get violations for specific vehicle
  static List<String> getViolationsForVehicle(String vehicleType) {
    List<String> violations = List.from(universalViolations);
    if (vehicleSpecificViolations.containsKey(vehicleType)) {
      violations.addAll(vehicleSpecificViolations[vehicleType]!);
    }
    return violations;
  }
  
  // Get fine amount
  static int getFineAmount(String vehicleType, String violation) {
    return violationFines[vehicleType]?[violation] ?? 1000;
  }
  
  // Calculate reward (20% of fine)
  static double calculateReward(int fineAmount) {
    return fineAmount * 0.20;
  }
}
