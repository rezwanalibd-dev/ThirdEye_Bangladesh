import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  // Common
  String get appName => _localizedValues[locale.languageCode]!['app_name']!;
  String get tagline => _localizedValues[locale.languageCode]!['tagline']!;
  String get loading => _localizedValues[locale.languageCode]!['loading']!;
  String get error => _localizedValues[locale.languageCode]!['error']!;
  String get success => _localizedValues[locale.languageCode]!['success']!;
  String get submit => _localizedValues[locale.languageCode]!['submit']!;
  String get cancel => _localizedValues[locale.languageCode]!['cancel']!;
  String get continueText => _localizedValues[locale.languageCode]!['continue']!;
  String get back => _localizedValues[locale.languageCode]!['back']!;
  String get next => _localizedValues[locale.languageCode]!['next']!;
  
  // Authentication
  String get login => _localizedValues[locale.languageCode]!['login']!;
  String get signup => _localizedValues[locale.languageCode]!['signup']!;
  String get phoneNumber => _localizedValues[locale.languageCode]!['phone_number']!;
  String get email => _localizedValues[locale.languageCode]!['email']!;
  String get fullName => _localizedValues[locale.languageCode]!['full_name']!;
  String get password => _localizedValues[locale.languageCode]!['password']!;
  String get confirmPassword => _localizedValues[locale.languageCode]!['confirm_password']!;
  String get forgotPassword => _localizedValues[locale.languageCode]!['forgot_password']!;
  String get createAccount => _localizedValues[locale.languageCode]!['create_account']!;
  
  // OTP
  String get otpVerification => _localizedValues[locale.languageCode]!['otp_verification']!;
  String get enterOtp => _localizedValues[locale.languageCode]!['enter_otp']!;
  String get verify => _localizedValues[locale.languageCode]!['verify']!;
  String get resendOtp => _localizedValues[locale.languageCode]!['resend_otp']!;
  
  // KYC
  String get kycVerification => _localizedValues[locale.languageCode]!['kyc_verification']!;
  String get nidNumber => _localizedValues[locale.languageCode]!['nid_number']!;
  String get drivingLicense => _localizedValues[locale.languageCode]!['driving_license']!;
  String get passportNumber => _localizedValues[locale.languageCode]!['passport_number']!;
  
  // Features
  String get reportTraffic => _localizedValues[locale.languageCode]!['report_traffic']!;
  String get earnRewards => _localizedValues[locale.languageCode]!['earn_rewards']!;
  String get saveLives => _localizedValues[locale.languageCode]!['save_lives']!;
  String get getStarted => _localizedValues[locale.languageCode]!['get_started']!;
  String get officerPortal => _localizedValues[locale.languageCode]!['officer_portal']!;
  String get trustedBy => _localizedValues[locale.languageCode]!['trusted_by']!;
  
  // Motivational text
  String get motivational1 => _localizedValues[locale.languageCode]!['motivational_1']!;
  String get motivational2 => _localizedValues[locale.languageCode]!['motivational_2']!;

  static const Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'app_name': 'Third Eye Bangladesh',
      'tagline': 'Report Traffic Violations • Earn Rewards • Save Lives',
      'loading': 'Loading...',
      'error': 'Error',
      'success': 'Success',
      'submit': 'Submit',
      'cancel': 'Cancel',
      'continue': 'Continue',
      'back': 'Back',
      'next': 'Next',
      
      // Auth
      'login': 'Login',
      'signup': 'Sign Up',
      'phone_number': 'Phone Number',
      'email': 'Email Address',
      'full_name': 'Full Name',
      'password': 'Password',
      'confirm_password': 'Confirm Password',
      'forgot_password': 'Forgot Password?',
      'create_account': 'Create Account',
      
      // OTP
      'otp_verification': 'OTP Verification',
      'enter_otp': 'Enter OTP code',
      'verify': 'Verify',
      'resend_otp': 'Resend OTP',
      
      // KYC
      'kyc_verification': 'KYC Verification',
      'nid_number': 'NID Number',
      'driving_license': 'Driving License',
      'passport_number': 'Passport Number',
      
      // Features
      'report_traffic': 'Report Traffic Violations',
      'earn_rewards': 'Earn Rewards',
      'save_lives': 'Save Lives',
      'get_started': 'Get Started',
      'officer_portal': 'Officer Portal',
      'trusted_by': 'Trusted by DMP & BRTA',
      
      // Motivational
      'motivational_1': 'Ready to Make a Difference?\n\nEvery report you make helps save lives. When you witness a traffic violation, you have the power to prevent accidents and protect your community.\n\nYour voice matters. Together, we can build a safer Bangladesh.',
      'motivational_2': 'Stand Against Social Crimes\n\nYour courage can save lives. In our society, silence enables injustice. When you witness violence, theft, corruption, or harassment—your voice becomes the shield that protects the vulnerable.\n\nJoin thousands of citizens making a difference.',
    },
    'bn': {
      'app_name': 'থার্ড আই বাংলাদেশ',
      'tagline': 'ট্রাফিক লঙ্ঘন রিপোর্ট করুন • পুরস্কার অর্জন করুন • জীবন বাঁচান',
      'loading': 'লোড হচ্ছে...',
      'error': 'ত্রুটি',
      'success': 'সফল',
      'submit': 'জমা দিন',
      'cancel': 'বাতিল',
      'continue': 'চালিয়ে যান',
      'back': 'পিছনে',
      'next': 'পরবর্তী',
      
      // Auth
      'login': 'লগইন',
      'signup': 'নিবন্ধন',
      'phone_number': 'মোবাইল নম্বর',
      'email': 'ইমেইল ঠিকানা',
      'full_name': 'পূর্ণ নাম',
      'password': 'পাসওয়ার্ড',
      'confirm_password': 'পাসওয়ার্ড নিশ্চিত করুন',
      'forgot_password': 'পাসওয়ার্ড ভুলে গেছেন?',
      'create_account': 'অ্যাকাউন্ট তৈরি করুন',
      
      // OTP
      'otp_verification': 'ওটিপি যাচাইকরণ',
      'enter_otp': 'ওটিপি কোড লিখুন',
      'verify': 'যাচাই করুন',
      'resend_otp': 'ওটিপি পুনরায় পাঠান',
      
      // KYC
      'kyc_verification': 'কেওয়াইসি যাচাইকরণ',
      'nid_number': 'এনআইডি নম্বর',
      'driving_license': 'ড্রাইভিং লাইসেন্স',
      'passport_number': 'পাসপোর্ট নম্বর',
      
      // Features
      'report_traffic': 'ট্রাফিক লঙ্ঘন রিপোর্ট করুন',
      'earn_rewards': 'পুরস্কার অর্জন করুন',
      'save_lives': 'জীবন রক্ষা করুন',
      'get_started': 'শুরু করুন',
      'officer_portal': 'অফিসার পোর্টাল',
      'trusted_by': 'ডিএমপি এবং বিআরটিএ কর্তৃক বিশ্বস্ত',
      
      // Motivational
      'motivational_1': 'প্রস্তুত কি ইতিবাচক পরিবর্তনের অংশ হতে?\n\nআপনার একটি রিপোর্টই অনেকগুলো জীবন বাঁচাতে পারে। ট্রাফিক আইন লঙ্ঘন দেখামাত্রই আপনার রিপোর্ট হতে পারে দুর্ঘটনা প্রতিরোধের প্রথম ধাপ।\n\nআসুন আমরা হাতে হাত মিলিয়ে গড়ে তুলি একটি নিরাপদ বাংলাদেশ।',
      'motivational_2': 'সামাজিক অপরাধের বিরুদ্ধে রুখে দাঁড়ান\n\nআপনার একটু সাহসই অনেকগুলো জীবন বাঁচাতে পারে। আমাদের সমাজে নীরবতাই অপরাধকে দেয় বাড়তি প্রেরণা। যখনই আপনি প্রত্যক্ষ করেন সহিংসতা, চুরি, দুর্নীতি বা হয়রানি—তখনই আপনার কণ্ঠস্বরই হয়ে উঠতে পারে নির্যাতিত মানুষের আশ্রয়।\n\nহাজারো নাগরিকের সাথে যোগ দিন পরিবর্তনের এই যাত্রায়।',
    },
  };
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'bn'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
