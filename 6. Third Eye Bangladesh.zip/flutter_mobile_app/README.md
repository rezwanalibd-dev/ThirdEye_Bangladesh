# Third Eye Bangladesh - Flutter Mobile App

Official mobile application for reporting traffic violations in Bangladesh.

## Features

- **Multi-step Registration**: Complete signup flow with OTP verification
- **Bilingual Support**: English and Bengali (বাংলা) languages
- **Traffic Violation Reporting**: Capture evidence and report violations
- **KYC Verification**: Document and biometric verification
- **Wallet Integration**: Commission tracking and payments
- **Officer Portals**: Separate interfaces for DMP and BRTA officers
- **Real-time Tracking**: Case status and reward tracking

## Getting Started

### Prerequisites

- Flutter SDK 3.0+
- Dart SDK 3.0+
- Android Studio / VS Code
- Firebase Account (for backend services)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd flutter_mobile_app
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Firebase Setup**
   - Create a new Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
   - Enable Authentication (Phone), Firestore Database, and Storage
   - Download configuration files:
     - `google-services.json` → `android/app/`
     - `GoogleService-Info.plist` → `ios/Runner/`

4. **Run the app**
   ```bash
   flutter run
   ```

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── providers/               # State management
│   ├── auth_provider.dart
│   └── language_provider.dart
├── screens/                 # App screens
│   ├── welcome_screen.dart
│   ├── login_screen.dart
│   └── signup_screen.dart
├── widgets/                 # Reusable components
│   ├── language_toggle.dart
│   ├── feature_card.dart
│   └── motivational_carousel.dart
├── utils/                   # Utilities and constants
│   ├── theme.dart
│   ├── constants.dart
│   └── app_localizations.dart
└── assets/                  # Images, fonts, and other assets
```

## Key Technologies

- **Flutter**: Cross-platform mobile development
- **Firebase**: Backend services (Auth, Firestore, Storage)
- **Provider**: State management
- **Geolocator**: Location services
- **Image Picker**: Camera and gallery access

## Bangladesh-Specific Features

### Traffic Rules & Fines
- Motorbike violations (No Helmet: ৳1,000)
- Car violations (Red Light: ৳5,000)
- Bus/Truck violations (Overloading: ৳10,000+)

### Government Integration
- **DMP (Dhaka Metropolitan Police)** verification
- **BRTA (Bangladesh Road Transport Authority)** collaboration
- Official government partnership logos and branding

### Mobile Wallet Support
- bKash, Nagad, Rocket
- Upay, mCash, CellFin, SureCash
- Commission tracking and automatic transfers

## Building for Production

### Android APK
```bash
flutter build apk --release
```

### Android App Bundle (for Play Store)
```bash
flutter build appbundle --release
```

### iOS (requires macOS with Xcode)
```bash
flutter build ios --release
```

## Localization

The app supports English and Bengali:

- **English**: Primary interface
- **Bengali (বাংলা)**: Full translation support
- **Dynamic switching**: Users can toggle between languages

### Adding New Translations

1. Update `lib/utils/app_localizations.dart`
2. Add new key-value pairs to both language maps
3. Use in screens: `AppLocalizations.of(context)!.newKey`

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/new-feature`)
5. Open a Pull Request

## Architecture Notes

### State Management
- **Provider Pattern**: Chosen for simplicity and reliability
- **Separation of Concerns**: Providers handle business logic, widgets handle UI

### File Organization
- **Screens**: Page-level components
- **Widgets**: Reusable UI components
- **Providers**: State management and business logic
- **Utils**: Constants, themes, and helper functions

### Firebase Integration
- **Authentication**: Phone-based OTP verification
- **Firestore**: User data and report storage
- **Storage**: Image and document uploads

## Testing

### Run Tests
```bash
flutter test
```

### Widget Tests
```bash
flutter test test/widget_test.dart
```

### Integration Tests
```bash
flutter drive --target=test_driver/app.dart
```

## Deployment

### Google Play Store
1. Build signed APK/AAB
2. Create Play Console account
3. Upload app bundle
4. Complete store listing
5. Submit for review

### Apple App Store
1. Build iOS archive in Xcode
2. Upload to App Store Connect
3. Complete app information
4. Submit for App Store review

## Support

For technical support or questions:
- Email: support@thirdeye.gov.bd
- GitHub Issues: [Create an issue](../../issues)

## License

This project is developed for the Government of Bangladesh.
All rights reserved.

---

**Third Eye Bangladesh**  
*Making roads safer through community participation*
