# Code Download & Publishing Guide

This guide helps you download and organize the complete Third Eye Bangladesh codebase for publishing to Google Play Store and Apple App Store.

## Project Structure

```
third-eye-bangladesh/
├── web-app/                    # Web/PWA version (React + Cloudflare)
│   ├── public/                 # Static assets
│   ├── src/
│   │   ├── react-app/         # React frontend
│   │   ├── worker/            # Cloudflare Worker backend
│   │   └── shared/            # Shared types
│   ├── index.html
│   ├── package.json
│   ├── vite.config.ts
│   └── wrangler.json
│
├── flutter-app/               # Mobile app (Flutter)
│   ├── lib/
│   │   ├── main.dart
│   │   ├── screens/
│   │   ├── widgets/
│   │   ├── services/
│   │   ├── providers/
│   │   ├── models/
│   │   └── utils/
│   ├── android/               # Android build configuration
│   ├── ios/                   # iOS build configuration
│   ├── pubspec.yaml
│   └── README.md
│
├── docs/                      # Documentation
│   ├── PUBLISHING_GUIDE.md
│   ├── DEPLOYMENT_MASTER_GUIDE.md
│   ├── PRE_PUBLISHING_CHECKLIST.md
│   └── TESTING_GUIDE.md
│
└── assets/                    # Shared assets (icons, images)
```

## Download Instructions

### Option 1: Download as ZIP (Recommended for beginners)

1. **Click the Download button** in your development environment
2. **Extract the ZIP file** to your desired location
3. **Rename the folder** from `mocha-app` to `third-eye-bangladesh`

### Option 2: Git Clone (Recommended for developers)

```bash
# Clone the repository
git clone <repository-url> third-eye-bangladesh
cd third-eye-bangladesh

# Remove git history if you want a fresh start
rm -rf .git
git init
git add .
git commit -m "Initial commit: Third Eye Bangladesh"
```

## Organize for Publishing

### 1. Web/PWA Version

The web version is ready to deploy to Cloudflare Pages:

```bash
cd web-app
npm install
npm run build
```

Deploy using:
```bash
npm run deploy
```

### 2. Android Version

#### Prepare Android Build

1. **Open in Android Studio**:
   ```bash
   cd flutter-app
   flutter pub get
   ```

2. **Update `android/app/build.gradle`**:
   - Change `applicationId` to `bd.gov.thirdeye`
   - Update `versionCode` and `versionName`

3. **Generate keystore** (for release):
   ```bash
   keytool -genkey -v -keystore ~/third-eye-release-key.jks \
     -keyalg RSA -keysize 2048 -validity 10000 \
     -alias thirdeye-key
   ```

4. **Create `android/key.properties`**:
   ```properties
   storePassword=<your-password>
   keyPassword=<your-password>
   keyAlias=thirdeye-key
   storeFile=<path-to-jks-file>
   ```

5. **Build release APK**:
   ```bash
   flutter build apk --release
   ```

6. **Build App Bundle** (for Play Store):
   ```bash
   flutter build appbundle --release
   ```

Output files:
- APK: `build/app/outputs/flutter-apk/app-release.apk`
- AAB: `build/app/outputs/bundle/release/app-release.aab`

### 3. iOS Version

#### Prepare iOS Build

1. **Open in Xcode**:
   ```bash
   cd flutter-app
   open ios/Runner.xcworkspace
   ```

2. **Update in Xcode**:
   - Bundle Identifier: `bd.gov.thirdeye`
   - Version and Build numbers
   - Signing & Capabilities (use your Apple Developer account)

3. **Build for release**:
   ```bash
   flutter build ios --release
   ```

4. **Create archive in Xcode**:
   - Product → Archive
   - Upload to App Store Connect

## Pre-Publishing Checklist

Before uploading to stores, ensure:

### Assets Ready
- [ ] App icons (all sizes generated)
- [ ] Screenshots (5-8 per device type)
- [ ] Feature graphic (1024x500px for Play Store)
- [ ] Promotional video (optional but recommended)

### App Configuration
- [ ] App name: "Third Eye Bangladesh"
- [ ] Package name: `bd.gov.thirdeye`
- [ ] Version codes set correctly
- [ ] Permissions properly declared
- [ ] Privacy policy URL updated
- [ ] Terms of service URL updated

### Testing
- [ ] All features tested on Android
- [ ] All features tested on iOS
- [ ] Offline functionality verified
- [ ] Push notifications working
- [ ] Payment/wallet integration tested
- [ ] Language switching works (English/Bengali)

### Legal & Compliance
- [ ] Privacy Policy uploaded
- [ ] Terms of Service uploaded
- [ ] Data handling disclosure completed
- [ ] Government partnership verification
- [ ] BRTA/DMP approval documents ready

## File Organization for Submission

### Google Play Console

Create this folder structure:
```
google-play-submission/
├── app-release.aab
├── release-notes.txt
├── store-listing/
│   ├── title.txt (30 chars max)
│   ├── short-description.txt (80 chars max)
│   ├── full-description.txt (4000 chars max)
│   ├── screenshots/
│   │   ├── phone/
│   │   ├── 7-inch-tablet/
│   │   └── 10-inch-tablet/
│   ├── feature-graphic.png
│   └── icon-512.png
└── documents/
    ├── privacy-policy.pdf
    └── government-approval.pdf
```

### Apple App Store

Create this folder structure:
```
app-store-submission/
├── app-archive.xcarchive
├── screenshots/
│   ├── iphone-6.5/
│   ├── iphone-5.5/
│   └── ipad-12.9/
├── store-information/
│   ├── app-name.txt
│   ├── subtitle.txt
│   ├── description.txt
│   ├── keywords.txt
│   └── whats-new.txt
└── documents/
    ├── privacy-policy.pdf
    └── government-approval.pdf
```

## Quick Commands Reference

### Flutter Commands
```bash
# Get dependencies
flutter pub get

# Run on device
flutter run

# Build APK
flutter build apk --release

# Build iOS
flutter build ios --release

# Analyze code
flutter analyze

# Run tests
flutter test
```

### Web Commands
```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build

# Deploy to Cloudflare
npm run deploy

# Run tests
npm test
```

## Support & Resources

- **Flutter Documentation**: https://docs.flutter.dev/
- **Play Console Help**: https://support.google.com/googleplay/android-developer
- **App Store Connect**: https://developer.apple.com/app-store-connect/
- **BRTA Bangladesh**: https://brta.gov.bd/
- **DMP**: https://dmp.gov.bd/

## Notes

- Keep your signing keys secure and backed up
- Never commit keys or passwords to version control
- Test thoroughly on real devices before submission
- Allow 2-7 days for app review on both platforms
- Have government approval documents ready for verification
- Ensure compliance with Bangladesh data protection laws

---

For detailed publishing steps, see:
- `docs/PUBLISHING_GUIDE.md` - Complete publishing guide
- `docs/PRE_PUBLISHING_CHECKLIST.md` - Submission checklist
- `docs/DEPLOYMENT_MASTER_GUIDE.md` - Deployment procedures
