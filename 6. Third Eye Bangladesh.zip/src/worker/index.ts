import { Hono } from "hono";
import { cors } from "hono/cors";
import auth from "./routes/auth";
import reports from "./routes/reports";
import users from "./routes/users";
import officers from "./routes/officers";

const app = new Hono<{ Bindings: Env }>();

// Enable CORS
app.use('/*', cors());

// Health check
app.get('/', (c) => {
  return c.json({ 
    message: 'Third Eye Bangladesh API',
    version: '1.0.0',
    status: 'healthy' 
  });
});

// Routes
app.route('/api/auth', auth);
app.route('/api/reports', reports);
app.route('/api/users', users);
app.route('/api/officers', officers);

export default app;
