import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";

const auth = new Hono<{ Bindings: Env }>();

// Signup schema
const signupSchema = z.object({
  fullName: z.string().min(2),
  phoneNumber: z.string().regex(/^01[3-9]\d{8}$/),
  email: z.string().email().optional(),
  password: z.string().min(8),
  userType: z.enum(['citizen', 'officer']).default('citizen')
});

// OTP verification schema
const otpSchema = z.object({
  phoneNumber: z.string(),
  otpCode: z.string().length(6),
  purpose: z.enum(['signup', 'login', 'wallet_verify']).default('signup')
});

// Login schema
const loginSchema = z.object({
  phoneEmail: z.string(),
  password: z.string()
});

// Generate OTP
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Hash password (simplified - use proper hashing in production)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Verify password
async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const hashedInput = await hashPassword(password);
  return hashedInput === hash;
}

// POST /api/auth/signup - Send OTP for signup
auth.post('/signup', zValidator('json', signupSchema), async (c) => {
  try {
    const { fullName, phoneNumber, email, password, userType } = c.req.valid('json');
    
    // Format phone number
    const formattedPhone: string = phoneNumber.startsWith('+88') ? phoneNumber : `+88${phoneNumber}`;
    
    // Check if user already exists
    const existingUser = await c.env.DB.prepare(
      'SELECT id FROM users WHERE phone_number = ?'
    ).bind(formattedPhone).first();
    
    if (existingUser) {
      return c.json({ error: 'Phone number already registered' }, 400);
    }
    
    // Generate OTP
    const otpCode = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    
    // Store OTP
    await c.env.DB.prepare(`
      INSERT INTO otp_verifications (phone_number, otp_code, purpose, expires_at)
      VALUES (?, ?, 'signup', ?)
    `).bind(formattedPhone, otpCode, expiresAt.toISOString()).run();
    
    // Store temporary user data in a secure way (you might want to use a different approach)
    // For now, we'll create the user as unverified
    const passwordHash = await hashPassword(password);
    
    await c.env.DB.prepare(`
      INSERT INTO users (uid, phone_number, email, full_name, user_type, is_verified, password_hash)
      VALUES (?, ?, ?, ?, ?, false, ?)
    `).bind(
      `temp_${Date.now()}`, 
      formattedPhone, 
      email || null, 
      fullName, 
      userType, 
      passwordHash
    ).run();
    
    // In production, send SMS via service like Twilio
    console.log(`OTP for ${formattedPhone}: ${otpCode}`);
    
    return c.json({ 
      success: true, 
      message: 'OTP sent successfully',
      // Remove in production - only for demo
      debug: { otpCode }
    });
    
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/auth/verify-otp - Verify OTP and complete signup/login
auth.post('/verify-otp', zValidator('json', otpSchema), async (c) => {
  try {
    const validatedData = c.req.valid('json');
    const phoneNumber: string = validatedData.phoneNumber;
    const otpCode: string = validatedData.otpCode;
    const purpose: string = validatedData.purpose;
    
    const formattedPhone: string = phoneNumber.startsWith('+88') ? phoneNumber : `+88${phoneNumber}`;
    
    // Check OTP
    const otpRecord = await c.env.DB.prepare(`
      SELECT * FROM otp_verifications 
      WHERE phone_number = ? AND otp_code = ? AND purpose = ? AND is_verified = false
      AND expires_at > datetime('now')
      ORDER BY created_at DESC
      LIMIT 1
    `).bind(formattedPhone, otpCode, purpose).first() as any;
    
    if (!otpRecord) {
      return c.json({ error: 'Invalid or expired OTP' }, 400);
    }
    
    // Mark OTP as verified
    await c.env.DB.prepare(
      'UPDATE otp_verifications SET is_verified = true WHERE id = ?'
    ).bind(otpRecord.id).run();
    
    // Update user as verified
    const userId: string = `user_${Date.now()}`;
    const user = await c.env.DB.prepare(`
      UPDATE users SET is_verified = true, uid = ? WHERE phone_number = ?
      RETURNING *
    `).bind(userId, formattedPhone).first() as any;
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    // Create session token (simplified - use proper JWT in production)
    const sessionToken = btoa(JSON.stringify({ 
      userId: user.uid, 
      userType: user.user_type,
      timestamp: Date.now() 
    }));
    
    return c.json({
      success: true,
      user: {
        uid: user.uid,
        fullName: user.full_name,
        phoneNumber: user.phone_number,
        email: user.email,
        userType: user.user_type,
        isVerified: true
      },
      sessionToken
    });
    
  } catch (error) {
    console.error('OTP verification error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/auth/login - Login with phone/email and password
auth.post('/login', zValidator('json', loginSchema), async (c) => {
  try {
    const { phoneEmail, password } = c.req.valid('json');
    
    // Determine if it's phone or email
    const isEmail = phoneEmail.includes('@');
    const formattedPhone = isEmail ? null : (phoneEmail.startsWith('+88') ? phoneEmail : `+88${phoneEmail}`);
    
    // Find user
    const user = await c.env.DB.prepare(`
      SELECT * FROM users 
      WHERE ${isEmail ? 'email' : 'phone_number'} = ? AND is_verified = true
    `).bind(isEmail ? phoneEmail : formattedPhone).first() as any;
    
    if (!user) {
      return c.json({ error: 'Invalid credentials' }, 401);
    }
    
    // Verify password
    const isValidPassword = await verifyPassword(password, user.password_hash);
    if (!isValidPassword) {
      return c.json({ error: 'Invalid credentials' }, 401);
    }
    
    // Create session token
    const sessionToken = btoa(JSON.stringify({ 
      userId: user.uid, 
      userType: user.user_type,
      timestamp: Date.now() 
    }));
    
    return c.json({
      success: true,
      user: {
        uid: user.uid,
        fullName: user.full_name,
        phoneNumber: user.phone_number,
        email: user.email,
        userType: user.user_type,
        isVerified: user.is_verified
      },
      sessionToken
    });
    
  } catch (error) {
    console.error('Login error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/auth/logout - Logout (invalidate session)
auth.post('/logout', async (c) => {
  // In a real implementation, you'd blacklist the token
  return c.json({ success: true, message: 'Logged out successfully' });
});

export default auth;
