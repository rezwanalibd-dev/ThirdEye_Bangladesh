import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";

const reports = new Hono<{ Bindings: Env }>();

// Traffic report schema
const trafficReportSchema = z.object({
  vehicleType: z.string(),
  violationType: z.string(),
  vehicleNumber: z.string().optional(),
  description: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  address: z.string(),
  imageUrls: z.array(z.string()),
  videoUrls: z.array(z.string()).optional().default([]),
  isAnonymous: z.boolean().optional().default(false)
});

// Social crime report schema
const socialCrimeSchema = z.object({
  crimeType: z.string(),
  description: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  address: z.string(),
  imageUrls: z.array(z.string()),
  videoUrls: z.array(z.string()).optional().default([]),
  isAnonymous: z.boolean().optional().default(true)
});

// Update status schema
const updateStatusSchema = z.object({
  status: z.enum(['pending', 'under_review', 'verified', 'approved', 'rejected', 'fine_collected', 'reward_paid']),
  officerComments: z.string().optional()
});

// Generate case number
function generateCaseNumber(): string {
  const date = new Date();
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 999).toString().padStart(3, '0');
  return `TE-${year}-${month}${day}-${random}`;
}

// Fine amounts (in BDT)
const violationFines: Record<string, Record<string, number>> = {
  'Motorbike': {
    'Red Light Jumping': 5000,
    'Wrong Side Driving': 3000,
    'Speeding': 5000,
    'Using Mobile Phone': 2000,
    'Illegal Parking': 2000,
    'No License': 5000,
    'No Helmet': 1000,
    'Driving on Footpath': 3000,
  },
  'Car': {
    'Red Light Jumping': 5000,
    'Wrong Side Driving': 3000,
    'Speeding': 5000,
    'Using Mobile Phone': 2000,
    'Illegal Parking': 4000,
    'No License': 25000,
    'No Seatbelt': 1000,
  },
  'Bus': {
    'Red Light Jumping': 10000,
    'Wrong Side Driving': 5000,
    'Speeding': 10000,
    'Using Mobile Phone': 5000,
    'Illegal Parking': 5000,
    'No License': 50000,
    'Overloading': 10000,
  },
  'Truck': {
    'Red Light Jumping': 10000,
    'Wrong Side Driving': 5000,
    'Speeding': 10000,
    'Using Mobile Phone': 5000,
    'Illegal Parking': 5000,
    'No License': 50000,
    'Overloading': 20000,
  }
};

// Get user from session token
async function getUserFromToken(token: string): Promise<any> {
  try {
    const decoded = JSON.parse(atob(token));
    return decoded;
  } catch {
    return null;
  }
}

// POST /api/reports/traffic - Submit traffic violation report
reports.post('/traffic', zValidator('json', trafficReportSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const reportData = c.req.valid('json');
    const caseNumber = generateCaseNumber();
    
    // Calculate estimated fine and commission
    const estimatedFine = violationFines[reportData.vehicleType]?.[reportData.violationType] || 1000;
    const commission = estimatedFine * 0.20;
    
    // Insert report
    const result = await c.env.DB.prepare(`
      INSERT INTO reports (
        case_number, user_id, report_type, violation_type, vehicle_type, vehicle_number,
        description, latitude, longitude, address, status, is_anonymous, 
        estimated_fine, commission
      ) VALUES (?, ?, 'traffic', ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
    `).bind(
      caseNumber,
      reportData.isAnonymous ? 'anonymous' : session.userId,
      reportData.violationType,
      reportData.vehicleType,
      reportData.vehicleNumber || null,
      reportData.description || null,
      reportData.latitude,
      reportData.longitude,
      reportData.address,
      reportData.isAnonymous,
      estimatedFine,
      commission
    ).run();
    
    const reportId = result.meta.last_row_id;
    
    // Insert attachments
    for (const imageUrl of reportData.imageUrls) {
      await c.env.DB.prepare(`
        INSERT INTO report_attachments (report_id, file_url, file_type)
        VALUES (?, ?, 'image')
      `).bind(reportId, imageUrl).run();
    }
    
    for (const videoUrl of reportData.videoUrls || []) {
      await c.env.DB.prepare(`
        INSERT INTO report_attachments (report_id, file_url, file_type)
        VALUES (?, ?, 'video')
      `).bind(reportId, videoUrl).run();
    }
    
    // Update user report count if not anonymous
    if (!reportData.isAnonymous && session.userId !== 'anonymous') {
      await c.env.DB.prepare(`
        UPDATE users SET total_reports = total_reports + 1, updated_at = datetime('now')
        WHERE uid = ?
      `).bind(session.userId).run();
    }
    
    return c.json({
      success: true,
      caseNumber,
      estimatedReward: commission,
      message: 'Report submitted successfully'
    });
    
  } catch (error) {
    console.error('Traffic report error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/reports/social-crime - Submit social crime report
reports.post('/social-crime', zValidator('json', socialCrimeSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const reportData = c.req.valid('json');
    const caseNumber = generateCaseNumber();
    
    // Insert report
    const result = await c.env.DB.prepare(`
      INSERT INTO reports (
        case_number, user_id, report_type, violation_type,
        description, latitude, longitude, address, status, is_anonymous
      ) VALUES (?, ?, 'social_crime', ?, ?, ?, ?, ?, 'pending', ?)
    `).bind(
      caseNumber,
      reportData.isAnonymous ? 'anonymous' : session.userId,
      reportData.crimeType,
      reportData.description || null,
      reportData.latitude,
      reportData.longitude,
      reportData.address,
      reportData.isAnonymous
    ).run();
    
    const reportId = result.meta.last_row_id;
    
    // Insert attachments
    for (const imageUrl of reportData.imageUrls) {
      await c.env.DB.prepare(`
        INSERT INTO report_attachments (report_id, file_url, file_type)
        VALUES (?, ?, 'image')
      `).bind(reportId, imageUrl).run();
    }
    
    for (const videoUrl of reportData.videoUrls || []) {
      await c.env.DB.prepare(`
        INSERT INTO report_attachments (report_id, file_url, file_type)
        VALUES (?, ?, 'video')
      `).bind(reportId, videoUrl).run();
    }
    
    return c.json({
      success: true,
      caseNumber,
      message: 'Crime report submitted successfully'
    });
    
  } catch (error) {
    console.error('Crime report error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/reports/user/:userId - Get user's reports
reports.get('/user/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    
    const userReports = await c.env.DB.prepare(`
      SELECT r.*, 
        GROUP_CONCAT(ra.file_url) as attachment_urls,
        GROUP_CONCAT(ra.file_type) as attachment_types
      FROM reports r
      LEFT JOIN report_attachments ra ON r.id = ra.report_id
      WHERE r.user_id = ?
      GROUP BY r.id
      ORDER BY r.created_at DESC
    `).bind(userId).all();
    
    return c.json({
      success: true,
      reports: (userReports.results as any[]).map((report: any) => ({
        ...report,
        attachments: report.attachment_urls ? 
          (report.attachment_urls as string).split(',').map((url: string, index: number) => ({
            url,
            type: (report.attachment_types as string).split(',')[index]
          })) : []
      }))
    });
    
  } catch (error) {
    console.error('Get user reports error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/reports/case/:caseNumber - Get report by case number
reports.get('/case/:caseNumber', async (c) => {
  try {
    const caseNumber = c.req.param('caseNumber');
    
    const report = await c.env.DB.prepare(`
      SELECT r.*, 
        GROUP_CONCAT(ra.file_url) as attachment_urls,
        GROUP_CONCAT(ra.file_type) as attachment_types
      FROM reports r
      LEFT JOIN report_attachments ra ON r.id = ra.report_id
      WHERE r.case_number = ?
      GROUP BY r.id
    `).bind(caseNumber).first();
    
    if (!report) {
      return c.json({ error: 'Report not found' }, 404);
    }
    
    return c.json({
      success: true,
      report: {
        ...report,
        attachments: (report as any).attachment_urls ? 
          ((report as any).attachment_urls as string).split(',').map((url: string, index: number) => ({
            url,
            type: ((report as any).attachment_types as string).split(',')[index]
          })) : []
      }
    });
    
  } catch (error) {
    console.error('Get report by case error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/reports/:id/status - Update report status (officer only)
reports.put('/:id/status', zValidator('json', updateStatusSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session || session.userType !== 'officer') {
      return c.json({ error: 'Forbidden - Officer access required' }, 403);
    }
    
    const reportId = c.req.param('id');
    const { status, officerComments } = c.req.valid('json');
    
    // Update report status
    await c.env.DB.prepare(`
      UPDATE reports SET 
        status = ?, 
        officer_id = ?, 
        officer_comments = ?,
        reviewed_at = datetime('now'),
        updated_at = datetime('now')
      WHERE id = ?
    `).bind(status, session.userId, officerComments || null, reportId).run();
    
    // If approved, update user's approved count and pending rewards
    if (status === 'approved') {
      const report = await c.env.DB.prepare('SELECT * FROM reports WHERE id = ?').bind(reportId).first();
      if (report && !report.is_anonymous && report.user_id !== 'anonymous') {
        await c.env.DB.prepare(`
          UPDATE users SET 
            approved_reports = approved_reports + 1,
            pending_rewards = pending_rewards + ?,
            updated_at = datetime('now')
          WHERE uid = ?
        `).bind(report.commission, report.user_id).run();
      }
    }
    
    return c.json({ success: true, message: 'Report status updated' });
    
  } catch (error) {
    console.error('Update status error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default reports;
