import { Hono } from "hono";

const officers = new Hono<{ Bindings: Env }>();

// Get user from session token
async function getUserFromToken(token: string): Promise<any> {
  try {
    const decoded = JSON.parse(atob(token));
    return decoded;
  } catch {
    return null;
  }
}

// GET /api/officers/pending-reports - Get all pending reports for officers
officers.get('/pending-reports', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session || session.userType !== 'officer') {
      return c.json({ error: 'Forbidden - Officer access required' }, 403);
    }
    
    const priority = c.req.query('priority');
    let whereClause = "WHERE r.status IN ('pending', 'under_review')";
    
    if (priority && priority !== 'all') {
      // Add priority filtering based on violation type and time
      const priorityConditions: Record<string, string> = {
        'high': "AND (r.violation_type IN ('Red Light Jumping', 'Wrong Side Driving', 'No License') OR r.estimated_fine > 5000)",
        'medium': "AND (r.estimated_fine BETWEEN 2000 AND 5000)",
        'low': "AND (r.estimated_fine < 2000)"
      };
      whereClause += ` ${priorityConditions[priority] || ''}`;
    }
    
    const pendingReports = await c.env.DB.prepare(`
      SELECT r.*, 
        u.full_name as reporter_name,
        u.is_verified as reporter_verified,
        COUNT(ra.id) as evidence_count,
        GROUP_CONCAT(ra.file_url) as attachment_urls,
        GROUP_CONCAT(ra.file_type) as attachment_types
      FROM reports r
      LEFT JOIN users u ON r.user_id = u.uid
      LEFT JOIN report_attachments ra ON r.id = ra.report_id
      ${whereClause}
      GROUP BY r.id
      ORDER BY 
        CASE 
          WHEN r.violation_type IN ('Red Light Jumping', 'Wrong Side Driving') THEN 1
          WHEN r.estimated_fine > 5000 THEN 2
          ELSE 3
        END,
        r.created_at ASC
    `).all();
    
    return c.json({
      success: true,
      reports: (pendingReports.results as any[]).map((report: any) => ({
        ...report,
        priority: (report.violation_type as string)?.includes('Red Light') || 
                 (report.violation_type as string)?.includes('Wrong Side') || 
                 (report.estimated_fine as number) > 5000 ? 'high' :
                 (report.estimated_fine as number) >= 2000 ? 'medium' : 'low',
        attachments: report.attachment_urls ? 
          (report.attachment_urls as string).split(',').map((url: string, index: number) => ({
            url,
            type: (report.attachment_types as string).split(',')[index]
          })) : []
      }))
    });
    
  } catch (error) {
    console.error('Get pending reports error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/officers/review/:reportId - Quick review action
officers.put('/review/:reportId', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session || session.userType !== 'officer') {
      return c.json({ error: 'Forbidden - Officer access required' }, 403);
    }
    
    const reportId = c.req.param('reportId');
    const { action, comments } = await c.req.json();
    
    if (!['approve', 'reject', 'review'].includes(action)) {
      return c.json({ error: 'Invalid action' }, 400);
    }
    
    const statusMap: Record<string, string> = {
      'approve': 'approved',
      'reject': 'rejected',
      'review': 'under_review'
    };
    
    const status = statusMap[action];
    
    // Update report
    await c.env.DB.prepare(`
      UPDATE reports SET 
        status = ?, 
        officer_id = ?, 
        officer_comments = ?,
        reviewed_at = datetime('now'),
        updated_at = datetime('now')
      WHERE id = ?
    `).bind(status, session.userId, comments || null, reportId).run();
    
    // If approved, update user stats
    if (action === 'approve') {
      const report = await c.env.DB.prepare('SELECT * FROM reports WHERE id = ?').bind(reportId).first();
      if (report && !report.is_anonymous && report.user_id !== 'anonymous') {
        await c.env.DB.prepare(`
          UPDATE users SET 
            approved_reports = approved_reports + 1,
            pending_rewards = pending_rewards + ?,
            updated_at = datetime('now')
          WHERE uid = ?
        `).bind(report.commission, report.user_id).run();
      }
    }
    
    return c.json({ 
      success: true, 
      message: `Report ${action}ed successfully` 
    });
    
  } catch (error) {
    console.error('Review action error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/officers/statistics - Get officer dashboard statistics
officers.get('/statistics', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session || session.userType !== 'officer') {
      return c.json({ error: 'Forbidden - Officer access required' }, 403);
    }
    
    // Get overall statistics
    const totalStats = await c.env.DB.prepare(`
      SELECT 
        COUNT(*) as total_reports,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_reports,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_reports,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_reports,
        SUM(CASE WHEN officer_id = ? AND DATE(reviewed_at) = DATE('now') THEN 1 ELSE 0 END) as reviewed_today
      FROM reports
    `).bind(session.userId).first();
    
    // Get report breakdown by type
    const typeBreakdown = await c.env.DB.prepare(`
      SELECT 
        report_type,
        COUNT(*) as count
      FROM reports
      GROUP BY report_type
    `).all();
    
    return c.json({
      success: true,
      statistics: {
        total: (totalStats as any)?.total_reports || 0,
        pending: (totalStats as any)?.pending_reports || 0,
        approved: (totalStats as any)?.approved_reports || 0,
        rejected: (totalStats as any)?.rejected_reports || 0,
        reviewedToday: (totalStats as any)?.reviewed_today || 0,
        typeBreakdown: typeBreakdown.results
      }
    });
    
  } catch (error) {
    console.error('Get statistics error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default officers;
