import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";

const users = new Hono<{ Bindings: Env }>();

// KYC update schema
const kycSchema = z.object({
  nidNumber: z.string().optional(),
  drivingLicense: z.string().optional(),
  passportNumber: z.string().optional(),
  documentUrls: z.array(z.string()).optional()
});

// Biometric update schema
const biometricSchema = z.object({
  selfieUrls: z.array(z.string())
});

// Wallet setup schema
const walletSchema = z.object({
  paymentMethod: z.string(),
  walletNumber: z.string()
});

// Get user from session token
async function getUserFromToken(token: string): Promise<any> {
  try {
    const decoded = JSON.parse(atob(token));
    return decoded;
  } catch {
    return null;
  }
}

// GET /api/users/profile - Get user profile
users.get('/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const user = await c.env.DB.prepare(`
      SELECT 
        uid, phone_number, email, full_name, user_type, is_verified,
        nid_number, driving_license, passport_number, document_urls,
        selfie_urls, is_biometric_verified,
        payment_method, wallet_number, is_wallet_verified,
        total_reports, approved_reports, total_rewards, pending_rewards,
        badge_number, rank, department,
        created_at, updated_at
      FROM users 
      WHERE uid = ?
    `).bind(session.userId).first();
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    // Parse JSON fields
    const profile = {
      ...user,
      documentUrls: (user as any).document_urls ? JSON.parse((user as any).document_urls as string) : [],
      selfieUrls: (user as any).selfie_urls ? JSON.parse((user as any).selfie_urls as string) : []
    };
    
    return c.json({ success: true, user: profile });
    
  } catch (error) {
    console.error('Get profile error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/users/profile - Update user profile
users.put('/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const { fullName, email } = await c.req.json();
    
    await c.env.DB.prepare(`
      UPDATE users SET 
        full_name = COALESCE(?, full_name),
        email = COALESCE(?, email),
        updated_at = datetime('now')
      WHERE uid = ?
    `).bind(fullName || null, email || null, session.userId).run();
    
    return c.json({ success: true, message: 'Profile updated successfully' });
    
  } catch (error) {
    console.error('Update profile error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/users/kyc - Update KYC information
users.put('/kyc', zValidator('json', kycSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const { nidNumber, drivingLicense, passportNumber, documentUrls } = c.req.valid('json');
    
    await c.env.DB.prepare(`
      UPDATE users SET 
        nid_number = COALESCE(?, nid_number),
        driving_license = COALESCE(?, driving_license),
        passport_number = COALESCE(?, passport_number),
        document_urls = COALESCE(?, document_urls),
        updated_at = datetime('now')
      WHERE uid = ?
    `).bind(
      nidNumber || null,
      drivingLicense || null,
      passportNumber || null,
      documentUrls ? JSON.stringify(documentUrls) : null,
      session.userId
    ).run();
    
    return c.json({ success: true, message: 'KYC information updated successfully' });
    
  } catch (error) {
    console.error('Update KYC error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/users/biometric - Update biometric verification
users.put('/biometric', zValidator('json', biometricSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const { selfieUrls } = c.req.valid('json');
    
    await c.env.DB.prepare(`
      UPDATE users SET 
        selfie_urls = ?,
        is_biometric_verified = true,
        updated_at = datetime('now')
      WHERE uid = ?
    `).bind(JSON.stringify(selfieUrls), session.userId).run();
    
    return c.json({ success: true, message: 'Biometric verification completed successfully' });
    
  } catch (error) {
    console.error('Update biometric error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/users/wallet - Setup wallet information
users.put('/wallet', zValidator('json', walletSchema), async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const { paymentMethod, walletNumber } = c.req.valid('json');
    
    // Generate OTP for wallet verification
    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes
    
    // Store OTP for wallet verification
    await c.env.DB.prepare(`
      INSERT INTO otp_verifications (phone_number, otp_code, purpose, expires_at)
      VALUES (?, ?, 'wallet_verify', ?)
    `).bind(walletNumber, otpCode, expiresAt.toISOString()).run();
    
    // Store wallet info (unverified)
    await c.env.DB.prepare(`
      UPDATE users SET 
        payment_method = ?,
        wallet_number = ?,
        is_wallet_verified = false,
        updated_at = datetime('now')
      WHERE uid = ?
    `).bind(paymentMethod, walletNumber, session.userId).run();
    
    // In production, send OTP to wallet number via payment API
    console.log(`Wallet OTP for ${walletNumber}: ${otpCode}`);
    
    return c.json({ 
      success: true, 
      message: 'OTP sent to wallet number',
      // Remove in production
      debug: { otpCode }
    });
    
  } catch (error) {
    console.error('Setup wallet error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/users/verify-wallet - Verify wallet with OTP
users.post('/verify-wallet', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const token = authHeader.split(' ')[1];
    const session = await getUserFromToken(token);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }
    
    const { otpCode } = await c.req.json();
    
    // Get user's wallet number
    const user = await c.env.DB.prepare('SELECT wallet_number FROM users WHERE uid = ?').bind(session.userId).first();
    if (!user?.wallet_number) {
      return c.json({ error: 'No wallet setup found' }, 400);
    }
    
    // Verify OTP
    const otpRecord = await c.env.DB.prepare(`
      SELECT * FROM otp_verifications 
      WHERE phone_number = ? AND otp_code = ? AND purpose = 'wallet_verify' 
      AND is_verified = false AND expires_at > datetime('now')
      ORDER BY created_at DESC LIMIT 1
    `).bind(user.wallet_number, otpCode).first();
    
    if (!otpRecord) {
      return c.json({ error: 'Invalid or expired OTP' }, 400);
    }
    
    // Mark OTP as verified
    await c.env.DB.prepare('UPDATE otp_verifications SET is_verified = true WHERE id = ?').bind(otpRecord.id).run();
    
    // Mark wallet as verified
    await c.env.DB.prepare(`
      UPDATE users SET 
        is_wallet_verified = true,
        updated_at = datetime('now')
      WHERE uid = ?
    `).bind(session.userId).run();
    
    return c.json({ success: true, message: 'Wallet verified successfully' });
    
  } catch (error) {
    console.error('Verify wallet error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default users;
