import { useState } from 'react';
import { X, Smartphone, Download, QrCode, ExternalLink, Apple, Chrome } from 'lucide-react';
import CustomButton from './CustomButton';

interface AppInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
}

export default function AppInstallModal({ isOpen, onClose, language }: AppInstallModalProps) {
  const [selectedPlatform, setSelectedPlatform] = useState<'android' | 'ios' | null>(null);

  const content = {
    en: {
      title: 'Install Mobile App',
      subtitle: 'Get the full Third Eye Bangladesh experience on your mobile device',
      
      // Platform selection
      chooseDevice: 'Choose Your Device',
      android: 'Android Phone',
      ios: 'iPhone / iPad',
      
      // Android section
      androidTitle: 'Install on Android',
      androidDesc: 'Download from Google Play Store or scan QR code',
      playStore: 'Download from Play Store',
      playStoreDesc: 'Official app from Google Play Store',
      sideload: 'Download APK (Advanced)',
      sideloadDesc: 'For devices without Google Play Store access',
      scanQr: 'Scan QR Code',
      scanQrDesc: 'Point your camera at this QR code to install',
      
      // iOS section
      iosTitle: 'Install on iPhone/iPad',
      iosDesc: 'Download from Apple App Store or scan QR code',
      appStore: 'Download from App Store',
      appStoreDesc: 'Official app from Apple App Store',
      testFlight: 'Join Beta (TestFlight)',
      testFlightDesc: 'Try the latest features before everyone else',
      
      // Features
      features: 'Mobile App Features',
      featureList: [
        'Quick photo & video capture for evidence',
        'GPS location tracking for accurate reports',
        'Offline report drafting',
        'Push notifications for case updates',
        'Voice notes and audio evidence',
        'Biometric login (fingerprint/face)',
        'Emergency quick report button',
        'Dark mode support'
      ],
      
      // Installation steps
      steps: 'Installation Steps',
      androidSteps: [
        'Tap "Download from Play Store" button',
        'You\'ll be redirected to Google Play Store',
        'Tap "Install" to download the app',
        'Open the app and login with your credentials'
      ],
      iosSteps: [
        'Tap "Download from App Store" button',
        'You\'ll be redirected to Apple App Store',
        'Tap "Get" to download the app',
        'Open the app and login with your credentials'
      ],
      
      // QR Code
      qrInstructions: 'QR Code Instructions',
      qrSteps: [
        'Open your phone\'s camera app',
        'Point the camera at the QR code',
        'Tap the notification that appears',
        'Follow the installation instructions'
      ],
      
      // Actions
      downloadNow: 'Download Now',
      openInBrowser: 'Open in Browser',
      close: 'Close',
      back: 'Back to Device Selection',
      copyLink: 'Copy Link',
      linkCopied: 'Link copied to clipboard!',
      
      // Requirements
      requirements: 'System Requirements',
      androidReq: 'Android 6.0 or later • 50MB storage space',
      iosReq: 'iOS 12.0 or later • 50MB storage space',
      
      // Benefits
      whyMobile: 'Why Use the Mobile App?',
      benefits: [
        'Faster report submission with camera integration',
        'Real-time notifications for your cases',
        'Work offline and sync when connected',
        'Better location accuracy with GPS',
        'Secure biometric authentication'
      ]
    },
    bn: {
      title: 'মোবাইল অ্যাপ ইনস্টল',
      subtitle: 'আপনার মোবাইল ডিভাইসে সম্পূর্ণ থার্ড আই বাংলাদেশ অভিজ্ঞতা পান',
      
      // Platform selection
      chooseDevice: 'আপনার ডিভাইস বেছে নিন',
      android: 'অ্যান্ড্রয়েড ফোন',
      ios: 'আইফোন / আইপ্যাড',
      
      // Android section
      androidTitle: 'অ্যান্ড্রয়েডে ইনস্টল করুন',
      androidDesc: 'গুগল প্লে স্টোর থেকে ডাউনলোড করুন বা QR কোড স্ক্যান করুন',
      playStore: 'প্লে স্টোর থেকে ডাউনলোড',
      playStoreDesc: 'গুগল প্লে স্টোর থেকে অফিসিয়াল অ্যাপ',
      sideload: 'APK ডাউনলোড (উন্নত)',
      sideloadDesc: 'গুগল প্লে স্টোর অ্যাক্সেস নেই এমন ডিভাইসের জন্য',
      scanQr: 'QR কোড স্ক্যান করুন',
      scanQrDesc: 'ইনস্টল করতে এই QR কোডে আপনার ক্যামেরা তাক করুন',
      
      // iOS section
      iosTitle: 'আইফোন/আইপ্যাডে ইনস্টল করুন',
      iosDesc: 'অ্যাপল অ্যাপ স্টোর থেকে ডাউনলোড করুন বা QR কোড স্ক্যান করুন',
      appStore: 'অ্যাপ স্টোর থেকে ডাউনলোড',
      appStoreDesc: 'অ্যাপল অ্যাপ স্টোর থেকে অফিসিয়াল অ্যাপ',
      testFlight: 'বেটা যোগ দিন (টেস্টফ্লাইট)',
      testFlightDesc: 'অন্যদের আগে সর্বশেষ ফিচার ব্যবহার করুন',
      
      // Features
      features: 'মোবাইল অ্যাপের বৈশিষ্ট্য',
      featureList: [
        'প্রমাণের জন্য দ্রুত ছবি ও ভিডিও ধারণ',
        'নির্ভুল রিপোর্টের জন্য GPS অবস্থান ট্র্যাকিং',
        'অফলাইন রিপোর্ট খসড়া তৈরি',
        'কেস আপডেটের জন্য পুশ নোটিফিকেশন',
        'ভয়েস নোট এবং অডিও প্রমাণ',
        'বায়োমেট্রিক লগইন (আঙুলের ছাপ/মুখ)',
        'জরুরি দ্রুত রিপোর্ট বাটন',
        'ডার্ক মোড সাপোর্ট'
      ],
      
      // Installation steps
      steps: 'ইনস্টলেশন ধাপ',
      androidSteps: [
        '"প্লে স্টোর থেকে ডাউনলোড" বাটনে ট্যাপ করুন',
        'আপনি গুগল প্লে স্টোরে রিডাইরেক্ট হবেন',
        'অ্যাপ ডাউনলোড করতে "ইনস্টল" এ ট্যাপ করুন',
        'অ্যাপ খুলুন এবং আপনার পরিচয়পত্র দিয়ে লগইন করুন'
      ],
      iosSteps: [
        '"অ্যাপ স্টোর থেকে ডাউনলোড" বাটনে ট্যাপ করুন',
        'আপনি অ্যাপল অ্যাপ স্টোরে রিডাইরেক্ট হবেন',
        'অ্যাপ ডাউনলোড করতে "Get" এ ট্যাপ করুন',
        'অ্যাপ খুলুন এবং আপনার পরিচয়পত্র দিয়ে লগইন করুন'
      ],
      
      // QR Code
      qrInstructions: 'QR কোড নির্দেশনা',
      qrSteps: [
        'আপনার ফোনের ক্যামেরা অ্যাপ খুলুন',
        'QR কোডে ক্যামেরা তাক করুন',
        'যে নোটিফিকেশন আসবে সেটিতে ট্যাপ করুন',
        'ইনস্টলেশন নির্দেশনা অনুসরণ করুন'
      ],
      
      // Actions
      downloadNow: 'এখনই ডাউনলোড',
      openInBrowser: 'ব্রাউজারে খুলুন',
      close: 'বন্ধ করুন',
      back: 'ডিভাইস নির্বাচনে ফিরুন',
      copyLink: 'লিংক কপি',
      linkCopied: 'লিংক ক্লিপবোর্ডে কপি হয়েছে!',
      
      // Requirements
      requirements: 'সিস্টেম প্রয়োজনীয়তা',
      androidReq: 'অ্যান্ড্রয়েড ৬.০ বা পরবর্তী • ৫০MB স্টোরেজ স্থান',
      iosReq: 'iOS ১২.০ বা পরবর্তী • ৫০MB স্টোরেজ স্থান',
      
      // Benefits
      whyMobile: 'মোবাইল অ্যাপ কেন ব্যবহার করবেন?',
      benefits: [
        'ক্যামেরা ইন্টিগ্রেশনের সাথে দ্রুত রিপোর্ট জমা',
        'আপনার কেসের রিয়েল-টাইম নোটিফিকেশন',
        'অফলাইনে কাজ করুন এবং সংযুক্ত হলে সিঙ্ক করুন',
        'GPS এর সাথে আরও ভাল অবস্থানের নির্ভুলতা',
        'নিরাপদ বায়োমেট্রিক প্রমাণীকরণ'
      ]
    }
  };

  const currentContent = content[language];

  // Mock app store URLs (replace with actual URLs)
  const appUrls = {
    android: {
      playStore: 'https://play.google.com/store/apps/details?id=bd.gov.thirdeye',
      apk: 'https://github.com/thirdeye-bd/releases/download/v1.0.0/thirdeye-v1.0.0.apk'
    },
    ios: {
      appStore: 'https://apps.apple.com/app/third-eye-bangladesh/id1234567890',
      testFlight: 'https://testflight.apple.com/join/ThirdEyeBD'
    }
  };

  if (!isOpen) return null;

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    alert(currentContent.linkCopied);
  };

  const QRCodePlaceholder = ({ size = 120 }: { size?: number }) => (
    <div 
      className="bg-gray-200 border border-gray-300 flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <QrCode className="w-8 h-8 text-gray-400" />
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            {selectedPlatform && (
              <button
                onClick={() => setSelectedPlatform(null)}
                className="p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="w-4 h-4 rotate-45" />
              </button>
            )}
            <div>
              <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
              <p className="text-gray-600 text-sm">{currentContent.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Platform Selection */}
          {!selectedPlatform && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.chooseDevice}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Android */}
                  <div
                    onClick={() => setSelectedPlatform('android')}
                    className="p-6 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-green-400 hover:bg-green-50 transition-colors"
                  >
                    <div className="text-center">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Chrome className="w-8 h-8 text-green-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900">{currentContent.android}</h4>
                      <p className="text-gray-600 text-sm mt-1">{currentContent.androidReq}</p>
                    </div>
                  </div>

                  {/* iOS */}
                  <div
                    onClick={() => setSelectedPlatform('ios')}
                    className="p-6 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors"
                  >
                    <div className="text-center">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Apple className="w-8 h-8 text-blue-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900">{currentContent.ios}</h4>
                      <p className="text-gray-600 text-sm mt-1">{currentContent.iosReq}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{currentContent.features}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {currentContent.featureList.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <Smartphone className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Why Mobile */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{currentContent.whyMobile}</h3>
                <div className="space-y-2">
                  {currentContent.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <Download className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Android Installation */}
          {selectedPlatform === 'android' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Chrome className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{currentContent.androidTitle}</h3>
                <p className="text-gray-600">{currentContent.androidDesc}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Download Options */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Download Options</h4>
                  
                  {/* Play Store */}
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Chrome className="w-8 h-8 text-green-600 mt-1" />
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{currentContent.playStore}</h5>
                        <p className="text-gray-600 text-sm mb-3">{currentContent.playStoreDesc}</p>
                        <div className="space-y-2">
                          <CustomButton
                            onClick={() => window.open(appUrls.android.playStore, '_blank')}
                            variant="primary"
                            className="w-full"
                            icon={<ExternalLink className="w-4 h-4" />}
                          >
                            {currentContent.downloadNow}
                          </CustomButton>
                          <button
                            onClick={() => handleCopyLink(appUrls.android.playStore)}
                            className="w-full py-2 text-green-600 hover:bg-green-50 rounded text-sm font-medium"
                          >
                            {currentContent.copyLink}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* APK Download */}
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Download className="w-8 h-8 text-orange-600 mt-1" />
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{currentContent.sideload}</h5>
                        <p className="text-gray-600 text-sm mb-3">{currentContent.sideloadDesc}</p>
                        <CustomButton
                          onClick={() => window.open(appUrls.android.apk, '_blank')}
                          variant="outline"
                          className="w-full"
                          icon={<Download className="w-4 h-4" />}
                        >
                          Download APK
                        </CustomButton>
                      </div>
                    </div>
                  </div>
                </div>

                {/* QR Code */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">{currentContent.scanQr}</h4>
                  <div className="text-center">
                    <QRCodePlaceholder size={150} />
                    <p className="text-gray-600 text-sm mt-2">{currentContent.scanQrDesc}</p>
                  </div>
                  
                  <div>
                    <h5 className="font-medium text-gray-900 mb-2">{currentContent.qrInstructions}</h5>
                    <ol className="text-sm text-gray-600 space-y-1">
                      {currentContent.qrSteps.map((step, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="font-medium text-green-600">{index + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>

              {/* Installation Steps */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">{currentContent.steps}</h4>
                <ol className="space-y-2">
                  {currentContent.androidSteps.map((step, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <span className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </span>
                      <span className="text-gray-700">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          )}

          {/* iOS Installation */}
          {selectedPlatform === 'ios' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Apple className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{currentContent.iosTitle}</h3>
                <p className="text-gray-600">{currentContent.iosDesc}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Download Options */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Download Options</h4>
                  
                  {/* App Store */}
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Apple className="w-8 h-8 text-blue-600 mt-1" />
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{currentContent.appStore}</h5>
                        <p className="text-gray-600 text-sm mb-3">{currentContent.appStoreDesc}</p>
                        <div className="space-y-2">
                          <CustomButton
                            onClick={() => window.open(appUrls.ios.appStore, '_blank')}
                            variant="primary"
                            className="w-full bg-blue-600 hover:bg-blue-700"
                            icon={<ExternalLink className="w-4 h-4" />}
                          >
                            {currentContent.downloadNow}
                          </CustomButton>
                          <button
                            onClick={() => handleCopyLink(appUrls.ios.appStore)}
                            className="w-full py-2 text-blue-600 hover:bg-blue-50 rounded text-sm font-medium"
                          >
                            {currentContent.copyLink}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* TestFlight */}
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Smartphone className="w-8 h-8 text-purple-600 mt-1" />
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{currentContent.testFlight}</h5>
                        <p className="text-gray-600 text-sm mb-3">{currentContent.testFlightDesc}</p>
                        <CustomButton
                          onClick={() => window.open(appUrls.ios.testFlight, '_blank')}
                          variant="outline"
                          className="w-full"
                          icon={<ExternalLink className="w-4 h-4" />}
                        >
                          Join Beta
                        </CustomButton>
                      </div>
                    </div>
                  </div>
                </div>

                {/* QR Code */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">{currentContent.scanQr}</h4>
                  <div className="text-center">
                    <QRCodePlaceholder size={150} />
                    <p className="text-gray-600 text-sm mt-2">{currentContent.scanQrDesc}</p>
                  </div>
                  
                  <div>
                    <h5 className="font-medium text-gray-900 mb-2">{currentContent.qrInstructions}</h5>
                    <ol className="text-sm text-gray-600 space-y-1">
                      {currentContent.qrSteps.map((step, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="font-medium text-blue-600">{index + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>

              {/* Installation Steps */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">{currentContent.steps}</h4>
                <ol className="space-y-2">
                  {currentContent.iosSteps.map((step, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <span className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </span>
                      <span className="text-gray-700">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 p-6">
          <button
            onClick={onClose}
            className="w-full py-3 px-4 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
          >
            {currentContent.close}
          </button>
        </div>
      </div>
    </div>
  );
}
