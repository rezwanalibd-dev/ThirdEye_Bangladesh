import { useState } from 'react';
import { Download, X, Smartphone } from 'lucide-react';
import { usePWA } from '@/react-app/hooks/usePWA';
import CustomButton from './CustomButton';

interface PWAInstallPromptProps {
  language: 'en' | 'bn';
}

export default function PWAInstallPrompt({ language }: PWAInstallPromptProps) {
  const { isInstallable, installApp } = usePWA();
  const [isDismissed, setIsDismissed] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  const content = {
    en: {
      title: 'Install Third Eye Bangladesh',
      description: 'Install our app for a better experience',
      install: 'Install App',
      later: 'Maybe Later',
      features: [
        '📱 Quick access from home screen',
        '⚡ Faster performance',
        '🔔 Push notifications',
        '📵 Works offline'
      ]
    },
    bn: {
      title: 'থার্ড আই বাংলাদেশ ইনস্টল করুন',
      description: 'আরও ভালো অভিজ্ঞতার জন্য আমাদের অ্যাপ ইনস্টল করুন',
      install: 'অ্যাপ ইনস্টল করুন',
      later: 'পরে করব',
      features: [
        '📱 হোম স্ক্রীন থেকে দ্রুত অ্যাক্সেস',
        '⚡ দ্রুততর পারফরম্যান্স',
        '🔔 পুশ নোটিফিকেশন',
        '📵 অফলাইনে কাজ করে'
      ]
    }
  };

  const currentContent = content[language];

  if (!isInstallable || isDismissed) {
    return null;
  }

  const handleInstall = async () => {
    setIsInstalling(true);
    const success = await installApp();
    setIsInstalling(false);
    
    if (success) {
      setIsDismissed(true);
    }
  };

  return (
    <div className="fixed bottom-20 left-4 right-4 bg-white rounded-xl shadow-2xl border-2 border-green-500 p-4 z-50 animate-slide-up">
      <button
        onClick={() => setIsDismissed(true)}
        className="absolute top-2 right-2 p-1 hover:bg-gray-100 rounded-full transition-colors"
      >
        <X className="w-4 h-4 text-gray-500" />
      </button>

      <div className="flex items-start space-x-3 mb-3">
        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
          <Smartphone className="w-6 h-6 text-green-600" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-gray-900 text-sm mb-1">
            {currentContent.title}
          </h3>
          <p className="text-gray-600 text-xs mb-2">
            {currentContent.description}
          </p>
        </div>
      </div>

      <div className="mb-3 pl-15">
        <div className="grid grid-cols-2 gap-1 text-xs text-gray-700">
          {currentContent.features.map((feature, index) => (
            <div key={index}>{feature}</div>
          ))}
        </div>
      </div>

      <div className="flex space-x-2">
        <CustomButton
          variant="primary"
          size="sm"
          className="flex-1"
          onClick={handleInstall}
          loading={isInstalling}
          icon={<Download className="w-4 h-4" />}
        >
          {currentContent.install}
        </CustomButton>
        <CustomButton
          variant="ghost"
          size="sm"
          className="flex-1"
          onClick={() => setIsDismissed(true)}
        >
          {currentContent.later}
        </CustomButton>
      </div>
    </div>
  );
}
