import { Home, Search, Plus, Bell, User } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  language: 'en' | 'bn';
}

export default function BottomNavigation({ activeTab, onTabChange, language }: BottomNavigationProps) {
  const content = {
    en: {
      home: 'Home',
      search: 'Search',
      report: 'Report',
      alerts: 'Alerts',
      profile: 'Profile'
    },
    bn: {
      home: 'হোম',
      search: 'খুঁজুন',
      report: 'রিপোর্ট',
      alerts: 'সতর্কতা',
      profile: 'প্রোফাইল'
    }
  };

  const currentContent = content[language];

  const tabs = [
    { id: 'home', icon: Home, label: currentContent.home, path: '/dashboard' },
    { id: 'search', icon: Search, label: currentContent.search, path: '/case-tracking' },
    { id: 'report', icon: Plus, label: currentContent.report, path: '/report-traffic', isSpecial: true },
    { id: 'alerts', icon: Bell, label: currentContent.alerts, path: '/alerts' },
    { id: 'profile', icon: User, label: currentContent.profile, path: '/profile' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-2 z-50">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              onTabChange(tab.id);
              if (tab.path) {
                // Use React Router navigation instead of window.location
                if (typeof window !== 'undefined' && window.history) {
                  window.history.pushState({}, '', tab.path);
                  window.dispatchEvent(new PopStateEvent('popstate'));
                } else {
                  window.location.href = tab.path;
                }
              }
            }}
            className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-lg transition-all ${
              activeTab === tab.id
                ? tab.isSpecial
                  ? 'text-white'
                  : 'text-green-600 bg-green-50'
                : 'text-gray-500 hover:text-gray-700'
            } ${tab.isSpecial ? 'relative' : ''}`}
          >
            {tab.isSpecial ? (
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center shadow-lg">
                <tab.icon className="w-6 h-6" />
              </div>
            ) : (
              <tab.icon className={`w-5 h-5 ${activeTab === tab.id ? 'text-green-600' : ''}`} />
            )}
            <span className={`text-xs font-medium ${
              tab.isSpecial && activeTab === tab.id ? 'text-green-600' : ''
            }`}>
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
