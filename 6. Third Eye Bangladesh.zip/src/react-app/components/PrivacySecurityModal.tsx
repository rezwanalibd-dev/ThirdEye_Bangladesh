import { useState } from 'react';
import { X, Shield, Eye, Download, Database, AlertTriangle } from 'lucide-react';
import CustomButton from './CustomButton';

interface PrivacySecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
}

export default function PrivacySecurityModal({ isOpen, onClose, language }: PrivacySecurityModalProps) {
  const [activeTab, setActiveTab] = useState<'privacy' | 'security' | 'data'>('privacy');
  const [showSessions, setShowSessions] = useState(false);

  const content = {
    en: {
      title: 'Privacy & Security',
      privacy: 'Privacy',
      security: 'Security',
      dataManagement: 'Data Management',
      
      // Privacy Tab
      profileVisibility: 'Profile Visibility',
      profileVisibilityDesc: 'Control who can see your profile information',
      publicProfile: 'Public Profile',
      friendsOnly: 'Friends Only',
      privateProfile: 'Private Profile',
      locationSharing: 'Location Sharing',
      locationSharingDesc: 'Share your location for better report accuracy',
      alwaysShare: 'Always Share',
      askEachTime: 'Ask Each Time',
      neverShare: 'Never Share',
      anonymousReports: 'Anonymous Reports',
      anonymousReportsDesc: 'Allow submitting reports without revealing identity',
      
      // Security Tab
      activeSessions: 'Active Sessions',
      activeSessionsDesc: 'Manage devices logged into your account',
      twoFactorAuth: '2FA Authentication',
      twoFactorAuthDesc: 'Add extra security to your account',
      enable2FA: 'Enable 2FA',
      disable2FA: 'Disable 2FA',
      loginAlerts: 'Login Alerts',
      loginAlertsDesc: 'Get notified of new login attempts',
      viewSessions: 'View Sessions',
      hideSessions: 'Hide Sessions',
      
      // Data Management Tab
      downloadData: 'Download My Data',
      downloadDataDesc: 'Download all your data in a portable format',
      deleteData: 'Delete Account Data',
      deleteDataDesc: 'Permanently delete your account and all data',
      dataRetention: 'Data Retention',
      dataRetentionDesc: 'Control how long we keep your data',
      
      // Session Info
      currentDevice: 'Current Device',
      lastActive: 'Last Active',
      location: 'Location',
      browser: 'Browser',
      terminateSession: 'Terminate',
      terminateAll: 'Terminate All Other Sessions',
      
      // Actions
      save: 'Save Changes',
      cancel: 'Cancel',
      download: 'Download',
      delete: 'Delete',
      enable: 'Enable',
      disable: 'Disable',
      
      // Success/Error messages
      settingsUpdated: 'Privacy settings updated successfully!',
      dataDownloaded: 'Data download started. You will receive an email when ready.',
      sessionTerminated: 'Session terminated successfully',
      allSessionsTerminated: 'All other sessions terminated successfully'
    },
    bn: {
      title: 'গোপনীয়তা ও নিরাপত্তা',
      privacy: 'গোপনীয়তা',
      security: 'নিরাপত্তা',
      dataManagement: 'ডেটা ব্যবস্থাপনা',
      
      // Privacy Tab
      profileVisibility: 'প্রোফাইল দৃশ্যমানতা',
      profileVisibilityDesc: 'কে আপনার প্রোফাইল তথ্য দেখতে পারবে তা নিয়ন্ত্রণ করুন',
      publicProfile: 'পাবলিক প্রোফাইল',
      friendsOnly: 'শুধুমাত্র বন্ধুরা',
      privateProfile: 'ব্যক্তিগত প্রোফাইল',
      locationSharing: 'অবস্থান ভাগাভাগি',
      locationSharingDesc: 'আরও ভাল রিপোর্ট নির্ভুলতার জন্য আপনার অবস্থান ভাগ করুন',
      alwaysShare: 'সর্বদা ভাগ করুন',
      askEachTime: 'প্রতিবার জিজ্ঞাসা করুন',
      neverShare: 'কখনও ভাগ করবেন না',
      anonymousReports: 'বেনামী রিপোর্ট',
      anonymousReportsDesc: 'পরিচয় প্রকাশ না করে রিপোর্ট জমা দেওয়ার অনুমতি দিন',
      
      // Security Tab
      activeSessions: 'সক্রিয় সেশন',
      activeSessionsDesc: 'আপনার অ্যাকাউন্টে লগইন করা ডিভাইসগুলি পরিচালনা করুন',
      twoFactorAuth: '২এফএ প্রমাণীকরণ',
      twoFactorAuthDesc: 'আপনার অ্যাকাউন্টে অতিরিক্ত নিরাপত্তা যোগ করুন',
      enable2FA: '২এফএ সক্রিয় করুন',
      disable2FA: '২এফএ নিষ্ক্রিয় করুন',
      loginAlerts: 'লগইন সতর্কতা',
      loginAlertsDesc: 'নতুন লগইন চেষ্টার বিজ্ঞপ্তি পান',
      viewSessions: 'সেশন দেখুন',
      hideSessions: 'সেশন লুকান',
      
      // Data Management Tab
      downloadData: 'আমার ডেটা ডাউনলোড',
      downloadDataDesc: 'পোর্টেবল ফরম্যাটে আপনার সমস্ত ডেটা ডাউনলোড করুন',
      deleteData: 'অ্যাকাউন্ট ডেটা মুছুন',
      deleteDataDesc: 'আপনার অ্যাকাউন্ট এবং সমস্ত ডেটা স্থায়ীভাবে মুছুন',
      dataRetention: 'ডেটা ধরে রাখা',
      dataRetentionDesc: 'আমরা কতদিন আপনার ডেটা রাখি তা নিয়ন্ত্রণ করুন',
      
      // Session Info
      currentDevice: 'বর্তমান ডিভাইস',
      lastActive: 'শেষ সক্রিয়',
      location: 'অবস্থান',
      browser: 'ব্রাউজার',
      terminateSession: 'বন্ধ করুন',
      terminateAll: 'অন্য সব সেশন বন্ধ করুন',
      
      // Actions
      save: 'পরিবর্তন সংরক্ষণ',
      cancel: 'বাতিল',
      download: 'ডাউনলোড',
      delete: 'মুছুন',
      enable: 'সক্রিয়',
      disable: 'নিষ্ক্রিয়',
      
      // Success/Error messages
      settingsUpdated: 'গোপনীয়তা সেটিংস সফলভাবে আপডেট হয়েছে!',
      dataDownloaded: 'ডেটা ডাউনলোড শুরু হয়েছে। প্রস্তুত হলে আপনি একটি ইমেল পাবেন।',
      sessionTerminated: 'সেশন সফলভাবে বন্ধ হয়েছে',
      allSessionsTerminated: 'অন্য সব সেশন সফলভাবে বন্ধ হয়েছে'
    }
  };

  const currentContent = content[language];

  const [settings, setSettings] = useState({
    profileVisibility: 'friendsOnly',
    locationSharing: 'askEachTime',
    anonymousReports: true,
    twoFactorAuth: false,
    loginAlerts: true
  });

  const [isLoading, setIsLoading] = useState(false);

  // Mock session data
  const activeSessions = [
    {
      id: 1,
      device: 'Chrome on Windows',
      location: 'Dhaka, Bangladesh',
      lastActive: 'Active now',
      isCurrent: true
    },
    {
      id: 2,
      device: 'Safari on iPhone',
      location: 'Dhaka, Bangladesh',
      lastActive: '2 hours ago',
      isCurrent: false
    },
    {
      id: 3,
      device: 'Chrome on Android',
      location: 'Chittagong, Bangladesh',
      lastActive: '1 day ago',
      isCurrent: false
    }
  ];

  if (!isOpen) return null;

  const handleSave = async () => {
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      alert(currentContent.settingsUpdated);
      onClose();
    } catch (error) {
      alert('Failed to update settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadData = async () => {
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert(currentContent.dataDownloaded);
    } catch (error) {
      alert('Failed to download data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTerminateSession = async (_sessionId: number) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert(currentContent.sessionTerminated);
    } catch (error) {
      alert('Failed to terminate session. Please try again.');
    }
  };

  const handleTerminateAllSessions = async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      alert(currentContent.allSessionsTerminated);
    } catch (error) {
      alert('Failed to terminate sessions. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <div className="flex">
            {[
              { id: 'privacy', label: currentContent.privacy, icon: Eye },
              { id: 'security', label: currentContent.security, icon: Shield },
              { id: 'data', label: currentContent.dataManagement, icon: Database }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-6 py-3 font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-green-600 border-b-2 border-green-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Privacy Tab */}
          {activeTab === 'privacy' && (
            <div className="space-y-6">
              {/* Profile Visibility */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{currentContent.profileVisibility}</h3>
                <p className="text-gray-600 text-sm mb-3">{currentContent.profileVisibilityDesc}</p>
                <div className="space-y-2">
                  {[
                    { id: 'public', label: currentContent.publicProfile },
                    { id: 'friendsOnly', label: currentContent.friendsOnly },
                    { id: 'private', label: currentContent.privateProfile }
                  ].map((option) => (
                    <label key={option.id} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="profileVisibility"
                        value={option.id}
                        checked={settings.profileVisibility === option.id}
                        onChange={(e) => setSettings({...settings, profileVisibility: e.target.value})}
                        className="w-4 h-4 text-green-600 border-gray-300 focus:ring-green-500"
                      />
                      <span className="text-gray-700">{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Location Sharing */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{currentContent.locationSharing}</h3>
                <p className="text-gray-600 text-sm mb-3">{currentContent.locationSharingDesc}</p>
                <div className="space-y-2">
                  {[
                    { id: 'always', label: currentContent.alwaysShare },
                    { id: 'askEachTime', label: currentContent.askEachTime },
                    { id: 'never', label: currentContent.neverShare }
                  ].map((option) => (
                    <label key={option.id} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="locationSharing"
                        value={option.id}
                        checked={settings.locationSharing === option.id}
                        onChange={(e) => setSettings({...settings, locationSharing: e.target.value})}
                        className="w-4 h-4 text-green-600 border-gray-300 focus:ring-green-500"
                      />
                      <span className="text-gray-700">{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Anonymous Reports */}
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{currentContent.anonymousReports}</h3>
                  <p className="text-gray-600 text-sm">{currentContent.anonymousReportsDesc}</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, anonymousReports: !settings.anonymousReports})}
                  className={`relative inline-flex w-12 h-6 rounded-full transition-colors duration-200 ${
                    settings.anonymousReports ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ${
                      settings.anonymousReports ? 'translate-x-7' : 'translate-x-1'
                    } mt-1`}
                  />
                </button>
              </div>
            </div>
          )}

          {/* Security Tab */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              {/* 2FA Authentication */}
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{currentContent.twoFactorAuth}</h3>
                  <p className="text-gray-600 text-sm">{currentContent.twoFactorAuthDesc}</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, twoFactorAuth: !settings.twoFactorAuth})}
                  className={`relative inline-flex w-12 h-6 rounded-full transition-colors duration-200 ${
                    settings.twoFactorAuth ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ${
                      settings.twoFactorAuth ? 'translate-x-7' : 'translate-x-1'
                    } mt-1`}
                  />
                </button>
              </div>

              {/* Login Alerts */}
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{currentContent.loginAlerts}</h3>
                  <p className="text-gray-600 text-sm">{currentContent.loginAlertsDesc}</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, loginAlerts: !settings.loginAlerts})}
                  className={`relative inline-flex w-12 h-6 rounded-full transition-colors duration-200 ${
                    settings.loginAlerts ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ${
                      settings.loginAlerts ? 'translate-x-7' : 'translate-x-1'
                    } mt-1`}
                  />
                </button>
              </div>

              {/* Active Sessions */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{currentContent.activeSessions}</h3>
                    <p className="text-gray-600 text-sm">{currentContent.activeSessionsDesc}</p>
                  </div>
                  <button
                    onClick={() => setShowSessions(!showSessions)}
                    className="text-green-600 hover:text-green-700 font-medium text-sm"
                  >
                    {showSessions ? currentContent.hideSessions : currentContent.viewSessions}
                  </button>
                </div>

                {showSessions && (
                  <div className="space-y-3">
                    {activeSessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="font-medium text-gray-900">{session.device}</p>
                            {session.isCurrent && (
                              <span className="px-2 py-1 bg-green-100 text-green-600 text-xs rounded-full">
                                {currentContent.currentDevice}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{session.location} • {session.lastActive}</p>
                        </div>
                        {!session.isCurrent && (
                          <button
                            onClick={() => handleTerminateSession(session.id)}
                            className="px-3 py-1 text-red-600 hover:bg-red-50 rounded text-sm font-medium"
                          >
                            {currentContent.terminateSession}
                          </button>
                        )}
                      </div>
                    ))}
                    
                    <button
                      onClick={handleTerminateAllSessions}
                      className="w-full py-2 text-red-600 hover:bg-red-50 rounded-lg font-medium text-sm"
                    >
                      {currentContent.terminateAll}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Data Management Tab */}
          {activeTab === 'data' && (
            <div className="space-y-6">
              {/* Download Data */}
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">{currentContent.downloadData}</h3>
                    <p className="text-gray-600 text-sm">{currentContent.downloadDataDesc}</p>
                  </div>
                  <button
                    onClick={handleDownloadData}
                    disabled={isLoading}
                    className="ml-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium text-sm flex items-center space-x-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>{currentContent.download}</span>
                  </button>
                </div>
              </div>

              {/* Delete Data Warning */}
              <div className="p-4 border border-red-200 bg-red-50 rounded-lg">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-red-900 mb-1">{currentContent.deleteData}</h3>
                    <p className="text-red-700 text-sm mb-3">{currentContent.deleteDataDesc}</p>
                    <p className="text-red-600 text-xs">This action cannot be undone. All your reports, rewards, and account data will be permanently deleted.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-3 p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            {currentContent.cancel}
          </button>
          <CustomButton
            onClick={handleSave}
            variant="primary"
            className="flex-1"
            loading={isLoading}
            icon={<Shield className="w-4 h-4" />}
          >
            {currentContent.save}
          </CustomButton>
        </div>
      </div>
    </div>
  );
}
