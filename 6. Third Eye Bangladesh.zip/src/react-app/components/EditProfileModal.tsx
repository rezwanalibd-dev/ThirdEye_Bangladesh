import { useState } from 'react';
import { X, User, Mail, Phone, Save, Camera } from 'lucide-react';
import CustomButton from './CustomButton';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
  userData: {
    name: string;
    phone: string;
    email: string;
  };
}

export default function EditProfileModal({ isOpen, onClose, language, userData }: EditProfileModalProps) {
  const [formData, setFormData] = useState({
    fullName: userData.name,
    email: userData.email,
    phone: userData.phone
  });
  const [isLoading, setIsLoading] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);

  const content = {
    en: {
      title: 'Edit Profile',
      fullName: 'Full Name',
      email: 'Email Address',
      phone: 'Phone Number',
      profilePicture: 'Profile Picture',
      changePhoto: 'Change Photo',
      save: 'Save Changes',
      cancel: 'Cancel',
      enterName: 'Enter your full name',
      enterEmail: 'Enter your email address',
      phoneReadOnly: 'Phone number cannot be changed',
      saveSuccess: 'Profile updated successfully!',
      saveError: 'Failed to update profile. Please try again.'
    },
    bn: {
      title: 'প্রোফাইল সম্পাদনা',
      fullName: 'পূর্ণ নাম',
      email: 'ইমেইল ঠিকানা',
      phone: 'ফোন নম্বর',
      profilePicture: 'প্রোফাইল ছবি',
      changePhoto: 'ছবি পরিবর্তন',
      save: 'পরিবর্তন সংরক্ষণ',
      cancel: 'বাতিল',
      enterName: 'আপনার পূর্ণ নাম লিখুন',
      enterEmail: 'আপনার ইমেইল ঠিকানা লিখুন',
      phoneReadOnly: 'ফোন নম্বর পরিবর্তন করা যাবে না',
      saveSuccess: 'প্রোফাইল সফলভাবে আপডেট হয়েছে!',
      saveError: 'প্রোফাইল আপডেট করতে ব্যর্থ। অনুগ্রহ করে আবার চেষ্টা করুন।'
    }
  };

  const currentContent = content[language];

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Show success message
      alert(currentContent.saveSuccess);
      onClose();
    } catch (error) {
      alert(currentContent.saveError);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Profile Picture */}
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center overflow-hidden mx-auto">
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-12 h-12 text-green-600" />
                )}
              </div>
              <button
                type="button"
                onClick={() => document.getElementById('modalImageInput')?.click()}
                className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-green-700 transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-gray-600 mt-2">{currentContent.changePhoto}</p>
            <input
              id="modalImageInput"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="inline w-4 h-4 mr-2" />
              {currentContent.fullName}
            </label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({...formData, fullName: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder={currentContent.enterName}
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="inline w-4 h-4 mr-2" />
              {currentContent.email}
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder={currentContent.enterEmail}
            />
          </div>

          {/* Phone (Read-only) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Phone className="inline w-4 h-4 mr-2" />
              {currentContent.phone}
            </label>
            <input
              type="text"
              value={formData.phone}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-500"
              disabled
            />
            <p className="text-xs text-gray-500 mt-1">{currentContent.phoneReadOnly}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              {currentContent.cancel}
            </button>
            <CustomButton
              type="submit"
              variant="primary"
              className="flex-1"
              loading={isLoading}
              icon={<Save className="w-4 h-4" />}
            >
              {currentContent.save}
            </CustomButton>
          </div>
        </form>
      </div>
    </div>
  );
}
