import { useState } from 'react';
import { X, Lock, Eye, EyeOff, Shield, Mail, Phone, Check } from 'lucide-react';
import CustomButton from './CustomButton';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
  userPhone: string;
  userEmail: string;
}

export default function ChangePasswordModal({ isOpen, onClose, language, userPhone, userEmail }: ChangePasswordModalProps) {
  const [step, setStep] = useState<'verify' | 'otp' | 'newPassword'>('verify');
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    verifyMethod: 'phone' as 'phone' | 'email'
  });
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [countdown, setCountdown] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const content = {
    en: {
      title: 'Change Password',
      currentPassword: 'Current Password',
      newPassword: 'New Password',
      confirmPassword: 'Confirm New Password',
      verifyIdentity: 'Verify Identity',
      chooseMethod: 'Choose verification method',
      sendToPhone: 'Send OTP to Phone',
      sendToEmail: 'Send OTP to Email',
      enterCurrent: 'Enter your current password',
      enterNew: 'Enter new password (min 8 characters)',
      enterConfirm: 'Confirm your new password',
      otpSent: 'OTP sent to',
      enterOtp: 'Enter the 6-digit verification code',
      resendOtp: 'Resend OTP',
      resendIn: 'Resend in',
      verify: 'Verify & Continue',
      changePassword: 'Change Password',
      cancel: 'Cancel',
      back: 'Back',
      passwordMismatch: 'Passwords do not match',
      weakPassword: 'Password must be at least 8 characters with mixed case, numbers and symbols',
      invalidOtp: 'Please enter the complete 6-digit code',
      success: 'Password changed successfully!',
      error: 'Failed to change password. Please try again.',
      invalidCurrent: 'Current password is incorrect'
    },
    bn: {
      title: 'পাসওয়ার্ড পরিবর্তন',
      currentPassword: 'বর্তমান পাসওয়ার্ড',
      newPassword: 'নতুন পাসওয়ার্ড',
      confirmPassword: 'নতুন পাসওয়ার্ড নিশ্চিত করুন',
      verifyIdentity: 'পরিচয় যাচাই',
      chooseMethod: 'যাচাইকরণের পদ্ধতি বেছে নিন',
      sendToPhone: 'ফোনে ওটিপি পাঠান',
      sendToEmail: 'ইমেইলে ওটিপি পাঠান',
      enterCurrent: 'আপনার বর্তমান পাসওয়ার্ড লিখুন',
      enterNew: 'নতুন পাসওয়ার্ড লিখুন (কমপক্ষে ৮ অক্ষর)',
      enterConfirm: 'নতুন পাসওয়ার্ড নিশ্চিত করুন',
      otpSent: 'ওটিপি পাঠানো হয়েছে',
      enterOtp: '৬ সংখ্যার যাচাইকরণ কোড লিখুন',
      resendOtp: 'ওটিপি পুনরায় পাঠান',
      resendIn: 'পুনরায় পাঠানো হবে',
      verify: 'যাচাই করুন ও এগিয়ে যান',
      changePassword: 'পাসওয়ার্ড পরিবর্তন',
      cancel: 'বাতিল',
      back: 'পিছনে',
      passwordMismatch: 'পাসওয়ার্ড মিলছে না',
      weakPassword: 'পাসওয়ার্ডে কমপক্ষে ৮ অক্ষর, বড়-ছোট হাতের অক্ষর, সংখ্যা ও চিহ্ন থাকতে হবে',
      invalidOtp: 'সম্পূর্ণ ৬ সংখ্যার কোড লিখুন',
      success: 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!',
      error: 'পাসওয়ার্ড পরিবর্তন করতে ব্যর্থ। অনুগ্রহ করে আবার চেষ্টা করুন।',
      invalidCurrent: 'বর্তমান পাসওয়ার্ড ভুল'
    }
  };

  const currentContent = content[language];

  if (!isOpen) return null;

  const maskContact = (contact: string, type: 'phone' | 'email') => {
    if (type === 'phone') {
      return contact.replace(/(\+88\s\d{2})(\d{3})(\d{3})(\d{2})/, '$1***$3**$4');
    } else {
      const [username, domain] = contact.split('@');
      return `${username.substring(0, 2)}***@${domain}`;
    }
  };

  const validatePassword = (password: string) => {
    const hasMinLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSymbols = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return hasMinLength && hasUpperCase && hasLowerCase && hasNumbers && hasSymbols;
  };

  const handleSendOTP = async () => {
    setIsLoading(true);
    
    try {
      // Simulate OTP sending
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStep('otp');
      setCountdown(120); // 2 minutes
      
      // Start countdown
      const timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
    } catch (error) {
      alert(currentContent.error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleVerifyOTP = async () => {
    const otpCode = otp.join('');
    if (otpCode.length !== 6) {
      alert(currentContent.invalidOtp);
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate OTP verification
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStep('newPassword');
    } catch (error) {
      alert(currentContent.error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordChange = async () => {
    // Validate passwords
    if (!validatePassword(formData.newPassword)) {
      alert(currentContent.weakPassword);
      return;
    }
    
    if (formData.newPassword !== formData.confirmPassword) {
      alert(currentContent.passwordMismatch);
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate password change
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert(currentContent.success);
      onClose();
    } catch (error) {
      alert(currentContent.error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            {step !== 'verify' && (
              <button
                onClick={() => {
                  if (step === 'otp') setStep('verify');
                  if (step === 'newPassword') setStep('otp');
                }}
                className="p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="w-4 h-4 rotate-45" />
              </button>
            )}
            <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Step 1: Verify Current Password */}
          {step === 'verify' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentContent.verifyIdentity}</h3>
                <p className="text-gray-600 text-sm">{currentContent.chooseMethod}</p>
              </div>

              {/* Current Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Lock className="inline w-4 h-4 mr-2" />
                  {currentContent.currentPassword}
                </label>
                <div className="relative">
                  <input
                    type={showPasswords.current ? 'text' : 'password'}
                    value={formData.currentPassword}
                    onChange={(e) => setFormData({...formData, currentPassword: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 pr-12"
                    placeholder={currentContent.enterCurrent}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords({...showPasswords, current: !showPasswords.current})}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPasswords.current ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Verification Method */}
              <div className="space-y-3">
                <button
                  onClick={() => setFormData({...formData, verifyMethod: 'phone'})}
                  className={`w-full p-4 border rounded-lg text-left transition-colors ${
                    formData.verifyMethod === 'phone'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-300 hover:border-green-400'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium text-gray-900">{currentContent.sendToPhone}</p>
                      <p className="text-sm text-gray-600">{maskContact(userPhone, 'phone')}</p>
                    </div>
                    {formData.verifyMethod === 'phone' && <Check className="w-5 h-5 text-green-600 ml-auto" />}
                  </div>
                </button>

                <button
                  onClick={() => setFormData({...formData, verifyMethod: 'email'})}
                  className={`w-full p-4 border rounded-lg text-left transition-colors ${
                    formData.verifyMethod === 'email'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-300 hover:border-green-400'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium text-gray-900">{currentContent.sendToEmail}</p>
                      <p className="text-sm text-gray-600">{maskContact(userEmail, 'email')}</p>
                    </div>
                    {formData.verifyMethod === 'email' && <Check className="w-5 h-5 text-green-600 ml-auto" />}
                  </div>
                </button>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  {currentContent.cancel}
                </button>
                <CustomButton
                  onClick={handleSendOTP}
                  variant="primary"
                  className="flex-1"
                  loading={isLoading}
                  disabled={!formData.currentPassword}
                >
                  {currentContent.verify}
                </CustomButton>
              </div>
            </div>
          )}

          {/* Step 2: OTP Verification */}
          {step === 'otp' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentContent.enterOtp}</h3>
                <p className="text-gray-600 text-sm mb-2">{currentContent.otpSent}</p>
                <p className="text-green-600 font-semibold">
                  {formData.verifyMethod === 'phone' 
                    ? maskContact(userPhone, 'phone')
                    : maskContact(userEmail, 'email')
                  }
                </p>
              </div>

              {/* OTP Input */}
              <div className="flex justify-center space-x-3">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    id={`otp-${index}`}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    className="w-12 h-12 text-center text-lg font-bold border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                    inputMode="numeric"
                  />
                ))}
              </div>

              {/* Countdown */}
              <div className="text-center">
                {countdown > 0 ? (
                  <p className="text-gray-600 text-sm">{currentContent.resendIn} {formatTime(countdown)}</p>
                ) : (
                  <button
                    onClick={handleSendOTP}
                    className="text-green-600 font-medium text-sm hover:text-green-700"
                  >
                    {currentContent.resendOtp}
                  </button>
                )}
              </div>

              <CustomButton
                onClick={handleVerifyOTP}
                variant="primary"
                className="w-full"
                loading={isLoading}
                disabled={otp.some(digit => digit === '')}
              >
                {currentContent.verify}
              </CustomButton>
            </div>
          )}

          {/* Step 3: New Password */}
          {step === 'newPassword' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentContent.newPassword}</h3>
                <p className="text-gray-600 text-sm">Create a strong password for your account</p>
              </div>

              {/* New Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {currentContent.newPassword}
                </label>
                <div className="relative">
                  <input
                    type={showPasswords.new ? 'text' : 'password'}
                    value={formData.newPassword}
                    onChange={(e) => setFormData({...formData, newPassword: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 pr-12"
                    placeholder={currentContent.enterNew}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords({...showPasswords, new: !showPasswords.new})}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPasswords.new ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {currentContent.confirmPassword}
                </label>
                <div className="relative">
                  <input
                    type={showPasswords.confirm ? 'text' : 'password'}
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 pr-12"
                    placeholder={currentContent.enterConfirm}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords({...showPasswords, confirm: !showPasswords.confirm})}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPasswords.confirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <CustomButton
                onClick={handlePasswordChange}
                variant="primary"
                className="w-full"
                loading={isLoading}
                disabled={!formData.newPassword || !formData.confirmPassword}
              >
                {currentContent.changePassword}
              </CustomButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
