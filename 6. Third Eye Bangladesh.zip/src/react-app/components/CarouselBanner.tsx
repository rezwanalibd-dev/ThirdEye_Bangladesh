import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CarouselBannerProps {
  language: 'en' | 'bn';
}

export default function CarouselBanner({ language }: CarouselBannerProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const content = {
    en: [
      {
        title: 'Are You Ready to Make a Difference?',
        description: 'Your Report Can Save Lives. Every traffic violation you witness—wrong-side driving, footpath riding, illegal horns, or mobile use while driving—can be reported to prevent accidents. Whether it\'s speeding, helmetless riders, or illegal parking, your report ensures everyone\'s safety. Don\'t just be a bystander—become a guardian of your community.',
        cta: 'Report a traffic violation today and help create safer, rule-respecting streets where every life is valued. Report for Safer Roads',
        gradient: 'from-blue-600 to-purple-600'
      },
      {
        title: 'Stand Against Social Crimes',
        description: 'Your Courage Saves Lives. Break the silence against injustice. Report violence, theft, corruption, harassment, or criminal activities anonymously. Your report shields the vulnerable and fights for justice. Every unreported crime denies justice. Be the guardian your society needs.',
        cta: 'Your Identity Protected. Your Impact Eternal. Build a fearless Bangladesh where safety is everyone\'s right. Don\'t Stay Silent—Act Today. Report Social Crime Anonymously',
        gradient: 'from-green-600 to-teal-600'
      },
      {
        title: 'Earn an Income by Enhancing Public Safety',
        description: 'You are rewarded for contributing to a safer community. Generate a 20% income from traffic fines while supporting authorities in maintaining legal order.',
        cta: 'Your vigilance now yields a financial return.',
        gradient: 'from-orange-600 to-red-600'
      }
    ],
    bn: [
      {
        title: 'আপনি কি পরিবর্তন আনতে প্রস্তুত?',
        description: 'আপনার রিপোর্ট জীবন বাঁচাতে পারে। আপনি যে ট্রাফিক আইন লঙ্ঘন দেখেন—ভুল দিকে গাড়ি চালানো, ফুটপাতে গাড়ি চালানো, অবৈধ হর্ন, বা গাড়ি চালানোর সময় মোবাইল ব্যবহার—দুর্ঘটনা প্রতিরোধের জন্য রিপোর্ট করা যেতে পারে। এটি দ্রুত গতি, হেলমেটবিহীন রাইডার, বা অবৈধ পার্কিং যাই হোক না কেন, আপনার রিপোর্ট সবার নিরাপত্তা নিশ্চিত করে। শুধু একজন দর্শক হয়ে থাকবেন না—আপনার সম্প্রদায়ের একজন অভিভাবক হয়ে উঠুন।',
        cta: 'আজই একটি ট্রাফিক আইন লঙ্ঘন রিপোর্ট করুন এবং নিরাপদ, নিয়ম-সম্মানকারী রাস্তা তৈরি করতে সাহায্য করুন যেখানে প্রতিটি জীবনকে মূল্য দেওয়া হয়। নিরাপদ রাস্তার জন্য রিপোর্ট করুন',
        gradient: 'from-blue-600 to-purple-600'
      },
      {
        title: 'সামাজিক অপরাধের বিরুদ্ধে দাঁড়ান',
        description: 'আপনার সাহস জীবন বাঁচায়। অন্যায়ের বিরুদ্ধে নীরবতা ভাঙুন। সহিংসতা, চুরি, দুর্নীতি, হয়রানি বা অপরাধমূলক কার্যকলাপ বেনামে রিপোর্ট করুন। আপনার রিপোর্ট দুর্বলদের রক্ষা করে এবং ন্যায়বিচারের জন্য লড়ে। প্রতিটি অপ্রকাশিত অপরাধ ন্যায়বিচারকে অস্বীকার করে। আপনার সমাজের প্রয়োজনীয় অভিভাবক হয়ে উঠুন।',
        cta: 'আপনার পরিচয় সুরক্ষিত। আপনার প্রভাব চিরস্থায়ী। একটি নির্ভীক বাংলাদেশ গড়ুন যেখানে নিরাপত্তা সবার অধিকার। নীরব থাকবেন না—আজই কাজ করুন। বেনামে সামাজিক অপরাধ রিপোর্ট করুন',
        gradient: 'from-green-600 to-teal-600'
      },
      {
        title: 'জননিরাপত্তা বৃদ্ধি করে আয় করুন',
        description: 'একটি নিরাপদ সম্প্রদায় গঠনে আপনার অবদানের জন্য পুরস্কৃত হন। কর্তৃপক্ষকে আইনশৃঙ্খলা রক্ষায় সহায়তা করার পাশাপাশি ট্রাফিক জরিমানা থেকে ২০% আয় করুন।',
        cta: 'আপনার সজাগ দৃষ্টিই এখন আর্থিক প্রতিদান আনে।',
        gradient: 'from-orange-600 to-red-600'
      }
    ]
  };

  const slides = content[language];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative bg-white rounded-2xl shadow-lg overflow-hidden mx-auto">
      <div className="relative min-h-64 h-auto">
        <div 
          className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].gradient} opacity-90`}
        />
        <div className="relative z-10 p-6 h-full flex flex-col justify-center text-white text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-lg font-bold mb-4 leading-tight">
              {slides[currentSlide].title}
            </h3>
            <p className="text-sm opacity-90 leading-relaxed mb-4">
              {slides[currentSlide].description}
            </p>
            <p className="text-sm font-medium opacity-95">
              {slides[currentSlide].cta}
            </p>
          </div>
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-3 top-1/2 transform -translate-y-1/2 z-20 p-2 bg-black/20 hover:bg-black/30 rounded-full transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-white" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-3 top-1/2 transform -translate-y-1/2 z-20 p-2 bg-black/20 hover:bg-black/30 rounded-full transition-colors"
        >
          <ChevronRight className="w-5 h-5 text-white" />
        </button>

        {/* Slide Indicators */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
