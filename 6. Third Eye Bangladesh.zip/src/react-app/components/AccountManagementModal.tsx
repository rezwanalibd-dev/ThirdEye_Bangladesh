import { useState } from 'react';
import { X, UserMinus, Trash2, AlertTriangle, Shield, Lock, Eye, EyeOff } from 'lucide-react';
import CustomButton from './CustomButton';

interface AccountManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
  onLogout: () => void;
}

export default function AccountManagementModal({ isOpen, onClose, language, onLogout }: AccountManagementModalProps) {
  const [activeAction, setActiveAction] = useState<'none' | 'deactivate' | 'delete'>('none');
  const [step, setStep] = useState<'confirm' | 'password' | 'otp'>('confirm');
  const [formData, setFormData] = useState({
    password: '',
    reason: '',
    otp: ['', '', '', '', '', '']
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const content = {
    en: {
      title: 'Account Management',
      subtitle: 'Manage your account settings and data',
      
      // Main options
      deactivateAccount: 'Deactivate Account',
      deactivateDesc: 'Temporarily disable your account. You can reactivate it anytime.',
      deleteAccount: 'Delete Account',
      deleteDesc: 'Permanently delete your account and all data. This cannot be undone.',
      
      // Deactivate flow
      deactivateTitle: 'Deactivate Your Account',
      deactivateWarning: 'Your account will be temporarily disabled. You can reactivate it by logging in again.',
      deactivateReasons: 'Why are you deactivating? (Optional)',
      reasonPlaceholder: 'Tell us why you\'re taking a break...',
      
      // Delete flow
      deleteTitle: 'Delete Your Account',
      deleteWarning: 'This will permanently delete your account and all associated data including:',
      deleteItems: [
        'All your traffic violation reports',
        'Earned rewards and payment history',
        'Profile information and documents',
        'Case tracking history',
        'All uploaded evidence files'
      ],
      deleteConfirmText: 'This action cannot be undone. Are you absolutely sure?',
      deleteReasons: 'Reason for deletion (Required)',
      
      // Password verification
      enterPassword: 'Enter your password to continue',
      passwordPlaceholder: 'Enter your current password',
      invalidPassword: 'Incorrect password. Please try again.',
      
      // OTP verification
      otpTitle: 'Verify Your Identity',
      otpDesc: 'We\'ve sent a verification code to your registered phone number',
      enterOtp: 'Enter the 6-digit verification code',
      resendOtp: 'Resend Code',
      resendIn: 'Resend in',
      
      // Reasons
      reasons: {
        privacy: 'Privacy concerns',
        tooManyNotifications: 'Too many notifications',
        notUseful: 'App not useful',
        technical: 'Technical issues',
        other: 'Other'
      },
      
      // Actions
      continue: 'Continue',
      confirm: 'Confirm',
      cancel: 'Cancel',
      back: 'Back',
      deactivateButton: 'Deactivate Account',
      deleteButton: 'Delete Account Permanently',
      verify: 'Verify & Continue',
      
      // Success messages
      deactivateSuccess: 'Account deactivated successfully. You can reactivate by logging in again.',
      deleteSuccess: 'Account deletion initiated. You will receive a confirmation email.',
      
      // Warnings
      finalWarning: 'Final Warning',
      deleteConfirmation: 'Type "DELETE" below to confirm permanent account deletion',
      typeDelete: 'Type DELETE here',
      confirmationMismatch: 'Confirmation text does not match'
    },
    bn: {
      title: 'অ্যাকাউন্ট ব্যবস্থাপনা',
      subtitle: 'আপনার অ্যাকাউন্ট সেটিংস এবং ডেটা পরিচালনা করুন',
      
      // Main options
      deactivateAccount: 'অ্যাকাউন্ট নিষ্ক্রিয় করুন',
      deactivateDesc: 'সাময়িকভাবে আপনার অ্যাকাউন্ট বন্ধ করুন। যেকোনো সময় পুনরায় সক্রিয় করতে পারবেন।',
      deleteAccount: 'অ্যাকাউন্ট মুছে ফেলুন',
      deleteDesc: 'স্থায়ীভাবে আপনার অ্যাকাউন্ট এবং সমস্ত ডেটা মুছে ফেলুন। এটি পূর্বাবস্থায় ফেরানো যাবে না।',
      
      // Deactivate flow
      deactivateTitle: 'আপনার অ্যাকাউন্ট নিষ্ক্রিয় করুন',
      deactivateWarning: 'আপনার অ্যাকাউন্ট সাময়িকভাবে বন্ধ হবে। আবার লগইন করে পুনরায় সক্রিয় করতে পারবেন।',
      deactivateReasons: 'কেন নিষ্ক্রিয় করছেন? (ঐচ্ছিক)',
      reasonPlaceholder: 'আমাদের জানান কেন বিরতি নিচ্ছেন...',
      
      // Delete flow
      deleteTitle: 'আপনার অ্যাকাউন্ট মুছে ফেলুন',
      deleteWarning: 'এটি স্থায়ীভাবে আপনার অ্যাকাউন্ট এবং সকল সংশ্লিষ্ট ডেটা মুছে ফেলবে যার মধ্যে রয়েছে:',
      deleteItems: [
        'আপনার সমস্ত ট্রাফিক লঙ্ঘন রিপোর্ট',
        'অর্জিত পুরস্কার এবং পেমেন্ট ইতিহাস',
        'প্রোফাইল তথ্য এবং ডকুমেন্ট',
        'কেস ট্র্যাকিং ইতিহাস',
        'সমস্ত আপলোড করা প্রমাণ ফাইল'
      ],
      deleteConfirmText: 'এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না। আপনি কি সম্পূর্ণ নিশ্চিত?',
      deleteReasons: 'মুছে ফেলার কারণ (আবশ্যক)',
      
      // Password verification
      enterPassword: 'এগিয়ে যেতে আপনার পাসওয়ার্ড লিখুন',
      passwordPlaceholder: 'আপনার বর্তমান পাসওয়ার্ড লিখুন',
      invalidPassword: 'ভুল পাসওয়ার্ড। অনুগ্রহ করে আবার চেষ্টা করুন।',
      
      // OTP verification
      otpTitle: 'আপনার পরিচয় যাচাই করুন',
      otpDesc: 'আমরা আপনার নিবন্ধিত ফোন নম্বরে একটি যাচাইকরণ কোড পাঠিয়েছি',
      enterOtp: '৬ সংখ্যার যাচাইকরণ কোড লিখুন',
      resendOtp: 'কোড পুনরায় পাঠান',
      resendIn: 'পুনরায় পাঠানো হবে',
      
      // Reasons
      reasons: {
        privacy: 'গোপনীয়তা সংক্রান্ত উদ্বেগ',
        tooManyNotifications: 'অতিরিক্ত বিজ্ঞপ্তি',
        notUseful: 'অ্যাপ উপযোগী নয়',
        technical: 'প্রযুক্তিগত সমস্যা',
        other: 'অন্যান্য'
      },
      
      // Actions
      continue: 'এগিয়ে যান',
      confirm: 'নিশ্চিত করুন',
      cancel: 'বাতিল',
      back: 'পিছনে',
      deactivateButton: 'অ্যাকাউন্ট নিষ্ক্রিয় করুন',
      deleteButton: 'অ্যাকাউন্ট স্থায়ীভাবে মুছুন',
      verify: 'যাচাই করুন ও এগিয়ে যান',
      
      // Success messages
      deactivateSuccess: 'অ্যাকাউন্ট সফলভাবে নিষ্ক্রিয় হয়েছে। আবার লগইন করে পুনরায় সক্রিয় করতে পারবেন।',
      deleteSuccess: 'অ্যাকাউন্ট মুছে ফেলার প্রক্রিয়া শুরু হয়েছে। আপনি একটি নিশ্চিতকরণ ইমেল পাবেন।',
      
      // Warnings
      finalWarning: 'চূড়ান্ত সতর্কতা',
      deleteConfirmation: 'স্থায়ী অ্যাকাউন্ট মুছে ফেলা নিশ্চিত করতে নিচে "DELETE" টাইপ করুন',
      typeDelete: 'এখানে DELETE টাইপ করুন',
      confirmationMismatch: 'নিশ্চিতকরণ টেক্সট মিলছে না'
    }
  };

  const currentContent = content[language];

  const [deleteConfirmation, setDeleteConfirmation] = useState('');

  if (!isOpen) return null;

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...formData.otp];
    newOtp[index] = value;
    setFormData({...formData, otp: newOtp});
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`account-otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handlePasswordVerification = async () => {
    if (!formData.password) return;
    
    setIsLoading(true);
    
    try {
      // Simulate password verification
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStep('otp');
      
      // Start countdown for OTP
      setCountdown(120);
      const timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
    } catch (error) {
      alert(currentContent.invalidPassword);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpVerification = async () => {
    const otpCode = formData.otp.join('');
    if (otpCode.length !== 6) return;
    
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (activeAction === 'deactivate') {
        alert(currentContent.deactivateSuccess);
        onLogout();
      } else {
        alert(currentContent.deleteSuccess);
        onLogout();
      }
      
    } catch (error) {
      alert('Verification failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const resetFlow = () => {
    setActiveAction('none');
    setStep('confirm');
    setFormData({
      password: '',
      reason: '',
      otp: ['', '', '', '', '', '']
    });
    setDeleteConfirmation('');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            {activeAction !== 'none' && (
              <button
                onClick={resetFlow}
                className="p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="w-4 h-4 rotate-45" />
              </button>
            )}
            <div>
              <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
              <p className="text-gray-600 text-sm">{currentContent.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Main Menu */}
          {activeAction === 'none' && (
            <div className="space-y-4">
              {/* Deactivate Account */}
              <div 
                onClick={() => setActiveAction('deactivate')}
                className="p-4 border-2 border-orange-200 bg-orange-50 rounded-lg cursor-pointer hover:bg-orange-100 transition-colors"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                    <UserMinus className="w-6 h-6 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-orange-900 mb-1">{currentContent.deactivateAccount}</h3>
                    <p className="text-orange-700 text-sm">{currentContent.deactivateDesc}</p>
                  </div>
                </div>
              </div>

              {/* Delete Account */}
              <div 
                onClick={() => setActiveAction('delete')}
                className="p-4 border-2 border-red-200 bg-red-50 rounded-lg cursor-pointer hover:bg-red-100 transition-colors"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <Trash2 className="w-6 h-6 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-red-900 mb-1">{currentContent.deleteAccount}</h3>
                    <p className="text-red-700 text-sm">{currentContent.deleteDesc}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Deactivate Flow */}
          {activeAction === 'deactivate' && step === 'confirm' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UserMinus className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{currentContent.deactivateTitle}</h3>
                <p className="text-gray-600">{currentContent.deactivateWarning}</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {currentContent.deactivateReasons}
                </label>
                <div className="space-y-2 mb-4">
                  {Object.entries(currentContent.reasons).map(([key, value]) => (
                    <label key={key} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="reason"
                        value={key}
                        checked={formData.reason === key}
                        onChange={(e) => setFormData({...formData, reason: e.target.value})}
                        className="w-4 h-4 text-orange-600 border-gray-300 focus:ring-orange-500"
                      />
                      <span className="text-gray-700">{value}</span>
                    </label>
                  ))}
                </div>
                <textarea
                  placeholder={currentContent.reasonPlaceholder}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm"
                  rows={3}
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={resetFlow}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  {currentContent.cancel}
                </button>
                <CustomButton
                  onClick={() => setStep('password')}
                  variant="primary"
                  className="flex-1 bg-orange-600 hover:bg-orange-700"
                >
                  {currentContent.continue}
                </CustomButton>
              </div>
            </div>
          )}

          {/* Delete Flow */}
          {activeAction === 'delete' && step === 'confirm' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-red-900 mb-2">{currentContent.deleteTitle}</h3>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800 font-medium mb-2">{currentContent.deleteWarning}</p>
                <ul className="text-red-700 text-sm space-y-1 mb-3">
                  {currentContent.deleteItems.map((item, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <span className="text-red-500">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-red-800 font-semibold">{currentContent.deleteConfirmText}</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {currentContent.deleteReasons}
                </label>
                <div className="space-y-2">
                  {Object.entries(currentContent.reasons).map(([key, value]) => (
                    <label key={key} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="reason"
                        value={key}
                        checked={formData.reason === key}
                        onChange={(e) => setFormData({...formData, reason: e.target.value})}
                        className="w-4 h-4 text-red-600 border-gray-300 focus:ring-red-500"
                        required
                      />
                      <span className="text-gray-700">{value}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Final Confirmation */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">{currentContent.finalWarning}</h4>
                <p className="text-gray-700 text-sm mb-3">{currentContent.deleteConfirmation}</p>
                <input
                  type="text"
                  value={deleteConfirmation}
                  onChange={(e) => setDeleteConfirmation(e.target.value)}
                  placeholder={currentContent.typeDelete}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={resetFlow}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  {currentContent.cancel}
                </button>
                <CustomButton
                  onClick={() => setStep('password')}
                  variant="primary"
                  className="flex-1 bg-red-600 hover:bg-red-700"
                  disabled={!formData.reason || deleteConfirmation !== 'DELETE'}
                >
                  {currentContent.continue}
                </CustomButton>
              </div>
            </div>
          )}

          {/* Password Verification Step */}
          {step === 'password' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentContent.enterPassword}</h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Lock className="inline w-4 h-4 mr-2" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-12"
                    placeholder={currentContent.passwordPlaceholder}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => setStep('confirm')}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  {currentContent.back}
                </button>
                <CustomButton
                  onClick={handlePasswordVerification}
                  variant="primary"
                  className="flex-1"
                  loading={isLoading}
                  disabled={!formData.password}
                >
                  {currentContent.verify}
                </CustomButton>
              </div>
            </div>
          )}

          {/* OTP Verification Step */}
          {step === 'otp' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentContent.otpTitle}</h3>
                <p className="text-gray-600 text-sm">{currentContent.otpDesc}</p>
              </div>

              {/* OTP Input */}
              <div className="flex justify-center space-x-3">
                {formData.otp.map((digit, index) => (
                  <input
                    key={index}
                    id={`account-otp-${index}`}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    className="w-12 h-12 text-center text-lg font-bold border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                    inputMode="numeric"
                  />
                ))}
              </div>

              {/* Countdown */}
              <div className="text-center">
                {countdown > 0 ? (
                  <p className="text-gray-600 text-sm">{currentContent.resendIn} {formatTime(countdown)}</p>
                ) : (
                  <button className="text-green-600 font-medium text-sm hover:text-green-700">
                    {currentContent.resendOtp}
                  </button>
                )}
              </div>

              <CustomButton
                onClick={handleOtpVerification}
                variant="primary"
                className={`w-full ${activeAction === 'delete' ? 'bg-red-600 hover:bg-red-700' : 'bg-orange-600 hover:bg-orange-700'}`}
                loading={isLoading}
                disabled={formData.otp.some(digit => digit === '')}
                icon={activeAction === 'delete' ? <Trash2 className="w-4 h-4" /> : <UserMinus className="w-4 h-4" />}
              >
                {activeAction === 'delete' ? currentContent.deleteButton : currentContent.deactivateButton}
              </CustomButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
