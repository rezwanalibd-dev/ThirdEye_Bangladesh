import { useState } from 'react';
import { X, Bell, Smartphone, Mail, MessageSquare, AlertTriangle, Award, FileText } from 'lucide-react';
import CustomButton from './CustomButton';

interface NotificationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'bn';
}

interface NotificationSetting {
  id: string;
  title: string;
  description: string;
  icon: any;
  enabled: boolean;
  channels: {
    push: boolean;
    email: boolean;
    sms: boolean;
  };
}

export default function NotificationSettingsModal({ isOpen, onClose, language }: NotificationSettingsModalProps) {
  const content = {
    en: {
      title: 'Notification Settings',
      subtitle: 'Control how you receive notifications',
      pushNotifications: 'Push Notifications',
      emailNotifications: 'Email Notifications',
      smsNotifications: 'SMS Notifications',
      reportUpdates: 'Report Status Updates',
      reportUpdatesDesc: 'Get notified when your report status changes',
      rewardNotifications: 'Reward Notifications',
      rewardNotificationsDesc: 'Notifications about earned rewards and payments',
      emergencyAlerts: 'Emergency Alerts',
      emergencyAlertsDesc: 'Critical alerts and emergency notifications',
      systemUpdates: 'System Updates',
      systemUpdatesDesc: 'App updates and maintenance notifications',
      communityNews: 'Community News',
      communityNewsDesc: 'Updates about Third Eye Bangladesh community',
      enable: 'Enable',
      disable: 'Disable',
      save: 'Save Settings',
      cancel: 'Cancel',
      allOff: 'Turn Off All',
      allOn: 'Turn On All',
      success: 'Notification settings updated successfully!',
      channels: 'Notification Channels'
    },
    bn: {
      title: 'বিজ্ঞপ্তি সেটিংস',
      subtitle: 'কীভাবে বিজ্ঞপ্তি পেতে চান তা নিয়ন্ত্রণ করুন',
      pushNotifications: 'পুশ বিজ্ঞপ্তি',
      emailNotifications: 'ইমেইল বিজ্ঞপ্তি',
      smsNotifications: 'এসএমএস বিজ্ঞপ্তি',
      reportUpdates: 'রিপোর্ট স্ট্যাটাস আপডেট',
      reportUpdatesDesc: 'আপনার রিপোর্টের অবস্থা পরিবর্তনের বিজ্ঞপ্তি পান',
      rewardNotifications: 'পুরস্কার বিজ্ঞপ্তি',
      rewardNotificationsDesc: 'অর্জিত পুরস্কার এবং পেমেন্ট সম্পর্কে বিজ্ঞপ্তি',
      emergencyAlerts: 'জরুরি সতর্কতা',
      emergencyAlertsDesc: 'গুরুত্বপূর্ণ সতর্কতা এবং জরুরি বিজ্ঞপ্তি',
      systemUpdates: 'সিস্টেম আপডেট',
      systemUpdatesDesc: 'অ্যাপ আপডেট এবং রক্ষণাবেক্ষণ বিজ্ঞপ্তি',
      communityNews: 'কমিউনিটি খবর',
      communityNewsDesc: 'থার্ড আই বাংলাদেশ কমিউনিটি সম্পর্কে আপডেট',
      enable: 'সক্রিয়',
      disable: 'নিষ্ক্রিয়',
      save: 'সেটিংস সংরক্ষণ',
      cancel: 'বাতিল',
      allOff: 'সব বন্ধ করুন',
      allOn: 'সব চালু করুন',
      success: 'বিজ্ঞপ্তি সেটিংস সফলভাবে আপডেট হয়েছে!',
      channels: 'বিজ্ঞপ্তির মাধ্যম'
    }
  };

  const currentContent = content[language];

  const [isLoading, setIsLoading] = useState(false);
  const [settings, setSettings] = useState<NotificationSetting[]>([
    {
      id: 'reportUpdates',
      title: currentContent.reportUpdates,
      description: currentContent.reportUpdatesDesc,
      icon: FileText,
      enabled: true,
      channels: { push: true, email: true, sms: false }
    },
    {
      id: 'rewardNotifications',
      title: currentContent.rewardNotifications,
      description: currentContent.rewardNotificationsDesc,
      icon: Award,
      enabled: true,
      channels: { push: true, email: false, sms: true }
    },
    {
      id: 'emergencyAlerts',
      title: currentContent.emergencyAlerts,
      description: currentContent.emergencyAlertsDesc,
      icon: AlertTriangle,
      enabled: true,
      channels: { push: true, email: true, sms: true }
    },
    {
      id: 'systemUpdates',
      title: currentContent.systemUpdates,
      description: currentContent.systemUpdatesDesc,
      icon: Bell,
      enabled: false,
      channels: { push: true, email: false, sms: false }
    },
    {
      id: 'communityNews',
      title: currentContent.communityNews,
      description: currentContent.communityNewsDesc,
      icon: MessageSquare,
      enabled: false,
      channels: { push: false, email: true, sms: false }
    }
  ]);

  if (!isOpen) return null;

  const toggleSetting = (id: string) => {
    setSettings(prev => prev.map(setting => 
      setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
    ));
  };

  const toggleChannel = (id: string, channel: 'push' | 'email' | 'sms') => {
    setSettings(prev => prev.map(setting => 
      setting.id === id 
        ? { 
            ...setting, 
            channels: { 
              ...setting.channels, 
              [channel]: !setting.channels[channel] 
            }
          } 
        : setting
    ));
  };

  const toggleAllSettings = (enable: boolean) => {
    setSettings(prev => prev.map(setting => ({ 
      ...setting, 
      enabled: enable,
      channels: enable ? { push: true, email: true, sms: true } : { push: false, email: false, sms: false }
    })));
  };

  const handleSave = async () => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      alert(currentContent.success);
      onClose();
    } catch (error) {
      alert('Failed to update settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-bold text-gray-900">{currentContent.title}</h2>
            <p className="text-gray-600 text-sm">{currentContent.subtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Quick Actions */}
          <div className="flex space-x-3">
            <button
              onClick={() => toggleAllSettings(true)}
              className="flex-1 py-2 px-4 bg-green-100 text-green-700 rounded-lg font-medium hover:bg-green-200 transition-colors"
            >
              {currentContent.allOn}
            </button>
            <button
              onClick={() => toggleAllSettings(false)}
              className="flex-1 py-2 px-4 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              {currentContent.allOff}
            </button>
          </div>

          {/* Notification Settings */}
          <div className="space-y-4">
            {settings.map((setting) => (
              <div key={setting.id} className="border border-gray-200 rounded-lg p-4">
                {/* Setting Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      setting.enabled ? 'bg-green-100' : 'bg-gray-100'
                    }`}>
                      <setting.icon className={`w-5 h-5 ${
                        setting.enabled ? 'text-green-600' : 'text-gray-400'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{setting.title}</h3>
                      <p className="text-sm text-gray-600">{setting.description}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleSetting(setting.id)}
                    className={`relative inline-flex w-12 h-6 rounded-full transition-colors duration-200 ${
                      setting.enabled ? 'bg-green-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`inline-block w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ${
                        setting.enabled ? 'translate-x-7' : 'translate-x-1'
                      } mt-1`}
                    />
                  </button>
                </div>

                {/* Notification Channels */}
                {setting.enabled && (
                  <div className="border-t border-gray-100 pt-3">
                    <p className="text-sm font-medium text-gray-700 mb-2">{currentContent.channels}</p>
                    <div className="flex space-x-4">
                      {/* Push Notifications */}
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={setting.channels.push}
                          onChange={() => toggleChannel(setting.id, 'push')}
                          className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                        />
                        <div className="flex items-center space-x-1">
                          <Smartphone className="w-4 h-4 text-gray-600" />
                          <span className="text-sm text-gray-700">{currentContent.pushNotifications}</span>
                        </div>
                      </label>

                      {/* Email Notifications */}
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={setting.channels.email}
                          onChange={() => toggleChannel(setting.id, 'email')}
                          className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                        />
                        <div className="flex items-center space-x-1">
                          <Mail className="w-4 h-4 text-gray-600" />
                          <span className="text-sm text-gray-700">{currentContent.emailNotifications}</span>
                        </div>
                      </label>

                      {/* SMS Notifications */}
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={setting.channels.sms}
                          onChange={() => toggleChannel(setting.id, 'sms')}
                          className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                        />
                        <div className="flex items-center space-x-1">
                          <MessageSquare className="w-4 h-4 text-gray-600" />
                          <span className="text-sm text-gray-700">{currentContent.smsNotifications}</span>
                        </div>
                      </label>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              {currentContent.cancel}
            </button>
            <CustomButton
              onClick={handleSave}
              variant="primary"
              className="flex-1"
              loading={isLoading}
              icon={<Bell className="w-4 h-4" />}
            >
              {currentContent.save}
            </CustomButton>
          </div>
        </div>
      </div>
    </div>
  );
}
