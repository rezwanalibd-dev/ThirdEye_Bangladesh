import { BrowserRouter as Router, Routes, Route } from "react-router";
import Welcome from "@/react-app/pages/Welcome";
import Login from "@/react-app/pages/Login";
import Signup from "@/react-app/pages/Signup";
import OTPVerification from "@/react-app/pages/OTPVerification";
import KYCVerification from "@/react-app/pages/KYCVerification";
import BiometricVerification from "@/react-app/pages/BiometricVerification";
import WalletSetup from "@/react-app/pages/WalletSetup";
import Dashboard from "@/react-app/pages/Dashboard";
import ReportTraffic from "@/react-app/pages/ReportTraffic";
import ReportCrime from "@/react-app/pages/ReportCrime";
import CaseTracking from "@/react-app/pages/CaseTracking";
import OfficerDashboard from "@/react-app/pages/OfficerDashboard";
import Alerts from "@/react-app/pages/Alerts";
import Profile from "@/react-app/pages/Profile";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/otp-verification" element={<OTPVerification />} />
        <Route path="/kyc-verification" element={<KYCVerification />} />
        <Route path="/biometric-verification" element={<BiometricVerification />} />
        <Route path="/wallet-setup" element={<WalletSetup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/report-traffic" element={<ReportTraffic />} />
        <Route path="/report-crime" element={<ReportCrime />} />
        <Route path="/case-tracking" element={<CaseTracking />} />
        <Route path="/officer-dashboard" element={<OfficerDashboard />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </Router>
  );
}
