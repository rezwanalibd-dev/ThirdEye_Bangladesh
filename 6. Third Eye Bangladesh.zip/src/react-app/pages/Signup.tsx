import { useState } from 'react';
import { Eye, EyeOff, Phone, Mail, User, ArrowRight, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function Signup() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  // const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      createAccount: 'Create Account',
      step1Of4: 'Step 1 of 4',
      fullName: 'Full Name',
      phoneNumber: 'Phone Number',
      email: 'Email (Optional)',
      password: 'Password',
      confirmPassword: 'Confirm Password',
      enterFullName: 'Enter your full name',
      enterPhone: 'Enter your phone number',
      enterEmail: 'Enter your email address',
      enterPassword: 'Enter your password',
      reEnterPassword: 'Re-enter your password',
      continue: 'Continue',
      alreadyHave: 'Already have an account?',
      login: 'Login',
      passwordStrength: 'Password Strength',
      weak: 'Weak',
      good: 'Good',
      strong: 'Strong',
      note: 'Note: You can create your account now and provide identification documents later. However, you will need to complete verification before submitting any reports.'
    },
    bn: {
      createAccount: 'অ্যাকাউন্ট তৈরি করুন',
      step1Of4: '৪টি ধাপের ১ম ধাপ',
      fullName: 'পূর্ণ নাম',
      phoneNumber: 'মোবাইল নম্বর',
      email: 'ইমেইল (ঐচ্ছিক)',
      password: 'পাসওয়ার্ড',
      confirmPassword: 'পাসওয়ার্ড নিশ্চিত করুন',
      enterFullName: 'আপনার পূর্ণ নাম লিখুন',
      enterPhone: 'আপনার মোবাইল নম্বর লিখুন',
      enterEmail: 'আপনার ইমেইল ঠিকানা লিখুন',
      enterPassword: 'আপনার পাসওয়ার্ড লিখুন',
      reEnterPassword: 'পাসওয়ার্ডটি পুনরায় লিখুন',
      continue: 'চালিয়ে যান',
      alreadyHave: 'ইতিমধ্যে অ্যাকাউন্ট আছে?',
      login: 'লগইন',
      passwordStrength: 'পাসওয়ার্ডের শক্তি',
      weak: 'দুর্বল',
      good: 'ভালো',
      strong: 'শক্তিশালী',
      note: 'নোট: আপনি এখনই আপনার অ্যাকাউন্ট তৈরি করতে পারেন এবং পরে পরিচয়পত্র প্রদান করতে পারেন। তবে কোনো রিপোর্ট জমা দেওয়ার আগে আপনাকে যাচাইকরণ সম্পূর্ণ করতে হবে।'
    }
  };

  const currentContent = content[language];

  const getPasswordStrength = (password: string) => {
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[!@#$%^&*]/.test(password)) strength++;
    return strength;
  };

  const getPasswordStrengthText = (strength: number) => {
    if (strength < 2) return { text: currentContent.weak, color: 'text-red-500' };
    if (strength < 4) return { text: currentContent.good, color: 'text-yellow-500' };
    return { text: currentContent.strong, color: 'text-green-500' };
  };

  const validateForm = () => {
    if (!formData.fullName.trim() || formData.fullName.length < 2) {
      alert('Please enter a valid full name');
      return false;
    }
    if (!formData.phoneNumber.trim() || !/^01[3-9]\d{8}$/.test(formData.phoneNumber)) {
      alert('Please enter a valid Bangladesh phone number');
      return false;
    }
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      alert('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 8) {
      alert('Password must be at least 8 characters long');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return false;
    }
    return true;
  };

  const handleContinue = async () => {
    if (!validateForm()) return;

    setIsLoading(true);

    // Simulate sending OTP
    setTimeout(() => {
      setIsLoading(false);
      navigate('/otp-verification', { 
        state: { 
          phoneNumber: formData.phoneNumber,
          userData: formData
        }
      });
    }, 2000);
  };

  const passwordStrength = getPasswordStrength(formData.password);
  const strengthInfo = getPasswordStrengthText(passwordStrength);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigate('/')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.createAccount}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
        
        {/* Progress Indicator */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-green-700/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
          </div>
          <p className="text-green-100 text-sm mt-2">{currentContent.step1Of4}</p>
        </div>
      </div>

      <div className="px-6 -mt-3">
        <div className="bg-white rounded-t-3xl min-h-screen pt-8 px-6">
          <form className="space-y-6">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentContent.fullName} *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder={currentContent.enterFullName}
                  required
                />
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentContent.phoneNumber} *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <div className="absolute inset-y-0 left-10 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">+88</span>
                </div>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                  className="w-full pl-20 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder={currentContent.enterPhone}
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentContent.email}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder={currentContent.enterEmail}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentContent.password} *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="w-full pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder={currentContent.enterPassword}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
              {formData.password && (
                <div className="mt-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{currentContent.passwordStrength}:</span>
                    <span className={strengthInfo.color}>{strengthInfo.text}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        passwordStrength < 2 ? 'bg-red-500' :
                        passwordStrength < 4 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${(passwordStrength / 5) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentContent.confirmPassword} *
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                  className="w-full pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  placeholder={currentContent.reEnterPassword}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
              {formData.confirmPassword && (
                <div className="mt-1 flex items-center space-x-1">
                  {formData.password === formData.confirmPassword ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span className="text-green-600 text-sm">Passwords match</span>
                    </>
                  ) : (
                    <span className="text-red-600 text-sm">Passwords do not match</span>
                  )}
                </div>
              )}
            </div>

            {/* Note */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">{currentContent.note}</p>
            </div>

            {/* Continue Button */}
            <CustomButton
              type="button"
              variant="primary"
              size="lg"
              className="w-full"
              onClick={handleContinue}
              loading={isLoading}
              icon={<ArrowRight className="w-5 h-5" />}
            >
              {currentContent.continue}
            </CustomButton>

            {/* Login Link */}
            <div className="text-center">
              <span className="text-gray-600 text-sm">{currentContent.alreadyHave} </span>
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="text-green-600 font-medium text-sm hover:text-green-700"
              >
                {currentContent.login}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
