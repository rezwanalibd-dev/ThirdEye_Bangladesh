import { useState } from 'react';
import { 
  LogOut, 
  Bell, 
  Settings, 
  CheckCircle, 
  XCircle, 
  Clock,
  MapPin,
  Camera,
  AlertTriangle,
  BarChart3,
  Filter
} from 'lucide-react';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

interface PendingCase {
  id: string;
  type: string;
  vehicleType: string;
  location: string;
  reportedAt: string;
  priority: 'high' | 'medium' | 'low';
  evidenceCount: number;
  reporterVerified: boolean;
}

export default function OfficerDashboard() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [filter, setFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  // const [selectedCase, setSelectedCase] = useState<PendingCase | null>(null);

  const content = {
    en: {
      officerPortal: 'DMP Officer Portal',
      welcome: 'Welcome back',
      officer: 'Officer',
      badge: 'Badge',
      logout: 'Logout',
      statistics: 'Statistics',
      pending: 'Pending',
      reviewed: 'Reviewed Today',
      approved: 'Approved',
      rejected: 'Rejected',
      pendingCases: 'Pending Cases',
      filterBy: 'Filter by Priority',
      all: 'All',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
      viewDetails: 'View Details',
      quickApprove: 'Quick Approve',
      quickReject: 'Quick Reject',
      priority: 'Priority',
      evidence: 'Evidence',
      reportedBy: 'Reported by',
      verifiedUser: 'Verified User',
      location: 'Location',
      time: 'Time',
      hoursAgo: 'hours ago',
      approve: 'Approve',
      reject: 'Reject',
      reviewing: 'Reviewing...'
    },
    bn: {
      officerPortal: 'ডিএমপি অফিসার পোর্টাল',
      welcome: 'স্বাগতম',
      officer: 'অফিসার',
      badge: 'ব্যাজ',
      logout: 'লগআউট',
      statistics: 'পরিসংখ্যান',
      pending: 'অপেক্ষমাণ',
      reviewed: 'আজ পর্যালোচিত',
      approved: 'অনুমোদিত',
      rejected: 'প্রত্যাখ্যাত',
      pendingCases: 'অপেক্ষমাণ কেস',
      filterBy: 'অগ্রাধিকার অনুযায়ী ফিল্টার',
      all: 'সব',
      high: 'উচ্চ',
      medium: 'মধ্যম',
      low: 'নিম্ন',
      viewDetails: 'বিস্তারিত দেখুন',
      quickApprove: 'দ্রুত অনুমোদন',
      quickReject: 'দ্রুত প্রত্যাখ্যান',
      priority: 'অগ্রাধিকার',
      evidence: 'প্রমাণ',
      reportedBy: 'রিপোর্টকারী',
      verifiedUser: 'যাচাইকৃত ব্যবহারকারী',
      location: 'অবস্থান',
      time: 'সময়',
      hoursAgo: 'ঘন্টা আগে',
      approve: 'অনুমোদন',
      reject: 'প্রত্যাখ্যান',
      reviewing: 'পর্যালোচনা...'
    }
  };

  const currentContent = content[language];

  // Sample officer data
  const officer = {
    name: 'Inspector Md. Rahman',
    badge: 'DMP-2024-157',
    rank: 'Inspector'
  };

  // Sample statistics
  const stats = {
    pending: 45,
    reviewedToday: 12,
    approved: 8,
    rejected: 3
  };

  // Sample pending cases
  const pendingCases: PendingCase[] = [
    {
      id: 'TE-2024-1105-001',
      type: 'Red Light Jumping',
      vehicleType: 'Motorbike',
      location: 'Dhanmondi 27',
      reportedAt: '2 hours ago',
      priority: 'high',
      evidenceCount: 2,
      reporterVerified: true
    },
    {
      id: 'TE-2024-1105-002',
      type: 'Wrong Side Driving',
      vehicleType: 'Car',
      location: 'Gulshan 2',
      reportedAt: '1 hour ago',
      priority: 'high',
      evidenceCount: 3,
      reporterVerified: true
    },
    {
      id: 'TE-2024-1105-003',
      type: 'No Helmet',
      vehicleType: 'Motorbike',
      location: 'Uttara Sector 7',
      reportedAt: '3 hours ago',
      priority: 'medium',
      evidenceCount: 1,
      reporterVerified: false
    },
    {
      id: 'TE-2024-1105-004',
      type: 'Illegal Parking',
      vehicleType: 'Car',
      location: 'Wari',
      reportedAt: '4 hours ago',
      priority: 'low',
      evidenceCount: 2,
      reporterVerified: true
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertTriangle className="w-4 h-4" />;
      case 'medium': return <Clock className="w-4 h-4" />;
      case 'low': return <CheckCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const filteredCases = pendingCases.filter(caseItem => 
    filter === 'all' || caseItem.priority === filter
  );

  const handleQuickAction = (caseId: string, action: 'approve' | 'reject') => {
    // Simulate quick action
    console.log(`${action} case ${caseId}`);
    // Here you would make an API call to update the case status
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold">{currentContent.officerPortal}</h1>
            <p className="text-green-100 text-sm">{currentContent.welcome}</p>
          </div>
          <div className="flex items-center space-x-3">
            <LanguageToggle onLanguageChange={setLanguage} />
            <button className="p-2 hover:bg-green-700 rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-green-700 rounded-lg transition-colors">
              <Settings className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-green-700 rounded-lg transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Officer Info */}
        <div className="bg-green-700/30 rounded-xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">
                {officer.name.split(' ').map(n => n[0]).join('')}
              </span>
            </div>
            <div>
              <h2 className="font-semibold">{officer.name}</h2>
              <p className="text-green-100 text-sm">{currentContent.badge}: {officer.badge}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Statistics */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.statistics}</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.pending}</p>
                  <p className="text-gray-600 text-sm">{currentContent.pending}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.reviewedToday}</p>
                  <p className="text-gray-600 text-sm">{currentContent.reviewed}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.approved}</p>
                  <p className="text-gray-600 text-sm">{currentContent.approved}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <XCircle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stats.rejected}</p>
                  <p className="text-gray-600 text-sm">{currentContent.rejected}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Pending Cases */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">{currentContent.pendingCases}</h3>
            
            {/* Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as any)}
                className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="all">{currentContent.all}</option>
                <option value="high">{currentContent.high}</option>
                <option value="medium">{currentContent.medium}</option>
                <option value="low">{currentContent.low}</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredCases.map((caseItem) => (
              <div key={caseItem.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-semibold text-gray-900 text-sm">{caseItem.type}</h4>
                      <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(caseItem.priority)}`}>
                        {getPriorityIcon(caseItem.priority)}
                        <span>{currentContent[caseItem.priority as keyof typeof currentContent]}</span>
                      </div>
                    </div>
                    <p className="text-gray-600 text-xs mb-1">{caseItem.id}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3" />
                        <span>{caseItem.location}</span>
                      </div>
                      <span>{caseItem.reportedAt}</span>
                      <div className="flex items-center space-x-1">
                        <Camera className="w-3 h-3" />
                        <span>{caseItem.evidenceCount}</span>
                      </div>
                      {caseItem.reporterVerified && (
                        <span className="text-green-600 font-medium">✓ {currentContent.verifiedUser}</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <CustomButton
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => console.log('View details for:', caseItem.id)}
                  >
                    {currentContent.viewDetails}
                  </CustomButton>
                  <CustomButton
                    variant="primary"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleQuickAction(caseItem.id, 'approve')}
                    icon={<CheckCircle className="w-4 h-4" />}
                  >
                    {currentContent.quickApprove}
                  </CustomButton>
                  <CustomButton
                    variant="outline"
                    size="sm"
                    className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
                    onClick={() => handleQuickAction(caseItem.id, 'reject')}
                    icon={<XCircle className="w-4 h-4" />}
                  >
                    {currentContent.quickReject}
                  </CustomButton>
                </div>
              </div>
            ))}

            {filteredCases.length === 0 && (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600">No pending cases</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
