import { useState } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  Camera, 
  Video, 
  CheckCircle,
  Upload,
  Image,
  FileVideo
} from 'lucide-react';
import { useNavigate } from 'react-router';
import CustomButton from '@/react-app/components/CustomButton';
import LanguageToggle from '@/react-app/components/LanguageToggle';

export default function ReportTraffic() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [formData, setFormData] = useState({
    vehicleType: '',
    violationType: '',
    vehicleNumber: '',
    location: 'Dhanmondi 27, Dhaka',
    description: '',
    capturedPhotos: [] as string[],
    capturedVideos: [] as string[],
    uploadedFiles: [] as string[]
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      title: 'Report Traffic Violation',
      vehicleType: 'Vehicle Type *',
      violationType: 'Traffic Violation Type *',
      vehicleNumber: 'Vehicle Number (Optional)',
      location: 'Location',
      useCurrentLocation: 'Use Current',
      selectOther: 'Select Other',
      evidence: 'Evidence (Mandatory)',
      quickCapture: 'Quick Capture',
      additionalUpload: 'Additional Upload',
      takePhoto: 'Take Photo',
      recordVideo: 'Record Video',
      uploadPhoto: 'Upload Photo',
      uploadVideo: 'Upload Video',
      uploadDocument: 'Upload Document',
      description: 'Description (Optional)',
      submit: 'Submit Report',
      required: 'Required fields marked with *',
      evidenceRequired: 'At least one photo or video evidence is required',
      selectVehicleFirst: 'Please select vehicle type first'
    },
    bn: {
      title: 'ট্রাফিক আইন ভঙ্গের রিপোর্ট করুন',
      vehicleType: 'গাড়ির ধরণ *',
      violationType: 'সড়ক আইন লঙ্ঘন *',
      vehicleNumber: 'গাড়ির নম্বর (ঐচ্ছিক)',
      location: 'অবস্থান',
      useCurrentLocation: 'আমার বর্তমান অবস্থান ব্যবহার করুন',
      selectOther: 'অন্যান্য অবস্থান নির্বাচন করুন',
      evidence: 'প্রমাণ (বাধ্যতামূলক)',
      quickCapture: 'দ্রুত ক্যাপচার',
      additionalUpload: 'অতিরিক্ত ফাইল আপলোড',
      takePhoto: 'ছবি তুলুন',
      recordVideo: 'ভিডিও রেকর্ড করুন',
      uploadPhoto: 'ছবি আপলোড করুন',
      uploadVideo: 'ভিডিও আপলোড করুন',
      uploadDocument: 'দলিল আপলোড করুন',
      description: 'বিবরণ (ঐচ্ছিক)',
      submit: 'রিপোর্ট জমা দিন',
      required: 'চিহ্নিত ফিল্ডগুলি আবশ্যক',
      evidenceRequired: 'কমপক্ষে একটি ছবি বা ভিডিও প্রমাণ আবশ্যক',
      selectVehicleFirst: 'অনুগ্রহ করে প্রথমে গাড়ির ধরণ নির্বাচন করুন'
    }
  };

  const vehicleTypes = {
    en: ['Private Car', 'Motorcycle', 'Public Transport (Bus/Minibus)', 'CNG Auto-rickshaw', 'E-rickshaw', 'Commercial Vehicle (Truck/Van)'],
    bn: ['প্রাইভেট কার', 'মোটরসাইকেল', 'পাবলিক ট্রান্সপোর্ট (বাস/মিনিবাস)', 'সিএনজি অটোরিকশা', 'ই-রিকশা', 'বাণিজ্যিক যানবাহন (ট্রাক/ভ্যান)']
  };

  // Map English to Bengali vehicle types for proper lookup
  const vehicleTypeMapping = {
    'Private Car': 'প্রাইভেট কার',
    'Motorcycle': 'মোটরসাইকেল', 
    'Public Transport (Bus/Minibus)': 'পাবলিক ট্রান্সপোর্ট (বাস/মিনিবাস)',
    'CNG Auto-rickshaw': 'সিএনজি অটোরিকশা',
    'E-rickshaw': 'ই-রিকশা',
    'Commercial Vehicle (Truck/Van)': 'বাণিজ্যিক যানবাহন (ট্রাক/ভ্যান)'
  };

  // Comprehensive violation types by vehicle category
  const violationsByVehicle = {
    en: {
      'Private Car': [
        'Driving without a valid driving licence',
        'Driving on the wrong side of the road',
        'Ignoring traffic lights or police signals',
        'Overspeeding or racing',
        'Using a mobile phone while driving',
        'Driving under the influence of alcohol/drugs',
        'Not wearing seat belts',
        'Illegal parking',
        'Using high beams improperly',
        'Blocking pedestrian crossings',
        'Making illegal U-turns',
        'Using horns in silent zones',
        'Driving an unregistered vehicle',
        'Driving without valid insurance',
        'Refusing to stop for police'
      ],
      'Motorcycle': [
        'Riding without a helmet',
        'Triple riding',
        'Wrong-side riding',
        'Riding on footpaths',
        'Overspeeding or reckless overtaking',
        'Driving without licence',
        'Not using indicators',
        'Modified exhaust pipes',
        'Carrying goods unsafely',
        'Using a mobile phone while riding',
        'Performing stunts',
        'Parking on sidewalks',
        'Driving without proper lights at night'
      ],
      'Public Transport (Bus/Minibus)': [
        'Picking up/dropping passengers in non-designated areas',
        'Overloading passengers',
        'Aggressive driving for passengers',
        'Stopping suddenly in the road',
        'Overcharging or denying meter-based fare',
        'Driving without route permit',
        'Ignoring traffic police signals',
        'Using defective or smoky vehicles',
        'Blocking lanes or intersections',
        'Not maintaining bus stops',
        'Reckless overtaking',
        'Driving with open doors',
        'Not maintaining vehicle fitness',
        'Misbehaviour by driver/conductor'
      ],
      'CNG Auto-rickshaw': [
        'Overloading passengers or goods',
        'Charging excessive fare',
        'Driving without valid registration',
        'Riding on prohibited roads',
        'Reckless driving and wrong-side riding',
        'Obstructive parking',
        'Driving without proper lights at night',
        'Not using meter',
        'Refusing passengers'
      ],
      'E-rickshaw': [
        'Overloading passengers or goods',
        'Charging excessive fare',
        'Driving without valid registration',
        'Riding on prohibited roads',
        'Reckless driving and wrong-side riding',
        'Obstructive parking',
        'Using non-standard batteries',
        'Driving without proper lights at night',
        'Illegal modification of motor or chassis'
      ],
      'Commercial Vehicle (Truck/Van)': [
        'Overloading beyond legal weight limit',
        'Carrying passengers in goods vehicles',
        'Driving without proper documents',
        'Parking on roads blocking traffic',
        'Operating without reflective signs/lights at night',
        'Driving with uncovered cargo',
        'Illegal modification of vehicle body',
        'Not maintaining brake/lighting systems',
        'Driving during restricted hours',
        'Failing to give way to emergency vehicles',
        'Driving under fatigue'
      ]
    },
    bn: {
      'প্রাইভেট কার': [
        'বৈধ ড্রাইভিং লাইসেন্স ছাড়া গাড়ি চালানো',
        'রাস্তার ভুল পাশে গাড়ি চালানো',
        'ট্রাফিক সিগন্যাল বা পুলিশের নির্দেশ অমান্য করা',
        'অতিরিক্ত গতিতে বা রেস করে গাড়ি চালানো',
        'গাড়ি চালানোর সময় মোবাইল ব্যবহার করা',
        'মদ্যপ বা নেশাগ্রস্ত অবস্থায় গাড়ি চালানো',
        'সিটবেল্ট না পরা',
        'বেআইনি বা রাস্তা অবরোধ করে পার্কিং করা',
        'অযথা হাই বিম বা ফগ লাইট ব্যবহার',
        'জেব্রা ক্রসিং বা মোড়ে গাড়ি থামিয়ে পথচারী বাধা সৃষ্টি করা',
        'সংকেত না দিয়ে ইউ-টার্ন বা মোড় নেওয়া',
        'নিষিদ্ধ এলাকায় হর্ন ব্যবহার',
        'রেজিস্ট্রেশন মেয়াদোত্তীর্ণ বা অনিবন্ধিত গাড়ি চালানো',
        'বীমা বা ফিটনেস সার্টিফিকেট ছাড়া গাড়ি চালানো',
        'পুলিশের নির্দেশে না থামা'
      ],
      'মোটরসাইকেল': [
        'চালক বা আরোহী হেলমেট না পরা',
        'এক মোটরসাইকেলে তিনজন বা তার বেশি যাত্রী বহন',
        'রাস্তার ভুল পাশে চালানো',
        'ফুটপাথ বা জনপথে মোটরসাইকেল চালানো',
        'অতিরিক্ত গতি বা ঝুঁকিপূর্ণ ওভারটেক',
        'লাইসেন্স বা রেজিস্ট্রেশন ছাড়া চালানো',
        'মোড় নেওয়ার সময় সংকেত না দেওয়া',
        'নিষিদ্ধ সাইলেন্সার বা মাফলার ব্যবহার (শব্দদূষণ)',
        'বিপজ্জনকভাবে মালামাল বহন',
        'চালানোর সময় মোবাইল ব্যবহার',
        'রাস্তার মধ্যে স্টান্ট বা হুইলি করা',
        'ফুটপাথে বেআইনি পার্কিং',
        'রাতে লাইট ছাড়া চালানো'
      ],
      'পাবলিক ট্রান্সপোর্ট (বাস/মিনিবাস)': [
        'নির্ধারিত স্থানের বাইরে যাত্রী ওঠা-নামা করানো',
        'যাত্রী ধারণক্ষমতার বেশি যাত্রী বহন',
        'যাত্রী নেওয়ার প্রতিযোগিতায় বেপরোয়া চালানো',
        'রাস্তার মাঝখানে হঠাৎ থামা',
        'ভাড়ার বেশি টাকা নেওয়া বা মিটার ব্যবহার না করা',
        'রুট পারমিট বা রেজিস্ট্রেশন ছাড়া চলাচল',
        'ট্রাফিক পুলিশের নির্দেশ অমান্য করা',
        'ধোঁয়া নির্গত বা ত্রুটিপূর্ণ যানবাহন ব্যবহার',
        'রাস্তা বা মোড় অবরোধ করা',
        'নির্ধারিত বাস স্টপ বা বে ব্যবহার না করা',
        'বেপরোয়া ওভারটেক বা লেন ভঙ্গ',
        'খোলা দরজা বা ঝুলন্ত যাত্রী নিয়ে চালানো',
        'বীমা বা ফিটনেস ছাড়া গাড়ি চালানো',
        'চালক বা সহকারীর অসদাচরণ বা হয়রানি'
      ],
      'সিএনজি অটোরিকশা': [
        'যাত্রী বা মালামাল অতিরিক্ত বহন',
        'অতিরিক্ত ভাড়া নেওয়া',
        'বৈধ রেজিস্ট্রেশন বা পারমিট ছাড়া চালানো',
        'যে রাস্তায় চলাচল নিষিদ্ধ সেখানে চলাচল',
        'বেপরোয়া গাড়ি চালানো ও ভুল দিকে চলাচল',
        'যানজট সৃষ্টি করে পার্কিং',
        'রাতে সঠিক লাইট বা রিফ্লেক্টর ছাড়া চালানো',
        'মিটার ব্যবহার না করা',
        'যাত্রী নিতে অস্বীকার করা'
      ],
      'ই-রিকশা': [
        'যাত্রী বা মালামাল অতিরিক্ত বহন',
        'অতিরিক্ত ভাড়া নেওয়া',
        'বৈধ রেজিস্ট্রেশন বা পারমিট ছাড়া চালানো',
        'যে রাস্তায় ই-রিকশা চলাচল নিষিদ্ধ সেখানে চলাচল',
        'বেপরোয়া গাড়ি চালানো ও ভুল দিকে চলাচল',
        'যানজট সৃষ্টি করে পার্কিং',
        'অননুমোদিত বা অনিরাপদ ব্যাটারি ব্যবহার',
        'রাতে সঠিক লাইট বা রিফ্লেক্টর ছাড়া চালানো',
        'মোটর বা চ্যাসির অবৈধ পরিবর্তন'
      ],
      'বাণিজ্যিক যানবাহন (ট্রাক/ভ্যান)': [
        'অনুমোদিত ওজনসীমার বেশি মালামাল বহন',
        'পণ্যবাহী গাড়িতে যাত্রী বহন',
        'বৈধ নথি (লাইসেন্স, রুট পারমিট, ফিটনেস) ছাড়া চালানো',
        'রাস্তা বা মোড়ে গাড়ি দাঁড় করিয়ে যানজট সৃষ্টি',
        'রাতে রিফ্লেকটিভ সাইন বা লাইট ছাড়া চলাচল',
        'খোলা বা ঠিকভাবে বাঁধা নয় এমন মাল বহন',
        'অনুমতি ছাড়া গাড়ির কাঠামো পরিবর্তন',
        'ব্রেক বা লাইট ত্রুটিপূর্ণ অবস্থায় চালানো',
        'নির্দিষ্ট সময়ে নিষিদ্ধ এলাকায় প্রবেশ',
        'এমার্জেন্সি যানবাহনকে পথ না দেওয়া',
        'ক্লান্তি বা নিদ্রাহীন অবস্থায় গাড়ি চালানো'
      ]
    }
  };

  const currentContent = content[language];
  const currentVehicleTypes = vehicleTypes[language];

  const getViolationTypes = (vehicleType: string): string[] => {
    if (!vehicleType) return [];
    
    // Get the appropriate key for the violations lookup
    let lookupKey = vehicleType;
    
    // If we're in Bengali mode but the vehicle type is in English, map it to Bengali
    if (language === 'bn' && vehicleType in vehicleTypeMapping) {
      lookupKey = (vehicleTypeMapping as any)[vehicleType];
    }
    
    // If we're in English mode but the vehicle type is in Bengali, find the English equivalent
    if (language === 'en') {
      const reverseMapping = Object.entries(vehicleTypeMapping).find(([, bn]) => bn === vehicleType);
      if (reverseMapping) {
        lookupKey = reverseMapping[0];
      }
    }
    
    const violationData = violationsByVehicle[language];
    if (lookupKey in violationData) {
      return (violationData as any)[lookupKey];
    }
    return [];
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if at least one evidence (captured or uploaded) is provided
    if (formData.capturedPhotos.length === 0 && formData.capturedVideos.length === 0 && formData.uploadedFiles.length === 0) {
      alert(currentContent.evidenceRequired);
      return;
    }

    setIsLoading(true);
    
    // Simulate submission
    setTimeout(() => {
      setIsLoading(false);
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.title}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="px-6 py-6 space-y-6">
        {/* Vehicle Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.vehicleType}
          </label>
          <select
            value={formData.vehicleType}
            onChange={(e) => setFormData({...formData, vehicleType: e.target.value, violationType: ''})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            required
          >
            <option value="">{language === 'en' ? 'Select vehicle type' : 'গাড়ির ধরণ নির্বাচন করুন'}</option>
            {currentVehicleTypes.map((type, index) => (
              <option key={index} value={type}>{type}</option>
            ))}
          </select>
        </div>

        {/* Violation Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.violationType}
          </label>
          <select
            value={formData.violationType}
            onChange={(e) => setFormData({...formData, violationType: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            required
            disabled={!formData.vehicleType}
          >
            <option value="">
              {formData.vehicleType ? (language === 'en' ? 'Select Traffic Violation Type' : 'ট্রাফিক আইন ভঙ্গের ধরন নির্বাচন করুন') : currentContent.selectVehicleFirst}
            </option>
            {getViolationTypes(formData.vehicleType).map((type, index) => (
              <option key={index} value={type}>{type}</option>
            ))}
          </select>
        </div>

        {/* Vehicle Number */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.vehicleNumber}
          </label>
          <input
            type="text"
            value={formData.vehicleNumber}
            onChange={(e) => setFormData({...formData, vehicleNumber: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            placeholder={language === 'en' ? 'Dhaka Metro Ka 11-1234' : 'ঢাকা মেট্রো কা ১১-১২৩৪'}
          />
        </div>

        {/* Location */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.location}
          </label>
          <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg border border-green-200 mb-2">
            <MapPin className="w-5 h-5 text-green-600" />
            <span className="text-green-800 font-medium">{formData.location}</span>
          </div>
          <div className="flex space-x-2">
            <CustomButton variant="outline" size="sm" className="flex-1">
              {currentContent.useCurrentLocation}
            </CustomButton>
            <CustomButton variant="ghost" size="sm" className="flex-1">
              {currentContent.selectOther}
            </CustomButton>
          </div>
        </div>

        {/* Evidence Section */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.evidence}
          </label>
          
          {/* Quick Capture */}
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-600 mb-2">{currentContent.quickCapture}</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                className="border-2 border-dashed border-green-300 bg-green-50 rounded-lg p-6 text-center hover:border-green-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate photo capture
                  const newPhoto = `photo_${Date.now()}`;
                  setFormData({
                    ...formData, 
                    capturedPhotos: [...formData.capturedPhotos, newPhoto]
                  });
                }}
              >
                <Camera className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <p className="text-sm text-green-700 font-medium">{currentContent.takePhoto}</p>
                <p className="text-xs text-green-600">{language === 'en' ? 'Mandatory' : 'বাধ্যতামূলক'}</p>
              </button>
              
              <button
                type="button"
                className="border-2 border-dashed border-green-300 bg-green-50 rounded-lg p-6 text-center hover:border-green-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate video capture
                  const newVideo = `video_${Date.now()}`;
                  setFormData({
                    ...formData, 
                    capturedVideos: [...formData.capturedVideos, newVideo]
                  });
                }}
              >
                <Video className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <p className="text-sm text-green-700 font-medium">{currentContent.recordVideo}</p>
                <p className="text-xs text-green-600">{language === 'en' ? 'Mandatory' : 'বাধ্যতামূলক'}</p>
              </button>
            </div>
          </div>

          {/* Additional Upload */}
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-600 mb-2">{currentContent.additionalUpload}</h3>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate photo upload
                  const newFile = `uploaded_photo_${Date.now()}`;
                  setFormData({
                    ...formData,
                    uploadedFiles: [...formData.uploadedFiles, newFile]
                  });
                }}
              >
                <Image className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadPhoto}</p>
              </button>
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate video upload
                  const newFile = `uploaded_video_${Date.now()}`;
                  setFormData({
                    ...formData,
                    uploadedFiles: [...formData.uploadedFiles, newFile]
                  });
                }}
              >
                <FileVideo className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadVideo}</p>
              </button>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer">
                <Upload className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadDocument}</p>
              </div>
            </div>
          </div>

          {/* Evidence Summary */}
          {(formData.capturedPhotos.length > 0 || formData.capturedVideos.length > 0 || formData.uploadedFiles.length > 0) ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800">
                ✓ Evidence: {formData.capturedPhotos.length} photos captured, {formData.capturedVideos.length} videos captured, {formData.uploadedFiles.length} files uploaded
              </p>
            </div>
          ) : (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-800 font-medium">
                ⚠️ {currentContent.evidenceRequired}
              </p>
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.description}
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
            placeholder={language === 'en' ? 'Provide additional details about the violation...' : 'উল্লঙ্ঘন সম্পর্কে অতিরিক্ত তথ্য প্রদান করুন...'}
          />
        </div>

        {/* Required Fields Note */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">{currentContent.required}</p>
        </div>

        {/* Submit Button */}
        <CustomButton
          type="submit"
          variant="primary"
          size="lg"
          className="w-full"
          loading={isLoading}
          icon={<CheckCircle className="w-5 h-5" />}
        >
          {currentContent.submit}
        </CustomButton>
      </form>
    </div>
  );
}
