import { useState } from 'react';
import { ArrowRight, Camera, CheckCircle, RotateCcw } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function BiometricVerification() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [currentStep, setCurrentStep] = useState<'front' | 'left' | 'right'>('front');
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());
  const [isCapturing, setIsCapturing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      biometricVerification: 'Biometric Verification',
      step4Of4: 'Step 4 of 4',
      takeSelfie: 'Take 3 Selfie Photos',
      instructions: {
        front: 'Look straight at the camera with a neutral expression',
        left: 'Turn your head left (your right) at a 45-degree angle',
        right: 'Turn your head right (your left) at a 45-degree angle'
      },
      positions: {
        front: 'Front Face',
        left: 'Left Side',
        right: 'Right Side'
      },
      capture: 'Capture Photo',
      retake: 'Retake',
      continue: 'Continue',
      completed: 'Completed',
      guidelines: 'Photo Guidelines:',
      guideline1: '• Remove glasses and hat',
      guideline2: '• Ensure good lighting',
      guideline3: '• Keep neutral expression',
      guideline4: '• Fill the circle with your face',
      almostDone: 'Almost done! Complete your verification to start reporting violations.'
    },
    bn: {
      biometricVerification: 'বায়োমেট্রিক যাচাইকরণ',
      step4Of4: '৪টি ধাপের ৪র্থ ধাপ',
      takeSelfie: '৩টি সেলফি ছবি তুলুন',
      instructions: {
        front: 'ক্যামেরার দিকে সোজা তাকিয়ে স্বাভাবিক ভাব রাখুন',
        left: 'আপনার মাথা বামে (আপনার ডানে) ৪৫ ডিগ্রি কোণে ঘুরান',
        right: 'আপনার মাথা ডানে (আপনার বামে) ৪৫ ডিগ্রি কোণে ঘুরান'
      },
      positions: {
        front: 'সামনের দিক',
        left: 'বাম দিক',
        right: 'ডান দিক'
      },
      capture: 'ছবি তুলুন',
      retake: 'আবার তুলুন',
      continue: 'চালিয়ে যান',
      completed: 'সম্পন্ন',
      guidelines: 'ছবি তোলার নির্দেশনা:',
      guideline1: '• চশমা এবং টুপি সরান',
      guideline2: '• ভালো আলোর ব্যবস্থা করুন',
      guideline3: '• স্বাভাবিক ভাব রাখুন',
      guideline4: '• বৃত্তটি আপনার মুখ দিয়ে পূর্ণ করুন',
      almostDone: 'প্রায় শেষ! লঙ্ঘন রিপোর্ট শুরু করতে আপনার যাচাইকরণ সম্পূর্ণ করুন।'
    }
  };

  const currentContent = content[language];
  const positions = ['front', 'left', 'right'] as const;

  const handleCapture = async () => {
    setIsCapturing(true);
    
    // Simulate photo capture
    setTimeout(() => {
      setCompletedSteps(prev => new Set([...prev, currentStep]));
      setIsCapturing(false);
      
      // Move to next step
      const currentIndex = positions.indexOf(currentStep);
      if (currentIndex < positions.length - 1) {
        setCurrentStep(positions[currentIndex + 1]);
      }
    }, 2000);
  };

  const handleRetake = () => {
    setCompletedSteps(prev => {
      const newSet = new Set(prev);
      newSet.delete(currentStep);
      return newSet;
    });
  };

  const handleComplete = async () => {
    setIsLoading(true);
    
    // Simulate final verification
    setTimeout(() => {
      setIsLoading(false);
      navigate('/wallet-setup');
    }, 2000);
  };

  const allCompleted = positions.every(pos => completedSteps.has(pos));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.biometricVerification}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
        
        {/* Progress Indicator */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-green-700/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
          <p className="text-green-100 text-sm mt-2">{currentContent.step4Of4}</p>
        </div>
      </div>

      <div className="px-6 -mt-3">
        <div className="bg-white rounded-t-3xl min-h-screen pt-8 px-6">
          {/* Title */}
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {currentContent.takeSelfie}
            </h2>
            <p className="text-gray-600 text-sm">
              {currentContent.almostDone}
            </p>
          </div>

          {/* Position Steps */}
          <div className="flex justify-center space-x-6 mb-8">
            {positions.map((position, index) => (
              <div key={position} className="text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                  completedSteps.has(position) 
                    ? 'bg-green-500 text-white' 
                    : currentStep === position
                    ? 'bg-green-100 text-green-600 border-2 border-green-500'
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  {completedSteps.has(position) ? (
                    <CheckCircle className="w-6 h-6" />
                  ) : (
                    <span className="font-bold">{index + 1}</span>
                  )}
                </div>
                <span className={`text-xs font-medium ${
                  completedSteps.has(position) || currentStep === position
                    ? 'text-green-600'
                    : 'text-gray-500'
                }`}>
                  {currentContent.positions[position]}
                </span>
              </div>
            ))}
          </div>

          {/* Camera Preview */}
          <div className="relative mb-6">
            <div className="bg-gray-900 rounded-2xl aspect-[3/4] flex items-center justify-center overflow-hidden">
              {/* Face Guide Overlay */}
              <div className="relative">
                <div className="w-48 h-48 rounded-full border-4 border-white/50 flex items-center justify-center">
                  <div className="w-44 h-44 rounded-full border-2 border-dashed border-white/70 flex items-center justify-center">
                    {isCapturing ? (
                      <div className="w-40 h-40 rounded-full bg-white/20 animate-pulse"></div>
                    ) : (
                      <Camera className="w-8 h-8 text-white/60" />
                    )}
                  </div>
                </div>
                
                {/* Position indicator */}
                {currentStep === 'left' && (
                  <div className="absolute top-1/2 -right-16 transform -translate-y-1/2">
                    <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                )}
                {currentStep === 'right' && (
                  <div className="absolute top-1/2 -left-16 transform -translate-y-1/2">
                    <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Current instruction */}
            <div className="absolute bottom-4 left-4 right-4 bg-black/50 rounded-lg p-3">
              <p className="text-white text-sm text-center">
                {currentContent.instructions[currentStep]}
              </p>
            </div>
          </div>

          {/* Guidelines */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-blue-800 text-sm font-medium mb-2">
              {currentContent.guidelines}
            </p>
            <div className="text-blue-700 text-sm space-y-1">
              <div>{currentContent.guideline1}</div>
              <div>{currentContent.guideline2}</div>
              <div>{currentContent.guideline3}</div>
              <div>{currentContent.guideline4}</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 mb-6">
            {!allCompleted ? (
              <div className="flex space-x-3">
                {completedSteps.has(currentStep) ? (
                  <>
                    <CustomButton
                      variant="outline"
                      size="lg"
                      className="flex-1"
                      onClick={handleRetake}
                      icon={<RotateCcw className="w-5 h-5" />}
                    >
                      {currentContent.retake}
                    </CustomButton>
                    <CustomButton
                      variant="primary"
                      size="lg"
                      className="flex-1"
                      onClick={() => {
                        const currentIndex = positions.indexOf(currentStep);
                        if (currentIndex < positions.length - 1) {
                          setCurrentStep(positions[currentIndex + 1]);
                        }
                      }}
                      icon={<ArrowRight className="w-5 h-5" />}
                    >
                      Next
                    </CustomButton>
                  </>
                ) : (
                  <CustomButton
                    variant="primary"
                    size="lg"
                    className="w-full"
                    onClick={handleCapture}
                    loading={isCapturing}
                    icon={<Camera className="w-5 h-5" />}
                  >
                    {currentContent.capture}
                  </CustomButton>
                )}
              </div>
            ) : (
              <CustomButton
                variant="primary"
                size="lg"
                className="w-full"
                onClick={handleComplete}
                loading={isLoading}
                icon={<CheckCircle className="w-5 h-5" />}
              >
                {currentContent.continue}
              </CustomButton>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
