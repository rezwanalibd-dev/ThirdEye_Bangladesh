import { useState } from 'react';
import { ArrowLeft, Bell, AlertTriangle, CheckCircle, Clock, Info } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import BottomNavigation from '@/react-app/components/BottomNavigation';

interface Alert {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'urgent';
  time: string;
  isRead: boolean;
}

export default function Alerts() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [activeTab, setActiveTab] = useState('alerts');
  const navigate = useNavigate();

  const content = {
    en: {
      title: 'Alerts & Notifications',
      noAlerts: 'No new alerts',
      markAllRead: 'Mark all as read'
    },
    bn: {
      title: 'সতর্কতা এবং বিজ্ঞপ্তি',
      noAlerts: 'কোনো নতুন সতর্কতা নেই',
      markAllRead: 'সবগুলো পড়া হিসেবে চিহ্নিত করুন'
    }
  };

  const currentContent = content[language];

  // Sample alerts
  const alerts: Alert[] = [
    {
      id: '1',
      title: 'Case Status Update',
      message: 'Your traffic violation report TE-2024-1105-001 has been verified by DMP',
      type: 'success',
      time: '2 hours ago',
      isRead: false
    },
    {
      id: '2',
      title: 'Reward Payment',
      message: 'You have received ৳600 reward for case TE-2024-1031-015',
      type: 'success',
      time: '1 day ago',
      isRead: false
    },
    {
      id: '3',
      title: 'App Update',
      message: 'New features available in Third Eye Bangladesh v2.1',
      type: 'info',
      time: '3 days ago',
      isRead: true
    }
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'urgent': return <AlertTriangle className="w-5 h-5 text-red-600" />;
      default: return <Info className="w-5 h-5 text-blue-600" />;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'success': return 'border-green-200 bg-green-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      case 'urgent': return 'border-red-200 bg-red-50';
      default: return 'border-blue-200 bg-blue-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.title}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <div className="px-6 py-6">
        {alerts.length > 0 ? (
          <>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-900">
                  {alerts.filter(alert => !alert.isRead).length} new alerts
                </span>
              </div>
              <button className="text-green-600 text-sm font-medium hover:text-green-500">
                {currentContent.markAllRead}
              </button>
            </div>

            <div className="space-y-3">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${getAlertColor(alert.type)} ${
                    !alert.isRead ? 'shadow-sm' : ''
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">
                          {alert.title}
                        </h3>
                        {!alert.isRead && (
                          <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                        )}
                      </div>
                      <p className="text-gray-700 text-sm mb-2">{alert.message}</p>
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        <span>{alert.time}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600 font-medium">{currentContent.noAlerts}</p>
            <p className="text-gray-500 text-sm mt-1">
              We'll notify you about important updates
            </p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        language={language} 
      />
    </div>
  );
}
