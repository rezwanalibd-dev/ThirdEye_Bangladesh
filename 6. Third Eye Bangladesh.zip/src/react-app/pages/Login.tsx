import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, LogIn } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function Login() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [formData, setFormData] = useState({
    phoneEmail: '',
    password: '',
    userType: 'citizen'
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      title: 'Login to Third Eye',
      subtitle: 'Welcome back! Please sign in to your account',
      phoneEmail: 'Phone Number or Email',
      password: 'Password',
      forgotPassword: 'Forgot Password?',
      login: 'Login',
      noAccount: "Don't have an account?",
      signUp: 'Sign Up',
      accountType: 'Account Type',
      citizen: 'Citizen',
      officer: 'Officer',
      enterPhone: 'Enter phone number or email',
      enterPassword: 'Enter your password',
      loginSuccess: 'Login successful!',
      invalidCredentials: 'Invalid phone/email or password'
    },
    bn: {
      title: 'থার্ড আইতে লগইন',
      subtitle: 'স্বাগতম! আপনার অ্যাকাউন্টে সাইন ইন করুন',
      phoneEmail: 'ফোন নম্বর বা ইমেইল',
      password: 'পাসওয়ার্ড',
      forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?',
      login: 'লগইন',
      noAccount: 'কোনো অ্যাকাউন্ট নেই?',
      signUp: 'সাইন আপ করুন',
      accountType: 'অ্যাকাউন্টের ধরন',
      citizen: 'নাগরিক',
      officer: 'কর্মকর্তা',
      enterPhone: 'ফোন নম্বর বা ইমেইল লিখুন',
      enterPassword: 'আপনার পাসওয়ার্ড লিখুন',
      loginSuccess: 'লগইন সফল!',
      invalidCredentials: 'ভুল ফোন/ইমেইল বা পাসওয়ার্ড'
    }
  };

  const currentContent = content[language];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      if (formData.userType === 'officer') {
        navigate('/officer-dashboard');
      } else {
        navigate('/dashboard');
      }
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.title}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <div className="px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-green-700 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg">
            <LogIn className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{currentContent.title}</h2>
          <p className="text-gray-600 text-sm">{currentContent.subtitle}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Account Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {currentContent.accountType}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormData({...formData, userType: 'citizen'})}
                className={`py-3 px-4 rounded-lg border font-medium transition-colors ${
                  formData.userType === 'citizen'
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-green-400'
                }`}
              >
                {currentContent.citizen}
              </button>
              <button
                type="button"
                onClick={() => setFormData({...formData, userType: 'officer'})}
                className={`py-3 px-4 rounded-lg border font-medium transition-colors ${
                  formData.userType === 'officer'
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-green-400'
                }`}
              >
                {currentContent.officer}
              </button>
            </div>
          </div>

          {/* Phone/Email Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {currentContent.phoneEmail}
            </label>
            <input
              type="text"
              value={formData.phoneEmail}
              onChange={(e) => setFormData({...formData, phoneEmail: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder={currentContent.enterPhone}
              required
            />
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {currentContent.password}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 pr-12"
                placeholder={currentContent.enterPassword}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Forgot Password */}
          <div className="text-right">
            <button
              type="button"
              className="text-green-600 text-sm font-medium hover:text-green-500"
            >
              {currentContent.forgotPassword}
            </button>
          </div>

          {/* Login Button */}
          <CustomButton
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
            loading={isLoading}
            icon={<LogIn className="w-5 h-5" />}
          >
            {currentContent.login}
          </CustomButton>

          {/* Sign Up Link */}
          <div className="text-center">
            <span className="text-gray-600 text-sm">{currentContent.noAccount} </span>
            <button
              type="button"
              onClick={() => navigate('/signup')}
              className="text-green-600 text-sm font-medium hover:text-green-500"
            >
              {currentContent.signUp}
            </button>
          </div>
        </form>

        {/* Demo Credentials */}
        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">Demo Credentials</h3>
          <div className="text-sm text-blue-700 space-y-1">
            <p><strong>Citizen:</strong> demo@thirdeye.gov.bd / demo123</p>
            <p><strong>Officer:</strong> officer@dmp.gov.bd / demo123</p>
          </div>
        </div>
      </div>
    </div>
  );
}
