import { useState } from 'react';
import { 
  Bell, 
  Settings, 
  Car, 
  AlertTriangle, 
  Search, 
  Clock,
  ArrowRight,
  Plus
} from 'lucide-react';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import BottomNavigation from '@/react-app/components/BottomNavigation';
import PWAInstallPrompt from '@/react-app/components/PWAInstallPrompt';

export default function Dashboard() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [activeTab, setActiveTab] = useState('home');

  const content = {
    en: {
      appName: 'Third Eye Bangladesh',
      greeting: 'Welcome back, Rahman!',
      quickActions: 'Quick Actions',
      recentReports: 'Recent Reports',
      actions: [
        { id: 'traffic', icon: Car, title: 'Traffic Violation', subtitle: 'Report road violations', path: '/report-traffic' },
        { id: 'crime', icon: AlertTriangle, title: 'Social Crime', subtitle: 'Report criminal activities', path: '/report-crime' },
        { id: 'search', icon: Search, title: 'Case Search', subtitle: 'Track your reports', path: '/case-tracking' }
      ],
      reports: [
        { id: 'TE-2024-1101-001', type: 'Red Light Jump', status: 'Under Review', time: '2 hours ago', reward: '৳1,000' },
        { id: 'TE-2024-1031-015', type: 'Wrong Side', status: 'Verified', time: '1 day ago', reward: '৳600' }
      ]
    },
    bn: {
      appName: 'তৃতীয় চোখ বাংলাদেশ',
      greeting: 'স্বাগতম, রহমান!',
      quickActions: 'দ্রুত কার্যক্রম',
      recentReports: 'সাম্প্রতিক রিপোর্ট',
      actions: [
        { id: 'traffic', icon: Car, title: 'ট্রাফিক লঙ্ঘন', subtitle: 'যানবাহন লঙ্ঘন রিপোর্ট করুন', path: '/report-traffic' },
        { id: 'crime', icon: AlertTriangle, title: 'সামাজিক অপরাধ', subtitle: 'অপরাধমূলক কার্যকলাপ রিপোর্ট করুন', path: '/report-crime' },
        { id: 'search', icon: Search, title: 'কেস খোঁজ', subtitle: 'আপনার রিপোর্ট ট্র্যাক করুন', path: '/case-tracking' }
      ],
      reports: [
        { id: 'TE-2024-1101-001', type: 'লাল বাতি লঙ্ঘন', status: 'পর্যালোচনাধীন', time: '২ ঘন্টা আগে', reward: '৳১,০০০' },
        { id: 'TE-2024-1031-015', type: 'ভুল পাশ', status: 'যাচাইকৃত', time: '১ দিন আগে', reward: '৳৬০০' }
      ]
    }
  };

  const currentContent = content[language];

  const getStatusColor = (status: string) => {
    if (status.includes('Review') || status.includes('পর্যালোচনা')) return 'text-yellow-600 bg-yellow-50';
    if (status.includes('Verified') || status.includes('যাচাই')) return 'text-green-600 bg-green-50';
    return 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold">{currentContent.appName}</h1>
            <p className="text-green-100 text-sm">{currentContent.greeting}</p>
          </div>
          <div className="flex items-center space-x-3">
            <LanguageToggle onLanguageChange={setLanguage} />
            <button className="p-2 hover:bg-green-700 rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-green-700 rounded-lg transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-6 mt-8">
        {/* Quick Actions */}
        <div className="mb-6 mt-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.quickActions}</h2>
          <div className="grid grid-cols-2 gap-3">
            {currentContent.actions.map((action) => (
              <button
                key={action.id}
                onClick={() => window.location.href = action.path}
                className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left"
              >
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mb-3">
                  <action.icon className="w-5 h-5 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 text-sm mb-1">{action.title}</h3>
                <p className="text-gray-600 text-xs">{action.subtitle}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Reports */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">{currentContent.recentReports}</h2>
            <button className="text-green-600 text-sm font-medium">
              {language === 'en' ? 'View All' : 'সব দেখুন'}
            </button>
          </div>
          <div className="space-y-3">
            {currentContent.reports.map((report) => (
              <div key={report.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 text-sm">{report.type}</h3>
                    <p className="text-gray-600 text-xs">{report.id}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                    {report.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{report.time}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="font-medium text-green-600">{report.reward}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-400" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Floating Action Button */}
      <button className="fixed bottom-24 right-6 w-14 h-14 bg-green-600 text-white rounded-full shadow-lg hover:bg-green-700 transition-colors flex items-center justify-center">
        <Plus className="w-6 h-6" />
      </button>

      {/* PWA Install Prompt */}
      <PWAInstallPrompt language={language} />

      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        language={language} 
      />
    </div>
  );
}
