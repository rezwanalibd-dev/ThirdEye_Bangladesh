import { useState } from 'react';
import { ArrowLeft, Camera, Video, CheckCircle, MapPin, AlertTriangle, Upload, Image, FileVideo } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function ReportCrime() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [formData, setFormData] = useState({
    crimeCategory: '',
    crimeType: '',
    description: '',
    location: 'Dhanmondi 27, Dhaka',
    capturedPhotos: [] as string[],
    capturedVideos: [] as string[],
    uploadedFiles: [] as string[],
    isAnonymous: true
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      title: 'Report Social Crime',
      crimeCategory: 'Crime Category *',
      crimeType: 'Social Crime Type *',
      description: 'Description *',
      location: 'Location',
      useCurrentLocation: 'Use Current',
      selectOther: 'Select Other',
      evidence: 'Evidence *',
      quickCapture: 'Quick Capture',
      additionalUpload: 'Additional Upload',
      takePhoto: 'Take Photo',
      recordVideo: 'Record Video',
      uploadPhoto: 'Upload Photo',
      uploadVideo: 'Upload Video',
      uploadDocument: 'Upload Document',
      anonymous: 'Report Anonymously',
      anonymousNote: 'Your identity will be protected. Only authorized officials will have access to your details.',
      submit: 'Submit Report',
      required: 'Required fields marked with *',
      safetyFirst: 'Your Safety First',
      safetyNote: 'Only report if it is safe to do so. Do not put yourself in danger. Call 999 for immediate emergencies.',
      selectCategoryFirst: 'Please select crime category first',
      warning: 'Warning: False reports are punishable by law',
      evidenceRequired: 'Please capture at least one photo or video as evidence',
      requiredLabel: 'Required'
    },
    bn: {
      title: 'সামাজিক অপরাধ রিপোর্ট',
      crimeCategory: 'অপরাধের বিভাগ *',
      crimeType: 'সামাজিক অপরাধের ধরন *',
      description: 'বিবরণ *',
      location: 'অবস্থান',
      useCurrentLocation: 'বর্তমান ব্যবহার করুন',
      selectOther: 'অন্য নির্বাচন করুন',
      evidence: 'প্রমাণ *',
      quickCapture: 'দ্রুত ক্যাপচার',
      additionalUpload: 'অতিরিক্ত আপলোড',
      takePhoto: 'ছবি তুলুন',
      recordVideo: 'ভিডিও রেকর্ড',
      uploadPhoto: 'ছবি আপলোড',
      uploadVideo: 'ভিডিও আপলোড',
      uploadDocument: 'ডকুমেন্ট আপলোড',
      anonymous: 'আপনার পরিচয় গোপন রেখে রিপোর্ট করুন',
      anonymousNote: 'আপনার পরিচয় সুরক্ষিত থাকবে। শুধুমাত্র অনুমোদিত কর্মকর্তারা আপনার বিবরণ দেখতে পারবেন।',
      submit: 'রিপোর্ট জমা দিন',
      required: '* চিহ্নিত ক্ষেত্রগুলি আবশ্যক',
      safetyFirst: 'আপনার নিরাপত্তা প্রথম',
      safetyNote: 'শুধুমাত্র নিরাপদ হলেই রিপোর্ট করুন। নিজেকে বিপদে ফেলবেন না। জরুরি পরিস্থিতিতে 999 এ কল করুন।',
      selectCategoryFirst: 'প্রথমে অপরাধের বিভাগ নির্বাচন করুন',
      warning: 'সতর্কতা: মিথ্যা রিপোর্ট আইনত দণ্ডনীয়',
      evidenceRequired: 'প্রমাণ হিসেবে অন্তত একটি ছবি বা ভিডিও ক্যাপচার করুন',
      requiredLabel: 'আবশ্যক'
    }
  };

  const crimeCategories = {
    en: [
      'Crimes of Violence / Person-centric',
      'Property Crimes',
      'Economic / White-collar Crimes',
      'Crimes against Social / Moral Legislation',
      'Organised & High-Tech Crimes',
      'Crimes against Public Order / State / Society'
    ],
    bn: [
      'সহিংসতার অপরাধ / ব্যক্তিকেন্দ্রিক',
      'সম্পত্তি অপরাধ',
      'অর্থনৈতিক / হোয়াইট-কলার অপরাধ',
      'সামাজিক / নৈতিক আইনের বিরুদ্ধে অপরাধ',
      'সংগঠিত ও হাই-টেক অপরাধ',
      'জনশৃঙ্খলা / রাষ্ট্র / সমাজের বিরুদ্ধে অপরাধ'
    ]
  };

  const crimeTypesByCategory = {
    en: {
      'Crimes of Violence / Person-centric': [
        'Murder / Homicide',
        'Attempted murder',
        'Assault (serious bodily harm)',
        'Rape / Sexual assault / child sexual abuse',
        'Domestic violence (spousal abuse, child abuse)',
        'Kidnapping / Abduction',
        'Human trafficking (for labour, sexual exploitation)',
        'Mob violence / lynching'
      ],
      'Property Crimes': [
        'Theft / Burglary',
        'Robbery / Dacoity (armed robbery)',
        'Motor vehicle theft / snatching',
        'Land grabbing / illegal possession of land',
        'Arson (setting property on fire)'
      ],
      'Economic / White-collar Crimes': [
        'Corruption / bribery',
        'Embezzlement / misappropriation of funds',
        'Fraud (financial frauds, bank frauds)',
        'Money laundering',
        'Smuggling / contraband trade',
        'Tax evasion'
      ],
      'Crimes against Social / Moral Legislation': [
        'Dowry harassment / forced dowry',
        'Child marriage',
        'Prostitution / trafficking in the sex trade',
        'Indecent representation / sexual harassment in public / eve-teasing',
        'Drugs addiction / illegal drug trafficking',
        'Cyber‐crimes (online exploitation, pornography, cyber-bullying)'
      ],
      'Organised & High-Tech Crimes': [
        'Gang crime / organised youth gangs',
        'Organized drug cartels',
        'Cybercrime (hacking, identity theft, online scamming)',
        'Trafficking networks (women, children, organs)'
      ],
      'Crimes against Public Order / State / Society': [
        'Terrorism / violent extremism',
        'Hate crimes / communal violence / violence against minorities',
        'Political violence / election‐related offences',
        'Offences affecting public health and safety (unsafe food, adulteration)',
        'Violations of regulatory rules (weights & measures, consumer protection)'
      ]
    },
    bn: {
      'সহিংসতার অপরাধ / ব্যক্তিকেন্দ্রিক': [
        'হত্যা / হুমকিহত্যা',
        'হত্যা প্রচেষ্টা',
        'মারামারি, গুরুতর দেহরোগ সৃষ্টি করা',
        'ধর্ষণ / যৌন নির্যাতন / শিশু যৌন নির্যাতন',
        'পারিবারিক হিংসা (স্বামী স্ত্রী নির্যাতন, শিশু নির্যাতন)',
        'অপহরণ / অনৈচ্ছিক বন্দী রাখার অপরাধ',
        'মানব পাচার (শ্রমিক, যৌন শোষণ)',
        'গণহত্যা / মব হিংসা'
      ],
      'সম্পত্তি অপরাধ': [
        'চুরি / ঘর ভাঙ্গচুর',
        'ডাকাতি / সশস্ত্র ডাকাতি',
        'মোটরযান চুরি / ছিনতাই',
        'জমি দখল / অনৈতিকভাবে জমি অধিকার করা',
        'অগ্নিসংযোগ (সম্পত্তিতে আগুন দেওয়া)'
      ],
      'অর্থনৈতিক / হোয়াইট-কলার অপরাধ': [
        'দুর্নীতি / ঘুষ',
        'তহবিল বদলি / অর্থ দুর্নীতি',
        'প্রতারণা (ব্যাংক প্রতারণা, আর্থিক স্ক্যাম)',
        'টাকা পাচার',
        'চোরাচালানি / অবৈধ কর্পোরেট বাণিজ্য',
        'কর ফাঁকি'
      ],
      'সামাজিক / নৈতিক আইনের বিরুদ্ধে অপরাধ': [
        'যৌতুক নির্যাতন / জবরদস্তি যৌতুক',
        'বাল্যবিয়ে',
        'পতিতাবৃত্তি / যৌন পাচার',
        'অশ্লীল আচরণ / জনসমক্ষে যৌন হয়রানি / ইভ-টিজিং',
        'মাদকাসক্তি / অবৈধ মাদক পাচার',
        'সাইবার অপরাধ (অনলাইনে শোষণ, পর্নোগ্রাফি, সাইবার বুলিং)'
      ],
      'সংগঠিত ও হাই-টেক অপরাধ': [
        'গ্যাং অপরাধ / কিশোর গ্যাং',
        'মাদক সিন্ডিকেট',
        'সাইবার অপরাধ (হ্যাকিং, পরিচয় চুরি, অনলাইন স্ক্যাম)',
        'পাচার নেটওয়ার্ক (নারী, শিশু, অঙ্গ পাচার)'
      ],
      'জনশৃঙ্খলা / রাষ্ট্র / সমাজের বিরুদ্ধে অপরাধ': [
        'সন্ত্রাসবাদ / উগ্রবাদী কার্যক্রম',
        'ঘৃণাজনক অপরাধ / সাম্প্রদায়িক হিংসা / সংখ্যালঘু নির্যাতন',
        'রাজনৈতিক হিংসা / নির্বাচন-সংক্রান্ত অপরাধ',
        'জনস্বাস্থ্য ও নিরাপত্তা লঙ্ঘন (অনিরাপদ খাদ্য, ভেজাল)',
        'নিয়ন্ত্রক বিধি লঙ্ঘন (ওজন ও পরিমাপ, ভোক্তা সুরক্ষা)'
      ]
    }
  };

  const currentContent = content[language];
  const currentCrimeCategories = crimeCategories[language];

  const getCrimeTypes = (category: string): string[] => {
    if (!category) return [];
    const categoryData = crimeTypesByCategory[language];
    if (category in categoryData) {
      return (categoryData as any)[category];
    }
    return [];
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if at least one evidence (captured or uploaded) is provided
    if (formData.capturedPhotos.length === 0 && formData.capturedVideos.length === 0 && formData.uploadedFiles.length === 0) {
      alert(currentContent.evidenceRequired);
      return;
    }
    
    setIsLoading(true);
    
    // Simulate submission
    setTimeout(() => {
      setIsLoading(false);
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.title}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="px-6 py-6 space-y-6">
        {/* Safety Warning */}
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-800 mb-1">
                {currentContent.safetyFirst}
              </h3>
              <p className="text-red-700 text-sm">
                {currentContent.safetyNote}
              </p>
            </div>
          </div>
        </div>

        {/* Anonymous Reporting Toggle */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="font-semibold text-blue-800 mb-1">
                {currentContent.anonymous}
              </h3>
              <p className="text-blue-700 text-sm">
                {currentContent.anonymousNote}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-4">
              <input
                type="checkbox"
                checked={formData.isAnonymous}
                onChange={(e) => setFormData({...formData, isAnonymous: e.target.checked})}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        {/* Crime Category */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.crimeCategory}
          </label>
          <select
            value={formData.crimeCategory}
            onChange={(e) => setFormData({...formData, crimeCategory: e.target.value, crimeType: ''})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            required
          >
            <option value="">{language === 'en' ? 'Select crime category' : 'অপরাধের ধরণ নির্বাচন করুন'}</option>
            {currentCrimeCategories.map((category, index) => (
              <option key={index} value={category}>{category}</option>
            ))}
          </select>
        </div>

        {/* Crime Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.crimeType}
          </label>
          <select
            value={formData.crimeType}
            onChange={(e) => setFormData({...formData, crimeType: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            required
            disabled={!formData.crimeCategory}
          >
            <option value="">
              {formData.crimeCategory ? (language === 'en' ? 'Select crime type' : 'অপরাধের ধরন নির্বাচন করুন') : currentContent.selectCategoryFirst}
            </option>
            {getCrimeTypes(formData.crimeCategory).map((type, index) => (
              <option key={index} value={type}>{type}</option>
            ))}
          </select>
        </div>

        {/* Location */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.location}
          </label>
          <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg border border-green-200 mb-2">
            <MapPin className="w-5 h-5 text-green-600" />
            <span className="text-green-800 font-medium">{formData.location}</span>
          </div>
          <div className="flex space-x-2">
            <CustomButton variant="outline" size="sm" className="flex-1">
              {currentContent.useCurrentLocation}
            </CustomButton>
            <CustomButton variant="ghost" size="sm" className="flex-1">
              {currentContent.selectOther}
            </CustomButton>
          </div>
        </div>

        {/* Evidence Section */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.evidence}
          </label>
          
          {/* Quick Capture */}
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-600 mb-2">{currentContent.quickCapture}</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate photo capture
                  const newPhoto = `photo_${Date.now()}`;
                  setFormData({
                    ...formData, 
                    capturedPhotos: [...formData.capturedPhotos, newPhoto]
                  });
                }}
              >
                <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 font-medium">{currentContent.takePhoto}</p>
                <p className="text-xs text-red-500 font-medium">{currentContent.requiredLabel}</p>
              </button>
              
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate video capture
                  const newVideo = `video_${Date.now()}`;
                  setFormData({
                    ...formData, 
                    capturedVideos: [...formData.capturedVideos, newVideo]
                  });
                }}
              >
                <Video className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 font-medium">{currentContent.recordVideo}</p>
                <p className="text-xs text-red-500 font-medium">{currentContent.requiredLabel}</p>
              </button>
            </div>
          </div>

          {/* Additional Upload */}
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-600 mb-2">{currentContent.additionalUpload}</h3>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate photo upload
                  const newFile = `uploaded_photo_${Date.now()}`;
                  setFormData({
                    ...formData,
                    uploadedFiles: [...formData.uploadedFiles, newFile]
                  });
                }}
              >
                <Image className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadPhoto}</p>
              </button>
              <button
                type="button"
                className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer"
                onClick={() => {
                  // Simulate video upload
                  const newFile = `uploaded_video_${Date.now()}`;
                  setFormData({
                    ...formData,
                    uploadedFiles: [...formData.uploadedFiles, newFile]
                  });
                }}
              >
                <FileVideo className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadVideo}</p>
              </button>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer">
                <Upload className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{currentContent.uploadDocument}</p>
              </div>
            </div>
          </div>

          {/* Evidence Summary */}
          {(formData.capturedPhotos.length > 0 || formData.capturedVideos.length > 0 || formData.uploadedFiles.length > 0) ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800">
                ✓ Evidence: {formData.capturedPhotos.length} photos captured, {formData.capturedVideos.length} videos captured, {formData.uploadedFiles.length} files uploaded
              </p>
            </div>
          ) : (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-800 font-medium">
                ⚠️ {currentContent.evidenceRequired}
              </p>
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {currentContent.description}
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
            placeholder={language === 'en' ? 'Describe what happened...' : 'কী ঘটেছে তা বর্ণনা করুন...'}
            required
          />
        </div>

        {/* Warning Note */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <p className="text-sm text-yellow-800 font-medium">
            ⚠️ {currentContent.warning}
          </p>
        </div>

        {/* Submit Button */}
        <CustomButton
          type="submit"
          variant="primary"
          size="lg"
          className="w-full"
          loading={isLoading}
          icon={<CheckCircle className="w-5 h-5" />}
        >
          {currentContent.submit}
        </CustomButton>
      </form>
    </div>
  );
}
