import { useState } from 'react';
import { ArrowLeft, User, LogOut, Phone, Mail, Award, TrendingUp, FileText, Shield, Camera, Edit3, Bell, UserMinus, Smartphone } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import BottomNavigation from '@/react-app/components/BottomNavigation';
import EditProfileModal from '@/react-app/components/EditProfileModal';
import ChangePasswordModal from '@/react-app/components/ChangePasswordModal';
import NotificationSettingsModal from '@/react-app/components/NotificationSettingsModal';
import PrivacySecurityModal from '@/react-app/components/PrivacySecurityModal';
import AccountManagementModal from '@/react-app/components/AccountManagementModal';
import AppInstallModal from '@/react-app/components/AppInstallModal';

export default function Profile() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [activeTab, setActiveTab] = useState('profile');
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const navigate = useNavigate();

  const content = {
    en: {
      title: 'Profile',
      userInfo: 'User Information',
      stats: 'Statistics',
      settings: 'Settings',
      totalReports: 'Total Reports',
      earnedRewards: 'Earned Rewards',
      savedLives: 'Lives Saved',
      editProfile: 'Edit Profile',
      changePassword: 'Change Password',
      notifications: 'Notification Settings',
      privacy: 'Privacy & Security',
      accountManagement: 'Account Management',
      installApp: 'Install Mobile App',
      logout: 'Logout',
      verificationStatus: 'Verification Status',
      verified: 'Verified',
      pending: 'Pending',
      changePicture: 'Change Profile Picture',
      uploadPhoto: 'Upload Photo',
      takePhoto: 'Take Photo',
      removePhoto: 'Remove Photo'
    },
    bn: {
      title: 'প্রোফাইল',
      userInfo: 'ব্যবহারকারীর তথ্য',
      stats: 'পরিসংখ্যান',
      settings: 'সেটিংস',
      totalReports: 'মোট রিপোর্ট',
      earnedRewards: 'অর্জিত পুরস্কার',
      savedLives: 'রক্ষিত জীবন',
      editProfile: 'প্রোফাইল সম্পাদনা',
      changePassword: 'পাসওয়ার্ড পরিবর্তন',
      notifications: 'বিজ্ঞপ্তি সেটিংস',
      privacy: 'গোপনীয়তা ও নিরাপত্তা',
      accountManagement: 'একাউন্ট ব্যবস্থাপনা',
      installApp: 'মোবাইল অ্যাপ ইনস্টল',
      logout: 'লগআউট',
      verificationStatus: 'যাচাইকরণের অবস্থা',
      verified: 'যাচাইকৃত',
      pending: 'অপেক্ষমাণ',
      changePicture: 'প্রোফাইল ছবি পরিবর্তন',
      uploadPhoto: 'ছবি আপলোড',
      takePhoto: 'ছবি তুলুন',
      removePhoto: 'ছবি সরান'
    }
  };

  const currentContent = content[language];

  // Sample user data
  const userData = {
    name: 'Mohammad Rahman',
    phone: '+88 01712345678',
    email: 'rahman@example.com',
    joinDate: 'November 2024',
    totalReports: 12,
    earnedRewards: 2400,
    savedLives: 8,
    isVerified: true
  };

  const handleProfileImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogout = () => {
    // Clear session data
    localStorage.clear();
    sessionStorage.clear();
    navigate('/login');
  };

  const menuItems = [
    { 
      icon: Edit3, 
      label: currentContent.editProfile, 
      action: () => setActiveModal('editProfile') 
    },
    { 
      icon: Shield, 
      label: currentContent.changePassword, 
      action: () => setActiveModal('changePassword') 
    },
    { 
      icon: Bell, 
      label: currentContent.notifications, 
      action: () => setActiveModal('notifications') 
    },
    { 
      icon: Shield, 
      label: currentContent.privacy, 
      action: () => setActiveModal('privacy') 
    },
    { 
      icon: UserMinus, 
      label: currentContent.accountManagement, 
      action: () => setActiveModal('accountManagement'),
      warning: true 
    },
    { 
      icon: Smartphone, 
      label: currentContent.installApp, 
      action: () => setActiveModal('installApp') 
    },
    { 
      icon: LogOut, 
      label: currentContent.logout, 
      action: handleLogout, 
      danger: true 
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.title}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* User Information */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-4 mb-4">
            {/* Profile Picture */}
            <div className="relative">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center overflow-hidden">
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-10 h-10 text-green-600" />
                )}
              </div>
              <button
                onClick={() => document.getElementById('profileImageInput')?.click()}
                className="absolute -bottom-1 -right-1 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-green-700 transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
              <input
                id="profileImageInput"
                type="file"
                accept="image/*"
                onChange={handleProfileImageUpload}
                className="hidden"
              />
            </div>
            
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-900">{userData.name}</h2>
              <div className="flex items-center space-x-2 mb-1">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  userData.isVerified ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'
                }`}>
                  {userData.isVerified ? currentContent.verified : currentContent.pending}
                </span>
              </div>
              <p className="text-sm text-gray-500">Member since {userData.joinDate}</p>
            </div>
          </div>
          
          <div className="space-y-3 text-sm">
            <div className="flex items-center space-x-3">
              <Phone className="w-4 h-4 text-gray-400" />
              <span className="text-gray-700">{userData.phone}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-4 h-4 text-gray-400" />
              <span className="text-gray-700">{userData.email}</span>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.stats}</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{userData.totalReports}</p>
              <p className="text-sm text-gray-600">{currentContent.totalReports}</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Award className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">৳{userData.earnedRewards}</p>
              <p className="text-sm text-gray-600">{currentContent.earnedRewards}</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-6 h-6 text-red-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{userData.savedLives}</p>
              <p className="text-sm text-gray-600">{currentContent.savedLives}</p>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={item.action}
              className={`w-full flex items-center space-x-3 p-4 hover:bg-gray-50 transition-colors ${
                index === 0 ? 'rounded-t-xl' : ''
              } ${
                index === menuItems.length - 1 ? 'rounded-b-xl' : 'border-b border-gray-100'
              } ${
                item.danger ? 'text-red-600' : 
                item.warning ? 'text-orange-600' : 'text-gray-700'
              }`}
            >
              <item.icon className={`w-5 h-5 ${
                item.danger ? 'text-red-600' : 
                item.warning ? 'text-orange-600' : 'text-gray-400'
              }`} />
              <span className="font-medium">{item.label}</span>
              <ArrowLeft className={`w-4 h-4 rotate-180 ml-auto ${
                item.danger ? 'text-red-600' : 
                item.warning ? 'text-orange-600' : 'text-gray-400'
              }`} />
            </button>
          ))}
        </div>
      </div>

      {/* Modals */}
      {activeModal === 'editProfile' && (
        <EditProfileModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
          userData={userData}
        />
      )}

      {activeModal === 'changePassword' && (
        <ChangePasswordModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
          userPhone={userData.phone}
          userEmail={userData.email}
        />
      )}

      {activeModal === 'notifications' && (
        <NotificationSettingsModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
        />
      )}

      {activeModal === 'privacy' && (
        <PrivacySecurityModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
        />
      )}

      {activeModal === 'accountManagement' && (
        <AccountManagementModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
          onLogout={handleLogout}
        />
      )}

      {activeModal === 'installApp' && (
        <AppInstallModal 
          isOpen={true}
          onClose={() => setActiveModal(null)}
          language={language}
        />
      )}

      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        language={language} 
      />
    </div>
  );
}
