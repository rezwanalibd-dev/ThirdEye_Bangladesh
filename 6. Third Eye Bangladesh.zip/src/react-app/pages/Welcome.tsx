import { useState } from 'react';
import { Eye, Shield, Users, Award, ArrowRight, UserCheck, Phone, FileText, X, Search } from 'lucide-react';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CarouselBanner from '@/react-app/components/CarouselBanner';
import CustomButton from '@/react-app/components/CustomButton';
import PWAInstallPrompt from '@/react-app/components/PWAInstallPrompt';

export default function Welcome() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [showEmergencyContacts, setShowEmergencyContacts] = useState(false);
  const [showTrafficRules, setShowTrafficRules] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All Services');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const content = {
    en: {
      appName: 'Third Eye Bangladesh',
      tagline: 'Your Vigilance Saves Lives and Earns Rewards',
      features: [
        { icon: Shield, title: 'Report Traffic Violations', desc: 'Capture evidence and report violations safely' },
        { icon: Award, title: 'Earn Rewards', desc: 'Get commission from collected fines' },
        { icon: Users, title: 'Save Lives', desc: 'Help make Bangladesh roads safer' }
      ],
      getStarted: 'Get Started',
      officerPortal: 'Officer Portal',
      trustText: 'Trusted by DMP & BRTA',
      emergencyContacts: 'Emergency Contacts',
      trafficRules: 'All DMP Traffic Rules, Fines & BRTA Information',
      emergencyCall: 'For immediate police, fire, or medical emergency',
      call999: '📞 CALL 999 NOW',
      call: 'Call',
      close: 'Close'
    },
    bn: {
      appName: 'তৃতীয় চোখ বাংলাদেশ',
      tagline: 'আপনার সতর্কতা জীবন বাঁচায় এবং আপনাকে দেয় পুরস্কার',
      features: [
        { icon: Shield, title: 'ট্রাফিক লঙ্ঘন রিপোর্ট', desc: 'নিরাপদে প্রমাণ সংগ্রহ করুন ও রিপোর্ট করুন' },
        { icon: Award, title: 'পুরস্কার অর্জন', desc: 'জরিমানা সংগ্রহ থেকে কমিশন পান' },
        { icon: Users, title: 'জীবন রক্ষা', desc: 'বাংলাদেশের রাস্তা নিরাপদ করতে সাহায্য করুন' }
      ],
      getStarted: 'শুরু করুন',
      officerPortal: 'অফিসার পোর্টাল',
      trustText: 'ডিএমপি এবং বিআরটিএ কর্তৃক বিশ্বস্ত',
      emergencyContacts: 'জরুরি যোগাযোগ',
      trafficRules: 'সব ডিএমপি ট্রাফিক নিয়ম, জরিমানা ও বিআরটিএ তথ্য',
      emergencyCall: 'তাৎক্ষণিক পুলিশ, ফায়ার বা মেডিকেল জরুরি অবস্থার জন্য',
      call999: '📞 এখনই 999 এ কল করুন',
      call: 'কল',
      close: 'বন্ধ'
    }
  };

  const emergencyContacts = [
    // Emergency Category
    { category: 'Emergency', name: 'National Emergency Service', name_bn: 'জাতীয় জরুরি সেবা', number: '999', type: 'Toll-Free', desc: 'Primary emergency number for Police, Fire, Ambulance', desc_bn: 'পুলিশ, ফায়ার, অ্যাম্বুলেন্সের প্রধান জরুরি নম্বর' },
    
    // Police Category
    { category: 'Police', name: 'Bangladesh Police Emergency', name_bn: 'বাংলাদেশ পুলিশ জরুরি', number: '999', type: 'Toll-Free', desc: 'All types of police-related emergencies', desc_bn: 'সকল ধরনের পুলিশ-সংক্রান্ত জরুরি অবস্থা' },
    { category: 'Police', name: 'RAB (Rapid Action Battalion)', name_bn: 'র‍্যাব (র‍্যাপিড অ্যাকশন ব্যাটালিয়ন)', number: '01777720050', type: 'Mobile', desc: 'Crime, terrorism, drugs', desc_bn: 'অপরাধ, সন্ত্রাসবাদ, মাদক' },
    { category: 'Police', name: 'Dhaka Metropolitan Police', name_bn: 'ঢাকা মেট্রোপলিটন পুলিশ', number: '02-9514400', type: 'Landline', desc: 'City security and law enforcement', desc_bn: 'শহরের নিরাপত্তা ও আইন প্রয়োগ' },
    { category: 'Police', name: 'Traffic Police Helpline', name_bn: 'ট্রাফিক পুলিশ হেল্পলাইন', number: '01320-040244', type: 'Mobile', desc: 'Traffic accidents, violations, road assistance', desc_bn: 'ট্রাফিক দুর্ঘটনা, লঙ্ঘন, সড়ক সহায়তা' },
    { category: 'Police', name: 'Tourist Police', name_bn: 'ট্যুরিস্ট পুলিশ', number: '02-8322999', type: 'Landline', desc: 'Tourist assistance and security', desc_bn: 'পর্যটক সহায়তা ও নিরাপত্তা' },
    { category: 'Police', name: 'Cyber Crime Unit (CID)', name_bn: 'সাইবার ক্রাইম ইউনিট (সিআইডি)', number: '01769693535', type: 'Mobile', desc: 'Online fraud or harassment', desc_bn: 'অনলাইন প্রতারণা বা হয়রানি' },
    
    // Medical Category
    { category: 'Medical', name: 'Medical Emergency Service', name_bn: 'মেডিকেল জরুরি সেবা', number: '199', type: 'Toll-Free', desc: 'Ambulance & medical emergency assistance', desc_bn: 'অ্যাম্বুলেন্স ও মেডিকেল জরুরি সহায়তা' },
    { category: 'Medical', name: 'Health Hotline (DGHS)', name_bn: 'স্বাস্থ্য হটলাইন (স্বাস্থ্য অধিদপ্তর)', number: '16263', type: 'Toll-Free', desc: 'Medical advice, hospital info, COVID info', desc_bn: 'চিকিৎসা পরামর্শ, হাসপাতালের তথ্য, কোভিড তথ্য' },
    { category: 'Medical', name: 'Dhaka Medical College Hospital', name_bn: 'ঢাকা মেডিকেল কলেজ হাসপাতাল', number: '02-55165088', type: 'Landline', desc: 'Emergency medical services', desc_bn: 'জরুরি চিকিৎসা সেবা' },
    
    // Fire Service
    { category: 'Fire Service', name: 'Fire & Rescue Service', name_bn: 'ফায়ার ও রেসকিউ সার্ভিস', number: '16163', type: 'Toll-Free', desc: 'Fire incidents, rescue operations', desc_bn: 'অগ্নিকাণ্ড, উদ্ধার অভিযান' },
    
    // Support Category
    { category: 'Support', name: 'Women & Child Abuse Prevention Helpline', name_bn: 'নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন', number: '109', type: 'Toll-Free', desc: 'Legal aid, shelter, counseling', desc_bn: 'আইনি সহায়তা, আশ্রয়, কাউন্সেলিং' },
    { category: 'Support', name: 'Child Helpline', name_bn: 'শিশু হেল্পলাইন', number: '1098', type: 'Toll-Free', desc: 'Child protection, rescue, counseling', desc_bn: 'শিশু সুরক্ষা, উদ্ধার, কাউন্সেলিং' },
    { category: 'Support', name: 'Anti-Corruption Commission (ACC)', name_bn: 'দুর্নীতি দমন কমিশন (দুদক)', number: '106', type: 'Toll-Free', desc: 'Report corruption or abuse of power', desc_bn: 'দুর্নীতি বা ক্ষমতার অপব্যবহার রিপোর্ট' },
    
    // Banking Category
    { category: 'Banking', name: 'bKash', name_bn: 'বিকাশ', number: '16247', type: 'Toll-Free', desc: 'Mobile wallet customer service', desc_bn: 'মোবাইল ওয়ালেট কাস্টমার সার্ভিস' },
    { category: 'Banking', name: 'Nagad', name_bn: 'নগদ', number: '16167', type: 'Toll-Free', desc: 'Mobile wallet customer service', desc_bn: 'মোবাইল ওয়ালেট কাস্টমার সার্ভিস' },
    { category: 'Banking', name: 'Rocket (Dutch-Bangla Bank)', name_bn: 'রকেট (ডাচ-বাংলা ব্যাংক)', number: '16216', type: 'Toll-Free', desc: 'Mobile banking service', desc_bn: 'মোবাইল ব্যাংকিং সেবা' },
    
    // Transport Category
    { category: 'Transport', name: 'Hazrat Shahjalal International Airport', name_bn: 'হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দর', number: '02-8901904', type: 'Landline', desc: 'Flight information and services', desc_bn: 'ফ্লাইটের তথ্য ও সেবা' },
    { category: 'Transport', name: 'Bangladesh Railway Information', name_bn: 'বাংলাদেশ রেলওয়ে তথ্য', number: '131', type: 'Toll-Free', desc: 'Train ticket and schedule information', desc_bn: 'ট্রেনের টিকেট ও সময়সূচীর তথ্য' },
    
    // Telecom Category
    { category: 'Telecom', name: 'Grameenphone', name_bn: 'গ্রামীণফোন', number: '121', type: 'Toll-Free', desc: 'Customer care and support', desc_bn: 'কাস্টমার কেয়ার ও সহায়তা' },
    { category: 'Telecom', name: 'Robi', name_bn: 'রবি', number: '123', type: 'Toll-Free', desc: 'Customer care and support', desc_bn: 'কাস্টমার কেয়ার ও সহায়তা' },
    
    // Utility Category
    { category: 'Utility', name: 'DESCO (Dhaka Electric)', name_bn: 'ডেসকো (ঢাকা ইলেক্ট্রিক)', number: '16120', type: 'Toll-Free', desc: 'Electricity issues - Mirpur, Gulshan, Uttara', desc_bn: 'বিদ্যুৎ সমস্যা - মিরপুর, গুলশান, উত্তরা' },
    { category: 'Utility', name: 'Titas Gas', name_bn: 'তিতাস গ্যাস', number: '16496', type: 'Toll-Free', desc: 'Gas service - Dhaka, Narayanganj', desc_bn: 'গ্যাস সেবা - ঢাকা, নারায়ণগঞ্জ' }
  ];

  const trafficRulesData = {
    en: {
      title: 'Complete Bangladesh Traffic Law, Rules & Fines Guide (2025)',
      disclaimer: 'This guide is a comprehensive summary for informational purposes. Laws, fines, and fees are subject to change. For absolute and legally binding information, always refer to the official Bangladesh Road Transport Authority (BRTA) at brta.gov.bd and the Road Transport Act, 2018.',
      
      categories: [
        {
          title: 'Private Car Violations',
          items: [
            { violation: 'Driving without a valid driving licence', fine: 'Fine up to Tk 25,000 or up to 6 months imprisonment, or both' },
            { violation: 'Driving on the wrong side of the road', fine: 'Fine up to Tk 10,000 or up to 3 months imprisonment, or both' },
            { violation: 'Ignoring traffic lights or police signals', fine: 'Fine Tk 5,000 - Tk 10,000' },
            { violation: 'Overspeeding or racing', fine: 'Fine up to Tk 50,000' },
            { violation: 'Using a mobile phone while driving', fine: 'Fine Tk 5,000' },
            { violation: 'Not wearing seat belts', fine: 'Fine Tk 500 - Tk 5,000' },
            { violation: 'Illegal parking', fine: 'Fine Tk 5,000' },
            { violation: 'Driving without valid insurance', fine: 'Fine Tk 10,000 - Tk 20,000' }
          ]
        },
        {
          title: 'Motorcycle Violations',
          items: [
            { violation: 'Riding without a helmet', fine: 'Fine Tk 1,000 - Tk 10,000' },
            { violation: 'Triple riding', fine: 'Fine Tk 3,000' },
            { violation: 'Wrong-side riding', fine: 'Fine up to Tk 10,000' },
            { violation: 'Riding on footpaths', fine: 'Fine Tk 3,000' },
            { violation: 'Overspeeding or reckless overtaking', fine: 'Fine up to Tk 10,000' },
            { violation: 'Driving without licence', fine: 'Fine up to Tk 25,000 or imprisonment' },
            { violation: 'Modified exhaust pipes', fine: 'Fine up to Tk 5,000' },
            { violation: 'Performing stunts', fine: 'Fine up to Tk 10,000' }
          ]
        },
        {
          title: 'Commercial Vehicle Violations',
          items: [
            { violation: 'Overloading beyond legal weight limit', fine: 'Fine up to Tk 100,000 or up to 1 year imprisonment' },
            { violation: 'Carrying passengers in goods vehicles', fine: 'Fine up to Tk 50,000' },
            { violation: 'Driving without proper documents', fine: 'Fine up to Tk 25,000' },
            { violation: 'Illegal modification of vehicle body', fine: 'Fine up to Tk 300,000' },
            { violation: 'Driving during restricted hours', fine: 'Fine up to Tk 25,000' }
          ]
        }
      ]
    },
    bn: {
      title: 'সম্পূর্ণ বাংলাদেশ ট্রাফিক আইন, নিয়ম ও জরিমানা গাইড (২০২৫)',
      disclaimer: 'এই গাইডটি তথ্যগত উদ্দেশ্যে একটি বিস্তৃত সারসংক্ষেপ। আইন, জরিমানা এবং ফি পরিবর্তনের সাপেক্ষে। সম্পূর্ণ এবং আইনগতভাবে বাধ্যতামূলক তথ্যের জন্য, সর্বদা বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ) brta.gov.bd এবং সড়ক পরিবহন আইন, ২০১৮ দেখুন।',
      
      categories: [
        {
          title: 'ব্যক্তিগত গাড়ির লঙ্ঘন',
          items: [
            { violation: 'বৈধ ড্রাইভিং লাইসেন্স ছাড়া গাড়ি চালানো', fine: 'জরিমানা সর্বোচ্চ ২৫,০০০ ৳ অথবা কারাদণ্ড ৬ মাস, বা উভয় দণ্ড' },
            { violation: 'রাস্তার ভুল পাশে গাড়ি চালানো', fine: 'জরিমানা সর্বোচ্চ ১০,০০০ ৳ অথবা কারাদণ্ড ৩ মাস, বা উভয়' },
            { violation: 'ট্রাফিক সিগন্যাল বা পুলিশের নির্দেশ অমান্য করা', fine: 'জরিমানা ৫,০০০ - ১০,০০০ ৳' },
            { violation: 'অতিরিক্ত গতিতে বা রেস করে গাড়ি চালানো', fine: 'জরিমানা সর্বোচ্চ ৫০,০০০ ৳' },
            { violation: 'গাড়ি চালানোর সময় মোবাইল ব্যবহার করা', fine: 'জরিমানা ৫,০০০ ৳' },
            { violation: 'সিটবেল্ট না পরা', fine: 'জরিমানা ৫০০ - ৫,০০০ ৳' },
            { violation: 'বেআইনি পার্কিং', fine: 'জরিমানা ৫,০০০ ৳' },
            { violation: 'বীমা ছাড়া গাড়ি চালানো', fine: 'জরিমানা ১০,০০০ - ২০,০০০ ৳' }
          ]
        },
        {
          title: 'মোটরসাইকেলের লঙ্ঘন',
          items: [
            { violation: 'হেলমেট না পরা', fine: 'জরিমানা ১,০০০ - ১০,০০০ ৳' },
            { violation: 'তিনজন বা তার বেশি যাত্রী বহন', fine: 'জরিমানা ৩,০০০ ৳' },
            { violation: 'ভুল পাশে চালানো', fine: 'জরিমানা সর্বোচ্চ ১০,০০০ ৳' },
            { violation: 'ফুটপাথে চালানো', fine: 'জরিমানা ৩,০০০ ৳' },
            { violation: 'অতিরিক্ত গতি বা ঝুঁকিপূর্ণ ওভারটেক', fine: 'জরিমানা সর্বোচ্চ ১০,০০০ ৳' },
            { violation: 'লাইসেন্স ছাড়া চালানো', fine: 'জরিমানা সর্বোচ্চ ২৫,০০০ ৳ অথবা কারাদণ্ড' },
            { violation: 'নিষিদ্ধ সাইলেন্সার ব্যবহার', fine: 'জরিমানা সর্বোচ্চ ৫,০০০ ৳' },
            { violation: 'স্টান্ট বা হুইলি করা', fine: 'জরিমানা সর্বোচ্চ ১০,০০০ ৳' }
          ]
        },
        {
          title: 'বাণিজ্যিক যানবাহনের লঙ্ঘন',
          items: [
            { violation: 'অনুমোদিত ওজনসীমার বেশি মালামাল বহন', fine: 'জরিমানা সর্বোচ্চ ১,০০,০০০ ৳ অথবা কারাদণ্ড ১ বছর' },
            { violation: 'পণ্যবাহী গাড়িতে যাত্রী বহন', fine: 'জরিমানা সর্বোচ্চ ৫০,০০০ ৳' },
            { violation: 'বৈধ নথি ছাড়া চালানো', fine: 'জরিমানা সর্বোচ্চ ২৫,০০০ ৳' },
            { violation: 'অবৈধ পরিবর্তন', fine: 'জরিমানা সর্বোচ্চ ৩,০০,০০০ ৳' },
            { violation: 'নিষিদ্ধ সময়ে চলাচল', fine: 'জরিমানা সর্বোচ্চ ২৫,০০০ ৳' }
          ]
        }
      ]
    }
  };

  const currentContent = content[language];
  const currentTrafficRules = trafficRulesData[language];

  const emergencyCategories = [
    { id: 'All Services', count: 66, color: 'bg-gray-100 text-gray-800', hoverColor: 'hover:bg-gray-200' },
    { id: 'Emergency', count: 1, color: 'bg-red-100 text-red-800', hoverColor: 'hover:bg-red-200' },
    { id: 'Police', count: 6, color: 'bg-blue-100 text-blue-800', hoverColor: 'hover:bg-blue-200' },
    { id: 'Medical', count: 15, color: 'bg-green-100 text-green-800', hoverColor: 'hover:bg-green-200' },
    { id: 'Fire Service', count: 1, color: 'bg-orange-100 text-orange-800', hoverColor: 'hover:bg-orange-200' },
    { id: 'Utility', count: 8, color: 'bg-purple-100 text-purple-800', hoverColor: 'hover:bg-purple-200' },
    { id: 'Support', count: 9, color: 'bg-yellow-100 text-yellow-800', hoverColor: 'hover:bg-yellow-200' },
    { id: 'Banking', count: 6, color: 'bg-indigo-100 text-indigo-800', hoverColor: 'hover:bg-indigo-200' },
    { id: 'Transport', count: 5, color: 'bg-pink-100 text-pink-800', hoverColor: 'hover:bg-pink-200' },
    { id: 'Telecom', count: 6, color: 'bg-teal-100 text-teal-800', hoverColor: 'hover:bg-teal-200' }
  ];

  // Filter contacts based on selected category and search query
  const filteredContacts = emergencyContacts.filter(contact => {
    // Category filter
    const categoryMatches = selectedCategory === 'All Services' || contact.category === selectedCategory;
    
    // Search filter
    const searchMatches = searchQuery === '' || 
      contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.name_bn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.number.includes(searchQuery) ||
      contact.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.desc_bn.toLowerCase().includes(searchQuery.toLowerCase());
    
    return categoryMatches && searchMatches;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex justify-end">
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <div className="px-6 pb-8">
        {/* App Logo and Title */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-gradient-to-br from-green-600 to-green-700 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg">
            <Eye className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {currentContent.appName}
          </h1>
          <p className="text-green-600 font-medium text-sm leading-relaxed max-w-sm mx-auto">
            {currentContent.tagline}
          </p>
        </div>

        {/* Centered Hero Text Sections */}
        <div className="mb-8 flex justify-center">
          <div className="w-full max-w-4xl">
            <CarouselBanner language={language} />
          </div>
        </div>

        {/* Key Features - Horizontal Row */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {currentContent.features.map((feature, index) => (
            <div key={index} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <feature.icon className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 text-xs mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-xs">
                  {feature.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Emergency & Traffic Rules Buttons */}
        <div className="mb-8 space-y-3">
          <div className="flex space-x-3">
            <CustomButton
              variant="outline"
              size="md"
              className="flex-1"
              onClick={() => setShowEmergencyContacts(true)}
              icon={<Phone className="w-4 h-4" />}
            >
              {currentContent.emergencyContacts}
            </CustomButton>
            
            <CustomButton
              variant="outline"
              size="md"
              className="flex-1"
              onClick={() => setShowTrafficRules(true)}
              icon={<FileText className="w-4 h-4" />}
            >
              {currentContent.trafficRules}
            </CustomButton>
          </div>
        </div>

        {/* Trust Badge */}
        <div className="bg-white rounded-xl p-4 mb-8 text-center shadow-sm border border-gray-100">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Shield className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-gray-900 text-center">{currentContent.trustText}</span>
          </div>
          <div className="flex items-center justify-center space-x-4 text-xs text-gray-600 text-center">
            <span>DMP Verified</span>
            <span>•</span>
            <span>Secure Platform</span>
            <span>•</span>
            <span>End-to-End Encryption</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <CustomButton
            variant="primary"
            size="lg"
            className="w-full"
            onClick={() => window.location.href = '/login'}
            icon={<ArrowRight className="w-5 h-5" />}
          >
            {currentContent.getStarted}
          </CustomButton>
          
          <CustomButton
            variant="outline"
            size="md"
            className="w-full"
            onClick={() => window.location.href = '/login'}
            icon={<UserCheck className="w-4 h-4" />}
          >
            {currentContent.officerPortal}
          </CustomButton>
        </div>

        {/* Government Logos Section */}
        <div className="mt-8 pt-6 border-t border-gray-200 text-center">
          <p className="text-center text-xs text-gray-500 mb-4">
            {language === 'en' ? 'Official Partnership With' : 'সরকারি অংশীদারিত্বে'}
          </p>
          <div className="flex items-center justify-center space-x-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-1 mx-auto">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <span className="text-xs text-gray-600 text-center">DMP</span>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-1 mx-auto">
                <Shield className="w-6 h-6 text-red-600" />
              </div>
              <span className="text-xs text-gray-600 text-center">BRTA</span>
            </div>
          </div>
        </div>
      </div>

      {/* PWA Install Prompt */}
      <PWAInstallPrompt language={language} />

      {/* Emergency Contacts Modal */}
      {showEmergencyContacts && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-hidden">
            <div className="bg-red-600 text-white p-4 flex items-center justify-between">
              <h2 className="text-lg font-bold">{currentContent.emergencyContacts}</h2>
              <button onClick={() => setShowEmergencyContacts(false)} className="p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto max-h-[75vh]">
              {/* Emergency Call Banner */}
              <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 mb-4 text-center">
                <p className="text-sm text-red-800 mb-2">{currentContent.emergencyCall}</p>
                <a href="tel:999" className="bg-red-600 text-white px-4 py-2 rounded-lg font-bold text-lg">
                  {currentContent.call999}
                </a>
              </div>

              {/* Search Bar */}
              <div className="mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder={language === 'en' ? 'Search contacts...' : 'যোগাযোগ খুঁজুন...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Categories */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                {emergencyCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-2 rounded-lg text-center text-xs font-medium transition-colors ${cat.color} ${cat.hoverColor} ${
                      selectedCategory === cat.id ? 'ring-2 ring-red-500' : ''
                    }`}
                  >
                    <div className="font-bold">{cat.id} ({cat.count})</div>
                  </button>
                ))}
              </div>

              {/* Selected Category Info */}
              {selectedCategory !== 'All Services' && (
                <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800 font-medium">
                    {language === 'en' ? `Showing ${selectedCategory} contacts` : `${selectedCategory} যোগাযোগ দেখানো হচ্ছে`}
                    {searchQuery && (
                      <span className="ml-2">
                        {language === 'en' ? `matching "${searchQuery}"` : `"${searchQuery}" এর সাথে মিলছে`}
                      </span>
                    )}
                  </p>
                </div>
              )}

              {/* Contacts List */}
              <div className="space-y-3">
                {filteredContacts.length > 0 ? (
                  filteredContacts.map((contact, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-sm text-gray-900">
                              {language === 'en' ? contact.name : contact.name_bn}
                            </h3>
                            <span className="inline-block px-2 py-1 bg-blue-100 text-blue-600 text-xs rounded font-medium">
                              {contact.category}
                            </span>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">
                            {language === 'en' ? contact.desc : contact.desc_bn}
                          </p>
                          <span className="inline-block px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded mt-1">
                            {contact.type}
                          </span>
                        </div>
                        <a 
                          href={`tel:${contact.number}`}
                          className="bg-red-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-red-700 transition-colors ml-2"
                        >
                          {contact.number}
                        </a>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">
                      {language === 'en' 
                        ? 'No contacts found matching your search' 
                        : 'আপনার অনুসন্ধানের সাথে কোনো যোগাযোগ পাওয়া যায়নি'
                      }
                    </p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedCategory('All Services');
                      }}
                      className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700 transition-colors"
                    >
                      {language === 'en' ? 'Clear filters' : 'ফিল্টার সাফ করুন'}
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-4 p-3 bg-gray-50 rounded-lg text-center">
                <p className="text-xs text-gray-600">
                  📊 {language === 'en' ? `Showing ${filteredContacts.length} of ${emergencyContacts.length} contacts` : `${emergencyContacts.length} এর মধ্যে ${filteredContacts.length} টি যোগাযোগ দেখানো হচ্ছে`}<br/>
                  📅 {language === 'en' ? 'Last Updated: November 2025' : 'শেষ আপডেট: নভেম্বর ২০২৫'}<br/>
                  🏛️ {language === 'en' ? 'Source: Bangladesh Government Official Directory' : 'সূত্র: বাংলাদেশ সরকারি অফিসিয়াল ডিরেক্টরি'}<br/>
                  ✅ {language === 'en' ? 'Status: All numbers verified & active' : 'স্ট্যাটাস: সকল নম্বর যাচাইকৃত ও সক্রিয়'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Traffic Rules Modal */}
      {showTrafficRules && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-hidden">
            <div className="bg-green-600 text-white p-4 flex items-center justify-between">
              <h2 className="text-lg font-bold">{currentContent.trafficRules}</h2>
              <button onClick={() => setShowTrafficRules(false)} className="p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto max-h-[75vh]">
              <div className="mb-4">
                <h1 className="text-lg font-bold text-center mb-2">{currentTrafficRules.title}</h1>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                  <p className="text-xs text-yellow-800">{currentTrafficRules.disclaimer}</p>
                </div>
              </div>

              {/* Categories */}
              <div className="space-y-4">
                {currentTrafficRules.categories.map((category, catIndex) => (
                  <div key={catIndex} className="border border-gray-200 rounded-lg">
                    <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                      <h3 className="font-semibold text-sm text-gray-900">{category.title}</h3>
                    </div>
                    <div className="p-4 space-y-3">
                      {category.items.map((item, itemIndex) => (
                        <div key={itemIndex} className="border-l-4 border-green-400 pl-3">
                          <h4 className="font-medium text-sm text-gray-900 mb-1">{item.violation}</h4>
                          <p className="text-xs text-red-700 font-medium">{item.fine}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 bg-blue-50 rounded-lg text-center">
                <p className="text-xs text-blue-800">
                  🚗 Drive Safe, Follow Rules, Protect Lives 🛡️<br/>
                  📞 Emergency: 999 | BRTA Helpline: 16263
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
