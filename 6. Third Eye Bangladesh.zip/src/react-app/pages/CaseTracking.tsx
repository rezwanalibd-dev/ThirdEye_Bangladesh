import { useState } from 'react';
import { ArrowLeft, Search, Clock, CheckCircle, XCircle, MapPin, Camera, Download, Share } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

interface CaseReport {
  id: string;
  type: string;
  vehicleType: string;
  location: string;
  date: string;
  status: 'pending' | 'under_review' | 'verified' | 'approved' | 'rejected' | 'fine_collected' | 'reward_paid';
  expectedReward: number;
  evidenceCount: number;
  officer?: string;
}

export default function CaseTracking() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCase, setSelectedCase] = useState<CaseReport | null>(null);
  const navigate = useNavigate();

  const content = {
    en: {
      caseTracking: 'Case Tracking',
      searchCase: 'Search Case',
      enterCaseId: 'Enter case ID or vehicle number',
      myReports: 'My Reports',
      caseDetails: 'Case Details',
      status: 'Status',
      expectedReward: 'Expected Reward',
      timeline: 'Timeline',
      reportDetails: 'Report Details',
      evidence: 'Evidence',
      violation: 'Violation',
      vehicle: 'Vehicle',
      location: 'Location',
      dateTime: 'Date & Time',
      officer: 'Assigned Officer',
      downloadPdf: 'Download PDF',
      shareCase: 'Share Case',
      statuses: {
        pending: 'Pending Review',
        under_review: 'Under Review',
        verified: 'DMP Verified',
        approved: 'Approved',
        rejected: 'Rejected',
        fine_collected: 'Fine Collected',
        reward_paid: 'Reward Paid'
      },
      timelineSteps: {
        submitted: 'Report Submitted',
        under_review: 'Under DMP Review',
        verification: 'DMP Verification',
        fine_collection: 'Fine Collection',
        reward_payment: 'Reward Payment'
      }
    },
    bn: {
      caseTracking: 'কেস ট্র্যাকিং',
      searchCase: 'কেস খোঁজ',
      enterCaseId: 'কেস আইডি বা যানবাহন নম্বর লিখুন',
      myReports: 'আমার রিপোর্ট',
      caseDetails: 'কেসের বিবরণ',
      status: 'অবস্থা',
      expectedReward: 'প্রত্যাশিত পুরস্কার',
      timeline: 'টাইমলাইন',
      reportDetails: 'রিপোর্টের বিবরণ',
      evidence: 'প্রমাণ',
      violation: 'লঙ্ঘন',
      vehicle: 'যানবাহন',
      location: 'অবস্থান',
      dateTime: 'তারিখ ও সময়',
      officer: 'দায়িত্বপ্রাপ্ত কর্মকর্তা',
      downloadPdf: 'পিডিএফ ডাউনলোড',
      shareCase: 'কেস শেয়ার',
      statuses: {
        pending: 'পর্যালোচনার অপেক্ষায়',
        under_review: 'পর্যালোচনাধীন',
        verified: 'ডিএমপি যাচাইকৃত',
        approved: 'অনুমোদিত',
        rejected: 'প্রত্যাখ্যাত',
        fine_collected: 'জরিমানা আদায়',
        reward_paid: 'পুরস্কার প্রদান'
      },
      timelineSteps: {
        submitted: 'রিপোর্ট জমা',
        under_review: 'ডিএমপি পর্যালোচনা',
        verification: 'ডিএমপি যাচাইকরণ',
        fine_collection: 'জরিমানা আদায়',
        reward_payment: 'পুরস্কার প্রদান'
      }
    }
  };

  const currentContent = content[language];

  // Sample case data
  const cases: CaseReport[] = [
    {
      id: 'TE-2024-1105-001',
      type: 'Red Light Jumping',
      vehicleType: 'Motorbike',
      location: 'Dhanmondi 27, Dhaka',
      date: '2024-11-05 14:30',
      status: 'under_review',
      expectedReward: 1000,
      evidenceCount: 2,
      officer: 'Inspector Rahman'
    },
    {
      id: 'TE-2024-1104-015',
      type: 'Wrong Side Driving',
      vehicleType: 'Car',
      location: 'Gulshan 2, Dhaka',
      date: '2024-11-04 09:15',
      status: 'verified',
      expectedReward: 600,
      evidenceCount: 3,
      officer: 'SI Ahmed'
    },
    {
      id: 'TE-2024-1103-008',
      type: 'No Helmet',
      vehicleType: 'Motorbike',
      location: 'Uttara Sector 7',
      date: '2024-11-03 18:45',
      status: 'reward_paid',
      expectedReward: 200,
      evidenceCount: 1,
      officer: 'ASI Khan'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-50';
      case 'under_review': return 'text-blue-600 bg-blue-50';
      case 'verified': return 'text-green-600 bg-green-50';
      case 'approved': return 'text-green-600 bg-green-50';
      case 'rejected': return 'text-red-600 bg-red-50';
      case 'fine_collected': return 'text-purple-600 bg-purple-50';
      case 'reward_paid': return 'text-emerald-600 bg-emerald-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'under_review': return <Clock className="w-4 h-4" />;
      case 'verified': case 'approved': case 'reward_paid': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const filteredCases = cases.filter(caseItem =>
    caseItem.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caseItem.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caseItem.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (selectedCase) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-green-600 text-white px-6 pt-12 pb-6">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => setSelectedCase(null)}
              className="p-2 hover:bg-green-700 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold">{currentContent.caseDetails}</h1>
            <LanguageToggle onLanguageChange={setLanguage} />
          </div>
        </div>

        <div className="px-6 py-6 space-y-6">
          {/* Case Status */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">
                {selectedCase.id}
              </h2>
              <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedCase.status)}`}>
                {getStatusIcon(selectedCase.status)}
                <span>{currentContent.statuses[selectedCase.status]}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-gray-600 text-sm">{currentContent.expectedReward}</p>
                <p className="text-xl font-bold text-green-600">৳{selectedCase.expectedReward}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">{currentContent.evidence}</p>
                <p className="text-lg font-semibold text-gray-900">{selectedCase.evidenceCount} items</p>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.timeline}</h3>
            <div className="space-y-4">
              {Object.entries(currentContent.timelineSteps).map(([key, label]) => {
                const isCompleted = ['submitted', 'under_review'].includes(key) || 
                  (key === 'verification' && ['verified', 'approved', 'fine_collected', 'reward_paid'].includes(selectedCase.status));
                const isCurrent = key === selectedCase.status;
                
                return (
                  <div key={key} className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      isCompleted ? 'bg-green-500' : 
                      isCurrent ? 'bg-blue-500' : 'bg-gray-300'
                    }`}></div>
                    <span className={`text-sm ${
                      isCompleted || isCurrent ? 'text-gray-900 font-medium' : 'text-gray-500'
                    }`}>
                      {label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Report Details */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.reportDetails}</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">{currentContent.violation}:</span>
                <span className="font-medium">{selectedCase.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{currentContent.vehicle}:</span>
                <span className="font-medium">{selectedCase.vehicleType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{currentContent.location}:</span>
                <span className="font-medium">{selectedCase.location}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{currentContent.dateTime}:</span>
                <span className="font-medium">{selectedCase.date}</span>
              </div>
              {selectedCase.officer && (
                <div className="flex justify-between">
                  <span className="text-gray-600">{currentContent.officer}:</span>
                  <span className="font-medium">{selectedCase.officer}</span>
                </div>
              )}
            </div>
          </div>

          {/* Evidence */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{currentContent.evidence}</h3>
            <div className="grid grid-cols-2 gap-3">
              {Array.from({ length: selectedCase.evidenceCount }).map((_, i) => (
                <div key={i} className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                  <Camera className="w-8 h-8 text-gray-400" />
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <CustomButton
              variant="outline"
              size="md"
              className="flex-1"
              icon={<Download className="w-4 h-4" />}
            >
              {currentContent.downloadPdf}
            </CustomButton>
            <CustomButton
              variant="outline"
              size="md"
              className="flex-1"
              icon={<Share className="w-4 h-4" />}
            >
              {currentContent.shareCase}
            </CustomButton>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.caseTracking}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 bg-white"
              placeholder={currentContent.enterCaseId}
            />
          </div>
        </div>

        {/* Cases List */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">{currentContent.myReports}</h2>
          
          {filteredCases.map((caseItem) => (
            <button
              key={caseItem.id}
              onClick={() => setSelectedCase(caseItem)}
              className="w-full bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900 text-sm">{caseItem.type}</h3>
                  <p className="text-gray-600 text-xs">{caseItem.id}</p>
                </div>
                <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(caseItem.status)}`}>
                  {getStatusIcon(caseItem.status)}
                  <span>{currentContent.statuses[caseItem.status]}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                <div className="flex items-center space-x-1">
                  <MapPin className="w-3 h-3" />
                  <span>{caseItem.location}</span>
                </div>
                <span>{caseItem.date}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-green-600 font-semibold text-sm">৳{caseItem.expectedReward}</span>
                <ArrowLeft className="w-4 h-4 text-gray-400 rotate-180" />
              </div>
            </button>
          ))}
          
          {filteredCases.length === 0 && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-gray-600">No cases found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
