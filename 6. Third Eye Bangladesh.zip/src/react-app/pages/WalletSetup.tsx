import { useState } from 'react';
import { ArrowRight, Wallet, CheckCircle, Star } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function WalletSetup() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [selectedWallet, setSelectedWallet] = useState<string>('');
  const [walletNumber, setWalletNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'select' | 'verify' | 'complete'>('select');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      walletSetup: 'Wallet Setup',
      finalStep: 'Final Step',
      selectPayment: 'Select Payment Method',
      walletNumber: 'Wallet Number',
      enterWallet: 'Enter your wallet number',
      verifyOtp: 'Verify with OTP',
      enterOtp: 'Enter 4-digit OTP',
      setup: 'Setup Wallet',
      verify: 'Verify',
      complete: 'Complete Setup',
      congratulations: 'Congratulations!',
      accountReady: 'Your account is ready',
      canStartReporting: 'You can now start reporting traffic violations and earning rewards',
      goDashboard: 'Go to Dashboard',
      whyWallet: 'Why do we need your wallet?',
      reason1: 'Receive commission from fines (20%)',
      reason2: 'Secure and instant payments',
      reason3: 'Track your earnings',
      popularWallets: 'Popular Wallets in Bangladesh'
    },
    bn: {
      walletSetup: 'ওয়ালেট সেটআপ',
      finalStep: 'শেষ ধাপ',
      selectPayment: 'পেমেন্ট মাধ্যম নির্বাচন করুন',
      walletNumber: 'ওয়ালেট নম্বর',
      enterWallet: 'আপনার ওয়ালেট নম্বর লিখুন',
      verifyOtp: 'ওটিপি দিয়ে যাচাই করুন',
      enterOtp: '৪ সংখ্যার ওটিপি লিখুন',
      setup: 'ওয়ালেট সেটআপ',
      verify: 'যাচাই করুন',
      complete: 'সেটআপ সম্পূর্ণ করুন',
      congratulations: 'অভিনন্দন!',
      accountReady: 'আপনার অ্যাকাউন্ট প্রস্তুত',
      canStartReporting: 'আপনি এখন ট্রাফিক লঙ্ঘন রিপোর্ট করতে এবং পুরস্কার অর্জন করতে পারেন',
      goDashboard: 'ড্যাশবোর্ডে যান',
      whyWallet: 'আমাদের আপনার ওয়ালেট কেন প্রয়োজন?',
      reason1: 'জরিমানা থেকে কমিশন পান (২০%)',
      reason2: 'নিরাপদ এবং তাৎক্ষণিক পেমেন্ট',
      reason3: 'আপনার আয় ট্র্যাক করুন',
      popularWallets: 'বাংলাদেশের জনপ্রিয় ওয়ালেট'
    }
  };

  const currentContent = content[language];

  const wallets = [
    { id: 'bkash', name: 'bKash', color: 'bg-pink-500', prefix: '01' },
    { id: 'nagad', name: 'Nagad', color: 'bg-orange-500', prefix: '01' },
    { id: 'rocket', name: 'Rocket', color: 'bg-purple-500', prefix: '01' },
    { id: 'upay', name: 'Upay', color: 'bg-red-500', prefix: '01' },
    { id: 'mcash', name: 'mCash', color: 'bg-blue-500', prefix: '01' },
    { id: 'cellfin', name: 'CellFin', color: 'bg-green-500', prefix: '01' }
  ];

  const handleWalletSetup = async () => {
    if (!selectedWallet || !walletNumber) {
      alert('Please select wallet and enter number');
      return;
    }

    setIsLoading(true);
    
    // Simulate sending OTP to wallet
    setTimeout(() => {
      setIsLoading(false);
      setStep('verify');
    }, 2000);
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 4) {
      alert('Please enter 4-digit OTP');
      return;
    }

    setIsLoading(true);
    
    // Simulate OTP verification
    setTimeout(() => {
      setIsLoading(false);
      setStep('complete');
    }, 2000);
  };

  const handleCompletedSetup = () => {
    navigate('/dashboard');
  };

  if (step === 'complete') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-xl">
          {/* Success Animation */}
          <div className="relative mb-6">
            <div className="w-24 h-24 bg-green-100 rounded-full mx-auto flex items-center justify-center mb-4">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
              <Star className="w-4 h-4 text-white" />
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {currentContent.congratulations}
          </h2>
          <p className="text-green-600 font-semibold mb-4">
            {currentContent.accountReady}
          </p>
          <p className="text-gray-600 text-sm mb-8">
            {currentContent.canStartReporting}
          </p>

          <CustomButton
            variant="primary"
            size="lg"
            className="w-full"
            onClick={handleCompletedSetup}
            icon={<ArrowRight className="w-5 h-5" />}
          >
            {currentContent.goDashboard}
          </CustomButton>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => step === 'select' ? navigate(-1) : setStep('select')}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.walletSetup}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
        
        {/* Progress Indicator */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-green-700/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
          <p className="text-green-100 text-sm mt-2">{currentContent.finalStep}</p>
        </div>
      </div>

      <div className="px-6 -mt-3">
        <div className="bg-white rounded-t-3xl min-h-screen pt-8 px-6">
          {step === 'select' && (
            <>
              {/* Why Wallet Section */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 className="text-blue-800 font-semibold mb-2">
                  {currentContent.whyWallet}
                </h3>
                <div className="space-y-1 text-blue-700 text-sm">
                  <div>• {currentContent.reason1}</div>
                  <div>• {currentContent.reason2}</div>
                  <div>• {currentContent.reason3}</div>
                </div>
              </div>

              {/* Wallet Selection */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {currentContent.selectPayment} *
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  {currentContent.popularWallets}
                </p>
                <div className="grid grid-cols-2 gap-3">
                  {wallets.map((wallet) => (
                    <button
                      key={wallet.id}
                      onClick={() => setSelectedWallet(wallet.id)}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        selectedWallet === wallet.id
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className={`w-12 h-12 ${wallet.color} rounded-lg flex items-center justify-center mx-auto mb-2`}>
                        <Wallet className="w-6 h-6 text-white" />
                      </div>
                      <div className={`font-medium text-sm ${
                        selectedWallet === wallet.id ? 'text-green-700' : 'text-gray-700'
                      }`}>
                        {wallet.name}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Wallet Number Input */}
              {selectedWallet && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {currentContent.walletNumber} *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 text-sm">+88</span>
                    </div>
                    <input
                      type="tel"
                      value={walletNumber}
                      onChange={(e) => setWalletNumber(e.target.value)}
                      className="w-full pl-16 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder={currentContent.enterWallet}
                    />
                  </div>
                </div>
              )}

              <CustomButton
                type="button"
                variant="primary"
                size="lg"
                className="w-full"
                onClick={handleWalletSetup}
                loading={isLoading}
                disabled={!selectedWallet || !walletNumber}
                icon={<ArrowRight className="w-5 h-5" />}
              >
                {currentContent.setup}
              </CustomButton>
            </>
          )}

          {step === 'verify' && (
            <>
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wallet className="w-10 h-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {currentContent.verifyOtp}
                </h2>
                <p className="text-gray-600 text-sm">
                  OTP sent to your {selectedWallet} number
                </p>
                <p className="text-green-600 font-semibold">
                  +88 {walletNumber.replace(/(\d{2})(\d{3})(\d{3})(\d{3})/, '$1 $2 $3 $4')}
                </p>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {currentContent.enterOtp}
                </label>
                <input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.slice(0, 4))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-center text-lg font-mono"
                  placeholder="0000"
                  maxLength={4}
                />
              </div>

              <CustomButton
                type="button"
                variant="primary"
                size="lg"
                className="w-full"
                onClick={handleVerifyOTP}
                loading={isLoading}
                disabled={otp.length !== 4}
                icon={<CheckCircle className="w-5 h-5" />}
              >
                {currentContent.verify}
              </CustomButton>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
