import { useState } from 'react';
import { ArrowRight, Camera, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function KYCVerification() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [selectedDocType, setSelectedDocType] = useState<'nid' | 'license' | 'passport'>('nid');
  const [documentNumber, setDocumentNumber] = useState('');
  const [uploads, setUploads] = useState({
    nidFront: false,
    nidBack: false,
    licenseFront: false,
    licenseBack: false,
    passport: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const content = {
    en: {
      kycVerification: 'KYC Verification',
      step3Of4: 'Step 3 of 4',
      documentType: 'Document Type',
      nid: 'National ID',
      license: 'Driving License',
      passport: 'Passport',
      documentNumber: 'Document Number',
      enterNid: 'Enter your NID number',
      enterLicense: 'Enter license number',
      enterPassport: 'Enter passport number',
      uploadDocuments: 'Upload Documents',
      frontPhoto: 'Front Photo',
      backPhoto: 'Back Photo',
      documentPhoto: 'Document Photo',
      uploadFront: 'Upload Front',
      uploadBack: 'Upload Back',
      uploadDocument: 'Upload Document',
      uploaded: 'Uploaded',
      continue: 'Continue',
      skipForNow: 'Skip for now',
      note: 'Upload clear photos of your documents. Make sure all text is readable and the document is not damaged.',
      guidelines: 'Photo Guidelines:',
      guideline1: '• Ensure good lighting',
      guideline2: '• Keep document flat',
      guideline3: '• All corners visible',
      guideline4: '• Text clearly readable'
    },
    bn: {
      kycVerification: 'কেওয়াইসি যাচাইকরণ',
      step3Of4: '৪টি ধাপের ৩য় ধাপ',
      documentType: 'দলিলের ধরন',
      nid: 'জাতীয় পরিচয়পত্র',
      license: 'ড্রাইভিং লাইসেন্স',
      passport: 'পাসপোর্ট',
      documentNumber: 'দলিল নম্বর',
      enterNid: 'আপনার এনআইডি নম্বর লিখুন',
      enterLicense: 'লাইসেন্স নম্বর লিখুন',
      enterPassport: 'পাসপোর্ট নম্বর লিখুন',
      uploadDocuments: 'দলিল আপলোড করুন',
      frontPhoto: 'সামনের ছবি',
      backPhoto: 'পেছনের ছবি',
      documentPhoto: 'দলিলের ছবি',
      uploadFront: 'সামনে আপলোড',
      uploadBack: 'পেছনে আপলোড',
      uploadDocument: 'দলিল আপলোড',
      uploaded: 'আপলোড হয়েছে',
      continue: 'চালিয়ে যান',
      skipForNow: 'পরে করুন',
      note: 'আপনার দলিলের স্পষ্ট ছবি আপলোড করুন। নিশ্চিত করুন যে সমস্ত লেখা পড়া যায় এবং দলিলটি ক্ষতিগ্রস্ত নয়।',
      guidelines: 'ছবি তোলার নির্দেশনা:',
      guideline1: '• ভালো আলোর ব্যবস্থা করুন',
      guideline2: '• দলিলটি সমান রাখুন',
      guideline3: '• সব কোণ দৃশ্যমান রাখুন',
      guideline4: '• লেখা স্পষ্টভাবে পড়া যায়'
    }
  };

  const currentContent = content[language];

  const documentTypes = [
    { id: 'nid', label: currentContent.nid, icon: '🆔' },
    { id: 'license', label: currentContent.license, icon: '🚗' },
    { id: 'passport', label: currentContent.passport, icon: '✈️' }
  ];

  const handleUpload = (type: string) => {
    // Simulate file upload
    setUploads(prev => ({ ...prev, [type]: true }));
  };

  const handleContinue = async () => {
    if (!documentNumber.trim()) {
      alert('Please enter document number');
      return;
    }

    setIsLoading(true);
    
    // Simulate verification process
    setTimeout(() => {
      setIsLoading(false);
      navigate('/biometric-verification');
    }, 2000);
  };

  const isFormValid = () => {
    if (!documentNumber.trim()) return false;
    
    switch (selectedDocType) {
      case 'nid':
        return uploads.nidFront && uploads.nidBack;
      case 'license':
        return uploads.licenseFront && uploads.licenseBack;
      case 'passport':
        return uploads.passport;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.kycVerification}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
        
        {/* Progress Indicator */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-green-700/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
          </div>
          <p className="text-green-100 text-sm mt-2">{currentContent.step3Of4}</p>
        </div>
      </div>

      <div className="px-6 -mt-3">
        <div className="bg-white rounded-t-3xl min-h-screen pt-8 px-6">
          {/* Document Type Selection */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {currentContent.documentType} *
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {documentTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => setSelectedDocType(type.id as any)}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    selectedDocType === type.id
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-2xl mb-2">{type.icon}</div>
                  <div className={`text-sm font-medium ${
                    selectedDocType === type.id ? 'text-green-700' : 'text-gray-700'
                  }`}>
                    {type.label}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Document Number Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {currentContent.documentNumber} *
            </label>
            <input
              type="text"
              value={documentNumber}
              onChange={(e) => setDocumentNumber(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder={
                selectedDocType === 'nid' ? currentContent.enterNid :
                selectedDocType === 'license' ? currentContent.enterLicense :
                currentContent.enterPassport
              }
            />
          </div>

          {/* Upload Section */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {currentContent.uploadDocuments} *
            </h3>
            
            {selectedDocType === 'nid' && (
              <div className="grid grid-cols-2 gap-4">
                <UploadBox
                  title={currentContent.frontPhoto}
                  uploaded={uploads.nidFront}
                  onUpload={() => handleUpload('nidFront')}
                />
                <UploadBox
                  title={currentContent.backPhoto}
                  uploaded={uploads.nidBack}
                  onUpload={() => handleUpload('nidBack')}
                />
              </div>
            )}

            {selectedDocType === 'license' && (
              <div className="grid grid-cols-2 gap-4">
                <UploadBox
                  title={currentContent.frontPhoto}
                  uploaded={uploads.licenseFront}
                  onUpload={() => handleUpload('licenseFront')}
                />
                <UploadBox
                  title={currentContent.backPhoto}
                  uploaded={uploads.licenseBack}
                  onUpload={() => handleUpload('licenseBack')}
                />
              </div>
            )}

            {selectedDocType === 'passport' && (
              <div className="grid grid-cols-1">
                <UploadBox
                  title={currentContent.documentPhoto}
                  uploaded={uploads.passport}
                  onUpload={() => handleUpload('passport')}
                />
              </div>
            )}
          </div>

          {/* Guidelines */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex items-start space-x-2">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-blue-800 text-sm font-medium mb-2">
                  {currentContent.guidelines}
                </p>
                <div className="text-blue-700 text-sm space-y-1">
                  <div>{currentContent.guideline1}</div>
                  <div>{currentContent.guideline2}</div>
                  <div>{currentContent.guideline3}</div>
                  <div>{currentContent.guideline4}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 mb-6">
            <CustomButton
              type="button"
              variant="primary"
              size="lg"
              className="w-full"
              onClick={handleContinue}
              loading={isLoading}
              disabled={!isFormValid()}
              icon={<ArrowRight className="w-5 h-5" />}
            >
              {currentContent.continue}
            </CustomButton>

            <CustomButton
              type="button"
              variant="ghost"
              size="md"
              className="w-full"
              onClick={() => navigate('/biometric-verification')}
            >
              {currentContent.skipForNow}
            </CustomButton>
          </div>
        </div>
      </div>
    </div>
  );
}

interface UploadBoxProps {
  title: string;
  uploaded: boolean;
  onUpload: () => void;
}

function UploadBox({ title, uploaded, onUpload }: UploadBoxProps) {
  return (
    <button
      onClick={onUpload}
      className={`w-full h-32 border-2 border-dashed rounded-lg transition-all ${
        uploaded
          ? 'border-green-500 bg-green-50'
          : 'border-gray-300 hover:border-gray-400 bg-gray-50'
      }`}
    >
      <div className="flex flex-col items-center justify-center h-full">
        {uploaded ? (
          <>
            <CheckCircle className="w-8 h-8 text-green-600 mb-2" />
            <span className="text-green-700 font-medium text-sm">
              Uploaded
            </span>
          </>
        ) : (
          <>
            <Camera className="w-8 h-8 text-gray-400 mb-2" />
            <span className="text-gray-600 font-medium text-sm">
              {title}
            </span>
            <span className="text-gray-500 text-xs mt-1">
              Tap to upload
            </span>
          </>
        )}
      </div>
    </button>
  );
}
