import { useState, useEffect, useRef } from 'react';
import { ArrowRight, Clock, RefreshCw } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import CustomButton from '@/react-app/components/CustomButton';

export default function OTPVerification() {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [countdown, setCountdown] = useState(120); // 2 minutes
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const navigate = useNavigate();
  const location = useLocation();
  const { phoneNumber, userData } = location.state || {};

  const content = {
    en: {
      verifyPhone: 'Verify Phone Number',
      step2Of4: 'Step 2 of 4',
      codeSent: 'We\'ve sent a 6-digit code to',
      enterCode: 'Enter the code to verify your number',
      resendIn: 'Resend code in',
      resendCode: 'Resend Code',
      verify: 'Verify',
      didntReceive: 'Didn\'t receive the code?',
      callMe: 'Call me instead'
    },
    bn: {
      verifyPhone: 'ফোন নম্বর যাচাই করুন',
      step2Of4: '৪টি ধাপের ২য় ধাপ',
      codeSent: 'আমরা ৬ সংখ্যার একটি কোড পাঠিয়েছি',
      enterCode: 'আপনার নম্বর যাচাই করতে কোডটি লিখুন',
      resendIn: 'পুনরায় কোড পাঠানো হবে',
      resendCode: 'কোড পুনরায় পাঠান',
      verify: 'যাচাই করুন',
      didntReceive: 'কোড পাননি?',
      callMe: 'পরিবর্তে কল করুন'
    }
  };

  const currentContent = content[language];

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-verify when all digits are entered
    if (value && index === 5 && newOtp.every(digit => digit !== '')) {
      handleVerify();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async () => {
    const otpCode = otp.join('');
    if (otpCode.length !== 6) {
      alert('Please enter the complete 6-digit code');
      return;
    }

    setIsLoading(true);

    // Simulate OTP verification
    setTimeout(() => {
      setIsLoading(false);
      navigate('/kyc-verification', { state: { userData } });
    }, 2000);
  };

  const handleResendOTP = async () => {
    setIsResending(true);
    
    // Simulate resending OTP
    setTimeout(() => {
      setIsResending(false);
      setCountdown(120);
      setOtp(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-600 text-white px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-green-700 rounded-lg transition-colors"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <h1 className="text-xl font-bold">{currentContent.verifyPhone}</h1>
          <LanguageToggle onLanguageChange={setLanguage} />
        </div>
        
        {/* Progress Indicator */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-green-700/30 rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
            <div className="w-2 h-2 bg-green-300 rounded-full"></div>
          </div>
          <p className="text-green-100 text-sm mt-2">{currentContent.step2Of4}</p>
        </div>
      </div>

      <div className="px-6 -mt-3">
        <div className="bg-white rounded-t-3xl min-h-screen pt-8 px-6">
          {/* Verification Icon */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">✓</span>
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {currentContent.verifyPhone}
            </h2>
            <p className="text-gray-600 text-sm mb-2">
              {currentContent.codeSent}
            </p>
            <p className="text-green-600 font-semibold">
              +88 {phoneNumber?.replace(/(\d{2})(\d{3})(\d{3})(\d{3})/, '$1 $2 $3 $4')}
            </p>
            <p className="text-gray-500 text-sm mt-2">
              {currentContent.enterCode}
            </p>
          </div>

          {/* OTP Input */}
          <div className="flex justify-center space-x-3 mb-6">
            {otp.map((digit, index) => (
              <input
                key={index}
                ref={(el) => { inputRefs.current[index] = el; }}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-12 text-center text-lg font-bold border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                inputMode="numeric"
                pattern="[0-9]*"
              />
            ))}
          </div>

          {/* Countdown Timer */}
          <div className="text-center mb-6">
            {countdown > 0 ? (
              <div className="flex items-center justify-center space-x-2 text-gray-600">
                <Clock className="w-4 h-4" />
                <span className="text-sm">
                  {currentContent.resendIn} {formatTime(countdown)}
                </span>
              </div>
            ) : (
              <button
                onClick={handleResendOTP}
                disabled={isResending}
                className="flex items-center justify-center space-x-2 text-green-600 hover:text-green-700 font-medium text-sm"
              >
                <RefreshCw className={`w-4 h-4 ${isResending ? 'animate-spin' : ''}`} />
                <span>{currentContent.resendCode}</span>
              </button>
            )}
          </div>

          {/* Verify Button */}
          <CustomButton
            type="button"
            variant="primary"
            size="lg"
            className="w-full mb-4"
            onClick={handleVerify}
            loading={isLoading}
            disabled={otp.some(digit => digit === '')}
            icon={<ArrowRight className="w-5 h-5" />}
          >
            {currentContent.verify}
          </CustomButton>

          {/* Alternative Options */}
          <div className="text-center space-y-2">
            <p className="text-gray-600 text-sm">{currentContent.didntReceive}</p>
            <div className="flex justify-center space-x-4">
              <button 
                onClick={handleResendOTP}
                disabled={countdown > 0 || isResending}
                className="text-green-600 font-medium text-sm hover:text-green-700 disabled:text-gray-400"
              >
                {currentContent.resendCode}
              </button>
              <span className="text-gray-300">•</span>
              <button className="text-green-600 font-medium text-sm hover:text-green-700">
                {currentContent.callMe}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
