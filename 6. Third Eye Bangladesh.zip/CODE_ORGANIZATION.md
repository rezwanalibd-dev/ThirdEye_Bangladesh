# Third Eye Bangladesh - Code Organization & Structure

## Complete Project Structure

```
third-eye-bangladesh/
│
├── flutter_mobile_app/                 # 📱 MOBILE APPLICATION (Android & iOS)
│   ├── android/                        # Android platform-specific code
│   │   ├── app/
│   │   │   ├── src/main/
│   │   │   │   ├── AndroidManifest.xml
│   │   │   │   ├── kotlin/
│   │   │   │   └── res/
│   │   │   └── build.gradle            # App-level build config
│   │   ├── gradle/                     # Gradle wrapper
│   │   └── build.gradle                # Project-level build config
│   │
│   ├── ios/                            # iOS platform-specific code
│   │   ├── Runner/
│   │   │   ├── Info.plist             # iOS app configuration
│   │   │   ├── Assets.xcassets/       # App icons & images
│   │   │   └── AppDelegate.swift
│   │   ├── Runner.xcodeproj/          # Xcode project
│   │   └── Podfile                    # iOS dependencies
│   │
│   ├── lib/                            # 🎯 FLUTTER APPLICATION CODE
│   │   ├── main.dart                  # App entry point
│   │   │
│   │   ├── models/                    # 📦 Data Models
│   │   │   ├── user_model.dart
│   │   │   └── report_model.dart
│   │   │
│   │   ├── providers/                 # 🔄 State Management (Provider)
│   │   │   ├── auth_provider.dart
│   │   │   └── language_provider.dart
│   │   │
│   │   ├── screens/                   # 📺 UI Screens
│   │   │   ├── auth/
│   │   │   │   ├── welcome_screen.dart
│   │   │   │   ├── login_screen.dart
│   │   │   │   ├── signup_screen.dart
│   │   │   │   └── otp_verification_screen.dart
│   │   │   ├── kyc/
│   │   │   │   ├── kyc_verification_screen.dart
│   │   │   │   └── biometric_verification_screen.dart
│   │   │   ├── dashboard/
│   │   │   │   └── dashboard_screen.dart
│   │   │   ├── reports/
│   │   │   │   ├── report_traffic_screen.dart
│   │   │   │   └── case_tracking_screen.dart
│   │   │   └── profile/
│   │   │       └── profile_screen.dart
│   │   │
│   │   ├── services/                  # 🔌 API & External Services
│   │   │   ├── auth_service.dart
│   │   │   └── report_service.dart
│   │   │
│   │   ├── utils/                     # 🛠️ Utilities & Constants
│   │   │   ├── constants.dart
│   │   │   ├── theme.dart
│   │   │   └── app_localizations.dart
│   │   │
│   │   └── widgets/                   # 🧩 Reusable Widgets
│   │       ├── language_toggle.dart
│   │       ├── feature_card.dart
│   │       └── motivational_carousel.dart
│   │
│   ├── assets/                        # 🖼️ Static Assets
│   │   ├── images/
│   │   ├── icons/
│   │   └── fonts/
│   │
│   ├── test/                          # 🧪 Unit & Widget Tests
│   │   └── widget_test.dart
│   │
│   ├── pubspec.yaml                   # Flutter dependencies
│   └── README.md                      # Mobile app documentation
│
├── src/                               # 🌐 WEB APPLICATION
│   ├── react-app/                     # Frontend (React + TypeScript)
│   │   ├── components/                # Reusable React components
│   │   │   ├── LanguageToggle.tsx
│   │   │   ├── CustomButton.tsx
│   │   │   ├── BottomNavigation.tsx
│   │   │   ├── CarouselBanner.tsx
│   │   │   ├── EditProfileModal.tsx
│   │   │   ├── ChangePasswordModal.tsx
│   │   │   ├── NotificationSettingsModal.tsx
│   │   │   ├── PrivacySecurityModal.tsx
│   │   │   ├── AccountManagementModal.tsx
│   │   │   └── AppInstallModal.tsx
│   │   │
│   │   ├── pages/                     # Page components
│   │   │   ├── Welcome.tsx
│   │   │   ├── Home.tsx
│   │   │   ├── Login.tsx
│   │   │   ├── Signup.tsx
│   │   │   ├── OTPVerification.tsx
│   │   │   ├── KYCVerification.tsx
│   │   │   ├── BiometricVerification.tsx
│   │   │   ├── WalletSetup.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── ReportTraffic.tsx
│   │   │   ├── ReportCrime.tsx
│   │   │   ├── CaseTracking.tsx
│   │   │   ├── Alerts.tsx
│   │   │   ├── Profile.tsx
│   │   │   └── OfficerDashboard.tsx
│   │   │
│   │   ├── App.tsx                    # Main app component
│   │   ├── main.tsx                   # React entry point
│   │   ├── index.css                  # Global styles
│   │   └── vite-env.d.ts             # TypeScript definitions
│   │
│   ├── worker/                        # Backend (Cloudflare Worker)
│   │   ├── routes/                    # API route handlers
│   │   │   ├── auth.ts               # Authentication endpoints
│   │   │   ├── users.ts              # User management endpoints
│   │   │   ├── reports.ts            # Report management endpoints
│   │   │   └── officers.ts           # Officer endpoints
│   │   │
│   │   └── index.ts                  # Worker entry point
│   │
│   └── shared/                        # Shared types & utilities
│       └── types.ts                   # TypeScript type definitions
│
├── docs/                              # 📚 DOCUMENTATION
│   ├── BUILD_DEPLOY_GUIDE.md         # Build & deployment guide
│   ├── PROJECT_STRUCTURE.md          # Project structure overview
│   ├── UI_SPECIFICATION.md           # UI/UX specifications
│   └── SAMPLE_SCREENS.md             # Screen mockups & specs
│
├── lib/                               # Shared utilities (Web)
│   ├── utils/
│   │   ├── constants.dart
│   │   └── theme.dart
│
├── assets/                            # Web assets
│   └── README.md
│
├── DEMO_ACCOUNTS.md                   # Demo account credentials
├── TESTING_GUIDE.md                   # Testing instructions
├── PUBLISHING_GUIDE.md                # App store publishing guide
├── CODE_ORGANIZATION.md               # This file
├── IMPLEMENTATION_PLAN.md             # Development roadmap
│
├── package.json                       # Node.js dependencies
├── tsconfig.json                      # TypeScript configuration
├── vite.config.ts                     # Vite build configuration
├── tailwind.config.js                 # Tailwind CSS configuration
├── wrangler.json                      # Cloudflare Worker config
└── index.html                         # Web app entry HTML
```

---

## Folder Organization Principles

### 1. Mobile App (flutter_mobile_app/)

#### Screens Organization
```
screens/
├── auth/           # All authentication related screens
├── kyc/            # KYC and verification screens
├── dashboard/      # Dashboard and home screens
├── reports/        # Report submission and tracking
└── profile/        # User profile and settings
```

**Why this structure?**
- Groups related functionality together
- Easy to navigate and find screens
- Scalable as app grows
- Clear separation of concerns

#### Services Organization
```
services/
├── auth_service.dart       # Firebase Auth integration
├── report_service.dart     # Report API calls
├── location_service.dart   # GPS/location handling
├── storage_service.dart    # File upload/download
└── notification_service.dart # Push notifications
```

**Why this structure?**
- Each service has single responsibility
- Easy to mock for testing
- Clear API boundaries
- Reusable across screens

#### Models Organization
```
models/
├── user_model.dart         # User data structure
├── report_model.dart       # Report data structure
├── violation_model.dart    # Violation types
└── payment_model.dart      # Payment/wallet data
```

**Why this structure?**
- Type-safe data handling
- Easy serialization/deserialization
- Validation in one place
- Clear data contracts

### 2. Web App (src/)

#### React Components
```
react-app/components/
├── LanguageToggle.tsx      # Language switching
├── CustomButton.tsx        # Reusable button
├── BottomNavigation.tsx    # Bottom nav bar
├── CarouselBanner.tsx      # Image carousel
├── EditProfileModal.tsx    # Profile editing
├── ChangePasswordModal.tsx # Password change
├── NotificationSettingsModal.tsx
├── PrivacySecurityModal.tsx
├── AccountManagementModal.tsx
└── AppInstallModal.tsx     # Mobile app install guide
```

**Why this structure?**
- Reusable UI components
- Consistent styling
- Easy to maintain
- Single source of truth

#### Pages Organization
```
react-app/pages/
├── Welcome.tsx             # Landing page
├── Home.tsx               # Home page
├── Login.tsx              # Login page
├── Signup.tsx             # Registration
├── OTPVerification.tsx    # OTP input
├── KYCVerification.tsx    # Document upload
├── BiometricVerification.tsx
├── WalletSetup.tsx        # Payment setup
├── Dashboard.tsx          # User dashboard
├── ReportTraffic.tsx      # Traffic violation form
├── ReportCrime.tsx        # Crime reporting form
├── CaseTracking.tsx       # Track reports
├── Alerts.tsx             # Notifications
├── Profile.tsx            # User profile
└── OfficerDashboard.tsx   # Officer interface
```

**Why this structure?**
- One page per route
- Clear navigation structure
- Easy to add new pages
- Lazy loading support

#### Worker API Routes
```
worker/routes/
├── auth.ts        # /api/auth/* endpoints
├── users.ts       # /api/users/* endpoints
├── reports.ts     # /api/reports/* endpoints
└── officers.ts    # /api/officers/* endpoints
```

**Why this structure?**
- RESTful API organization
- Clear endpoint grouping
- Easy to add new routes
- Separation by resource

---

## Code Quality Standards

### Flutter Code Standards

#### File Naming
```
✅ CORRECT:
user_model.dart
auth_provider.dart
login_screen.dart

❌ INCORRECT:
UserModel.dart
authProvider.dart
LoginScreen.dart
```

#### Class Naming
```dart
✅ CORRECT:
class UserModel { }
class AuthProvider extends ChangeNotifier { }
class LoginScreen extends StatefulWidget { }

❌ INCORRECT:
class user_model { }
class authProvider { }
class login_screen { }
```

#### Widget File Structure
```dart
// 1. Imports
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 2. Main Widget
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

// 3. State Class
class _LoginScreenState extends State<LoginScreen> {
  // State variables
  // Lifecycle methods
  // Build method
  // Helper methods
}

// 4. Helper Widgets (if needed)
class _CustomWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) { }
}
```

### React/TypeScript Code Standards

#### File Naming
```
✅ CORRECT:
Login.tsx
CustomButton.tsx
useAuth.ts

❌ INCORRECT:
login.tsx
custom-button.tsx
UseAuth.ts
```

#### Component Structure
```typescript
// 1. Imports
import { useState } from 'react';
import CustomButton from '@/components/CustomButton';

// 2. Interface/Types
interface LoginProps {
  onSuccess: () => void;
}

// 3. Component
export default function Login({ onSuccess }: LoginProps) {
  // State
  const [email, setEmail] = useState('');
  
  // Handlers
  const handleSubmit = () => { };
  
  // Render
  return (
    <div>
      {/* JSX */}
    </div>
  );
}
```

---

## Build & Deployment Workflow

### Mobile App Workflow

```mermaid
graph LR
    A[Code Changes] --> B[Run Tests]
    B --> C[Flutter Analyze]
    C --> D[Build Debug]
    D --> E[Test on Device]
    E --> F{Tests Pass?}
    F -->|Yes| G[Build Release]
    F -->|No| A
    G --> H[Upload to Store]
```

### Web App Workflow

```mermaid
graph LR
    A[Code Changes] --> B[Run Tests]
    B --> C[TypeScript Check]
    C --> D[Build Preview]
    D --> E[Test Locally]
    E --> F{Tests Pass?}
    F -->|Yes| G[Build Production]
    F -->|No| A
    G --> H[Deploy to Cloudflare]
```

---

## Environment Configuration

### Mobile App Environments

#### Development
```dart
// lib/config/dev_config.dart
class DevConfig {
  static const String apiBaseUrl = 'http://localhost:8787';
  static const String environment = 'development';
  static const bool enableLogging = true;
}
```

#### Production
```dart
// lib/config/prod_config.dart
class ProdConfig {
  static const String apiBaseUrl = 'https://api.thirdeye.gov.bd';
  static const String environment = 'production';
  static const bool enableLogging = false;
}
```

### Web App Environments

#### .env.development
```bash
VITE_API_URL=http://localhost:8787
VITE_ENVIRONMENT=development
VITE_ENABLE_ANALYTICS=false
```

#### .env.production
```bash
VITE_API_URL=https://api.thirdeye.gov.bd
VITE_ENVIRONMENT=production
VITE_ENABLE_ANALYTICS=true
```

---

## Version Control Strategy

### Branch Structure
```
main                  # Production-ready code
├── develop          # Development branch
├── feature/*        # Feature branches
├── bugfix/*         # Bug fix branches
└── hotfix/*         # Urgent fixes
```

### Commit Message Format
```
type(scope): subject

body

footer
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code restructuring
- `test`: Adding tests
- `chore`: Maintenance

**Example:**
```
feat(auth): add OTP verification flow

- Implement OTP input screen
- Add OTP verification API call
- Add resend OTP functionality

Closes #123
```

---

## Testing Strategy

### Mobile App Tests

#### Unit Tests
```dart
// test/models/user_model_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:third_eye_bangladesh/models/user_model.dart';

void main() {
  group('UserModel', () {
    test('fromMap creates valid user', () {
      final map = {
        'uid': '123',
        'phoneNumber': '01712345678',
        'fullName': 'Test User',
      };
      
      final user = UserModel.fromMap(map);
      
      expect(user.uid, '123');
      expect(user.phoneNumber, '01712345678');
      expect(user.fullName, 'Test User');
    });
  });
}
```

#### Widget Tests
```dart
// test/widgets/language_toggle_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:third_eye_bangladesh/widgets/language_toggle.dart';

void main() {
  testWidgets('LanguageToggle switches language', (tester) async {
    await tester.pumpWidget(
      MaterialApp(home: Scaffold(body: LanguageToggle())),
    );
    
    expect(find.text('EN'), findsOneWidget);
    
    await tester.tap(find.byType(LanguageToggle));
    await tester.pump();
    
    expect(find.text('বাং'), findsOneWidget);
  });
}
```

### Web App Tests

#### Component Tests
```typescript
// src/react-app/components/__tests__/CustomButton.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import CustomButton from '../CustomButton';

describe('CustomButton', () => {
  it('renders with text', () => {
    render(<CustomButton>Click me</CustomButton>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });
  
  it('calls onClick when clicked', () => {
    const handleClick = jest.fn();
    render(<CustomButton onClick={handleClick}>Click</CustomButton>);
    fireEvent.click(screen.getByText('Click'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
```

---

## Performance Optimization

### Mobile App Optimization

1. **Image Optimization**
   ```dart
   Image.network(
     url,
     cacheWidth: 300,
     cacheHeight: 300,
   )
   ```

2. **List Performance**
   ```dart
   ListView.builder(
     itemCount: items.length,
     itemBuilder: (context, index) => ItemWidget(items[index]),
   )
   ```

3. **State Management**
   ```dart
   // Use const constructors
   const Text('Hello');
   
   // Use keys for stateful widgets
   ListView(
     key: PageStorageKey('myList'),
   )
   ```

### Web App Optimization

1. **Code Splitting**
   ```typescript
   const Dashboard = lazy(() => import('./pages/Dashboard'));
   ```

2. **Image Optimization**
   ```typescript
   <img 
     src={imageUrl} 
     loading="lazy"
     decoding="async"
   />
   ```

3. **Memoization**
   ```typescript
   const expensiveValue = useMemo(() => 
     computeExpensiveValue(a, b), 
     [a, b]
   );
   ```

---

## Security Best Practices

### Mobile App Security

1. **Secure Storage**
   ```dart
   import 'package:flutter_secure_storage/flutter_secure_storage.dart';
   
   final storage = FlutterSecureStorage();
   await storage.write(key: 'token', value: token);
   ```

2. **API Keys**
   ```dart
   // Never hardcode API keys
   // Use environment variables or secure storage
   const apiKey = String.fromEnvironment('API_KEY');
   ```

3. **Network Security**
   ```dart
   // Enable certificate pinning
   final client = HttpClient()
     ..badCertificateCallback = (cert, host, port) => false;
   ```

### Web App Security

1. **Environment Variables**
   ```typescript
   // Never commit .env files
   const apiKey = import.meta.env.VITE_API_KEY;
   ```

2. **Input Validation**
   ```typescript
   const sanitizedInput = DOMPurify.sanitize(userInput);
   ```

3. **HTTPS Only**
   ```typescript
   if (window.location.protocol !== 'https:') {
     window.location.protocol = 'https:';
   }
   ```

---

## Continuous Integration

### GitHub Actions Workflow

```yaml
name: CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  flutter-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      - run: flutter pub get
      - run: flutter analyze
      - run: flutter test
      
  web-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm test
      - run: npm run build
```

---

## Monitoring & Analytics

### Firebase Analytics Events

```dart
// Track custom events
FirebaseAnalytics.instance.logEvent(
  name: 'report_submitted',
  parameters: {
    'report_type': 'traffic',
    'violation_type': 'red_light',
  },
);
```

### Error Tracking

```dart
// Crashlytics
FirebaseCrashlytics.instance.recordError(
  error,
  stackTrace,
  reason: 'User action failed',
);
```

---

**Last Updated:** November 12, 2024
**Maintained By:** Third Eye Bangladesh Development Team
