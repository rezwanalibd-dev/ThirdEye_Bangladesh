
DROP INDEX idx_otp_user_id;
DROP INDEX idx_sessions_token;
DROP INDEX idx_users_mobile;
DROP INDEX idx_users_email;

ALTER TABLE user_profiles DROP COLUMN custom_user_id;

DROP TABLE sessions;
DROP TABLE biometric_verifications;
DROP TABLE identity_verifications;
DROP TABLE otp_verifications;
DROP TABLE users;
