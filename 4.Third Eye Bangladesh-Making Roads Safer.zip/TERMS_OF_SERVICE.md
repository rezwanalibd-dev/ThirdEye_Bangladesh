# Terms of Service - Third Eye Traffic Reporter

**Effective Date**: November 2025  
**Last Updated**: November 3, 2025

---

## Agreement to Terms

By downloading, installing, or using the Third Eye mobile application ("App," "Service," or "Platform"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, you may not access or use our Service.

**Legal Agreement**: These Terms constitute a legally binding agreement between you ("User," "you," or "your") and Third Eye ("Company," "we," "us," or "our").

---

## Description of Service

### Third Eye Platform
Third Eye is a citizen reporting platform that enables users to:
- Report traffic violations through mobile app photography
- Earn commission on verified violation reports
- Access emergency contact services
- Contribute to Bangladesh road safety initiatives

### Government Partnership
Our Service operates in partnership with:
- Bangladesh Traffic Police
- Department of Transport
- Local traffic enforcement authorities
- Emergency services coordination

---

## User Eligibility

### Age Requirements
- **Minimum Age**: 18 years or older
- **Legal Capacity**: Must have legal capacity to enter contracts
- **Parental Consent**: Users 16-17 require parental consent
- **Identity Verification**: Must provide valid government-issued ID

### Account Requirements
- **Accurate Information**: All registration information must be truthful
- **Valid Contact**: Must provide working mobile number
- **Bangladesh Residency**: Primary focus on Bangladesh users
- **Single Account**: One account per person

---

## Account Registration and Security

### Registration Process
1. **Phone Verification**: SMS OTP verification required
2. **Identity Verification**: Government ID document upload
3. **Biometric Verification**: Facial recognition for identity confirmation
4. **Agreement Acceptance**: Must accept these Terms and Privacy Policy

### Account Security
- **Password Strength**: Must meet security requirements
- **Account Sharing**: Accounts are non-transferable
- **Unauthorized Access**: Report security breaches immediately
- **Account Suspension**: We may suspend accounts for violations

---

## Acceptable Use Policy

### Permitted Activities
- **Legitimate Reporting**: Report actual traffic violations only
- **Accurate Information**: Provide truthful violation details
- **Safety First**: Prioritize safety when capturing evidence
- **Respectful Conduct**: Interact professionally with all users

### Prohibited Activities
- **False Reports**: Submitting fake or fabricated violations
- **Harassment**: Targeting specific individuals or groups
- **Privacy Violations**: Recording private property without consent
- **System Abuse**: Attempting to manipulate the reporting system
- **Illegal Activity**: Using the app for any unlawful purposes

### Content Guidelines
- **Evidence Quality**: Submit clear, relevant photos and videos
- **Privacy Respect**: Avoid capturing unnecessary personal information
- **Appropriate Content**: No offensive, discriminatory, or harmful content
- **Copyright**: Only submit original content you own or have rights to

---

## Traffic Violation Reporting

### Reporting Standards
- **Accurate Location**: Provide precise GPS coordinates
- **Clear Evidence**: Submit high-quality photos/videos
- **Timely Reporting**: Submit reports promptly after witnessing violations
- **Complete Information**: Fill out all required violation details

### Verification Process
1. **Initial Review**: Automated system checks for completeness
2. **Traffic Police Review**: Official verification by authorized officers
3. **Status Updates**: Real-time notification of case progress
4. **Appeal Process**: Option to contest rejected reports

### User Responsibilities
- **Safety Priority**: Never endanger yourself or others for reports
- **Legal Compliance**: Follow all traffic laws while reporting
- **Evidence Integrity**: Do not alter or manipulate evidence
- **Cooperation**: Assist with official investigations when requested

---

## Commission and Payment System

### Earning Structure
- **Commission Rate**: 20% of collected violation fines
- **Payment Calculation**: Based on official fine amounts
- **Processing Time**: Payments processed after fine collection
- **Minimum Threshold**: ৳100 minimum for payout requests

### Payment Methods
- **Mobile Wallets**: bKash, Rocket, Nagad, others
- **Bank Transfer**: Direct deposit to local bank accounts
- **Payment Schedule**: Monthly payment cycles
- **Tax Responsibilities**: Users responsible for tax compliance

### Commission Conditions
- **Verified Cases Only**: Payment only for officially verified violations
- **Fine Collection**: Commission paid only when violators pay fines
- **Quality Standards**: Maintains high accuracy standards for payments
- **Fraud Prevention**: Advanced systems to prevent fraudulent earnings

---

## Intellectual Property Rights

### Third Eye Property
- **App Technology**: All app software and technology owned by Third Eye
- **Trademarks**: Third Eye name, logo, and branding are our property
- **Content**: All app content, including text, graphics, and interfaces
- **Data Analytics**: Insights and analytics derived from user data

### User Content
- **Content Ownership**: You retain ownership of submitted photos/videos
- **License Grant**: You grant us license to use content for violation processing
- **Public Safety Use**: Content may be shared with authorities for enforcement
- **Quality Control**: We reserve right to refuse low-quality submissions

### Third-Party Content
- **Government Data**: Traffic rules and fine information from official sources
- **Emergency Services**: Contact information from official government sources
- **Maps and Location**: Third-party mapping and GPS services
- **Respect Rights**: All third-party intellectual property rights respected

---

## Privacy and Data Protection

### Data Collection
- **Personal Information**: Name, contact details, identity documents
- **Usage Data**: App interaction patterns and violation reports
- **Location Data**: GPS coordinates for accurate reporting
- **Device Information**: Technical details for app optimization

### Data Use
- **Service Provision**: Process violation reports and manage accounts
- **Commission Payments**: Calculate and distribute earnings
- **Law Enforcement**: Share violation data with traffic authorities
- **Service Improvement**: Analyze usage to enhance app functionality

### Privacy Rights
- **Data Access**: View and download your personal data
- **Data Correction**: Update inaccurate information
- **Data Deletion**: Request account and data deletion
- **Privacy Policy**: Full details in our Privacy Policy document

---

## Limitation of Liability

### Service Disclaimer
- **"As Is" Service**: App provided without warranties or guarantees
- **Best Efforts**: We strive for accuracy but cannot guarantee perfection
- **Third-Party Services**: Not responsible for third-party service failures
- **Government Decisions**: Cannot guarantee government approval of all reports

### Liability Limits
- **Maximum Liability**: Limited to amounts paid by you (if any) to us
- **Indirect Damages**: Not liable for lost profits, data, or opportunities
- **Force Majeure**: Not liable for circumstances beyond our control
- **User Actions**: Not liable for your use of the app or violation of Terms

### Indemnification
You agree to indemnify and hold us harmless from:
- **Legal Claims**: Arising from your use of the Service
- **Content Liability**: Related to content you submit
- **Violation of Terms**: Resulting from your breach of these Terms
- **Third-Party Claims**: From your interaction with other users

---

## Government Cooperation

### Law Enforcement Support
- **Official Partnership**: Collaborate with Bangladesh traffic authorities
- **Data Sharing**: Share violation reports with appropriate officials
- **Legal Compliance**: Comply with all local and national laws
- **Court Orders**: Respond to valid legal requests and subpoenas

### Public Safety Mission
- **Road Safety**: Primary mission to improve Bangladesh road safety
- **Community Service**: Enable citizen participation in traffic enforcement
- **Government Revenue**: Help collect legitimate traffic fines
- **Accident Prevention**: Contribute to reducing traffic accidents

---

## Termination

### Account Termination by You
- **Voluntary Closure**: Delete your account anytime through app settings
- **Data Retention**: Some data retained for legal compliance
- **Outstanding Payments**: Receive pending commissions before closure
- **Content License**: License to use your content may survive termination

### Account Termination by Us
We may suspend or terminate your account for:
- **Terms Violation**: Breach of these Terms or acceptable use
- **Fraudulent Activity**: Suspected fraud or system manipulation
- **Legal Requirements**: Court orders or government requests
- **Service Discontinuation**: If we cease operations

### Effects of Termination
- **Access Removal**: Immediate loss of app access
- **Data Deletion**: Personal data deleted per retention policy
- **Payment Processing**: Outstanding commissions processed
- **Surviving Provisions**: Certain Terms survive termination

---

## Modifications to Service and Terms

### Service Changes
- **Feature Updates**: Regular app improvements and new features
- **Service Availability**: May temporarily suspend service for maintenance
- **Geographic Expansion**: May expand to new regions
- **Policy Updates**: Traffic rules and procedures may change

### Terms Updates
- **Notification**: 30-day notice for material changes
- **Continued Use**: Using service after changes constitutes acceptance
- **Disagreement**: Stop using service if you disagree with new terms
- **Version Control**: Always refer to latest version of Terms

---

## Dispute Resolution

### Informal Resolution
- **Direct Contact**: First contact us directly to resolve disputes
- **Good Faith**: Both parties attempt good faith resolution
- **Documentation**: Maintain records of dispute communications
- **Reasonable Time**: Allow reasonable time for resolution attempts

### Formal Dispute Process
- **Jurisdiction**: Disputes resolved under Bangladesh law
- **Local Courts**: Bangladesh courts have jurisdiction
- **Language**: Proceedings conducted in Bengali or English
- **Legal Fees**: Each party bears own legal costs unless otherwise ordered

### Emergency Relief
- **Immediate Harm**: Either party may seek emergency relief in court
- **Preliminary Injunctions**: Available for urgent matters
- **Specific Performance**: Court may order specific actions
- **Preservation Orders**: Court may order preservation of evidence

---

## Force Majeure

We are not liable for delays or failures caused by:
- **Natural Disasters**: Floods, earthquakes, storms
- **Government Actions**: Law changes, regulations, restrictions
- **Technical Issues**: Internet outages, server failures
- **Civil Unrest**: Strikes, protests, political instability
- **Pandemic**: Disease outbreaks affecting operations

---

## Governing Law and Jurisdiction

### Applicable Law
- **Bangladesh Law**: These Terms governed by laws of Bangladesh
- **International Standards**: Consistent with international best practices
- **Regulatory Compliance**: Subject to Bangladesh regulatory requirements
- **Constitutional Rights**: Respects fundamental rights under Bangladesh Constitution

### Jurisdiction
- **Bangladesh Courts**: Exclusive jurisdiction of Bangladesh courts
- **Dhaka Venue**: Dhaka courts have preferred venue
- **Service of Process**: Legal notices served per Bangladesh law
- **Language**: Legal proceedings in Bengali or English as appropriate

---

## Miscellaneous Provisions

### Entire Agreement
These Terms, together with our Privacy Policy, constitute the complete agreement between you and Third Eye.

### Severability
If any provision is found invalid, the remaining provisions remain in full effect.

### No Waiver
Our failure to enforce any right does not constitute a waiver of that right.

### Assignment
You may not assign these Terms without our written consent. We may assign freely.

### Headings
Section headings are for convenience only and do not affect interpretation.

---

## Contact Information

### Legal Department
**Email**: legal@thirdeye.bd  
**Phone**: +880-1XXX-XXXXXX  
**Address**: Third Eye Legal Team, Dhaka, Bangladesh

### Customer Support
**Email**: support@thirdeye.bd  
**In-App**: Customer support chat available 24/7  
**Response Time**: Within 24 hours for general inquiries

### Regulatory Compliance
**Email**: compliance@thirdeye.bd  
**Government Relations**: govt.relations@thirdeye.bd

---

## Acknowledgment

By using the Third Eye app, you acknowledge that:

1. **You have read and understood these Terms**
2. **You agree to be bound by these Terms**
3. **You are eligible to use the Service**
4. **You will use the Service responsibly and legally**
5. **You understand the commission and payment system**
6. **You agree to cooperate with law enforcement**
7. **You accept the limitation of liability**
8. **You understand your privacy rights and responsibilities**

**Thank you for joining our mission to make Bangladesh roads safer through community participation.**

---

**Third Eye - Empowering Citizens, Enhancing Safety, Building Better Roads**

*These Terms of Service are effective as of the date listed above and will remain in effect until modified or terminated.*
