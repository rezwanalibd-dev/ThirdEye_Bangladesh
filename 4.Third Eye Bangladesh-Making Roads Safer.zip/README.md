# 👁️ Third Eye - তৃতীয় চোখ

**Report Traffic Violations • Earn Rewards • Save Lives in Bangladesh**

A mobile-first Progressive Web App (PWA) that empowers citizens to report traffic violations and earn commission while making Bangladesh roads safer.

---

## 🎯 Overview

Third Eye is a community-driven traffic enforcement platform that allows citizens to:
- 📸 Report traffic violations with photo/video evidence
- 💰 Earn 20% commission on fines collected
- 🚨 Access emergency contacts instantly
- 📍 Track GPS-verified violation locations
- 🏆 Monitor case status and earnings in real-time

---

## ✨ Key Features

### For Citizens
- **Easy Reporting**: 4-step process to report violations
- **Earn Money**: 20% commission on verified reports
- **Safety First**: Emergency contact numbers and safety tips
- **Track Progress**: Real-time case status updates
- **Instant Payments**: Automatic mobile money transfers

### For Traffic Officers
- **Review Cases**: Verify submitted reports
- **Issue Fines**: Generate violation notices
- **Track Metrics**: Monitor enforcement statistics
- **Approve Payments**: Process citizen commissions

### Technical Features
- **PWA Support**: Install on Android/iOS without app stores
- **Offline Mode**: Works without internet connection
- **Bilingual**: Full Bengali and English support
- **Responsive**: Works on all screen sizes
- **Secure**: KYC verification and encrypted data

---

## 🚀 Tech Stack

### Frontend
- **React** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Vite** - Build tool
- **React Router** - Navigation

### Backend
- **Cloudflare Workers** - Serverless API
- **D1 Database** - SQLite-based storage
- **R2 Storage** - File storage
- **Hono** - API framework

### Mobile
- **Capacitor** - Native mobile wrapper
- **PWA** - Progressive Web App
- **Service Workers** - Offline support

---

## 📦 Installation

### Prerequisites
- Node.js 18+ or Bun
- npm or bun package manager

### Quick Start

```bash
# Clone the repository
git clone <repository-url>
cd third-eye-app

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Mobile Development

```bash
# Install Capacitor CLI
npm install -g @capacitor/cli

# Add Android platform
npx cap add android
npx cap sync
npx cap open android

# Add iOS platform (Mac only)
npx cap add ios
npx cap sync
npx cap open ios
```

---

## 📱 PWA Installation

The app supports Progressive Web App installation:

### Android (Chrome/Edge)
1. Open app in browser
2. Tap "Install" banner at bottom
3. Confirm installation
4. App appears on home screen

### iOS (Safari)
1. Open app in Safari
2. Tap Share button
3. Select "Add to Home Screen"
4. Confirm and add icon

### Desktop
1. Click install icon in address bar
2. Confirm installation
3. App opens as desktop application

---

## 🗂️ Project Structure

```
third-eye-app/
├── src/
│   ├── react-app/          # Frontend React application
│   │   ├── components/     # Reusable UI components
│   │   ├── contexts/       # React context providers
│   │   ├── hooks/          # Custom React hooks
│   │   ├── pages/          # Page components
│   │   ├── App.tsx         # Main app component
│   │   └── main.tsx        # Application entry
│   ├── shared/             # Shared utilities
│   └── worker/             # Backend API (Cloudflare Worker)
├── public/                 # Static assets
│   ├── icons/              # App icons (all sizes)
│   ├── splash/             # iOS splash screens
│   ├── manifest.json       # PWA manifest
│   └── sw.js              # Service worker
├── android/                # Android app files
├── ios/                    # iOS app files
└── docs/                   # Documentation
```

---

## 🎨 Design System

### Color Palette
- **Primary**: Blue (#3b82f6) - Main actions
- **Secondary**: Red (#ef4444) - Reports/alerts
- **Success**: Green (#10b981) - Earnings/approvals
- **Background**: White (#ffffff) - Clean, light theme

### Typography
- **Font**: Inter (system fallback)
- **Sizes**: Responsive (0.75rem - 4rem)
- **Line Heights**: Optimized for readability

### Components
- Minimum 48px touch targets
- High contrast for accessibility
- Mobile-first responsive design
- Smooth transitions and animations

---

## 🌍 Internationalization

The app supports:
- 🇬🇧 **English** - Primary language
- 🇧🇩 **Bengali** - বাংলা support

Translation system:
- Context-based translations
- RTL layout support
- Number/currency formatting
- Date/time localization

---

## 🔐 Security

### User Authentication
- Phone number + password login
- OTP verification via SMS
- Session-based authentication
- Secure password hashing (bcrypt)

### KYC Verification
- Identity document upload
- Facial verification
- Officer manual review
- Secure document storage

### Data Protection
- HTTPS encryption
- SQL injection prevention
- XSS protection
- CORS configuration
- Input validation (Zod)

---

## 📊 Features Breakdown

### 1. User Registration
- Phone number registration
- Email (optional)
- Password with strength validation
- OTP verification
- Identity document upload
- Facial verification

### 2. Report Submission
- Vehicle type selection
- Violation category
- Photo/video upload
- GPS location capture
- Additional description
- Evidence verification

### 3. Case Management
- Real-time status tracking
- Officer review process
- Approval/rejection workflow
- Payment processing
- Case history

### 4. Payment System
- Mobile money integration
- 20% commission calculation
- Automatic payouts
- Transaction history
- Payment verification

### 5. Emergency Features
- Quick emergency contacts
- Police (999)
- Fire Service (102)
- Ambulance
- Traffic Police (16263)
- Direct call functionality

---

## 🧪 Testing

### Run Tests
```bash
# Type checking
npx tsc --noEmit

# Linting
npx eslint --ext .ts,.tsx

# Build test
npm run build
```

### Testing Checklist
- [ ] User registration flow
- [ ] Login/logout
- [ ] Report submission
- [ ] Case status tracking
- [ ] Payment processing
- [ ] Emergency contacts
- [ ] PWA installation
- [ ] Offline functionality
- [ ] Language switching
- [ ] Mobile responsiveness

---

## 📈 Publishing

### Google Play Store
See `ANDROID_PUBLISHING_GUIDE.md` for detailed steps:
1. Build release APK/AAB
2. Create Play Console account
3. Complete store listing
4. Upload app bundle
5. Submit for review

### Apple App Store
See `IOS_PUBLISHING_GUIDE.md` for detailed steps:
1. Build release IPA
2. Create App Store Connect account
3. Complete app information
4. Upload via Xcode
5. Submit for review

### Web Deployment
```bash
# Build production bundle
npm run build

# Deploy to Cloudflare Pages
npx wrangler pages publish dist
```

---

## 🤝 Contributing

We welcome contributions! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Code Style
- Use TypeScript
- Follow ESLint rules
- Write meaningful comments
- Keep components small
- Use functional components

---

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

---

## 📞 Support

For support and questions:

- **Email**: support@thirdeyebd.com
- **Phone**: +880 1XXX-XXXXXX
- **Website**: https://thirdeye.app

---

## 🙏 Acknowledgments

- Bangladesh Road Transport Authority (BRTA)
- Dhaka Metropolitan Police (DMP)
- All beta testers and early users
- Open source community

---

## 📋 Legal

- Privacy Policy: `PRIVACY_POLICY.md`
- Terms of Service: `TERMS_OF_SERVICE.md`
- Data Protection: GDPR compliant
- Age Rating: Everyone/4+

---

## 🗺️ Roadmap

### Version 1.0 (Current)
- ✅ Basic reporting functionality
- ✅ PWA support
- ✅ Mobile payments
- ✅ Bilingual interface

### Version 1.1 (Planned)
- 🔄 AI-powered violation detection
- 🔄 Blockchain payment verification
- 🔄 Advanced analytics dashboard
- 🔄 Gamification features

### Version 2.0 (Future)
- 🔮 Social crime reporting
- 🔮 Community forums
- 🔮 Integration with traffic cameras
- 🔮 Predictive analytics

---

## 📊 Statistics

### Impact (Projected)
- **Target Users**: 10M+ smartphone users
- **Coverage**: All major cities in Bangladesh
- **Violations**: 50+ violation types
- **Revenue**: ৳100K-৳1M monthly potential

### Performance
- **Load Time**: < 2 seconds
- **App Size**: 2-5 MB
- **Offline**: Full functionality
- **Battery**: Optimized for mobile

---

**Made with ❤️ for Bangladesh** 🇧🇩

*Last Updated: November 2025*
*Version: 1.0.0*
