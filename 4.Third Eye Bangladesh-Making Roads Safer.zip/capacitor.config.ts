import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thirdeyebangladesh.app',
  appName: 'Third Eye',
  webDir: 'dist/client',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Camera: {
      requestPermissions: true,
      saveToGallery: true
    },
    Geolocation: {
      requestPermissions: true
    },
    LocalNotifications: {
      smallIcon: "ic_stat_icon_config_sample",
      iconColor: "#488AFF",
      sound: "beep.wav",
    }
  }
};

export default config;
