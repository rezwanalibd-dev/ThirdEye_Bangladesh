# Third Eye Android App

This directory contains the Android version of the Third Eye mobile application for reporting traffic violations in Bangladesh.

## Prerequisites

- Android Studio
- Android SDK 24 or higher
- Node.js and npm
- Capacitor CLI

## Setup Instructions

1. Install dependencies:
```bash
cd /path/to/third-eye-app
npm install
```

2. Build the web app:
```bash
npm run build
```

3. Add Android platform:
```bash
npx cap add android
```

4. Sync files to Android:
```bash
npx cap sync android
```

5. Open in Android Studio:
```bash
npx cap open android
```

## Build for Production

1. Build the web app for production:
```bash
npm run build
```

2. Sync the latest changes:
```bash
npx cap sync android
```

3. Open Android Studio and build the APK or AAB file for Google Play Store submission

## App Features

- Traffic violation reporting with camera
- GPS location detection
- Real-time case tracking
- Digital wallet integration for payments
- Emergency contact access
- Bilingual support (English/Bengali)

## Configuration

The app is configured in `capacitor.config.ts` with:
- App ID: `com.thirdeyebangladesh.app`
- App Name: `Third Eye`
- Web directory: `dist/client`

## Permissions

The app requires the following permissions:
- Camera (for taking photos of violations)
- Location (for GPS coordinates)
- Internet (for API communication)
- Storage (for caching files)

## Play Store Submission

1. Build signed APK/AAB in Android Studio
2. Test on multiple devices
3. Prepare store listing with screenshots
4. Submit to Google Play Console

For detailed setup instructions, see the main README.md file.
