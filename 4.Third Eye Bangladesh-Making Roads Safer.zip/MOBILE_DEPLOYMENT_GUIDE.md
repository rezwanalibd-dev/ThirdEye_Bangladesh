# Third Eye Mobile App Deployment Guide

This guide will help you deploy the Third Eye app to both Android (Google Play Store) and iOS (Apple App Store).

## Overview

Third Eye is a citizen reporting app for traffic violations in Bangladesh, built with:
- React + TypeScript for the frontend
- Capacitor for mobile app wrapper
- Cloudflare Workers for the backend
- SQLite (D1) database

## Prerequisites

### General
- Node.js 18+ and npm
- Git

### Android
- Android Studio
- Android SDK (API level 24+)
- Java Development Kit (JDK) 11+

### iOS
- macOS with Xcode 12+
- iOS SDK 13.0+
- Apple Developer Account ($99/year)

## Step 1: Setup Development Environment

1. Clone and setup the project:
```bash
git clone <repository-url>
cd third-eye-app
npm install
```

2. Build the web application:
```bash
npm run build
```

## Step 2: Android Deployment

### Initial Setup
```bash
# Add Android platform
npx cap add android

# Sync files
npx cap sync android

# Open in Android Studio
npx cap open android
```

### Configure Android App

1. **Update app details** in `android/app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">Third Eye</string>
<string name="title_activity_main">Third Eye</string>
<string name="package_name">com.thirdeyebangladesh.app</string>
```

2. **Set permissions** in `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
```

3. **Update app icon and splash screen**:
   - Replace files in `android/app/src/main/res/drawable/`
   - Use Android Asset Studio for generating icons

### Build for Production

1. **Generate signing key**:
```bash
keytool -genkey -v -keystore third-eye-release-key.keystore -alias third-eye -keyalg RSA -keysize 2048 -validity 10000
```

2. **Configure signing** in `android/app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            if (project.hasProperty('THIRD_EYE_RELEASE_STORE_FILE')) {
                storeFile file(THIRD_EYE_RELEASE_STORE_FILE)
                storePassword THIRD_EYE_RELEASE_STORE_PASSWORD
                keyAlias THIRD_EYE_RELEASE_KEY_ALIAS
                keyPassword THIRD_EYE_RELEASE_KEY_PASSWORD
            }
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

3. **Build signed APK**:
```bash
cd android
./gradlew assembleRelease
```

### Google Play Store Submission

1. Create app listing in Google Play Console
2. Upload APK/AAB file
3. Fill in app details, screenshots, and descriptions
4. Set content rating and pricing
5. Submit for review

## Step 3: iOS Deployment

### Initial Setup
```bash
# Add iOS platform
npx cap add ios

# Sync files
npx cap sync ios

# Open in Xcode
npx cap open ios
```

### Configure iOS App

1. **Update app configuration** in Xcode:
   - Set bundle identifier: `com.thirdeyebangladesh.app`
   - Configure app icons and launch screen
   - Set deployment target to iOS 13.0+

2. **Configure permissions** in `ios/App/App/Info.plist`:
```xml
<key>NSCameraUsageDescription</key>
<string>This app uses camera to capture traffic violations</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>This app uses location to record violation locations</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>This app accesses photo library to select violation evidence</string>
```

3. **Configure capabilities**:
   - Background App Refresh
   - Push Notifications (if needed)

### Build for Production

1. **Configure signing**:
   - Create App ID in Apple Developer portal
   - Generate distribution certificate
   - Create distribution provisioning profile

2. **Archive and upload**:
   - Select "Generic iOS Device" in Xcode
   - Product → Archive
   - Upload to App Store Connect

### App Store Submission

1. Create app listing in App Store Connect
2. Upload build from Xcode
3. Fill in app metadata, screenshots, and descriptions
4. Submit for App Review

## Step 4: Continuous Deployment

### Update Process

When you need to update the app:

1. **Update web code**:
```bash
npm run build
```

2. **Sync changes**:
```bash
npx cap sync
```

3. **Test on devices**:
```bash
# Android
npx cap run android

# iOS  
npx cap run ios
```

4. **Build and deploy**:
   - Follow production build steps above
   - Submit updated versions to stores

### Automated CI/CD (Optional)

You can set up GitHub Actions or similar CI/CD pipeline to:
- Run tests
- Build web app
- Generate mobile builds
- Deploy to internal testing tracks

## Step 5: Testing and Quality Assurance

### Testing Checklist

- [ ] Camera functionality works
- [ ] GPS location detection
- [ ] Form submission and validation
- [ ] Emergency contacts dial correctly
- [ ] Language switching (English/Bengali)
- [ ] Network error handling
- [ ] Offline functionality (if applicable)
- [ ] Performance on low-end devices

### Beta Testing

- **Android**: Use Google Play Internal Testing
- **iOS**: Use TestFlight for beta testing

## Step 6: Store Optimization

### App Store Listing

1. **Title**: "Third Eye - তৃতীয় চোখ"
2. **Subtitle**: "Report Traffic Violations"
3. **Keywords**: traffic, safety, bangladesh, reporting, violations
4. **Description**: Focus on citizen empowerment and road safety
5. **Screenshots**: Show key features in both English and Bengali
6. **Category**: Transportation or Utilities

### Localization

- Support both English and Bengali
- Localize store descriptions
- Use appropriate cultural references

## Security Considerations

- API keys should be stored securely
- Use certificate pinning for API calls
- Validate all user inputs
- Encrypt sensitive data storage
- Follow OWASP mobile security guidelines

## Monitoring and Analytics

Consider integrating:
- Crash reporting (Firebase Crashlytics)
- Analytics (Google Analytics, Firebase Analytics)
- Performance monitoring
- User feedback collection

## Support and Maintenance

- Monitor app reviews and respond promptly
- Keep dependencies updated
- Plan regular feature updates
- Maintain backend API compatibility
- Monitor app performance metrics

## Resources

- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Android Developer Guide](https://developer.android.com/)
- [iOS Developer Guide](https://developer.apple.com/)
- [Google Play Console](https://play.google.com/console/)
- [App Store Connect](https://appstoreconnect.apple.com/)

## Troubleshooting

### Common Issues

1. **Build failures**: Check Node.js version compatibility
2. **Plugin issues**: Ensure Capacitor plugins are up to date
3. **Permission errors**: Verify platform-specific permissions
4. **Network issues**: Check CORS and API endpoints
5. **Store rejection**: Review app store guidelines carefully

For technical support, refer to the main project documentation or create an issue in the project repository.
