import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

interface WorkerEnv extends Env {
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

interface User {
  id: number;
  email?: string;
  mobile_number: string;
  full_name: string;
  is_verified: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}



const app = new Hono<{ Bindings: WorkerEnv; Variables: { user: User } }>();

// Enable CORS
app.use("*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  credentials: true,
}));

// JWT Secret (in production, this should be in environment variables)
const JWT_SECRET = "your-jwt-secret-key";
const SESSION_COOKIE_NAME = "third_eye_session";

// Password validation function
function validatePassword(password: string): boolean {
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /\d/.test(password);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);
  const isLongEnough = password.length >= 8;
  
  return hasUppercase && hasLowercase && hasNumber && hasSymbol && isLongEnough;
}

// Generate OTP
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP (mock implementation)
async function sendOTP(type: 'email' | 'sms', contact: string, otp: string): Promise<boolean> {
  // Mock implementation - in production, integrate with SMS/Email service
  console.log(`Sending ${type} OTP ${otp} to ${contact}`);
  return true;
}

// Auth middleware
const authMiddleware = async (c: any, next: () => Promise<void>) => {
  const sessionToken = getCookie(c, SESSION_COOKIE_NAME);
  
  if (!sessionToken) {
    return c.json({ error: "No session token provided" }, 401);
  }

  try {
    jwt.verify(sessionToken, JWT_SECRET);
    
    // Check if session exists in database
    const session = await c.env.DB.prepare(
      "SELECT s.*, u.* FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.session_token = ? AND s.expires_at > datetime('now')"
    ).bind(sessionToken).first();

    if (!session) {
      return c.json({ error: "Invalid or expired session" }, 401);
    }

    c.set('user', {
      id: session.user_id,
      email: session.email,
      mobile_number: session.mobile_number,
      full_name: session.full_name,
      is_verified: session.is_verified,
      is_active: session.is_active,
      created_at: session.created_at,
      updated_at: session.updated_at
    });

    await next();
  } catch {
    return c.json({ error: "Invalid session token" }, 401);
  }
};

// Auth Routes
app.post("/api/auth/signup", async (c) => {
  const body = await c.req.json();
  const { full_name, mobile_number, email, password } = body;

  // Validate required fields
  if (!full_name || !mobile_number || !password) {
    return c.json({ error: "Full name, mobile number, and password are required" }, 400);
  }

  // Validate password strength
  if (!validatePassword(password)) {
    return c.json({ 
      error: "Password must contain uppercase, lowercase, number, symbol and be at least 8 characters" 
    }, 400);
  }

  // Check if user already exists
  const existingUser = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mobile_number = ? OR email = ?"
  ).bind(mobile_number, email || null).first();

  if (existingUser) {
    return c.json({ error: "User with this mobile number or email already exists" }, 400);
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 10);

  // Create user
  const result = await c.env.DB.prepare(`
    INSERT INTO users (full_name, mobile_number, email, password_hash)
    VALUES (?, ?, ?, ?)
  `).bind(full_name, mobile_number, email || null, passwordHash).run();

  const userId = result.meta.last_row_id as number;

  // Generate OTP for verification
  const otpCode = generateOTP();
  const expiresAt = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes

  // Store OTP
  await c.env.DB.prepare(`
    INSERT INTO otp_verifications (user_id, otp_code, otp_type, contact_info, expires_at)
    VALUES (?, ?, ?, ?, ?)
  `).bind(userId, otpCode, 'sms', mobile_number, expiresAt.toISOString()).run();

  // Send OTP
  await sendOTP('sms', mobile_number, otpCode);

  return c.json({ 
    success: true, 
    message: "User created successfully. OTP sent to mobile number.",
    user_id: userId
  });
});

app.post("/api/auth/verify-otp", async (c) => {
  const body = await c.req.json();
  const { user_id, otp_code } = body;

  if (!user_id || !otp_code) {
    return c.json({ error: "User ID and OTP code are required" }, 400);
  }

  // Find valid OTP
  const otpRecord = await c.env.DB.prepare(`
    SELECT * FROM otp_verifications 
    WHERE user_id = ? AND otp_code = ? AND is_used = FALSE AND expires_at > datetime('now')
    ORDER BY created_at DESC LIMIT 1
  `).bind(user_id, otp_code).first();

  if (!otpRecord) {
    return c.json({ error: "Invalid or expired OTP" }, 400);
  }

  // Mark OTP as used
  await c.env.DB.prepare(`
    UPDATE otp_verifications SET is_used = TRUE WHERE id = ?
  `).bind(otpRecord.id).run();

  // Mark user as verified
  await c.env.DB.prepare(`
    UPDATE users SET is_verified = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).bind(user_id).run();

  // Get updated user
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(user_id).first();

  // Create session
  const sessionToken = jwt.sign({ userId: user_id }, JWT_SECRET, { expiresIn: '60d' });
  const expiresAt = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000); // 60 days

  await c.env.DB.prepare(`
    INSERT INTO sessions (user_id, session_token, expires_at)
    VALUES (?, ?, ?)
  `).bind(user_id, sessionToken, expiresAt.toISOString()).run();

  // Set cookie
  setCookie(c, SESSION_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true, user });
});

app.post("/api/auth/signin", async (c) => {
  const body = await c.req.json();
  const { mobile_number, password } = body;

  if (!mobile_number || !password) {
    return c.json({ error: "Mobile number and password are required" }, 400);
  }

  // Find user
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE mobile_number = ? AND is_active = TRUE"
  ).bind(mobile_number).first();

  if (!user) {
    return c.json({ error: "Invalid credentials" }, 400);
  }

  // Verify password
  const passwordValid = await bcrypt.compare(password, user.password_hash as string);
  if (!passwordValid) {
    return c.json({ error: "Invalid credentials" }, 400);
  }

  if (!user.is_verified) {
    return c.json({ error: "Account not verified. Please verify your account first." }, 400);
  }

  // Create session
  const sessionToken = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '60d' });
  const expiresAt = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000); // 60 days

  await c.env.DB.prepare(`
    INSERT INTO sessions (user_id, session_token, expires_at)
    VALUES (?, ?, ?)
  `).bind(user.id, sessionToken, expiresAt.toISOString()).run();

  // Set cookie
  setCookie(c, SESSION_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true, user: {
    id: user.id,
    email: user.email,
    mobile_number: user.mobile_number,
    full_name: user.full_name,
    is_verified: user.is_verified,
    is_active: user.is_active,
    created_at: user.created_at,
    updated_at: user.updated_at
  }});
});

app.get("/api/users/me", authMiddleware, async (c: any) => {
  const user = c.get("user");
  
  // Get additional user profile data
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE custom_user_id = ?"
  ).bind(user.id).first();

  // Get identity verification status
  const identityVerification = await c.env.DB.prepare(
    "SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1"
  ).bind(user.id).first();

  // Get biometric verification status
  const biometricVerification = await c.env.DB.prepare(
    "SELECT * FROM biometric_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1"
  ).bind(user.id).first();

  return c.json({ 
    ...user, 
    profile: profile || null,
    identity_verification: identityVerification || null,
    biometric_verification: biometricVerification || null
  });
});

app.post('/api/auth/logout', authMiddleware, async (c: any) => {
  const sessionToken = getCookie(c, SESSION_COOKIE_NAME);

  if (sessionToken) {
    // Delete session from database
    await c.env.DB.prepare(
      "DELETE FROM sessions WHERE session_token = ?"
    ).bind(sessionToken).run();
  }

  // Clear cookie
  setCookie(c, SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true });
});

// Resend OTP
app.post("/api/auth/resend-otp", async (c) => {
  const body = await c.req.json();
  const { user_id } = body;

  if (!user_id) {
    return c.json({ error: "User ID is required" }, 400);
  }

  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(user_id).first();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  // Generate new OTP
  const otpCode = generateOTP();
  const expiresAt = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes

  // Store OTP
  await c.env.DB.prepare(`
    INSERT INTO otp_verifications (user_id, otp_code, otp_type, contact_info, expires_at)
    VALUES (?, ?, ?, ?, ?)
  `).bind(user_id, otpCode, 'sms', user.mobile_number, expiresAt.toISOString()).run();

  // Send OTP
  await sendOTP('sms', user.mobile_number as string, otpCode);

  return c.json({ success: true, message: "OTP sent successfully" });
});

// Identity Verification
app.post("/api/auth/verify-identity", authMiddleware, async (c: any) => {
  const user = c.get("user");
  const body = await c.req.json();

  const { document_type, document_number, document_front_url, document_back_url } = body;

  if (!document_type || !document_number || !document_front_url) {
    return c.json({ error: "Document type, number, and front image are required" }, 400);
  }

  if (document_type !== 'passport' && !document_back_url) {
    return c.json({ error: "Document back image is required for NID and driving license" }, 400);
  }

  // Insert identity verification
  const result = await c.env.DB.prepare(`
    INSERT INTO identity_verifications (
      user_id, document_type, document_number, document_front_url, document_back_url
    ) VALUES (?, ?, ?, ?, ?)
  `).bind(
    user.id, document_type, document_number, document_front_url, document_back_url || null
  ).run();

  return c.json({ success: true, verification_id: result.meta.last_row_id });
});

// Biometric Verification
app.post("/api/auth/verify-biometric", authMiddleware, async (c: any) => {
  const user = c.get("user");
  const body = await c.req.json();

  const { front_face_url, left_side_url, right_side_url } = body;

  if (!front_face_url || !left_side_url || !right_side_url) {
    return c.json({ error: "All three face images are required" }, 400);
  }

  // Insert biometric verification
  const result = await c.env.DB.prepare(`
    INSERT INTO biometric_verifications (
      user_id, front_face_url, left_side_url, right_side_url
    ) VALUES (?, ?, ?, ?)
  `).bind(user.id, front_face_url, left_side_url, right_side_url).run();

  return c.json({ success: true, verification_id: result.meta.last_row_id });
});

// Profile Routes
app.post("/api/profile", authMiddleware, async (c: any) => {
  const user = c.get("user");
  const body = await c.req.json();

  const { 
    user_type, 
    phone_number, 
    department, 
    badge_id,
    preferred_language,
    wallet_provider,
    wallet_number
  } = body;

  // Insert or update user profile
  const existingProfile = await c.env.DB.prepare(
    "SELECT id FROM user_profiles WHERE custom_user_id = ?"
  ).bind(user.id).first();

  if (existingProfile) {
    await c.env.DB.prepare(`
      UPDATE user_profiles SET 
        phone_number = ?, department = ?, badge_id = ?,
        preferred_language = ?, wallet_provider = ?, wallet_number = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE custom_user_id = ?
    `).bind(
      phone_number, department, badge_id,
      preferred_language, wallet_provider, wallet_number, user.id
    ).run();
  } else {
    await c.env.DB.prepare(`
      INSERT INTO user_profiles (
        custom_user_id, user_id, user_type, full_name, phone_number, 
        department, badge_id, preferred_language, wallet_provider, wallet_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      user.id, `custom_${user.id}`, user_type, user.full_name, phone_number,
      department, badge_id, preferred_language || 'en', wallet_provider, wallet_number
    ).run();
  }

  return c.json({ success: true });
});

// Violation Types
app.get("/api/violation-types", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM violation_types WHERE is_active = TRUE ORDER BY name_en"
  ).all();

  return c.json(results);
});

// Cases Routes
app.post("/api/cases", authMiddleware, async (c: any) => {
  const user = c.get("user");
  const body = await c.req.json();

  const {
    violation_type_id,
    vehicle_number,
    location_description,
    latitude,
    longitude,
    description,
    evidence_urls
  } = body;

  // Generate case number
  const caseNumber = `TE-${Date.now()}-${Math.floor(Math.random() * 10000)}`;

  // Get violation type for fine calculation
  const violationType = await c.env.DB.prepare(
    "SELECT * FROM violation_types WHERE id = ?"
  ).bind(violation_type_id).first();

  if (!violationType) {
    return c.json({ error: "Invalid violation type" }, 400);
  }

  const fineAmount = violationType.fine_amount as number;
  const rewardAmount = fineAmount * (violationType.reward_percentage as number);

  // Insert case
  const result = await c.env.DB.prepare(`
    INSERT INTO cases (
      case_number, reporter_id, violation_type_id, vehicle_number,
      location_description, latitude, longitude, description,
      evidence_urls, fine_amount, reward_amount
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    caseNumber, `custom_${user.id}`, violation_type_id, vehicle_number,
    location_description, latitude, longitude, description,
    JSON.stringify(evidence_urls), fineAmount, rewardAmount
  ).run();

  // Update user stats
  await c.env.DB.prepare(`
    UPDATE user_profiles SET 
      total_reports = total_reports + 1,
      updated_at = CURRENT_TIMESTAMP
    WHERE custom_user_id = ?
  `).bind(user.id).run();

  return c.json({ 
    success: true, 
    case_id: result.meta.last_row_id,
    case_number: caseNumber 
  });
});

app.get("/api/cases", authMiddleware, async (c: any) => {
  const user = c.get("user");
  
  const { results } = await c.env.DB.prepare(`
    SELECT c.*, vt.name_en as violation_name_en, vt.name_bn as violation_name_bn
    FROM cases c
    LEFT JOIN violation_types vt ON c.violation_type_id = vt.id
    WHERE c.reporter_id = ?
    ORDER BY c.created_at DESC
  `).bind(`custom_${user.id}`).all();

  return c.json(results);
});

app.get("/api/cases/:id", authMiddleware, async (c: any) => {
  const user = c.get("user");
  const caseId = c.req.param("id");
  
  const caseData = await c.env.DB.prepare(`
    SELECT c.*, vt.name_en as violation_name_en, vt.name_bn as violation_name_bn
    FROM cases c
    LEFT JOIN violation_types vt ON c.violation_type_id = vt.id
    WHERE c.id = ? AND c.reporter_id = ?
  `).bind(caseId, `custom_${user.id}`).first();

  if (!caseData) {
    return c.json({ error: "Case not found" }, 404);
  }

  return c.json(caseData);
});

// Dashboard Stats
app.get("/api/dashboard/stats", authMiddleware, async (c: any) => {
  const user = c.get("user");
  
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE custom_user_id = ?"
  ).bind(user.id).first();

  const pendingCases = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM cases WHERE reporter_id = ? AND status = 'pending'"
  ).bind(`custom_${user.id}`).first();

  const approvedCases = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM cases WHERE reporter_id = ? AND status = 'approved'"
  ).bind(`custom_${user.id}`).first();

  return c.json({
    profile,
    pending_cases: pendingCases?.count || 0,
    approved_cases: approvedCases?.count || 0,
  });
});

export default app;
