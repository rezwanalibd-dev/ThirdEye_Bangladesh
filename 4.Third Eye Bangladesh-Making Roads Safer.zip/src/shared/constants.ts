// Third Eye App Constants - Based on Bangladesh Traffic Rules
export const APP_NAME = 'Third Eye';
export const APP_TAGLINE = 'Report Traffic Violations • Earn Rewards • Save Lives';

// Vehicle Types (Exact match with requirements)
export const VEHICLE_TYPES = [
  'Motorcycle',
  'Car', 
  'Bus',
  'Truck',
  'E-Rickshaw',
  'CNG'
] as const;

// Base Violation Types (Universal + Vehicle-Specific as per requirements)
export const BASE_VIOLATIONS = [
  // Universal Violations (All Vehicles)
  {
    id: 'red_light_jumping',
    name_en: 'Red Light Jumping',
    name_bn: 'রেড লাইট জাম্পিং',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'wrong_side_driving',
    name_en: 'Wrong Side Driving',
    name_bn: 'ভুল দিক দিয়ে গাড়ি চালানো',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'speeding',
    name_en: 'Speeding',
    name_bn: 'গতি আইন লঙ্ঘন',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'using_mobile_phone',
    name_en: 'Using Mobile Phone',
    name_bn: 'মোবাইল ফোন ব্যবহার',
    fine_amount: 2000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'illegal_parking',
    name_en: 'Illegal Parking',
    name_bn: 'অবৈধ পার্কিং',
    fine_amount: 4000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  {
    id: 'no_license',
    name_en: 'No License',
    name_bn: 'লাইসেন্স নেই',
    fine_amount: 25000,
    reward_percentage: 0.20,
    applies_to: 'all'
  },
  // Vehicle-Specific Violations
  {
    id: 'footpath_driving',
    name_en: 'Driving on a Footpath',
    name_bn: 'ফুটপাতে গাড়ি চালানো',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: ['Motorcycle', 'CNG', 'E-Rickshaw']
  },
  {
    id: 'no_helmet',
    name_en: 'Not Wearing Helmet',
    name_bn: 'হেলমেট না পরা',
    fine_amount: 1000,
    reward_percentage: 0.20,
    applies_to: ['Motorcycle']
  },
  {
    id: 'no_seatbelt',
    name_en: 'Not Wearing Seatbelt',
    name_bn: 'সিটবেল্ট না পরা',
    fine_amount: 1000,
    reward_percentage: 0.20,
    applies_to: ['Car', 'Bus', 'Truck']
  },
  {
    id: 'overloading',
    name_en: 'Vehicle Overloading',
    name_bn: 'যানবাহনে অতিরিক্ত লোড',
    fine_amount: 5000,
    reward_percentage: 0.20,
    applies_to: ['Bus', 'Truck', 'CNG', 'E-Rickshaw']
  },
  {
    id: 'hydraulic_horn',
    name_en: 'Using Hydraulic Horn',
    name_bn: 'হাইড্রোলিক হর্ন ব্যবহার',
    fine_amount: 3000,
    reward_percentage: 0.20,
    applies_to: ['Bus', 'Truck']
  }
] as const;

// Get violations based on vehicle type
export const getViolationsForVehicle = (vehicleType: string) => {
  return BASE_VIOLATIONS.filter(violation => 
    violation.applies_to === 'all' || 
    (Array.isArray(violation.applies_to) && violation.applies_to.includes(vehicleType))
  );
};

// Payment Methods (Digital Wallets in Bangladesh)
export const PAYMENT_PROVIDERS = [
  { 
    name: 'bKash', 
    color: 'from-pink-500 to-pink-600',
    icon: '💳',
    popular: true 
  },
  { 
    name: 'Nagad', 
    color: 'from-orange-500 to-red-600',
    icon: '📱',
    popular: true 
  },
  { 
    name: 'Rocket', 
    color: 'from-blue-500 to-purple-600',
    icon: '🚀',
    popular: true 
  },
  { 
    name: 'Upay', 
    color: 'from-green-500 to-green-600',
    icon: '💰',
    popular: false 
  },
  { 
    name: 'mCash', 
    color: 'from-purple-500 to-purple-600',
    icon: '💵',
    popular: false 
  },
  { 
    name: 'CellFin', 
    color: 'from-yellow-500 to-orange-500',
    icon: '📞',
    popular: false 
  },
  { 
    name: 'SureCash', 
    color: 'from-blue-500 to-blue-600',
    icon: '💎',
    popular: false 
  },
  { 
    name: 'Trust Money', 
    color: 'from-gray-700 to-gray-800',
    icon: '🏦',
    popular: false 
  }
] as const;

// Commission Rate (20%)
export const COMMISSION_RATE = 0.20;

// Social Crime Categories
export const SOCIAL_CRIME_CATEGORIES = [
  {
    id: 'theft',
    name_en: 'Theft',
    name_bn: 'চুরি',
    icon: '🔐',
    anonymous: true
  },
  {
    id: 'fight',
    name_en: 'Public Fighting',
    name_bn: 'পাবলিক মারামারি',
    icon: '👊',
    anonymous: true
  },
  {
    id: 'youth_gang',
    name_en: 'Youth Gang Activity',
    name_bn: 'যুব গ্যাং কার্যকলাপ',
    icon: '👥',
    anonymous: true
  },
  {
    id: 'corruption',
    name_en: 'Corruption',
    name_bn: 'দুর্নীতি',
    icon: '💸',
    anonymous: true
  },
  {
    id: 'bribery',
    name_en: 'Bribery',
    name_bn: 'ঘুষ',
    icon: '🤝',
    anonymous: true
  },
  {
    id: 'robbery',
    name_en: 'Robbery',
    name_bn: 'ডাকাতি',
    icon: '💰',
    anonymous: true
  },
  {
    id: 'social_violence',
    name_en: 'Social Violence',
    name_bn: 'সামাজিক সহিংসতা',
    icon: '⚡',
    anonymous: true
  },
  {
    id: 'serious_crime',
    name_en: 'Serious Crime',
    name_bn: 'গুরুতর অপরাধ',
    icon: '🚨',
    anonymous: true
  }
] as const;

// Emergency Numbers Bangladesh - Updated with requested contact numbers
export const EMERGENCY_CONTACTS = {
  urgent_emergency: [
    {
      number: "999",
      name_en: "Police/Fire/Ambulance",
      name_bn: "পুলিশ/ফায়ার/অ্যাম্বুলেন্স",
      description_en: "MAIN EMERGENCY",
      description_bn: "মূল জরুরি সেবা",
      icon: "🚨"
    },
    {
      number: "199",
      name_en: "Fire Service",
      name_bn: "ফায়ার সার্ভিস",
      description_en: "Fire & Rescue",
      description_bn: "অগ্নি ও উদ্ধার",
      icon: "🚒"
    },
    {
      number: "199",
      name_en: "Ambulance",
      name_bn: "অ্যাম্বুলেন্স",
      description_en: "Medical Emergency",
      description_bn: "চিকিৎসা জরুরি",
      icon: "🚑"
    },
    {
      number: "16263",
      name_en: "Health Helpline",
      name_bn: "স্বাস্থ্য হেল্পলাইন",
      description_en: "Alternative Medical",
      description_bn: "বিকল্প চিকিৎসা",
      icon: "💊"
    }
  ],
  
  law_enforcement: [
    {
      number: "01713-090411",
      name_en: "RAB Emergency",
      name_bn: "র‍্যাব জরুরি",
      description_en: "Terrorism/Serious Crimes",
      description_bn: "সন্ত্রাস/গুরুতর অপরাধ",
      icon: "🚔"
    },
    {
      number: "01320-040244",
      name_en: "Traffic Police",
      name_bn: "ট্রাফিক পুলিশ",
      description_en: "Traffic Accidents",
      description_bn: "ট্রাফিক দুর্ঘটনা",
      icon: "🚓"
    },
    {
      number: "01715-520520",
      name_en: "Anti-Terrorism",
      name_bn: "সন্ত্রাসবিরোধী",
      description_en: "Terrorism Threats",
      description_bn: "সন্ত্রাসী হুমকি",
      icon: "🛡️"
    }
  ],
  
  social_protection: [
    {
      number: "109",
      name_en: "Women & Children",
      name_bn: "নারী ও শিশু",
      description_en: "Violence/Harassment",
      description_bn: "সহিংসতা/হয়রানি",
      icon: "👩‍👧"
    },
    {
      number: "1098",
      name_en: "Child Helpline",
      name_bn: "শিশু হেল্পলাইন",
      description_en: "Child Abuse/Missing",
      description_bn: "শিশু নির্যাতন/নিখোঁজ",
      icon: "🧒"
    },
    {
      number: "16430",
      name_en: "Legal Aid",
      name_bn: "আইনি সহায়তা",
      description_en: "Free Legal Help",
      description_bn: "বিনামূল্যে আইনি সহায়তা",
      icon: "⚖️"
    }
  ],
  
  health_medical: [
    {
      number: "16263",
      name_en: "COVID-19 Hotline",
      name_bn: "কোভিড-১৯ হটলাইন",
      description_en: "Testing/Vaccination",
      description_bn: "পরীক্ষা/টিকাদান",
      icon: "🦠"
    },
    {
      number: "16263",
      name_en: "Health Ministry",
      name_bn: "স্বাস্থ্য মন্ত্রণালয়",
      description_en: "General Health Info",
      description_bn: "সাধারণ স্বাস্থ্য তথ্য",
      icon: "🏥"
    },
    {
      number: "09611-677777",
      name_en: "Mental Health",
      name_bn: "মানসিক স্বাস্থ্য",
      description_en: "Crisis Support",
      description_bn: "সংকট সহায়তা",
      icon: "🧠"
    }
  ],
  
  transport_utilities: [
    {
      number: "16263",
      name_en: "BRTA Help Desk",
      name_bn: "বিআরটিএ হেল্প ডেস্ক",
      description_en: "License/Registration",
      description_bn: "লাইসেন্স/নিবন্ধন",
      icon: "🚗"
    },
    {
      number: "16544",
      name_en: "Dhaka Power",
      name_bn: "ঢাকা পাওয়ার",
      description_en: "Electricity Emergency",
      description_bn: "বিদ্যুৎ জরুরি",
      icon: "⚡"
    },
    {
      number: "16462",
      name_en: "Titas Gas",
      name_bn: "তিতাস গ্যাস",
      description_en: "Gas Leaks/Supply",
      description_bn: "গ্যাস লিক/সরবরাহ",
      icon: "🔥"
    },
    {
      number: "16162",
      name_en: "WASA",
      name_bn: "ওয়াসা",
      description_en: "Water Supply",
      description_bn: "পানি সরবরাহ",
      icon: "💧"
    }
  ],
  
  disaster_crisis: [
    {
      number: "1090",
      name_en: "Disaster Management",
      name_bn: "দুর্যোগ ব্যবস্থাপনা",
      description_en: "Natural Disasters",
      description_bn: "প্রাকৃতিক দুর্যোগ",
      icon: "🌪️"
    },
    {
      number: "1090",
      name_en: "Cyclone Warning",
      name_bn: "ঘূর্ণিঝড় সতর্কতা",
      description_en: "Storm Alerts",
      description_bn: "ঝড় সতর্কবার্তা",
      icon: "🌀"
    },
    {
      number: "1090",
      name_en: "Flood Warning",
      name_bn: "বন্যা সতর্কতা",
      description_en: "Flood Safety",
      description_bn: "বন্যা নিরাপত্তা",
      icon: "🌊"
    }
  ],
  
  government_services: [
    {
      number: "106",
      name_en: "Anti-Corruption",
      name_bn: "দুর্নীতিবিরোধী",
      description_en: "Corruption Reports",
      description_bn: "দুর্নীতির অভিযোগ",
      icon: "🚫"
    },
    {
      number: "333",
      name_en: "National Helpline",
      name_bn: "জাতীয় হেল্পলাইন",
      description_en: "Government Info",
      description_bn: "সরকারি তথ্য",
      icon: "🏛️"
    },
    {
      number: "16157",
      name_en: "Public Service",
      name_bn: "সরকারি চাকরি",
      description_en: "Job Exam Info",
      description_bn: "চাকরির পরীক্ষার তথ্য",
      icon: "📋"
    }
  ]
};

// Flattened version for backward compatibility
export const EMERGENCY_CONTACTS_FLAT = [
  ...EMERGENCY_CONTACTS.urgent_emergency,
  ...EMERGENCY_CONTACTS.law_enforcement,
  ...EMERGENCY_CONTACTS.social_protection,
  ...EMERGENCY_CONTACTS.health_medical,
  ...EMERGENCY_CONTACTS.transport_utilities,
  ...EMERGENCY_CONTACTS.disaster_crisis,
  ...EMERGENCY_CONTACTS.government_services
] as const;

// Safety Tips
export const SAFETY_TIPS = [
  {
    id: 'helmet',
    title_en: 'Always Wear Helmet',
    title_bn: 'সর্বদা হেলমেট পরুন',
    description_en: 'Helmet reduces head injury risk by 70% in motorcycle accidents',
    description_bn: 'হেলমেট মোটরসাইকেল দুর্ঘটনায় মাথার আঘাতের ঝুঁকি ৭০% কমায়',
    icon: '🪖',
    category: 'protective_gear'
  },
  {
    id: 'traffic_signals',
    title_en: 'Follow Traffic Signals',
    title_bn: 'ট্রাফিক সিগন্যাল মেনে চলুন',
    description_en: 'Traffic signals prevent 40% of intersection accidents',
    description_bn: 'ট্রাফিক সিগন্যাল মোড়ের দুর্ঘটনার ৪০% প্রতিরোধ করে',
    icon: '🚦',
    category: 'road_rules'
  },
  {
    id: 'phone_driving',
    title_en: 'No Phone While Driving',
    title_bn: 'গাড়ি চালানোর সময় ফোন নয়',
    description_en: 'Using phone increases accident risk by 400%',
    description_bn: 'ফোন ব্যবহার দুর্ঘটনার ঝুঁকি ৪০০% বৃদ্ধি করে',
    icon: '📵',
    category: 'distraction'
  },
  {
    id: 'safe_distance',
    title_en: 'Maintain Safe Distance',
    title_bn: 'নিরাপদ দূরত্ব বজায় রাখুন',
    description_en: 'Keep 3-second distance from the vehicle ahead',
    description_bn: 'সামনের গাড়ি থেকে ৩ সেকেন্ডের দূরত্ব রাখুন',
    icon: '↔️',
    category: 'defensive_driving'
  },
  {
    id: 'speed_limit',
    title_en: 'Respect Speed Limits',
    title_bn: 'গতিসীমা মেনে চলুন',
    description_en: 'Overspeeding causes 30% of all road accidents',
    description_bn: 'অতিরিক্ত গতি সব সড়ক দুর্ঘটনার ৩০% কারণ',
    icon: '🚗',
    category: 'speed'
  },
  {
    id: 'seatbelt',
    title_en: 'Use Seatbelt Always',
    title_bn: 'সর্বদা সিটবেল্ট ব্যবহার করুন',
    description_en: 'Seatbelts reduce death risk by 45% in car accidents',
    description_bn: 'সিটবেল্ট গাড়ি দুর্ঘটনায় মৃত্যুর ঝুঁকি ৪৫% কমায়',
    icon: '🔒',
    category: 'protective_gear'
  }
] as const;

// Document Types for KYC
export const DOCUMENT_TYPES = [
  {
    id: 'nid',
    name_en: 'National ID Card',
    name_bn: 'জাতীয় পরিচয়পত্র',
    icon: '🆔',
    required_sides: ['front', 'back']
  },
  {
    id: 'driving_license',
    name_en: 'Driving License',
    name_bn: 'ড্রাইভিং লাইসেন্স',
    icon: '🚗',
    required_sides: ['front', 'back']
  },
  {
    id: 'passport',
    name_en: 'Passport',
    name_bn: 'পাসপোর্ট',
    icon: '📘',
    required_sides: ['info_page']
  }
] as const;

// Selfie Types for Biometric Verification
export const SELFIE_TYPES = [
  {
    id: 'front',
    name_en: 'Front Face',
    name_bn: 'সামনের মুখ',
    instruction_en: 'Look directly at the camera',
    instruction_bn: 'সরাসরি ক্যামেরার দিকে তাকান',
    icon: '👤'
  },
  {
    id: 'left',
    name_en: 'Left Side Profile',
    name_bn: 'বাম পাশের প্রোফাইল',
    instruction_en: 'Turn your head to the left',
    instruction_bn: 'আপনার মাথা বাম দিকে ঘুরান',
    icon: '👈'
  },
  {
    id: 'right',
    name_en: 'Right Side Profile',
    name_bn: 'ডান পাশের প্রোফাইল',
    instruction_en: 'Turn your head to the right',
    instruction_bn: 'আপনার মাথা ডান দিকে ঘুরান',
    icon: '👉'
  }
] as const;

// Case Status Colors
export const STATUS_COLORS = {
  pending: 'text-yellow-700 bg-yellow-100 border-yellow-200',
  under_review: 'text-blue-700 bg-blue-100 border-blue-200',
  approved: 'text-green-700 bg-green-100 border-green-200',
  rejected: 'text-red-700 bg-red-100 border-red-200',
  completed: 'text-purple-700 bg-purple-100 border-purple-200'
} as const;

// Validation Patterns
export const VALIDATION_PATTERNS = {
  BANGLADESH_PHONE: /^(?:\+88|88)?(01[3-9]\d{8})$/,
  NID_NUMBER: /^\d{10}$|^\d{13}$|^\d{17}$/,
  LICENSE_PLATE: /^[A-Za-z\u0980-\u09FF\s-]+\d+$/,
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
} as const;

// App Configuration
export const APP_CONFIG = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  MAX_FILES_PER_REPORT: 5,
  SUPPORTED_FILE_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'],
  OTP_TIMEOUT: 2 * 60 * 1000, // 2 minutes
  COMMISSION_RATE: 0.20,
  AUTO_CASE_NUMBER_PREFIX: 'TE'
} as const;

// Generate unique case number
export const generateCaseNumber = (): string => {
  const now = new Date();
  const date = now.getFullYear().toString() + 
               (now.getMonth() + 1).toString().padStart(2, '0') + 
               now.getDate().toString().padStart(2, '0');
  const time = now.getHours().toString().padStart(2, '0') + 
               now.getMinutes().toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  
  return `${APP_CONFIG.AUTO_CASE_NUMBER_PREFIX}-${date}-${time}-${random}`;
};

// Helper functions
export const formatCurrency = (amount: number, currency = '৳'): string => {
  return `${currency}${amount.toLocaleString('en-IN')}`;
};

export const calculateReward = (fineAmount: number, rewardRate = COMMISSION_RATE): number => {
  return Math.floor(fineAmount * rewardRate);
};

export const validateBangladeshPhone = (phone: string): boolean => {
  return VALIDATION_PATTERNS.BANGLADESH_PHONE.test(phone);
};

export const formatPhoneNumber = (phone: string): string => {
  // Remove country code if present and format
  const cleaned = phone.replace(/^(\+88|88)/, '');
  if (cleaned.length === 11 && cleaned.startsWith('01')) {
    return `+88${cleaned}`;
  }
  return phone;
};

// Departments for Officers
export const OFFICER_DEPARTMENTS = [
  {
    id: 'dmp',
    name_en: 'Dhaka Metropolitan Police (DMP)',
    name_bn: 'ঢাকা মহানগর পুলিশ (ডিএমপি)',
    category: 'police'
  },
  {
    id: 'brta',
    name_en: 'Bangladesh Road Transport Authority (BRTA)',
    name_bn: 'বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষ (বিআরটিএ)',
    category: 'transport'
  },
  {
    id: 'traffic_police',
    name_en: 'Traffic Police',
    name_bn: 'ট্রাফিক পুলিশ',
    category: 'traffic'
  },
  {
    id: 'highway_police',
    name_en: 'Highway Police',
    name_bn: 'হাইওয়ে পুলিশ',
    category: 'highway'
  }
] as const;

export const API_ENDPOINTS = {
  USERS: '/api/users',
  CASES: '/api/cases',
  VIOLATIONS: '/api/violations',
  NOTIFICATIONS: '/api/notifications',
  AUTH: '/api/auth'
};

export const VIOLATION_STATUS = {
  PENDING: 'pending',
  UNDER_REVIEW: 'under_review',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  COMPLETED: 'completed'
} as const;

export const USER_TYPES = {
  CITIZEN: 'citizen',
  OFFICER: 'officer'
} as const;

export const KYC_STATUS = {
  PENDING: 'pending',
  VERIFIED: 'verified',
  REJECTED: 'rejected'
} as const;

export const LANGUAGES = {
  EN: 'en',
  BN: 'bn'
} as const;

export const NOTIFICATION_TYPES = {
  CASE_UPDATE: 'case_update',
  PAYMENT: 'payment',
  KYC: 'kyc',
  GENERAL: 'general'
} as const;
