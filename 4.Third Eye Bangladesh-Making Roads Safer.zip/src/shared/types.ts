import z from "zod";

// User Profile Schema
export const UserProfileSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  user_type: z.enum(['citizen', 'officer']),
  full_name: z.string(),
  phone_number: z.string().optional(),
  nid_number: z.string().optional(),
  driving_license: z.string().optional(),
  department: z.string().optional(),
  badge_id: z.string().optional(),
  kyc_status: z.enum(['pending', 'verified', 'rejected']),
  kyc_documents: z.string().optional(),
  wallet_provider: z.string().optional(),
  wallet_number: z.string().optional(),
  wallet_verified: z.boolean(),
  total_reports: z.number(),
  approved_reports: z.number(),
  total_rewards: z.number(),
  is_active: z.boolean(),
  preferred_language: z.enum(['en', 'bn']),
  created_at: z.string(),
  updated_at: z.string(),
});

export type UserProfile = z.infer<typeof UserProfileSchema>;

// Violation Type Schema
export const ViolationTypeSchema = z.object({
  id: z.number(),
  name_en: z.string(),
  name_bn: z.string(),
  description_en: z.string().optional(),
  description_bn: z.string().optional(),
  fine_amount: z.number(),
  reward_percentage: z.number(),
  is_active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type ViolationType = z.infer<typeof ViolationTypeSchema>;

// Case Schema
export const CaseSchema = z.object({
  id: z.number(),
  case_number: z.string(),
  reporter_id: z.string(),
  violation_type_id: z.number(),
  vehicle_number: z.string(),
  location_description: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  description: z.string().optional(),
  evidence_urls: z.string().optional(),
  status: z.enum(['pending', 'under_review', 'approved', 'rejected', 'completed']),
  fine_amount: z.number(),
  reward_amount: z.number(),
  reviewing_officer_id: z.string().optional(),
  officer_notes: z.string().optional(),
  rejection_reason: z.string().optional(),
  reported_at: z.string(),
  reviewed_at: z.string().optional(),
  completed_at: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
  violation_name_en: z.string().optional(),
  violation_name_bn: z.string().optional(),
});

export type Case = z.infer<typeof CaseSchema>;

// Case Report Schema
export const ReportCaseSchema = z.object({
  violation_type_id: z.number(),
  vehicle_number: z.string().min(1, "Vehicle number is required"),
  location_description: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  description: z.string().optional(),
  evidence_urls: z.array(z.string()).optional(),
});

export type ReportCase = z.infer<typeof ReportCaseSchema>;

// Payment Schema
export const PaymentSchema = z.object({
  id: z.number(),
  case_id: z.number(),
  user_id: z.string(),
  payment_gateway: z.string(),
  transaction_id: z.string().optional(),
  amount: z.number(),
  status: z.enum(['pending', 'processing', 'completed', 'failed']),
  payment_type: z.enum(['commission', 'fine']),
  gateway_response: z.string().optional(),
  initiated_at: z.string(),
  completed_at: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Payment = z.infer<typeof PaymentSchema>;

// API Response Types
export const ApiSuccessResponseSchema = z.object({
  success: z.boolean(),
  data: z.any().optional(),
  message: z.string().optional(),
});

export const ApiErrorResponseSchema = z.object({
  error: z.string(),
  code: z.string().optional(),
});

export type ApiSuccessResponse = z.infer<typeof ApiSuccessResponseSchema>;
export type ApiErrorResponse = z.infer<typeof ApiErrorResponseSchema>;

// Language Support
export interface LanguageText {
  en: string;
  bn: string;
}

// Constants
export const VIOLATION_TYPES = {
  SPEEDING: { en: 'Speeding', bn: 'গতি আইন লঙ্ঘন' },
  RED_LIGHT_JUMPING: { en: 'Red Light Jumping', bn: 'রেড লাইট জাম্পিং' },
  ILLEGAL_PARKING: { en: 'Illegal Parking', bn: 'অবৈধ পার্কিং' },
  WRONG_SIDE_DRIVING: { en: 'Wrong Side Driving', bn: 'ভুল দিক দিয়ে গাড়ি চালানো' },
  NO_HELMET: { en: 'No Helmet', bn: 'হেলমেট না পরা' },
  NO_SEATBELT: { en: 'No Seatbelt', bn: 'সিটবেল্ট না পরা' },
  HYDRAULIC_HORN: { en: 'Hydraulic Horn', bn: 'হাইড্রোলিক হর্ন' },
  OVERLOADING: { en: 'Overloading', bn: 'ওভারলোডিং' },
  DRIVING_WITHOUT_LICENSE: { en: 'Driving without License', bn: 'লাইসেন্স ছাড়া গাড়ি চালানো' },
  USING_MOBILE_PHONE: { en: 'Using Mobile Phone', bn: 'মোবাইল ফোন ব্যবহার' },
} as const;

export const PAYMENT_GATEWAYS = [
  'bKash',
  'Nagad', 
  'Rocket',
  'Upay',
  'mCash',
  'CellFin',
  'SureCash',
  'Trust Money'
] as const;

export const CASE_STATUSES = {
  PENDING: { en: 'Pending', bn: 'বিচারাধীন' },
  UNDER_REVIEW: { en: 'Under Review', bn: 'পর্যালোচনাধীন' },
  APPROVED: { en: 'Approved', bn: 'অনুমোদিত' },
  REJECTED: { en: 'Rejected', bn: 'প্রত্যাখ্যাত' },
  COMPLETED: { en: 'Completed', bn: 'সম্পন্ন' },
} as const;
