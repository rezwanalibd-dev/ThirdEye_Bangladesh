import { useState } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { Search, AlertTriangle, Eye } from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

const VEHICLE_TYPES = [
  { id: 'all', name: 'All Vehicles', name_bn: 'সব যানবাহন', icon: '🚗' },
  { id: 'motorbike', name: 'Motorbike', name_bn: 'মোটরবাইক', icon: '🏍️' },
  { id: 'car', name: 'Car', name_bn: 'গাড়ি', icon: '🚗' },
  { id: 'bus', name: 'Bus', name_bn: 'বাস', icon: '🚌' },
  { id: 'truck', name: 'Truck', name_bn: 'ট্রাক', icon: '🚛' },
  { id: 'erickshaw', name: 'E-rickshaw', name_bn: 'ই-রিকশা', icon: '🔋' },
  { id: 'cng', name: 'CNG', name_bn: 'সিএনজি', icon: '🛺' }
];

const VIOLATIONS = [
  // Motorbike violations
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'No Helmet', violationBn: 'হেলমেট নেই', fine: '৳1,000-10,000', points: '1-2', jailTerm: '3 months', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Red Light Jumping', violationBn: 'রেড লাইট জাম্পিং', fine: '৳5,000-10,000', points: '1', jailTerm: '1 month', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Wrong Side Driving', violationBn: 'ভুল দিকে গাড়ি চালানো', fine: '৳3,000', points: '1', jailTerm: '-', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Speeding', violationBn: 'গতি আইন লঙ্ঘন', fine: '৳5,000-50,000', points: '1', jailTerm: '-', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Using Mobile Phone', violationBn: 'মোবাইল ফোন ব্যবহার', fine: '৳1,000-5,000', points: '1', jailTerm: '-', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Driving on a Footpath', violationBn: 'ফুটপাতে গাড়ি চালানো', fine: '৳2,000-5,000', points: '1', jailTerm: '-', vehicleId: 'motorbike' },
  { vehicle: '🏍️', vehicleType: 'Motorbike', violation: 'Overloading (3+)', violationBn: 'ওভারলোডিং (৩+)', fine: '৳500-5,000', points: '1', jailTerm: '-', vehicleId: 'motorbike' },

  // Car violations
  { vehicle: '🚗', vehicleType: 'Car', violation: 'No Seatbelt', violationBn: 'সিটবেল্ট নেই', fine: '৳5,000-10,000', points: '1', jailTerm: '-', vehicleId: 'car' },
  { vehicle: '🚗', vehicleType: 'Car', violation: 'Red Light Jumping', violationBn: 'রেড লাইট জাম্পিং', fine: '৳5,000-10,000', points: '1', jailTerm: '1 month', vehicleId: 'car' },
  { vehicle: '🚗', vehicleType: 'Car', violation: 'Illegal Parking', violationBn: 'অবৈধ পার্কিং', fine: '৳5,000', points: '1', jailTerm: '1 month', vehicleId: 'car' },
  { vehicle: '🚗', vehicleType: 'Car', violation: 'Speeding', violationBn: 'গতি আইন লঙ্ঘন', fine: '৳5,000-100,000', points: '1', jailTerm: '-', vehicleId: 'car' },
  { vehicle: '🚗', vehicleType: 'Car', violation: 'Using Mobile Phone', violationBn: 'মোবাইল ফোন ব্যবহার', fine: '৳5,000', points: '1', jailTerm: '1 month', vehicleId: 'car' },
  { vehicle: '🚗', vehicleType: 'Car', violation: 'No License', violationBn: 'লাইসেন্স নেই', fine: '৳25,000', points: 'N/A', jailTerm: '6 months', vehicleId: 'car' },

  // CNG violations
  { vehicle: '🛺', vehicleType: 'CNG', violation: 'Overcharging/No Meter', violationBn: 'অতিরিক্ত ভাড়া/মিটার নেই', fine: '৳1,000-50,000', points: '-', jailTerm: '-', vehicleId: 'cng' },
  { vehicle: '🛺', vehicleType: 'CNG', violation: 'Overloading', violationBn: 'ওভারলোডিং', fine: '৳500-5,000', points: '-', jailTerm: '-', vehicleId: 'cng' },
  { vehicle: '🛺', vehicleType: 'CNG', violation: 'Driving on a Footpath', violationBn: 'ফুটপাতে গাড়ি চালানো', fine: '৳2,000-5,000', points: '-', jailTerm: '-', vehicleId: 'cng' },
  { vehicle: '🛺', vehicleType: 'CNG', violation: 'Expired Permit (>9 years)', violationBn: 'মেয়াদোত্তীর্ণ পারমিট (>৯ বছর)', fine: '৳10,000 + Scrapping', points: '-', jailTerm: '-', vehicleId: 'cng' },

  // E-rickshaw violations
  { vehicle: '🔋', vehicleType: 'E-rickshaw', violation: 'Overloading', violationBn: 'ওভারলোডিং', fine: '৳500-2,000', points: '-', jailTerm: '-', vehicleId: 'erickshaw' },
  { vehicle: '🔋', vehicleType: 'E-rickshaw', violation: 'Speeding', violationBn: 'গতি আইন লঙ্ঘন', fine: '৳5,000-20,000', points: '-', jailTerm: '-', vehicleId: 'erickshaw' },
  { vehicle: '🔋', vehicleType: 'E-rickshaw', violation: 'Driving on a Footpath', violationBn: 'ফুটপাতে গাড়ি চালানো', fine: '৳1,000-3,000', points: '-', jailTerm: '-', vehicleId: 'erickshaw' },
  { vehicle: '🔋', vehicleType: 'E-rickshaw', violation: 'No Registration', violationBn: 'নিবন্ধন নেই', fine: '৳2,000 + Seizure', points: '-', jailTerm: '-', vehicleId: 'erickshaw' },

  // Bus violations
  { vehicle: '🚌', vehicleType: 'Bus', violation: 'Overloading', violationBn: 'ওভারলোডিং', fine: '৳10,000-25,000 + Seizure', points: '-', jailTerm: '-', vehicleId: 'bus' },
  { vehicle: '🚌', vehicleType: 'Bus', violation: 'No Conductor', violationBn: 'কন্ডাক্টর নেই', fine: '৳5,000', points: '-', jailTerm: '-', vehicleId: 'bus' },
  { vehicle: '🚌', vehicleType: 'Bus', violation: 'Speeding', violationBn: 'গতি আইন লঙ্ঘন', fine: '৳10,000-200,000', points: '-', jailTerm: '-', vehicleId: 'bus' },
  { vehicle: '🚌', vehicleType: 'Bus', violation: 'Expired Fitness', violationBn: 'মেয়াদোত্তীর্ণ ফিটনেস', fine: '৳25,000', points: '-', jailTerm: '-', vehicleId: 'bus' },

  // Truck violations
  { vehicle: '🚛', vehicleType: 'Truck', violation: 'Overloading (Weight)', violationBn: 'ওভারলোডিং (ওজন)', fine: '৳2,000-5,000/ton', points: '-', jailTerm: '-', vehicleId: 'truck' },
  { vehicle: '🚛', vehicleType: 'Truck', violation: 'Unsafe Load', violationBn: 'অনিরাপদ লোড', fine: '৳10,000 + Seizure', points: '-', jailTerm: '-', vehicleId: 'truck' },
  { vehicle: '🚛', vehicleType: 'Truck', violation: 'Speeding', violationBn: 'গতি আইন লঙ্ঘন', fine: '৳10,000-100,000', points: '-', jailTerm: '-', vehicleId: 'truck' },
  { vehicle: '🚛', vehicleType: 'Truck', violation: 'No Permit', violationBn: 'পারমিট নেই', fine: '৳25,000', points: '-', jailTerm: '-', vehicleId: 'truck' }
];

const POINT_SYSTEM_STATS = [
  { number: '12', label: 'Maximum Points', labelBn: 'সর্বোচ্চ পয়েন্ট', color: 'text-red-600' },
  { number: '1-2', label: 'Minor Violations', labelBn: 'ছোট আইন লঙ্ঘন', color: 'text-blue-600' },
  { number: '6', label: 'Months Suspension', labelBn: 'মাসের সাসপেনশন', color: 'text-purple-600' },
  { number: '0.05%', label: 'BAC Limit', labelBn: 'বিএসি সীমা', color: 'text-orange-600' }
];

export default function TrafficFines() {
  const { t, language } = useLanguage();
  const [selectedVehicle, setSelectedVehicle] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredViolations = VIOLATIONS.filter(violation => {
    const matchesVehicle = selectedVehicle === 'all' || violation.vehicleId === selectedVehicle;
    const matchesSearch = searchTerm === '' || 
      violation.violation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      violation.violationBn.includes(searchTerm);
    return matchesVehicle && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-red-600 to-orange-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center space-x-3 sm:space-x-4">
            <BackButton 
              to="/"
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            />
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-3 rounded-xl shadow-lg">
                <Eye className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold">
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-red-100 text-xs sm:text-sm">
                  {t('Traffic Rules & Fines', 'ট্রাফিক নিয়ম এবং জরিমানা')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* 12-Point License System */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {t('12-Point License System', '১২-পয়েন্ট লাইসেন্স সিস্টেম')}
          </h2>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {POINT_SYSTEM_STATS.map((stat, index) => (
              <div key={index} className="text-center">
                <div className={`text-4xl lg:text-5xl font-bold ${stat.color} mb-2`}>
                  {stat.number}
                </div>
                <p className="text-gray-600 font-medium">
                  {language === 'en' ? stat.label : stat.labelBn}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder={t('Search violations...', 'আইন লঙ্ঘন খুঁজুন...')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            {/* Vehicle Type Tabs */}
            <div className="flex flex-wrap gap-2">
              {VEHICLE_TYPES.map((type) => (
                <button
                  key={type.id}
                  onClick={() => setSelectedVehicle(type.id)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedVehicle === type.id
                      ? 'bg-red-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <span className="mr-2">{type.icon}</span>
                  {language === 'en' ? type.name : type.name_bn}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Violations Table */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden mb-8">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-900 text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-bold text-sm uppercase tracking-wide">
                    {t('Vehicle Type', 'যানবাহনের ধরন')}
                  </th>
                  <th className="px-6 py-4 text-left font-bold text-sm uppercase tracking-wide">
                    {t('Violation', 'আইন লঙ্ঘন')}
                  </th>
                  <th className="px-6 py-4 text-left font-bold text-sm uppercase tracking-wide">
                    {t('Fine (BDT)', 'জরিমানা (টাকা)')}
                  </th>
                  <th className="px-6 py-4 text-left font-bold text-sm uppercase tracking-wide">
                    {t('Points', 'পয়েন্ট')}
                  </th>
                  <th className="px-6 py-4 text-left font-bold text-sm uppercase tracking-wide">
                    {t('Jail Term', 'কারাদণ্ড')}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredViolations.map((violation, index) => (
                  <tr key={index} className={`border-b border-gray-200 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} hover:bg-red-50 transition-colors`}>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{violation.vehicle}</span>
                        <span className="font-medium text-gray-900">
                          {violation.vehicleType}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold text-gray-900">
                      {language === 'en' ? violation.violation : violation.violationBn}
                    </td>
                    <td className="px-6 py-4 text-red-600 font-bold">
                      {violation.fine}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                        violation.points === 'N/A' || violation.points === '-' ? 'bg-gray-200 text-gray-700' :
                        violation.points === '2' ? 'bg-red-200 text-red-800' :
                        'bg-yellow-200 text-yellow-800'
                      }`}>
                        {violation.points}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-700">
                      {violation.jailTerm === '-' ? '-' : violation.jailTerm}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Important Notice */}
        <div className="bg-yellow-50 rounded-2xl border-2 border-yellow-200 p-6">
          <div className="flex items-start space-x-4">
            <AlertTriangle className="w-6 h-6 text-yellow-600 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-bold text-yellow-800 mb-2">
                {t('Important Notice', 'গুরুত্বপূর্ণ নোটিশ')}
              </h3>
              <p className="text-yellow-700 mb-4">
                {t(
                  'This guide is for informational purposes only. Fines and rules are subject to change. Always refer to the latest official BRTA publications and the Road Transport Act for the most current legal information.',
                  'এই গাইড শুধুমাত্র তথ্যমূলক উদ্দেশ্যে। জরিমানা এবং নিয়ম পরিবর্তন সাপেক্ষে। সর্বশেষ আইনি তথ্যের জন্য সর্বদা সর্বশেষ অফিসিয়াল বিআরটিএ প্রকাশনা এবং সড়ক পরিবহন আইন দেখুন।'
                )}
              </p>
              <p className="text-sm text-yellow-600">
                {t('Last Updated: December 2024 | Source: Road Transport Act 2018, BRTA Guidelines 2025', 'সর্বশেষ আপডেট: ডিসেম্বর ২০২৪ | উৎস: সড়ক পরিবহন আইন ২০১৮, বিআরটিএ নির্দেশিকা ২০২৫')}
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
