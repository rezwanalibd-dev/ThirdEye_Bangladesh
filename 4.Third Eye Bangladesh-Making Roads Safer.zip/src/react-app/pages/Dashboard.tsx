import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate } from 'react-router';
import { 
  Camera, 
  History, 
  Award, 
  TrendingUp, 
  Eye, 
  CheckCircle,
  Clock,
  AlertCircle,
  User,
  LogOut,
  Menu,
  X,
  Shield,
  Users,
  Settings
} from 'lucide-react';
import SafetyTipsCard from '@/react-app/components/SafetyTipsCard';
import EmergencyContactCard from '@/react-app/components/EmergencyContactCard';
import { formatCurrency } from '@/shared/constants';

interface DashboardStats {
  profile?: {
    total_reports: number;
    total_rewards: number;
  };
  approved_cases: number;
}

interface CaseItem {
  case_number: string;
  status: string;
  violation_name_en: string;
  violation_name_bn: string;
  vehicle_number: string;
}

export default function Dashboard() {
  const { user, logout, isDemoMode } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentCases, setRecentCases] = useState<CaseItem[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const fetchDashboardData = useCallback(async () => {
    try {
      const [statsResponse, casesResponse] = await Promise.all([
        fetch('/api/dashboard/stats', { credentials: 'include' }),
        fetch('/api/cases', { credentials: 'include' })
      ]);
      
      const statsData = await statsResponse.json();
      const casesData = await casesResponse.json();
      
      setStats(statsData);
      setRecentCases(casesData.slice(0, 5));
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const quickStats = [
    {
      title: t('Total Citizens', 'মোট নাগরিক'),
      value: '12,450+',
      change: '+15%',
      icon: Users,
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: t('Cases Resolved', 'সমাধানকৃত কেস'),
      value: '8,230',
      change: '+22%',
      icon: CheckCircle,
      color: 'from-green-500 to-green-600'
    },
    {
      title: t('Active Officers', 'সক্রিয় অফিসার'),
      value: '156',
      change: '+8%',
      icon: Shield,
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: t('Revenue Generated', 'রাজস্ব আয়'),
      value: '৳2.8M',
      change: '+31%',
      icon: Award,
      color: 'from-yellow-500 to-orange-500'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-700 bg-green-100 border-green-200';
      case 'pending': return 'text-yellow-700 bg-yellow-100 border-yellow-200';
      case 'under_review': return 'text-blue-700 bg-blue-100 border-blue-200';
      case 'rejected': return 'text-red-700 bg-red-100 border-red-200';
      case 'completed': return 'text-purple-700 bg-purple-100 border-purple-200';
      default: return 'text-gray-700 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return CheckCircle;
      case 'completed': return CheckCircle;
      case 'pending': return Clock;
      case 'under_review': return Clock;
      case 'rejected': return AlertCircle;
      default: return Clock;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <button
                onClick={() => navigate('/')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title={t('Go to Home', 'হোমে যান')}
              >
                <Eye className="w-5 h-5 sm:w-7 sm:h-7 text-indigo-600" />
              </button>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900">
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-xs text-gray-600">
                  {t('Dashboard', 'ড্যাশবোর্ড')}
                </p>
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-4">
              <button
                onClick={toggleLanguage}
                className="text-gray-600 hover:text-gray-800 px-3 py-2 rounded-lg hover:bg-gray-100 transition-all text-sm font-medium"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
              
              <button
                onClick={() => navigate('/settings')}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-all"
                title={t('Settings', 'সেটিংস')}
              >
                <Settings className="w-5 h-5 text-gray-600" />
                <span className="text-sm font-medium text-gray-700">{t('Settings', 'সেটিংস')}</span>
              </button>
              
              <button
                onClick={() => navigate('/profile')}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-all"
              >
                <User className="w-8 h-8 text-gray-600" />
                <span className="text-sm font-medium text-gray-700">
                  {user?.full_name || 'User'}
                </span>
              </button>

              <button
                onClick={logout}
                className="flex items-center space-x-2 text-red-600 hover:text-red-800 px-3 py-2 rounded-lg hover:bg-red-50 transition-all"
              >
                <LogOut className="w-5 h-5" />
                <span className="text-sm font-medium">{t('Logout', 'লগআউট')}</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pt-4 border-t border-gray-200 space-y-2">
              <button
                onClick={toggleLanguage}
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 text-sm font-medium"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
              <button
                onClick={() => navigate('/settings')}
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 text-sm font-medium"
              >
                {t('Settings', 'সেটিংস')}
              </button>
              <button
                onClick={() => navigate('/profile')}
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 text-sm font-medium"
              >
                {t('Profile', 'প্রোফাইল')}
              </button>
              <button
                onClick={logout}
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-red-50 text-red-600 text-sm font-medium"
              >
                {t('Logout', 'লগআউট')}
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 rounded-xl sm:rounded-2xl p-6 sm:p-8 text-white mb-6 sm:mb-8 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl sm:text-3xl font-bold mb-2">
                {t(`Welcome back, ${user?.full_name?.split(' ')[0] || 'User'}!`, 
                   `ফিরে আসার জন্য স্বাগতম, ${user?.full_name?.split(' ')[0] || 'ব্যবহারকারী'}!`)}
                {isDemoMode && isDemoMode() && <span className="ml-2 px-2 py-1 bg-white/20 text-white text-xs rounded-full font-medium">DEMO</span>}
              </h2>
              <p className="text-indigo-100 text-sm sm:text-base">
                {isDemoMode && isDemoMode()
                  ? t("Testing all features in development mode", "ডেভেলপমেন্ট মোডে সব ফিচার পরীক্ষা করছেন")
                  : t('Ready to make the roads safer today?', 'আজ রাস্তা আরও নিরাপদ করতে প্রস্তুত?')
                }
              </p>
            </div>
            
            <button
              onClick={() => navigate('/report')}
              className="bg-white text-indigo-600 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold hover:bg-indigo-50 transition-all transform hover:scale-105 shadow-lg flex items-center justify-center text-sm sm:text-base"
            >
              <Camera className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
              {t('Report Now', 'এখনই রিপোর্ট করুন')}
            </button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mt-6 sm:mt-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-white/20">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                <p className="text-2xl sm:text-3xl font-bold">{stats?.profile?.total_reports || 0}</p>
              </div>
              <p className="text-indigo-100 text-sm">{t('Total Reports', 'মোট রিপোর্ট')}</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-white/20">
              <div className="flex items-center justify-between mb-2">
                <CheckCircle className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                <p className="text-2xl sm:text-3xl font-bold">{stats?.approved_cases || 0}</p>
              </div>
              <p className="text-indigo-100 text-sm">{t('Approved Cases', 'অনুমোদিত কেস')}</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-white/20">
              <div className="flex items-center justify-between mb-2">
                <Award className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                <p className="text-2xl sm:text-3xl font-bold">{formatCurrency(stats?.profile?.total_rewards || 0)}</p>
              </div>
              <p className="text-indigo-100 text-sm">{t('Total Earned', 'মোট আয়')}</p>
            </div>
          </div>
        </div>

        {/* Community Impact Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          {quickStats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6 hover:shadow-lg transition-all">
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                    <IconComponent className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">
                    {stat.change}
                  </span>
                </div>
                <p className="text-xl sm:text-2xl font-bold text-gray-900 mb-1">{stat.value}</p>
                <p className="text-xs sm:text-sm text-gray-600">{stat.title}</p>
              </div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6 sm:space-y-8">
            {/* Quick Actions */}
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">
                {t('Quick Actions', 'দ্রুত কর্ম')}
              </h3>
              
              <div className="grid gap-6">
                <button
                  onClick={() => navigate('/report')}
                  className="group bg-gradient-to-br from-red-500 via-red-600 to-red-700 text-white p-6 sm:p-8 rounded-xl sm:rounded-2xl hover:from-red-600 hover:via-red-700 hover:to-red-800 transition-all transform hover:scale-[1.02] shadow-xl hover:shadow-2xl text-left relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 sm:w-32 sm:h-32 bg-white/10 rounded-full -mr-12 -mt-12 sm:-mr-16 sm:-mt-16"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4 sm:mb-6">
                      <Camera className="w-12 h-12 sm:w-16 sm:h-16 group-hover:scale-110 transition-transform" />
                      <div className="text-right">
                        <p className="text-red-200 text-xs sm:text-sm">{t('Start Earning', 'উপার্জন শুরু করুন')}</p>
                        <p className="text-xl sm:text-2xl font-bold">20% {t('Commission', 'কমিশন')}</p>
                      </div>
                    </div>
                    <h4 className="text-xl sm:text-2xl font-bold mb-2">{t('Report Traffic Violation', 'ট্রাফিক আইন লঙ্ঘন রিপোর্ট করুন')}</h4>
                    <p className="text-red-100 leading-relaxed text-sm sm:text-base">{t('Capture violations with your phone camera and earn rewards when cases are resolved', 'আপনার ফোনের কেমেরা দিয়ে আইন লঙ্ঘন ক্যাপচার করুন এবং কেস সমাধান হলে পুরস্কার পান')}</p>
                  </div>
                </button>

                <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
                  <button
                    onClick={() => navigate('/cases')}
                    className="group bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 sm:p-6 rounded-xl sm:rounded-2xl hover:from-blue-600 hover:to-blue-700 transition-all transform hover:scale-105 shadow-lg text-left"
                  >
                    <History className="w-10 h-10 sm:w-12 sm:h-12 mb-3 sm:mb-4 group-hover:scale-110 transition-transform" />
                    <h4 className="text-lg sm:text-xl font-bold mb-2">{t('My Reports', 'আমার রিপোর্ট')}</h4>
                    <p className="text-blue-100 text-xs sm:text-sm">{t('Track status & earnings', 'স্ট্যাটাস ও আয় ট্র্যাক করুন')}</p>
                  </button>

                  <button
                    onClick={() => navigate('/profile')}
                    className="group bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 sm:p-6 rounded-xl sm:rounded-2xl hover:from-purple-600 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg text-left"
                  >
                    <User className="w-10 h-10 sm:w-12 sm:h-12 mb-3 sm:mb-4 group-hover:scale-110 transition-transform" />
                    <h4 className="text-lg sm:text-xl font-bold mb-2">{t('My Profile', 'আমার প্রোফাইল')}</h4>
                    <p className="text-purple-100 text-xs sm:text-sm">{t('Settings & wallet', 'সেটিংস ও ওয়ালেট')}</p>
                  </button>
                </div>

                {/* Citizen Education Hub */}
                <div>
                  <h4 className="text-base sm:text-lg font-bold text-gray-900 mb-4">
                    {t('Citizen Education Hub', 'নাগরিক শিক্ষা কেন্দ্র')}
                  </h4>
                  <div className="grid gap-4 sm:gap-6">
                    <button
                      onClick={() => navigate('/traffic-fines')}
                      className="group bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 sm:p-6 rounded-xl sm:rounded-2xl hover:from-orange-600 hover:to-orange-700 transition-all transform hover:scale-105 shadow-lg text-left"
                    >
                      <AlertCircle className="w-10 h-10 sm:w-12 sm:h-12 mb-3 sm:mb-4 group-hover:scale-110 transition-transform" />
                      <h5 className="text-lg sm:text-xl font-bold mb-2">{t('Traffic Rules & Fines', 'ট্রাফিক নিয়ম এবং জরিমানা')}</h5>
                      <p className="text-orange-100 text-xs sm:text-sm">{t('Violations, Penalties, Point System', 'আইন লঙ্ঘন, শাস্তি, পয়েন্ট সিস্টেম')}</p>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Cases */}
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <h4 className="text-lg sm:text-xl font-bold text-gray-900">
                  {t('Recent Reports', 'সাম্প্রতিক রিপোর্ট')}
                </h4>
                <button
                  onClick={() => navigate('/cases')}
                  className="text-indigo-600 hover:text-indigo-700 font-medium text-sm"
                >
                  {t('View All', 'সব দেখুন')} →
                </button>
              </div>
              
              {recentCases.length > 0 ? (
                <div className="space-y-4">
                  {recentCases.map((case_item, index) => {
                    const StatusIcon = getStatusIcon(case_item.status);
                    return (
                      <div 
                        key={index} 
                        className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all cursor-pointer"
                        onClick={() => navigate('/cases')}
                      >
                        <div className="flex items-center space-x-3 sm:space-x-4 flex-1">
                          <div className="bg-white p-2 sm:p-3 rounded-lg shadow-sm">
                            <StatusIcon className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-gray-900 mb-1 text-sm sm:text-base truncate">{case_item.case_number}</p>
                            <p className="text-xs sm:text-sm text-gray-600 truncate">
                              {language === 'en' ? case_item.violation_name_en : case_item.violation_name_bn} • {case_item.vehicle_number}
                            </p>
                          </div>
                        </div>
                        <span className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs font-semibold border ${getStatusColor(case_item.status)} whitespace-nowrap ml-2`}>
                          {t(
                            case_item.status.charAt(0).toUpperCase() + case_item.status.slice(1).replace('_', ' '), 
                            case_item.status
                          )}
                        </span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 sm:py-12">
                  <History className="w-16 h-16 sm:w-20 sm:h-20 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4 sm:mb-6 text-sm sm:text-base">{t('No reports yet', 'এখনও কোনো রিপোর্ট নেই')}</p>
                  <button
                    onClick={() => navigate('/report')}
                    className="bg-indigo-600 text-white px-6 sm:px-8 py-2 sm:py-3 rounded-xl hover:bg-indigo-700 font-semibold transition-all text-sm sm:text-base"
                  >
                    {t('Submit your first report', 'আপনার প্রথম রিপোর্ট জমা দিন')}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6 sm:space-y-8">
            {/* Emergency Contacts */}
            <EmergencyContactCard />

            {/* Safety Tips */}
            <SafetyTipsCard />

            {/* Rewards & Earnings Info */}
            <div className="bg-gradient-to-br from-green-500 via-green-600 to-emerald-600 rounded-xl sm:rounded-2xl p-4 sm:p-6 text-white shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 w-20 h-20 sm:w-24 sm:h-24 bg-white/10 rounded-full -mr-10 -mt-10 sm:-mr-12 sm:-mt-12"></div>
              <div className="relative z-10">
                <div className="flex items-center space-x-2 sm:space-x-3 mb-4 sm:mb-6">
                  <div className="bg-white/20 p-2 sm:p-2.5 rounded-xl backdrop-blur-sm">
                    <Award className="w-5 h-5 sm:w-7 sm:h-7 text-white" />
                  </div>
                  <div>
                    <h4 className="text-lg sm:text-xl font-bold">
                      {t('Earning System', 'উপার্জন সিস্টেম')}
                    </h4>
                    <p className="text-green-100 text-xs sm:text-sm">
                      {t('How rewards work', 'পুরস্কার কিভাবে কাজ করে')}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-white/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-green-100 text-xs sm:text-sm">{t('Commission Rate', 'কমিশনের হার')}</span>
                      <span className="text-xl sm:text-2xl font-bold">20%</span>
                    </div>
                    <p className="text-xs text-green-200">
                      {t('Of fine amount when violator pays', 'আইন লঙ্ঘনকারী পরিশোধ করলে জরিমানার')}
                    </p>
                  </div>

                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-white/20">
                    <h5 className="font-semibold text-white mb-2 text-sm sm:text-base">{t('Example Earnings', 'উদাহরণ আয়')}</h5>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs sm:text-sm">
                        <span className="text-green-100">{t('Speed Fine', 'গতিসীমা জরিমানা')} ৳5,000</span>
                        <span className="font-bold text-white">= ৳1,000</span>
                      </div>
                      <div className="flex justify-between text-xs sm:text-sm">
                        <span className="text-green-100">{t('Red Light', 'রেড লাইট')} ৳500</span>
                        <span className="font-bold text-white">= ৳100</span>
                      </div>
                      <div className="flex justify-between text-xs sm:text-sm">
                        <span className="text-green-100">{t('No License', 'লাইসেন্স নেই')} ৳25,000</span>
                        <span className="font-bold text-white">= ৳5,000</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/20 rounded-xl p-3 sm:p-4">
                    <p className="text-center text-xs sm:text-sm text-green-100">
                      {t('Payments are automatic and instant once fines are collected', 'জরিমানা সংগ্রহ হলেই পেমেন্ট স্বয়ংক্রিয় এবং তাৎক্ষণিক')}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Leaderboard Preview */}
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-4 sm:mb-6">
                <div className="bg-yellow-100 p-2 sm:p-2.5 rounded-xl">
                  <TrendingUp className="w-5 h-5 sm:w-7 sm:h-7 text-yellow-600" />
                </div>
                <div>
                  <h4 className="text-lg sm:text-xl font-bold text-gray-900">
                    {t('Top Contributors', 'শীর্ষ অবদানকারী')}
                  </h4>
                  <p className="text-gray-600 text-xs sm:text-sm">
                    {t('This month\'s leaders', 'এই মাসের নেতৃত্বদানকারী')}
                  </p>
                </div>
              </div>

              <div className="space-y-3 sm:space-y-4">
                {[1, 2, 3].map((rank) => (
                  <div key={rank} className="flex items-center space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all">
                    <div className={`
                      w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-bold text-white text-xs sm:text-sm
                      ${rank === 1 ? 'bg-yellow-500' : rank === 2 ? 'bg-gray-400' : 'bg-orange-500'}
                    `}>
                      #{rank}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 text-sm sm:text-base truncate">
                        {rank === 1 ? 'Mohammad Rahman' : rank === 2 ? 'Fatema Khatun' : 'Abdul Karim'}
                      </p>
                      <p className="text-xs sm:text-sm text-gray-600">
                        {rank === 1 ? '45' : rank === 2 ? '38' : '32'} {t('reports', 'রিপোর্ট')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600 text-sm sm:text-base">
                        ৳{rank === 1 ? '8,400' : rank === 2 ? '6,200' : '4,800'}
                      </p>
                      <p className="text-xs text-gray-500">{t('earned', 'আয়')}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 sm:mt-6 text-center">
                <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
                  {t('View Full Leaderboard →', 'সম্পূর্ণ লিডারবোর্ড দেখুন →')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
