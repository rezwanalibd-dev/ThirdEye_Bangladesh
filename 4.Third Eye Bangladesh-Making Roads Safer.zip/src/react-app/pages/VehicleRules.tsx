import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { ArrowLeft, ArrowRight, Eye, X } from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

interface VehicleDetails {
  registration_en: string[];
  registration_bn: string[];
  licensing_en: string[];
  licensing_bn: string[];
  safety_en: string[];
  safety_bn: string[];
}

interface VehicleType {
  id: string;
  icon: string;
  title_en: string;
  title_bn: string;
  subtitle_en: string;
  subtitle_bn: string;
  details: VehicleDetails;
}

const VEHICLE_TYPES: VehicleType[] = [
  {
    id: 'motorbike',
    icon: '🏍️',
    title_en: 'Motorbike',
    title_bn: '🏍️মোটরবাইক',
    subtitle_en: 'Motorcycles & Scooters - Helmet mandatory, max 2 persons',
    subtitle_bn: 'মোটরসাইকেল এবং স্কুটার - হেলমেট বাধ্যতামূলক, সর্বোচ্চ ২ জন',
    details: {
      registration_en: [
        'Process: Apply at BRTA office with invoice, chassis/engine numbers',
        'Fees: BDT 2,000-5,000 (new), BDT 1,000 (transfer)',
        'Digital plate with RFID is issued',
        'Validity: Lifetime for private use'
      ],
      registration_bn: [
        'প্রক্রিয়া: চালান, চ্যাসিস/ইঞ্জিন নম্বর সহ বিআরটিএ অফিসে আবেদন করুন',
        'ফি: নতুনের জন্য ২,০০০-৫,০০০ টাকা, স্থানান্তরের জন্য ১,০০০ টাকা',
        'আরএফআইডি সহ ডিজিটাল প্লেট জারি করা হয়',
        'বৈধতা: ব্যক্তিগত ব্যবহারের জন্য আজীবন'
      ],
      licensing_en: [
        'Minimum age: 18 years',
        'Education: Class 8 minimum',
        'Written test: 20 questions, must pass 12',
        'Practical driving test required',
        'Renewal: Every 5 years (BDT 500-1,000)'
      ],
      licensing_bn: [
        'ন্যূনতম বয়স: ১৮ বছর',
        'শিক্ষা: ন্যূনতম অষ্টম শ্রেণী',
        'লিখিত পরীক্ষা: ২০টি প্রশ্ন, ১২টি সঠিক হতে হবে',
        'ব্যবহারিক ড্রাইভিং পরীক্ষা প্রয়োজন',
        'নবায়ন: প্রতি ৫ বছরে (৫০০-১,০০০ টাকা)'
      ],
      safety_en: [
        'Helmet mandatory for both rider and pillion',
        'Maximum 2 persons allowed',
        'Speed Limits: City 40 km/h, Highway 60 km/h',
        'No modifications without BRTA approval',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'চালক এবং পেছনের যাত্রী উভয়ের জন্য হেলমেট বাধ্যতামূলক',
        'সর্বোচ্চ ২ জন অনুমোদিত',
        'গতিসীমা: শহর ৪০ কিমি/ঘন্টা, হাইওয়ে ৬০ কিমি/ঘন্টা',
        'বিআরটিএ অনুমোদন ছাড়া কোনো পরিবর্তন নেই',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'car',
    icon: '🚗',
    title_en: 'Car',
    title_bn: '🚗গাড়ি',
    subtitle_en: 'Private Cars, Jeeps, Taxis - Seatbelts mandatory in front seats',
    subtitle_bn: 'ব্যক্তিগত গাড়ি, জিপ, ট্যাক্সি - সামনের আসনে সিটবেল্ট বাধ্যতামূলক',
    details: {
      registration_en: [
        'Process: BRTA application with customs documents',
        'Fees: BDT 10,000-20,000 (new)',
        'Carbon Tax: BDT 5,000-20,000 (based on engine capacity)',
        'Annual tax varies by engine CC',
        'Semi-annual fitness check required'
      ],
      registration_bn: [
        'প্রক্রিয়া: কাস্টমস নথিপত্র সহ বিআরটিএ আবেদন',
        'ফি: নতুনের জন্য ১০,০০০-২০,০০০ টাকা',
        'কার্বন ট্যাক্স: ৫,০০০-২০,০০০ টাকা (ইঞ্জিন ক্ষমতার উপর ভিত্তি করে)',
        'বার্ষিক কর ইঞ্জিন সিসি অনুযায়ী পরিবর্তিত হয়',
        'অর্ধবার্ষিক ফিটনেস পরীক্ষা প্রয়োজন'
      ],
      licensing_en: [
        'Age: 20+ years for private cars',
        'Professional license required for taxis',
        'Renewal: BDT 1,000-2,000 every 5 years',
        'Point system: 12 points maximum'
      ],
      licensing_bn: [
        'বয়স: ব্যক্তিগত গাড়ির জন্য ২০+ বছর',
        'ট্যাক্সির জন্য পেশাদার লাইসেন্স প্রয়োজন',
        'নবায়ন: প্রতি ৫ বছরে ১,০০০-২,০০০ টাকা',
        'পয়েন্ট সিস্টেম: সর্বোচ্চ ১২ পয়েন্ট'
      ],
      safety_en: [
        'Seatbelts mandatory in front seats',
        'No overcrowding beyond seating capacity',
        'Speed Limits: City 50 km/h, Highway 80 km/h',
        'Left-hand drive requires special approval',
        'Modifications prohibited without BRTA approval'
      ],
      safety_bn: [
        'সামনের আসনের জন্য সিটবেল্ট বাধ্যতামূলক',
        'আসন ক্ষমতার বাইরে ভিড় নিষিদ্ধ',
        'গতিসীমা: শহর ৫০ কিমি/ঘন্টা, হাইওয়ে ৮০ কিমি/ঘন্টা',
        'বাম-হাত ড্রাইভের জন্য বিশেষ অনুমোদন প্রয়োজন',
        'বিআরটিএ অনুমোদন ছাড়া পরিবর্তন নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'bus',
    icon: '🚌',
    title_en: 'Bus',
    title_bn: '🚌বাস',
    subtitle_en: 'Buses & Microbuses - Route permit required, conductor mandatory',
    subtitle_bn: 'বাস এবং মাইক্রোবাস - রুট পারমিট প্রয়োজন, পরিচালক বাধ্যতামূলক',
    details: {
      registration_en: [
        'Fees: BDT 25,000+ (new)',
        'Annual tax: BDT 5,000-15,000',
        'Route permit mandatory',
        'Annual fitness and route permit renewal',
        'Exempt from carbon tax'
      ],
      registration_bn: [
        'ফি: নতুনের জন্য ২৫,০০০+ টাকা',
        'বার্ষিক কর: ৫,০০০-১৫,০০০ টাকা',
        'রুট পারমিট বাধ্যতামূলক',
        'বার্ষিক ফিটনেস এবং রুট পারমিট নবায়ন',
        'কার্বন ট্যাক্স থেকে মুক্ত'
      ],
      licensing_en: [
        'Age: 21+ years',
        'Professional heavy vehicle license required',
        'Driver and conductor both mandatory',
        'Regular training and renewal required'
      ],
      licensing_bn: [
        'বয়স: ২১+ বছর',
        'পেশাদার ভারী যানবাহন লাইসেন্স প্রয়োজন',
        'চালক এবং পরিচালক উভয়ই বাধ্যতামূলক',
        'নিয়মিত প্রশিক্ষণ এবং নবায়ন প্রয়োজন'
      ],
      safety_en: [
        'Must stop only at designated bus stops',
        'Exact seating capacity must be maintained',
        'Emergency exits must be clear',
        'Speed governor mandatory',
        'Speed Limits: City 40 km/h, Highway 60 km/h'
      ],
      safety_bn: [
        'শুধুমাত্র নির্ধারিত বাস স্টপে থামতে হবে',
        'সঠিক আসন ক্ষমতা বজায় রাখতে হবে',
        'জরুরি প্রস্থান পথ পরিষ্কার থাকতে হবে',
        'স্পিড গভর্নর বাধ্যতামূলক',
        'গতিসীমা: শহর ৪০ কিমি/ঘন্টা, হাইওয়ে ৬০ কিমি/ঘন্টা'
      ]
    }
  },
  {
    id: 'truck',
    icon: '🚛',
    title_en: 'Truck',
    title_bn: '🚛ট্রাক',
    subtitle_en: 'Trucks & Lorries - Load permit required, weight restrictions',
    subtitle_bn: 'ট্রাক এবং লরি - লোড পারমিট প্রয়োজন, ওজন সীমাবদ্ধতা',
    details: {
      registration_en: [
        'Process: BRTA weight and load verification',
        'Fees: BDT 25,000-50,000 (new)',
        'Annual fitness certificate required',
        'Load permits mandatory',
        'Exempt from carbon tax'
      ],
      registration_bn: [
        'প্রক্রিয়া: বিআরটিএ ওজন এবং লোড যাচাইকরণ',
        'ফি: নতুনের জন্য ২৫,০০০-৫০,০০০ টাকা',
        'বার্ষিক ফিটনেস সার্টিফিকেট প্রয়োজন',
        'লোড পারমিট বাধ্যতামূলক',
        'কার্বন ট্যাক্স থেকে মুক্ত'
      ],
      licensing_en: [
        'Age: 21+ years',
        'Heavy vehicle license endorsement required',
        'Special training for cargo handling',
        'Regular fitness tests mandatory'
      ],
      licensing_bn: [
        'বয়স: ২১+ বছর',
        'ভারী যানবাহন লাইসেন্স অনুমোদন প্রয়োজন',
        'পণ্য পরিচালনার জন্য বিশেষ প্রশিক্ষণ',
        'নিয়মিত ফিটনেস পরীক্ষা বাধ্যতামূলক'
      ],
      safety_en: [
        'Load must be secured properly',
        'No overhang >1m without flag',
        'Reflective tapes mandatory at night',
        'Speed Limits: City 30 km/h, Highway 50 km/h',
        'Banned from city centers during peak hours'
      ],
      safety_bn: [
        'লোড সঠিকভাবে সুরক্ষিত করতে হবে',
        'পতাকা ছাড়া >১ মিটার ওভারহ্যাং নিষিদ্ধ',
        'রাতে প্রতিফলক টেপ বাধ্যতামূলক',
        'গতিসীমা: শহর ৩০ কিমি/ঘন্টা, হাইওয়ে ৫০ কিমি/ঘন্টা',
        'পিক আওয়ারে শহরের কেন্দ্র থেকে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'erickshaw',
    icon: '🔋',
    title_en: 'E-rickshaw',
    title_bn: '🔋ই-রিকশা',
    subtitle_en: 'E-Rickshaws & Easy-Bikes - Eco-friendly, local roads only',
    subtitle_bn: 'ই-রিকশা এবং ইজি-বাইক - পরিবেশ বান্ধব, শুধুমাত্র স্থানীয় রাস্তা',
    details: {
      registration_en: [
        'Process: BRTA for motorized variants',
        'Fees: BDT 2,000-5,000',
        'Annual fitness check',
        'Battery recycling mandatory',
        'Maximum age limit: 10 years'
      ],
      registration_bn: [
        'প্রক্রিয়া: মোটরচালিত ভ্যারিয়েন্টের জন্য বিআরটিএ',
        'ফি: ২,০০০-৫,০০০ টাকা',
        'বার্ষিক ফিটনেস পরীক্ষা',
        'ব্যাটারি পুনর্ব্যবহার বাধ্যতামূলক',
        'সর্বোচ্চ বয়স সীমা: ১০ বছর'
      ],
      licensing_en: [
        'Age: 18+ years',
        'Basic driving license required',
        'Eco-friendly vehicle training',
        'Battery safety certification'
      ],
      licensing_bn: [
        'বয়স: ১৮+ বছর',
        'মৌলিক ড্রাইভিং লাইসেন্স প্রয়োজন',
        'পরিবেশ বান্ধব যানবাহন প্রশিক্ষণ',
        'ব্যাটারি নিরাপত্তা সার্টিফিকেশন'
      ],
      safety_en: [
        'Speed Limit: City 25 km/h',
        'Restricted to local roads only',
        'Maximum 2-3 passengers',
        'Battery must be properly secured',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'গতিসীমা: শহর ২৫ কিমি/ঘন্টা',
        'শুধুমাত্র স্থানীয় রাস্তায় সীমাবদ্ধ',
        'সর্বোচ্চ ২-৩ জন যাত্রী',
        'ব্যাটারি সঠিকভাবে সুরক্ষিত থাকতে হবে',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  },
  {
    id: 'cng',
    icon: '🛺',
    title_en: 'CNG',
    title_bn: '🛺সিএনজি',
    subtitle_en: 'CNG Auto-Rickshaws - Meter mandatory, max 3 passengers',
    subtitle_bn: 'সিএনজি অটো-রিকশা - মিটার বাধ্যতামূলক, সর্বোচ্চ ৩ জন যাত্রী',
    details: {
      registration_en: [
        'Process: BRTA application with meter calibration',
        'Fees: BDT 5,000-10,000 (new)',
        'Government-approved meter mandatory',
        'Annual fitness required',
        'Phased out after 9-15 years'
      ],
      registration_bn: [
        'প্রক্রিয়া: মিটার ক্যালিব্রেশন সহ বিআরটিএ আবেদন',
        'ফি: নতুনের জন্য ৫,০০০-১০,০০০ টাকা',
        'সরকার অনুমোদিত মিটার বাধ্যতামূলক',
        'বার্ষিক ফিটনেস প্রয়োজন',
        '৯-১৫ বছর পরে পর্যায়ক্রমে বন্ধ'
      ],
      licensing_en: [
        'Age: 18+ years',
        'Professional license required',
        'Route knowledge test',
        'Annual CNG leak check mandatory'
      ],
      licensing_bn: [
        'বয়স: ১৮+ বছর',
        'পেশাদার লাইসেন্স প্রয়োজন',
        'রুট জ্ঞান পরীক্ষা',
        'বার্ষিক সিএনজি লিক পরীক্ষা বাধ্যতামূলক'
      ],
      safety_en: [
        'Maximum 3 passengers allowed',
        'Must use government-approved meter',
        'Speed Limit: City 30 km/h',
        'Not allowed on highways',
        'Strictly prohibited on footpaths/walking areas'
      ],
      safety_bn: [
        'সর্বোচ্চ ৩ জন যাত্রী অনুমোদিত',
        'সরকার অনুমোদিত মিটার ব্যবহার করতে হবে',
        'গতিসীমা: শহর ৩০ কিমি/ঘন্টা',
        'হাইওয়েতে অনুমোদিত নয়',
        'ফুটপাথ/পথচারী এলাকায় কঠোরভাবে নিষিদ্ধ'
      ]
    }
  }
];

interface CommonRequirement {
  icon: string;
  title_en: string;
  title_bn: string;
  desc_en: string;
  desc_bn: string;
}

const COMMON_REQUIREMENTS: CommonRequirement[] = [
  {
    icon: '🪪',
    title_en: 'Driving License',
    title_bn: 'ড্রাইভিং লাইসেন্স',
    desc_en: 'Renew every 5 years (BDT 500-2,000)',
    desc_bn: 'প্রতি ৫ বছরে নবায়ন (৫০০-২,০০০ টাকা)'
  },
  {
    icon: '📝',
    title_en: 'Vehicle Registration',
    title_bn: 'যানবাহন নিবন্ধন',
    desc_en: 'Within 30 days of purchase',
    desc_bn: 'ক্রয়ের ৩০ দিনের মধ্যে'
  },
  {
    icon: '🏥',
    title_en: 'Fitness Certificate',
    title_bn: 'ফিটনেস সার্টিফিকেট',
    desc_en: 'Annual (commercial), Semi-annual (private)',
    desc_bn: 'বার্ষিক (বাণিজ্যিক), অর্ধবার্ষিক (ব্যক্তিগত)'
  },
  {
    icon: '🛡️',
    title_en: 'Insurance',
    title_bn: 'বীমা',
    desc_en: 'Third-party mandatory (BDT 500-5,000)',
    desc_bn: 'তৃতীয় পক্ষের বাধ্যতামূলক (৫০০-৫,০০০ টাকা)'
  },
  {
    icon: '🎫',
    title_en: 'Tax Token',
    title_bn: 'ট্যাক্স টোকেন',
    desc_en: 'Annual renewal (25% late fee)',
    desc_bn: 'বার্ষিক নবায়ন (২৫% দেরি ফি)'
  },
  {
    icon: '📊',
    title_en: 'Point System',
    title_bn: 'পয়েন্ট সিস্টেম',
    desc_en: '12 points maximum license',
    desc_bn: '১২ পয়েন্ট সর্বোচ্চ লাইসেন্স'
  }
];

// Modal Component
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title_en: string;
  title_bn: string;
  icon: string;
  children: React.ReactNode;
}

function Modal({ isOpen, onClose, title_en, title_bn, icon, children }: ModalProps) {
  const { language } = useLanguage();
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-6xl max-h-[90vh] overflow-y-auto w-full">
        <div className="sticky top-0 bg-white p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <span className="text-3xl">{icon}</span>
              {language === 'bn' ? title_bn : title_en}
            </h2>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>
        </div>
        <div className="p-4 sm:p-6">
          {children}
        </div>
      </div>
    </div>
  );
}

export default function VehicleRules() {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const selectedType = VEHICLE_TYPES.find(v => v.id === selectedVehicle);

  const handleRequirementClick = (title: string) => {
    setActiveModal(title);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center space-x-3 sm:space-x-4">
            <BackButton 
              onClick={() => selectedVehicle ? setSelectedVehicle(null) : navigate('/')}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors backdrop-blur-sm"
            />
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-3 rounded-xl shadow-lg">
                <Eye className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold">
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-blue-100 text-xs sm:text-sm">
                  {t('Vehicle Rules', 'যানবাহন নিয়ম')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {!selectedVehicle ? (
          <>
            {/* Title Section */}
            <div className="text-center mb-6 sm:mb-8">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                {t('Complete Vehicle Rules in Bangladesh', 'বাংলাদেশে সম্পূর্ণ যানবাহন নিয়ম')}
              </h2>
              <p className="text-base sm:text-lg text-gray-600">
                {t('Registration, Licensing & Safety Requirements', 'নিবন্ধন, লাইসেন্সিং এবং নিরাপত্তা প্রয়োজনীয়তা')}
              </p>
            </div>

            {/* Select Vehicle Type */}
            <div className="mb-8 sm:mb-12">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">
                {t('Select Vehicle Type', 'যানবাহনের ধরন নির্বাচন করুন')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {VEHICLE_TYPES.map((vehicle) => (
                  <button
                    key={vehicle.id}
                    onClick={() => setSelectedVehicle(vehicle.id)}
                    className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border-2 border-gray-200 hover:border-blue-500 hover:shadow-lg transition-all text-left group hover:scale-[1.02] transform duration-200"
                  >
                    <div className="text-3xl sm:text-4xl mb-3 sm:mb-4">{vehicle.icon}</div>
                    <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {language === 'en' ? vehicle.title_en : vehicle.title_bn}
                    </h4>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed mb-3">
                      {language === 'en' ? vehicle.subtitle_en : vehicle.subtitle_bn}
                    </p>
                    <p className="text-blue-600 font-medium text-xs sm:text-sm flex items-center">
                      {t('View Details', 'বিস্তারিত দেখুন')}
                      <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 ml-2 transform rotate-180" />
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Common Requirements */}
            <div className="mb-8 sm:mb-12">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6">
                {t('Common Requirements for All Vehicles', 'সকল যানবাহনের জন্য সাধারণ প্রয়োজনীয়তা')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {COMMON_REQUIREMENTS.map((req, index) => (
                  <button
                    key={index}
                    onClick={() => handleRequirementClick(req.title_en)}
                    className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-200 hover:shadow-lg transition-all hover:scale-[1.02] transform duration-200 text-left w-full group"
                  >
                    <div className="text-2xl sm:text-3xl mb-3 sm:mb-4">{req.icon}</div>
                    <h4 className="text-base sm:text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {language === 'en' ? req.title_en : req.title_bn}
                    </h4>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed mb-3">
                      {language === 'en' ? req.desc_en : req.desc_bn}
                    </p>
                    <p className="text-blue-600 font-medium text-xs sm:text-sm flex items-center">
                      {t('View Details', 'বিস্তারিত দেখুন')}
                      <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                    </p>
                  </button>
                ))}
              </div>
              
              {/* Compliance Checklist Button */}
              <div className="text-center mt-6 sm:mt-8">
                <button
                  onClick={() => navigate('/traffic-fines')}
                  className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl transform hover:scale-105 duration-200 flex items-center gap-2 sm:gap-3 mx-auto text-sm sm:text-base flex-wrap justify-center"
                >
                  <span className="text-xl sm:text-2xl">⚠️</span>
                  <span className="text-center">
                    {t('VIEW TRAFFIC FINES & PENALTIES', 'ট্রাফিক জরিমানা এবং শাস্তি দেখুন')}
                  </span>
                </button>
              </div>
            </div>

            {/* Important Notes */}
            <div className="bg-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-blue-200">
              <h4 className="font-bold text-blue-900 mb-3 flex items-center text-base sm:text-lg">
                <span className="text-lg sm:text-xl mr-2">ℹ️</span>
                {t('Important Information', 'গুরুত্বপূর্ণ তথ্য')}
              </h4>
              <div className="space-y-2 text-blue-800 text-xs sm:text-sm">
                <p>• {t('All information is based on current Bangladesh Road Transport Act 2018', 'সমস্ত তথ্য বর্তমান বাংলাদেশ সড়ক পরিবহন আইন ২০১৮ এর উপর ভিত্তি করে')}</p>
                <p>• {t('Fees and requirements may change - always verify with BRTA', 'ফি এবং প্রয়োজনীয়তা পরিবর্তিত হতে পারে - সর্বদা বিআরটিএ দিয়ে যাচাই করুন')}</p>
                <p>• {t('This guide is for educational purposes only', 'এই গাইড শুধুমাত্র শিক্ষামূলক উদ্দেশ্যে')}</p>
              </div>
            </div>

            {/* Modals */}
            {/* Driving License Modal */}
            <Modal
              isOpen={activeModal === 'Driving License'}
              onClose={() => setActiveModal(null)}
              title_en="Driving License Details"
              title_bn="ড্রাইভিং লাইসেন্স বিস্তারিত"
              icon="🪪"
            >
              <div className="space-y-6">
                {/* License Types */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'লাইসেন্সের ধরন' : 'License Types'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-bold text-blue-900 mb-2">
                        {language === 'bn' ? 'মোটরসাইকেল লাইসেন্স' : 'Motorcycle License'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বয়স: ১৮+, ফি: ৫০০-১,০০০ টাকা' : 'Age: 18+, Fee: BDT 500-1,000'}
                      </p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-bold text-green-900 mb-2">
                        {language === 'bn' ? 'গাড়ি লাইসেন্স' : 'Car License'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বয়স: ২০+, ফি: ১,০০০-২,০০০ টাকা' : 'Age: 20+, Fee: BDT 1,000-2,000'}
                      </p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <h4 className="font-bold text-purple-900 mb-2">
                        {language === 'bn' ? 'পেশাদার লাইসেন্স' : 'Professional License'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বয়স: ২১+, ভারী যানবাহনের জন্য' : 'Age: 21+, For heavy vehicles'}
                      </p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <h4 className="font-bold text-orange-900 mb-2">
                        {language === 'bn' ? 'আন্তর্জাতিক লাইসেন্স' : 'International License'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বৈধ দেশীয় লাইসেন্স প্রয়োজন' : 'Valid national license required'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Application Process */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'আবেদন প্রক্রিয়া' : 'Application Process'}
                  </h3>
                  <ol className="space-y-3">
                    {(language === 'bn' ? [
                      'নিকটস্থ বিআরটিএ অফিসে যান',
                      'আবেদন ফর্ম পূরণ করুন (ফি: ৫০ টাকা)',
                      'প্রয়োজনীয় নথি জমা দিন (এনআইডি, ছবি, মেডিকেল সার্টিফিকেট)',
                      'মেডিকেল পরীক্ষা সম্পন্ন করুন',
                      'লিখিত পরীক্ষা দিন (২০ প্রশ্ন, ১২টি সঠিক হতে হবে)',
                      'ব্যবহারিক ড্রাইভিং পরীক্ষা',
                      'লাইসেন্স সংগ্রহ করুন (১৫ দিনের মধ্যে)'
                    ] : [
                      'Visit nearest BRTA office',
                      'Fill application form (Fee: BDT 50)',
                      'Submit required documents (NID, photos, medical certificate)',
                      'Complete medical examination',
                      'Take written test (20 questions, need 12 correct)',
                      'Practical driving test',
                      'Collect license (within 15 days)'
                    ]).map((step, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <span className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold">
                          {index + 1}
                        </span>
                        <span className="text-gray-700">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                {/* Renewal Process */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'নবায়ন প্রক্রিয়া' : 'Renewal Process'}
                  </h3>
                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li>✓ {language === 'bn' ? 'প্রতি ৫ বছরে নবায়ন প্রয়োজন' : 'Renewal required every 5 years'}</li>
                      <li>✓ {language === 'bn' ? 'ফি: ৫০০-২,০০০ টাকা (লাইসেন্স ধরন অনুযায়ী)' : 'Fee: BDT 500-2,000 (based on license type)'}</li>
                      <li>✓ {language === 'bn' ? 'মেয়াদ শেষের ৩ মাস আগে নবায়ন করুন' : 'Renew 3 months before expiry'}</li>
                      <li>✓ {language === 'bn' ? 'অনলাইন নবায়ন সুবিধা উপলব্ধ' : 'Online renewal facility available'}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </Modal>

            {/* Vehicle Registration Modal */}
            <Modal
              isOpen={activeModal === 'Vehicle Registration'}
              onClose={() => setActiveModal(null)}
              title_en="Vehicle Registration Details"
              title_bn="যানবাহন নিবন্ধন বিস্তারিত"
              icon="📝"
            >
              <div className="space-y-6">
                {/* Registration Types */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'নিবন্ধনের ধরন' : 'Registration Types'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-bold text-blue-900 mb-2">
                        {language === 'bn' ? 'নতুন নিবন্ধন' : 'New Registration'}
                      </h4>
                      <p className="text-sm text-gray-700 mb-2">
                        {language === 'bn' ? 'ক্রয়ের ৩০ দিনের মধ্যে সম্পন্ন করতে হবে' : 'Must complete within 30 days of purchase'}
                      </p>
                      <p className="text-xs text-gray-600">
                        {language === 'bn' ? 'ফি: যানবাহন ধরন অনুযায়ী ২,০০০-৫০,০০০ টাকা' : 'Fee: BDT 2,000-50,000 based on vehicle type'}
                      </p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-bold text-green-900 mb-2">
                        {language === 'bn' ? 'স্থানান্তর' : 'Transfer'}
                      </h4>
                      <p className="text-sm text-gray-700 mb-2">
                        {language === 'bn' ? 'মালিকানা পরিবর্তনের সময়' : 'During ownership change'}
                      </p>
                      <p className="text-xs text-gray-600">
                        {language === 'bn' ? 'ফি: ১,০০০-১০,০০০ টাকা' : 'Fee: BDT 1,000-10,000'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Required Documents */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'প্রয়োজনীয় নথিপত্র' : 'Required Documents'}
                  </h3>
                  <ul className="space-y-2">
                    {(language === 'bn' ? [
                      'ক্রয় চালান এবং রসিদ',
                      'চ্যাসিস এবং ইঞ্জিন নম্বর',
                      'কাস্টমস ক্লিয়ারেন্স (আমদানিকৃত গাড়ির জন্য)',
                      'মালিকের এনআইডি কপি',
                      'ট্যাক্স টোকেন পেমেন্ট রসিদ',
                      'বীমা সার্টিফিকেট',
                      'ফিটনেস সার্টিফিকেট'
                    ] : [
                      'Purchase invoice and receipt',
                      'Chassis and engine numbers',
                      'Customs clearance (for imported vehicles)',
                      'Owner\'s NID copy',
                      'Tax token payment receipt',
                      'Insurance certificate',
                      'Fitness certificate'
                    ]).map((doc, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span className="text-gray-700">{doc}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Fees by Vehicle Type */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'যানবাহন ধরন অনুযায়ী ফি' : 'Fees by Vehicle Type'}
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full border border-gray-300 rounded-lg">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="border border-gray-300 px-4 py-2 text-left">
                            {language === 'bn' ? 'যানবাহন' : 'Vehicle'}
                          </th>
                          <th className="border border-gray-300 px-4 py-2 text-left">
                            {language === 'bn' ? 'নিবন্ধন ফি' : 'Registration Fee'}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'মোটরসাইকেল' : 'Motorcycle'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳2,000-5,000</td>
                        </tr>
                        <tr className="bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'গাড়ি' : 'Car'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳10,000-20,000</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'বাস' : 'Bus'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳25,000+</td>
                        </tr>
                        <tr className="bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'ট্রাক' : 'Truck'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳25,000-50,000</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </Modal>

            {/* Fitness Certificate Modal */}
            <Modal
              isOpen={activeModal === 'Fitness Certificate'}
              onClose={() => setActiveModal(null)}
              title_en="Fitness Certificate Details"
              title_bn="ফিটনেস সার্টিফিকেট বিস্তারিত"
              icon="🏥"
            >
              <div className="space-y-6">
                {/* Inspection Schedule */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পরিদর্শনের সময়সূচী' : 'Inspection Schedule'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-bold text-blue-900 mb-2">
                        {language === 'bn' ? 'ব্যক্তিগত যানবাহন' : 'Private Vehicles'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'অর্ধবার্ষিক (প্রতি ৬ মাসে)' : 'Semi-annual (Every 6 months)'}
                      </p>
                      <p className="text-xs text-gray-600 mt-2">
                        {language === 'bn' ? 'ফি: ১,০০০-২,০০০ টাকা' : 'Fee: BDT 1,000-2,000'}
                      </p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <h4 className="font-bold text-green-900 mb-2">
                        {language === 'bn' ? 'বাণিজ্যিক যানবাহন' : 'Commercial Vehicles'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বার্ষিক (প্রতি বছর)' : 'Annual (Every year)'}
                      </p>
                      <p className="text-xs text-gray-600 mt-2">
                        {language === 'bn' ? 'ফি: ২,০০০-৫,০০০ টাকা' : 'Fee: BDT 2,000-5,000'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Inspection Checklist */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পরিদর্শন চেকলিস্ট' : 'Inspection Checklist'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {(language === 'bn' ? [
                      'ব্রেক সিস্টেম',
                      'লাইট এবং সিগন্যাল',
                      'টায়ার অবস্থা',
                      'স্টিয়ারিং সিস্টেম',
                      'ইঞ্জিন পারফরম্যান্স',
                      'নিঃসরণ পরীক্ষা',
                      'বডি এবং ফ্রেম',
                      'নিরাপত্তা সরঞ্জাম'
                    ] : [
                      'Brake System',
                      'Lights and Signals',
                      'Tire Condition',
                      'Steering System',
                      'Engine Performance',
                      'Emission Test',
                      'Body and Frame',
                      'Safety Equipment'
                    ]).map((item, index) => (
                      <div key={index} className="flex items-center gap-2 bg-gray-50 p-2 rounded">
                        <span className="text-green-600">✓</span>
                        <span className="text-sm text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Rejection Reasons */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'সাধারণ প্রত্যাখ্যানের কারণ' : 'Common Rejection Reasons'}
                  </h3>
                  <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                    <ul className="space-y-2 text-sm text-gray-700">
                      {(language === 'bn' ? [
                        'দুর্বল ব্রেক সিস্টেম',
                        'অত্যধিক নিঃসরণ',
                        'ত্রুটিপূর্ণ লাইট',
                        'অনুপযুক্ত টায়ার',
                        'মেয়াদোত্তীর্ণ সরঞ্জাম'
                      ] : [
                        'Weak brake system',
                        'Excessive emissions',
                        'Faulty lights',
                        'Improper tires',
                        'Expired equipment'
                      ]).map((reason, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-red-600 mt-1">✗</span>
                          <span>{reason}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </Modal>

            {/* Insurance Modal */}
            <Modal
              isOpen={activeModal === 'Insurance'}
              onClose={() => setActiveModal(null)}
              title_en="Vehicle Insurance Details"
              title_bn="যানবাহন বীমা বিস্তারিত"
              icon="🛡️"
            >
              <div className="space-y-6">
                {/* Insurance Types */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'বীমার ধরন' : 'Insurance Types'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-red-50 p-4 rounded-lg border-2 border-red-300">
                      <h4 className="font-bold text-red-900 mb-2 flex items-center gap-2">
                        <span>⚠️</span>
                        {language === 'bn' ? 'তৃতীয় পক্ষের বীমা (বাধ্যতামূলক)' : 'Third-Party Insurance (Mandatory)'}
                      </h4>
                      <p className="text-sm text-gray-700 mb-2">
                        {language === 'bn' ? 'সর্বনিম্ন আইনগত প্রয়োজনীয়তা' : 'Minimum legal requirement'}
                      </p>
                      <p className="text-xs text-gray-600">
                        {language === 'bn' ? 'ফি: ৫০০-৫,০০০ টাকা/বছর' : 'Fee: BDT 500-5,000/year'}
                      </p>
                      <ul className="mt-3 space-y-1 text-xs text-gray-600">
                        <li>✓ {language === 'bn' ? 'অন্যদের ক্ষতি কভার করে' : 'Covers damage to others'}</li>
                        <li>✓ {language === 'bn' ? 'শারীরিক আঘাত দায়' : 'Bodily injury liability'}</li>
                        <li>✓ {language === 'bn' ? 'সম্পত্তির ক্ষতি দায়' : 'Property damage liability'}</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-bold text-blue-900 mb-2">
                        {language === 'bn' ? 'সম্পূর্ণ বীমা (ঐচ্ছিক)' : 'Comprehensive Insurance (Optional)'}
                      </h4>
                      <p className="text-sm text-gray-700 mb-2">
                        {language === 'bn' ? 'সম্পূর্ণ সুরক্ষা' : 'Complete protection'}
                      </p>
                      <p className="text-xs text-gray-600">
                        {language === 'bn' ? 'ফি: ১০,০০০-১,০০,০০০ টাকা/বছর' : 'Fee: BDT 10,000-1,00,000/year'}
                      </p>
                      <ul className="mt-3 space-y-1 text-xs text-gray-600">
                        <li>✓ {language === 'bn' ? 'নিজের যানবাহনের ক্ষতি' : 'Own vehicle damage'}</li>
                        <li>✓ {language === 'bn' ? 'চুরি কভারেজ' : 'Theft coverage'}</li>
                        <li>✓ {language === 'bn' ? 'প্রাকৃতিক দুর্যোগ' : 'Natural disasters'}</li>
                        <li>✓ {language === 'bn' ? 'তৃতীয় পক্ষের দায়' : 'Third-party liability'}</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Premium Factors */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'প্রিমিয়াম নির্ধারণকারী' : 'Premium Determining Factors'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {(language === 'bn' ? [
                      { label: 'যানবাহনের মূল্য', impact: 'উচ্চ মূল্য = উচ্চ প্রিমিয়াম' },
                      { label: 'যানবাহনের বয়স', impact: 'পুরাতন গাড়ি = কম প্রিমিয়াম' },
                      { label: 'ইঞ্জিন ক্ষমতা', impact: 'বড় ইঞ্জিন = উচ্চ প্রিমিয়াম' },
                      { label: 'দাবির ইতিহাস', impact: 'কোন দাবি নেই = ছাড়' },
                      { label: 'ব্যবহারের উদ্দেশ্য', impact: 'বাণিজ্যিক = উচ্চ প্রিমিয়াম' },
                      { label: 'এলাকা/জোন', impact: 'ঢাকা = উচ্চ প্রিমিয়াম' }
                    ] : [
                      { label: 'Vehicle Value', impact: 'Higher value = Higher premium' },
                      { label: 'Vehicle Age', impact: 'Older car = Lower premium' },
                      { label: 'Engine Capacity', impact: 'Bigger engine = Higher premium' },
                      { label: 'Claim History', impact: 'No claims = Discount' },
                      { label: 'Usage Purpose', impact: 'Commercial = Higher premium' },
                      { label: 'Area/Zone', impact: 'Dhaka = Higher premium' }
                    ]).map((factor, index) => (
                      <div key={index} className="bg-gray-50 p-3 rounded-lg">
                        <h5 className="font-semibold text-gray-800 text-sm mb-1">{factor.label}</h5>
                        <p className="text-xs text-gray-600">{factor.impact}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Claim Process */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'দাবি প্রক্রিয়া' : 'Claim Process'}
                  </h3>
                  <ol className="space-y-3">
                    {(language === 'bn' ? [
                      'অবিলম্বে বীমা কোম্পানিকে অবহিত করুন (২৪-৪৮ ঘন্টার মধ্যে)',
                      'পুলিশ রিপোর্ট ফাইল করুন (প্রয়োজনে)',
                      'ক্ষতির ছবি তুলুন',
                      'দাবির ফর্ম পূরণ করুন',
                      'নথি জমা দিন (এফআইআর, চালান, ফিটনেস)',
                      'সার্ভেয়ার পরিদর্শনের জন্য অপেক্ষা করুন',
                      'ক্ষতিপূরণ পান (অনুমোদন হলে)'
                    ] : [
                      'Inform insurance company immediately (within 24-48 hours)',
                      'File police report (if required)',
                      'Take photos of damage',
                      'Fill claim form',
                      'Submit documents (FIR, invoice, fitness)',
                      'Wait for surveyor inspection',
                      'Receive compensation (if approved)'
                    ]).map((step, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <span className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold">
                          {index + 1}
                        </span>
                        <span className="text-gray-700 text-sm">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </Modal>

            {/* Tax Token Modal */}
            <Modal
              isOpen={activeModal === 'Tax Token'}
              onClose={() => setActiveModal(null)}
              title_en="Tax Token Details"
              title_bn="ট্যাক্স টোকেন বিস্তারিত"
              icon="🎫"
            >
              <div className="space-y-6">
                {/* Tax Structure */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'কর কাঠামো' : 'Tax Structure'}
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full border border-gray-300 rounded-lg">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="border border-gray-300 px-4 py-2 text-left">
                            {language === 'bn' ? 'যানবাহনের ধরন' : 'Vehicle Type'}
                          </th>
                          <th className="border border-gray-300 px-4 py-2 text-left">
                            {language === 'bn' ? 'বার্ষিক কর' : 'Annual Tax'}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'মোটরসাইকেল' : 'Motorcycle'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳500-1,500</td>
                        </tr>
                        <tr className="bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'গাড়ি (1000cc পর্যন্ত)' : 'Car (up to 1000cc)'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳3,000-5,000</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'গাড়ি (1001-1500cc)' : 'Car (1001-1500cc)'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳7,500-15,000</td>
                        </tr>
                        <tr className="bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'গাড়ি (1500cc+)' : 'Car (1500cc+)'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳20,000-40,000</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 px-4 py-2">
                            {language === 'bn' ? 'বাস/ট্রাক' : 'Bus/Truck'}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">৳5,000-20,000</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Payment Details */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পেমেন্ট বিস্তারিত' : 'Payment Details'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-bold text-blue-900 mb-2">
                        {language === 'bn' ? 'বৈধতার মেয়াদ' : 'Validity Period'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? '১ বছর (জানুয়ারি-ডিসেম্বর)' : '1 year (January-December)'}
                      </p>
                    </div>
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <h4 className="font-bold text-yellow-900 mb-2">
                        {language === 'bn' ? 'বিলম্ব ফি' : 'Late Fee'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বার্ষিক করের ২৫%' : '25% of annual tax'}
                      </p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-bold text-green-900 mb-2">
                        {language === 'bn' ? 'পেমেন্ট পদ্ধতি' : 'Payment Method'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'অনলাইন/ব্যাংক/বিআরটিএ' : 'Online/Bank/BRTA'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Carbon Tax */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'কার্বন ট্যাক্স' : 'Carbon Tax'}
                  </h3>
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <p className="text-sm text-gray-700 mb-3">
                      {language === 'bn' 
                        ? 'একাধিক ব্যক্তিগত গাড়ির মালিকদের জন্য অতিরিক্ত কর:'
                        : 'Additional tax for owners of multiple private cars:'}
                    </p>
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li>• {language === 'bn' ? '১ম গাড়ি: কোন কার্বন ট্যাক্স নেই' : '1st car: No carbon tax'}</li>
                      <li>• {language === 'bn' ? '২য় গাড়ি: ২৫,০০০ টাকা/বছর' : '2nd car: BDT 25,000/year'}</li>
                      <li>• {language === 'bn' ? '৩য় গাড়ি: ৫০,০০০ টাকা/বছর' : '3rd car: BDT 50,000/year'}</li>
                      <li>• {language === 'bn' ? '৪র্থ+ গাড়ি: ৭৫,০০০ টাকা/বছর' : '4th+ car: BDT 75,000/year'}</li>
                    </ul>
                  </div>
                </div>

                {/* Renewal Process */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'নবায়ন প্রক্রিয়া' : 'Renewal Process'}
                  </h3>
                  <ol className="space-y-3">
                    {(language === 'bn' ? [
                      'জানুয়ারিতে নবায়ন শুরু হয়',
                      'অনলাইন পোর্টালে যান বা বিআরটিএ অফিসে যান',
                      'ফিটনেস সার্টিফিকেট জমা দিন',
                      'বীমা সার্টিফিকেট জমা দিন',
                      'কর প্রদান করুন',
                      'নতুন ট্যাক্স টোকেন সংগ্রহ করুন'
                    ] : [
                      'Renewal starts in January',
                      'Visit online portal or BRTA office',
                      'Submit fitness certificate',
                      'Submit insurance certificate',
                      'Pay tax amount',
                      'Collect new tax token'
                    ]).map((step, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <span className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold">
                          {index + 1}
                        </span>
                        <span className="text-gray-700 text-sm">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </Modal>

            {/* Point System Modal */}
            <Modal
              isOpen={activeModal === 'Point System'}
              onClose={() => setActiveModal(null)}
              title_en="12-Point License System"
              title_bn="১২-পয়েন্ট লাইসেন্স সিস্টেম"
              icon="📊"
            >
              <div className="space-y-6">
                {/* How It Works */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'কিভাবে কাজ করে' : 'How It Works'}
                  </h3>
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <p className="text-gray-700 mb-3">
                      {language === 'bn'
                        ? 'প্রতিটি ড্রাইভিং লাইসেন্স ১২ পয়েন্ট দিয়ে শুরু হয়। ট্রাফিক লঙ্ঘনের জন্য পয়েন্ট কাটা হয়। সব পয়েন্ট শেষ হলে লাইসেন্স স্থগিত হয়।'
                        : 'Each driving license starts with 12 points. Points are deducted for traffic violations. When all points are exhausted, license gets suspended.'}
                    </p>
                  </div>
                </div>

                {/* Point Deduction */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'লঙ্ঘন এবং পয়েন্ট কাটা' : 'Violations and Point Deduction'}
                  </h3>
                  <div className="space-y-3">
                    <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                      <h4 className="font-bold text-red-900 mb-2">
                        {language === 'bn' ? '২ পয়েন্ট কাটা - গুরুতর লঙ্ঘন' : '2 Points Deduction - Serious Violations'}
                      </h4>
                      <ul className="space-y-1 text-sm text-gray-700">
                        <li>• {language === 'bn' ? 'মদ্যপ অবস্থায় গাড়ি চালানো' : 'Drunk driving'}</li>
                        <li>• {language === 'bn' ? 'দুর্ঘটনায় পলায়ন' : 'Hit and run'}</li>
                        <li>• {language === 'bn' ? 'রেসিং/রেকলেস ড্রাইভিং' : 'Racing/reckless driving'}</li>
                      </ul>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                      <h4 className="font-bold text-orange-900 mb-2">
                        {language === 'bn' ? '১ পয়েন্ট কাটা - মাঝারি লঙ্ঘন' : '1 Point Deduction - Moderate Violations'}
                      </h4>
                      <ul className="space-y-1 text-sm text-gray-700">
                        <li>• {language === 'bn' ? 'রেড লাইট জাম্পিং' : 'Red light jumping'}</li>
                        <li>• {language === 'bn' ? 'গতি সীমা লঙ্ঘন' : 'Speeding'}</li>
                        <li>• {language === 'bn' ? 'ভুল দিক দিয়ে গাড়ি চালানো' : 'Wrong-way driving'}</li>
                        <li>• {language === 'bn' ? 'মোবাইল ফোন ব্যবহার' : 'Mobile phone use'}</li>
                        <li>• {language === 'bn' ? 'হেলমেট/সিটবেল্ট না পরা' : 'No helmet/seatbelt'}</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Consequences */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পরিণতি' : 'Consequences'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                      <h4 className="font-bold text-yellow-900 mb-2">
                        {language === 'bn' ? '৮-১১ পয়েন্ট অবশিষ্ট' : '8-11 Points Remaining'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'লিখিত সতর্কতা পত্র জারি' : 'Written warning letter issued'}
                      </p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                      <h4 className="font-bold text-orange-900 mb-2">
                        {language === 'bn' ? '৫-৭ পয়েন্ট অবশিষ্ট' : '5-7 Points Remaining'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'বাধ্যতামূলক নিরাপত্তা প্রশিক্ষণ' : 'Mandatory safety training'}
                      </p>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg border-2 border-red-300">
                      <h4 className="font-bold text-red-900 mb-2">
                        {language === 'bn' ? '০ পয়েন্ট অবশিষ্ট' : '0 Points Remaining'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? '৬ মাসের লাইসেন্স স্থগিতাদেশ' : '6-month license suspension'}
                      </p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                      <h4 className="font-bold text-purple-900 mb-2">
                        {language === 'bn' ? 'পুনরায় সক্রিয়করণ' : 'Reactivation'}
                      </h4>
                      <p className="text-sm text-gray-700">
                        {language === 'bn' ? 'পুনরায় পরীক্ষা এবং প্রশিক্ষণ প্রয়োজন' : 'Retesting and training required'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Point Reset */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পয়েন্ট রিসেট' : 'Point Reset'}
                  </h3>
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li>✓ {language === 'bn' ? 'প্রতি ২ বছরে পয়েন্ট রিসেট হয় (লঙ্ঘন মুক্ত থাকলে)' : 'Points reset every 2 years (if violation-free)'}</li>
                      <li>✓ {language === 'bn' ? 'নিরাপত্তা প্রশিক্ষণ সম্পন্ন করলে ১ পয়েন্ট ফেরত' : 'Completing safety training restores 1 point'}</li>
                      <li>✓ {language === 'bn' ? 'সম্প্রদায় সেবা ২ পয়েন্ট পর্যন্ত ফেরত দিতে পারে' : 'Community service can restore up to 2 points'}</li>
                    </ul>
                  </div>
                </div>

                {/* Check Points */}
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">
                    {language === 'bn' ? 'পয়েন্ট পরীক্ষা করুন' : 'Check Your Points'}
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <p className="text-sm text-gray-700 mb-3">
                      {language === 'bn'
                        ? 'আপনার বর্তমান পয়েন্ট স্ট্যাটাস পরীক্ষা করতে:'
                        : 'To check your current point status:'}
                    </p>
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li>• {language === 'bn' ? 'বিআরটিএ অনলাইন পোর্টাল ব্যবহার করুন' : 'Use BRTA online portal'}</li>
                      <li>• {language === 'bn' ? 'লাইসেন্স নম্বর দিয়ে লগইন করুন' : 'Login with license number'}</li>
                      <li>• {language === 'bn' ? 'বা নিকটস্থ বিআরটিএ অফিসে যান' : 'Or visit nearest BRTA office'}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </Modal>
          </>
        ) : selectedType && (
          <div className="space-y-6 sm:space-y-8">
            {/* Vehicle Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-xl">
              <div className="flex items-center space-x-3 sm:space-x-4">
                <div className="text-4xl sm:text-6xl">{selectedType.icon}</div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold mb-2">
                    {language === 'en' ? selectedType.title_en : selectedType.title_bn}
                  </h2>
                  <p className="text-blue-100 text-sm sm:text-lg">
                    {language === 'en' ? selectedType.subtitle_en : selectedType.subtitle_bn}
                  </p>
                </div>
              </div>
            </div>

            {/* Registration Details */}
            <div className="bg-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">📝</span>
                {t('Registration & Fees', 'নিবন্ধন এবং ফি')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.registration_en : selectedType.details.registration_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-blue-600 text-xs sm:text-sm font-bold">✓</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Licensing Requirements */}
            <div className="bg-white rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">🪪</span>
                {t('Licensing Requirements', 'লাইসেন্সের প্রয়োজনীয়তা')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.licensing_en : selectedType.details.licensing_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-green-600 text-xs sm:text-sm font-bold">✓</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Safety Rules */}
            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 border-2 border-red-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
                <span className="text-2xl sm:text-3xl mr-3">⚠️</span>
                {t('Key Safety Rules', 'মূল নিরাপত্তা নিয়ম')}
              </h3>
              <div className="space-y-4">
                {(language === 'en' ? selectedType.details.safety_en : selectedType.details.safety_bn).map((detail, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-red-600 text-xs sm:text-sm font-bold">!</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed font-medium text-sm sm:text-base">{detail}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Back to List Button */}
            <div className="text-center">
              <button
                onClick={() => setSelectedVehicle(null)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 sm:px-8 py-3 rounded-xl font-semibold transition-colors shadow-lg hover:shadow-xl text-sm sm:text-base"
              >
                {t('Back to Vehicle Types', 'যানবাহনের ধরনে ফিরে যান')}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
