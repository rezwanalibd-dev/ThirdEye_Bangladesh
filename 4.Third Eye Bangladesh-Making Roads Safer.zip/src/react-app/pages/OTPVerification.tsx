import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Shield, Phone, Timer, AlertCircle, CheckCircle } from "lucide-react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import BackButton from '@/react-app/components/BackButton';

export default function OTPVerification() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { verifyOTP, resendOTP } = useAuth();
  const { t } = useLanguage();
  
  const user_id = parseInt(searchParams.get('user_id') || '0');
  const mobile = searchParams.get('mobile') || '';
  
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [error, setError] = useState("");
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (!user_id || !mobile) {
      navigate('/signup');
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [user_id, mobile, navigate]);

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
    
    // Auto-submit when all fields are filled
    if (newOtp.every(digit => digit !== '') && newOtp.join('').length === 6) {
      handleSubmit(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleSubmit = async (otpCode?: string) => {
    const code = otpCode || otp.join('');
    if (code.length !== 6) {
      setError(t("Please enter complete OTP", "সম্পূর্ণ OTP লিখুন"));
      return;
    }

    setLoading(true);
    setError("");

    try {
      await verifyOTP(user_id, code);
      navigate('/verify-identity');
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setError(errorMessage || t("Invalid OTP", "ভুল OTP"));
      setOtp(['', '', '', '', '', '']); // Clear OTP on error
      const firstInput = document.getElementById('otp-0');
      firstInput?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!canResend) return;
    
    setResendLoading(true);
    setError("");
    
    try {
      await resendOTP(user_id);
      setTimeLeft(120);
      setCanResend(false);
      setOtp(['', '', '', '', '', '']);
      const firstInput = document.getElementById('otp-0');
      firstInput?.focus();
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setError(errorMessage || t("Failed to resend OTP", "OTP পুনরায় পাঠাতে ব্যর্থ"));
    } finally {
      setResendLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <BackButton 
              to="/signup" 
              label={t("Back to Sign Up", "সাইন আপে ফিরুন")}
              className="inline-flex items-center text-indigo-600 hover:text-indigo-700"
            />
          </div>
          
          <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-4 rounded-xl w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Shield className="w-8 h-8 text-white" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t("Verify Your Number", "আপনার নম্বর যাচাই করুন")}
          </h1>
          <p className="text-gray-600 mb-4">
            {t("We sent a 6-digit code to", "আমরা ৬-ডিজিটের কোড পাঠিয়েছি")}
          </p>
          <div className="flex items-center justify-center text-indigo-600 font-medium">
            <Phone className="w-4 h-4 mr-2" />
            {mobile}
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 flex-shrink-0" />
              <span className="text-red-700 text-sm">{error}</span>
            </div>
          )}

          {/* OTP Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-4">
              {t("Enter 6-digit code", "৬-ডিজিটের কোড লিখুন")}
            </label>
            <div className="flex justify-center space-x-3">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  id={`otp-${index}`}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-12 h-12 text-center text-xl font-bold border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  disabled={loading}
                />
              ))}
            </div>
          </div>

          {/* Timer */}
          <div className="text-center mb-6">
            <div className="flex items-center justify-center text-gray-600 mb-2">
              <Timer className="w-4 h-4 mr-2" />
              <span className="text-sm">
                {timeLeft > 0 
                  ? t(`Code expires in ${formatTime(timeLeft)}`, `কোডের মেয়াদ ${formatTime(timeLeft)}`) 
                  : t("Code expired", "কোডের মেয়াদ শেষ")
                }
              </span>
            </div>
            
            {canResend && (
              <button
                onClick={handleResend}
                disabled={resendLoading}
                className="text-indigo-600 hover:text-indigo-700 font-medium text-sm disabled:opacity-50"
              >
                {resendLoading 
                  ? t("Sending...", "পাঠানো হচ্ছে...") 
                  : t("Resend Code", "কোড পুনরায় পাঠান")
                }
              </button>
            )}
          </div>

          {/* Submit Button */}
          <button
            onClick={() => handleSubmit()}
            disabled={loading || otp.some(digit => !digit)}
            className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-indigo-700 hover:to-blue-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? t("Verifying...", "যাচাই করা হচ্ছে...") : t("Verify Code", "কোড যাচাই করুন")}
          </button>

          {/* Instructions */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start">
              <CheckCircle className="w-5 h-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
              <div className="text-blue-700 text-sm">
                <p className="font-medium mb-1">
                  {t("Didn't receive the code?", "কোড পাননি?")}
                </p>
                <ul className="text-xs space-y-1">
                  <li>• {t("Check your SMS inbox", "আপনার SMS ইনবক্স চেক করুন")}</li>
                  <li>• {t("Make sure your phone has signal", "নিশ্চিত করুন আপনার ফোনে সিগন্যাল আছে")}</li>
                  <li>• {t("Wait for the timer to resend", "রিসেন্ড করার জন্য টাইমার অপেক্ষা করুন")}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
