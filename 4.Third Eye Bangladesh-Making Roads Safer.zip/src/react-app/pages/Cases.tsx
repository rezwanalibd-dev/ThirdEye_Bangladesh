import React, { useState, useEffect } from 'react';
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useNavigate } from 'react-router';
import { 
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  MapPin,
  Calendar,
  DollarSign,
  Image as ImageIcon,
  ChevronDown,
  Eye
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

interface CaseItem {
  id: number;
  case_number: string;
  status: string;
  vehicle_number: string;
  violation_name_en: string;
  violation_name_bn: string;
  reward_amount: number;
  fine_amount: number;
  reported_at: string;
  location_description?: string;
  description?: string;
  rejection_reason?: string;
  evidence_urls?: string;
}

export default function Cases() {
  const { isDemoMode } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [filteredCases, setFilteredCases] = useState<CaseItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);

  const filterCases = React.useCallback(() => {
    let filtered = [...cases];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(c =>
        c.case_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.vehicle_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.violation_name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.violation_name_bn.includes(searchTerm)
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(c => c.status === statusFilter);
    }

    setFilteredCases(filtered);
  }, [cases, searchTerm, statusFilter]);

  const fetchCases = async () => {
    try {
      const response = await fetch('/api/cases', { credentials: 'include' });
      const data = await response.json();
      setCases(data);
      setFilteredCases(data);
    } catch (error) {
      console.error('Failed to fetch cases:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCases();
  }, []);

  useEffect(() => {
    filterCases();
  }, [filterCases]);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'approved':
        return {
          color: 'text-green-700 bg-green-100 border-green-200',
          icon: CheckCircle,
          label: t('Approved', 'অনুমোদিত')
        };
      case 'pending':
        return {
          color: 'text-yellow-700 bg-yellow-100 border-yellow-200',
          icon: Clock,
          label: t('Pending', 'বিচারাধীন')
        };
      case 'under_review':
        return {
          color: 'text-blue-700 bg-blue-100 border-blue-200',
          icon: Clock,
          label: t('Under Review', 'পর্যালোচনাধীন')
        };
      case 'rejected':
        return {
          color: 'text-red-700 bg-red-100 border-red-200',
          icon: XCircle,
          label: t('Rejected', 'প্রত্যাখ্যাত')
        };
      case 'completed':
        return {
          color: 'text-purple-700 bg-purple-100 border-purple-200',
          icon: CheckCircle,
          label: t('Completed', 'সম্পন্ন')
        };
      default:
        return {
          color: 'text-gray-700 bg-gray-100 border-gray-200',
          icon: Clock,
          label: status
        };
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'en' ? 'en-US' : 'bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const statusOptions = [
    { value: 'all', label: t('All Cases', 'সব কেস') },
    { value: 'pending', label: t('Pending', 'বিচারাধীন') },
    { value: 'under_review', label: t('Under Review', 'পর্যালোচনাধীন') },
    { value: 'approved', label: t('Approved', 'অনুমোদিত') },
    { value: 'rejected', label: t('Rejected', 'প্রত্যাখ্যাত') },
    { value: 'completed', label: t('Completed', 'সম্পন্ন') }
  ];

  const stats = {
    total: cases.length,
    pending: cases.filter(c => c.status === 'pending').length,
    approved: cases.filter(c => c.status === 'approved' || c.status === 'completed').length,
    rejected: cases.filter(c => c.status === 'rejected').length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BackButton 
                to="/dashboard"
                className="p-2 hover:bg-gray-100 rounded-lg transition-all"
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {t('My Reports', 'আমার রিপোর্ট')}
                </h1>
                <p className="text-sm text-gray-600">
                  {t('Track all your submitted cases', 'আপনার জমা দেওয়া সব কেস ট্র্যাক করুন')}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-indigo-600 to-blue-600 p-2.5 rounded-xl shadow-md">
                <Eye className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600 text-sm">{t('Total Cases', 'মোট কেস')}</p>
              <div className="bg-blue-100 p-2 rounded-lg">
                <Eye className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600 text-sm">{t('Pending', 'বিচারাধীন')}</p>
              <div className="bg-yellow-100 p-2 rounded-lg">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.pending}</p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600 text-sm">{t('Approved', 'অনুমোদিত')}</p>
              <div className="bg-green-100 p-2 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.approved}</p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600 text-sm">{t('Rejected', 'প্রত্যাখ্যাত')}</p>
              <div className="bg-red-100 p-2 rounded-lg">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.rejected}</p>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('Search by case number, vehicle, or violation...', 'কেস নম্বর, যানবাহন বা আইন লঙ্ঘন দ্বারা অনুসন্ধান করুন...')}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            {/* Status Filter */}
            <div className="relative">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition-all"
              >
                <Filter className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-700">
                  {statusOptions.find(s => s.value === statusFilter)?.label}
                </span>
                <ChevronDown className="w-4 h-4 text-gray-600" />
              </button>

              {showFilters && (
                <div className="absolute right-0 mt-2 w-56 bg-white border border-gray-200 rounded-xl shadow-lg z-10">
                  {statusOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setStatusFilter(option.value);
                        setShowFilters(false);
                      }}
                      className={`
                        w-full text-left px-4 py-3 hover:bg-gray-50 transition-all first:rounded-t-xl last:rounded-b-xl
                        ${statusFilter === option.value ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-700'}
                      `}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Cases List */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto"></div>
            <p className="text-gray-600 mt-4">{t('Loading cases...', 'কেস লোড হচ্ছে...')}</p>
          </div>
        ) : filteredCases.length > 0 ? (
          <div className="grid gap-6">
            {filteredCases.map((caseItem) => {
              const statusConfig = getStatusConfig(caseItem.status);
              const StatusIcon = statusConfig.icon;
              const evidenceUrls = caseItem.evidence_urls ? JSON.parse(caseItem.evidence_urls) : [];

              return (
                <div
                  key={caseItem.id}
                  className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden relative"
                >
                  {isDemoMode && isDemoMode() && caseItem.case_number?.startsWith('TE-DEV') && (
                    <div className="absolute top-4 right-4 z-10">
                      <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full font-medium">
                        DEMO DATA
                      </span>
                    </div>
                  )}
                  <div className="p-6">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-xl font-bold text-gray-900">
                            {caseItem.case_number}
                          </h3>
                          <span className={`px-3 py-1.5 rounded-full text-xs font-semibold border ${statusConfig.color} flex items-center space-x-1`}>
                            <StatusIcon className="w-4 h-4" />
                            <span>{statusConfig.label}</span>
                          </span>
                        </div>
                        <p className="text-gray-600">
                          {language === 'en' ? caseItem.violation_name_en : caseItem.violation_name_bn}
                        </p>
                      </div>

                      {caseItem.reward_amount > 0 && caseItem.status === 'completed' && (
                        <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-2">
                          <div className="flex items-center space-x-2">
                            <DollarSign className="w-5 h-5 text-green-600" />
                            <span className="font-bold text-green-700">৳{caseItem.reward_amount.toFixed(0)}</span>
                          </div>
                          <p className="text-xs text-green-600">{t('Earned', 'আয়')}</p>
                        </div>
                      )}
                    </div>

                    {/* Details Grid */}
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div className="bg-white p-2 rounded-lg">
                          <ImageIcon className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">{t('Vehicle Number', 'যানবাহন নম্বর')}</p>
                          <p className="font-semibold text-gray-900">{caseItem.vehicle_number}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div className="bg-white p-2 rounded-lg">
                          <Calendar className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">{t('Reported At', 'রিপোর্ট করা হয়েছে')}</p>
                          <p className="font-semibold text-gray-900 text-sm">{formatDate(caseItem.reported_at)}</p>
                        </div>
                      </div>

                      {caseItem.location_description && (
                        <div className="md:col-span-2 flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                          <div className="bg-white p-2 rounded-lg">
                            <MapPin className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">{t('Location', 'অবস্থান')}</p>
                            <p className="font-medium text-gray-900">{caseItem.location_description}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Evidence Images */}
                    {evidenceUrls.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm font-medium text-gray-700 mb-3">
                          {t('Evidence Photos', 'প্রমাণ ছবি')} ({evidenceUrls.length})
                        </p>
                        <div className="grid grid-cols-4 gap-3">
                          {evidenceUrls.slice(0, 4).map((_: string, index: number) => (
                            <div key={index} className="aspect-square bg-gray-100 rounded-lg border border-gray-200 flex items-center justify-center">
                              <ImageIcon className="w-8 h-8 text-gray-400" />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Description */}
                    {caseItem.description && (
                      <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm font-medium text-blue-900 mb-1">
                          {t('Description', 'বর্ণনা')}
                        </p>
                        <p className="text-sm text-blue-800">{caseItem.description}</p>
                      </div>
                    )}

                    {/* Officer Notes (if rejected) */}
                    {caseItem.status === 'rejected' && caseItem.rejection_reason && (
                      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm font-medium text-red-900 mb-1">
                          {t('Rejection Reason', 'প্রত্যাখ্যানের কারণ')}
                        </p>
                        <p className="text-sm text-red-800">{caseItem.rejection_reason}</p>
                      </div>
                    )}

                    {/* Fine and Reward Info */}
                    {caseItem.fine_amount > 0 && (
                      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                        <div>
                          <p className="text-xs text-gray-500">{t('Fine Amount', 'জরিমানার পরিমাণ')}</p>
                          <p className="text-lg font-bold text-gray-900">৳{caseItem.fine_amount.toFixed(0)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-500">{t('Your Reward (20%)', 'আপনার পুরস্কার (২০%)')}</p>
                          <p className="text-lg font-bold text-green-600">৳{caseItem.reward_amount.toFixed(0)}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 text-center">
            <AlertCircle className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              {t('No cases found', 'কোনো কেস পাওয়া যায়নি')}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || statusFilter !== 'all'
                ? t('Try adjusting your search or filters', 'আপনার অনুসন্ধান বা ফিল্টার সামঞ্জস্য করার চেষ্টা করুন')
                : t('You haven\'t submitted any reports yet', 'আপনি এখনও কোনো রিপোর্ট জমা দেননি')
              }
            </p>
            {!searchTerm && statusFilter === 'all' && (
              <button
                onClick={() => navigate('/report')}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl hover:bg-indigo-700 font-semibold transition-all"
              >
                {t('Submit your first report', 'আপনার প্রথম রিপোর্ট জমা দিন')}
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
