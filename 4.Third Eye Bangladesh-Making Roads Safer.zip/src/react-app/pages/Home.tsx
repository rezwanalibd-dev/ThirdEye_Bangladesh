import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Link } from "react-router";
import { Eye, Camera, Shield, ArrowRight, Phone, DollarSign, Star, Car } from 'lucide-react';
import LoadingSpinner from "@/react-app/components/LoadingSpinner";
import HierarchicalEmergencyContacts from "@/react-app/components/HierarchicalEmergencyContacts";


export default function Home() {
  const { user, isLoading } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();

  if (isLoading) {
    return <LoadingSpinner />;
  }

  

  

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-2.5">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2.5">
              <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-3 rounded-lg shadow-lg">
                <Eye className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                  {t('Third Eye', 'তৃতীয় চোখ')}
                </h1>
                <p className="text-sm text-gray-600 font-medium">
                  {t('Making Roads Safer', 'রাস্তা নিরাপদ করা')}
                </p>
              </div>
              
              {/* Quick Camera Button for instant reporting */}
              <Link
                to="/report"
                className="group relative bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white p-2.5 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 ml-3"
                title={t('Quick Report - Capture Incident', 'দ্রুত রিপোর্ট - ঘটনা ক্যাপচার করুন')}
              >
                <Camera className="w-4 h-4" />
                <div className="absolute inset-0 bg-white/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Pulse animation ring */}
                <div className="absolute -inset-1 bg-red-400 rounded-full opacity-75 animate-ping"></div>
                <div className="absolute -inset-2 bg-red-300 rounded-full opacity-50 animate-ping animation-delay-200"></div>
              </Link>
            </div>
            
            <div className="flex items-center space-x-2">
              <Link
                to="/features"
                className="hidden sm:flex items-center px-2.5 py-1.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-semibold rounded-md hover:from-purple-700 hover:to-pink-700 transition-all duration-200"
              >
                <Star className="w-3 h-3 mr-1" />
                {t('Features', 'বৈশিষ্ট্য')}
              </Link>
              
              <Link
                to="/vehicle-rules"
                className="hidden md:flex items-center px-2.5 py-1.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white text-xs font-semibold rounded-md hover:from-green-700 hover:to-emerald-700 transition-all duration-200"
              >
                <Car className="w-3 h-3 mr-1" />
                {t('Traffic Rules', 'ট্রাফিক নিয়ম')}
              </Link>
              
              <Link
                to="/traffic-fines"
                className="hidden md:flex items-center px-2.5 py-1.5 bg-gradient-to-r from-red-600 to-orange-600 text-white text-xs font-semibold rounded-md hover:from-red-700 hover:to-orange-700 transition-all duration-200"
              >
                <DollarSign className="w-3 h-3 mr-1" />
                {t('Fines', 'জরিমানা')}
              </Link>
              
              <button
                onClick={toggleLanguage}
                className="px-2.5 py-1.5 text-xs font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-all duration-200"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
              
              {user ? (
                <div className="hidden md:flex items-center space-x-2">
                  <Link to="/dashboard" className="flex items-center px-3 py-1.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-sm font-semibold rounded-md hover:from-blue-700 hover:to-blue-800 transition-all duration-200">
                    {t('Dashboard', 'ড্যাশবোর্ড')}
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </Link>
                </div>
              ) : (
                <div className="hidden md:flex items-center space-x-2">
                  <Link to="/signin" className="px-2.5 py-1.5 text-indigo-600 hover:text-indigo-700 font-medium text-sm">
                    {t('Sign In', 'সাইন ইন')}
                  </Link>
                  <Link to="/signup" className="flex items-center px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 text-white text-sm font-semibold rounded-md hover:from-indigo-700 hover:to-blue-700 transition-all duration-200">
                    {t('Sign Up', 'সাইন আপ')}
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="pt-16">
        <div className="relative overflow-hidden">
          {/* Background Gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(99,102,241,0.1),transparent_50%)]"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(59,130,246,0.1),transparent_50%)]"></div>
          
          <div className="relative max-w-7xl mx-auto px-4 py-12">
            <div className="text-center max-w-4xl mx-auto mb-12">
              {/* Hero Logo and Tagline */}
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-4 rounded-xl shadow-lg">
                  <Eye className="w-10 h-10 text-white" />
                </div>
                <div className="text-left">
                  <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                    {t('Third Eye', 'তৃতীয় চোখ')}
                  </h1>
                  <p className="text-base md:text-lg text-gray-600 font-medium">
                    {t('Making Roads Safer', 'রাস্তা নিরাপদ করা')}
                  </p>
                </div>
              </div>
              
              <div className="inline-flex items-center px-3 py-1 bg-gradient-to-r from-indigo-100 to-blue-100 rounded-full text-xs font-medium text-indigo-700 mb-4">
                <Star className="w-3 h-3 mr-1" />
                {t('Trusted by 15,000+ Citizens', '১৫,০০০+ নাগরিকের বিশ্বস্ত')}
              </div>
              
              <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4 leading-tight">
                {t('Report Traffic Violations', 'ট্রাফিক আইন লঙ্ঘন রিপোর্ট করুন')}
                <br />
                <span className="bg-gradient-to-r from-indigo-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {t('Earn Real Money', 'প্রকৃত অর্থ উপার্জন করুন')}
                </span>
                <br />
                <span className="text-base md:text-lg text-gray-700">
                  {t('Save Lives', 'জীবন বাঁচান')}
                </span>
              </h2>
              
              <p className="text-sm text-gray-600 mb-6 leading-relaxed font-medium max-w-3xl mx-auto">
                {t(
                  'Join thousands of citizens making Bangladesh roads safer. Report violations, get verified by traffic officers, and earn 20% commission on fines.',
                  'বাংলাদেশের রাস্তা নিরাপদ করতে হাজার হাজার নাগরিকের সাথে যোগ দিন। আইন লঙ্ঘন রিপোর্ট করুন, ট্রাফিক অফিসারদের দ্বারা যাচাই হন এবং জরিমানার ২০% কমিশন উপার্জন করুন।'
                )}
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 justify-center items-center mb-4">
                {user ? (
                  <Link
                    to="/dashboard"
                    className="group relative inline-flex items-center px-5 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-sm font-semibold rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  >
                    <Shield className="w-4 h-4 mr-2" />
                    {t('Go to Dashboard', 'ড্যাশবোর্ডে যান')}
                    <div className="absolute inset-0 bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </Link>
                ) : (
                  <Link
                    to="/signup"
                    className="group relative inline-flex items-center px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 text-white text-sm font-semibold rounded-lg hover:from-indigo-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  >
                    <Shield className="w-4 h-4 mr-2" />
                    {t('Get Started Now', 'এখনই শুরু করুন')}
                    <div className="absolute inset-0 bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </Link>
                )}
                
                <div className="flex items-center text-gray-600">
                  <Phone className="w-3 h-3 mr-1" />
                  <span className="text-xs">
                    {t('Call 999 for emergencies', 'জরুরি অবস্থায় ৯৯৯ কল করুন')}
                  </span>
                </div>
              </div>

              
            </div>
          </div>
        </div>

        {/* Are You Ready to Make a Difference? Section */}
        <div className="bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 py-16">
          <div className="max-w-5xl mx-auto px-4 text-center">
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-full mb-6 shadow-xl">
                <Camera className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                {t('Are You Ready to Make a Difference?', 'আপনি কি পরিবর্তন আনতে প্রস্তুত?')}
              </h2>
              
              <div className="max-w-4xl mx-auto space-y-4 text-gray-700 leading-relaxed">
                <p className="text-lg md:text-xl">
                  {t('Your report can save lives. Every time you witness a traffic violation—from dangerous acts like wrong-side driving and driving on footpaths to common infractions like illegal horn use or mobile usage while driving—you have the power to prevent a tragedy.',
                     'আপনার রিপোর্ট জীবন বাঁচাতে পারে। প্রতিবারই যখন আপনি একটি ট্রাফিক লঙ্ঘন দেখেন—ভুল দিকে গাড়ি চালানো এবং ফুটপাতে গাড়ি চালানোর মতো বিপজ্জনক কর্ম থেকে শুরু করে অবৈধ হর্ন ব্যবহার বা গাড়ি চালানোর সময় মোবাইল ব্যবহারের মতো সাধারণ লঙ্ঘন পর্যন্ত—আপনার একটি ট্র্যাজেডি প্রতিরোধ করার শক্তি আছে।')}
                </p>
                
                <p className="text-lg md:text-xl">
                  {t('Whether it\'s a speeding vehicle, a helmetless rider, or an illegally parked car causing a jam, your decision to report it protects everyone. Don\'t just be a bystander; become a guardian of your community.',
                     'এটি একটি দ্রুতগামী যানবাহন হোক, হেলমেটবিহীন রাইডার হোক, বা জ্যাম সৃষ্টিকারী একটি অবৈধভাবে পার্ক করা গাড়ি হোক, এটি রিপোর্ট করার আপনার সিদ্ধান্ত সবাইকে রক্ষা করে। শুধু একজন দর্শক হয়ে থাকবেন না; আপনার সম্প্রদায়ের একজন অভিভাবক হয়ে উঠুন।')}
                </p>
                
                <p className="text-xl md:text-2xl font-bold text-red-700 mt-6">
                  {t('Your voice matters.', 'আপনার কণ্ঠস্বর গুরুত্বপূর্ণ।')}
                </p>
                
                <p className="text-lg md:text-xl">
                  {t('Report a traffic violation today and help us build safer, more livable streets where rules are respected and every life is valued.',
                     'আজই একটি ট্রাফিক লঙ্ঘন রিপোর্ট করুন এবং আমাদের নিরাপদ, আরও বাসযোগ্য রাস্তা তৈরি করতে সাহায্য করুন যেখানে নিয়ম মানা হয় এবং প্রতিটি জীবনকে মূল্য দেওয়া হয়।')}
                </p>
              </div>
              
              <div className="mt-10">
                <Link
                  to="/report"
                  className="inline-flex items-center px-10 py-4 bg-gradient-to-r from-red-600 to-red-700 text-white text-lg font-bold rounded-2xl hover:from-red-700 hover:to-red-800 transition-all transform hover:scale-105 shadow-2xl"
                >
                  <Camera className="w-6 h-6 mr-3" />
                  {t('Report for Safer Roads', 'নিরাপদ রাস্তার জন্য রিপোর্ট করুন')}
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Stand Against Social Crimes Section */}
        <div className="bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-16 text-white">
          <div className="max-w-5xl mx-auto px-4 text-center">
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full mb-6 shadow-xl">
                <Shield className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                {t('Stand Against Social Crimes', 'সামাজিক অপরাধের বিরুদ্ধে দাঁড়ান')}
              </h2>
              
              <div className="max-w-4xl mx-auto space-y-4 text-purple-100 leading-relaxed">
                <p className="text-lg md:text-xl">
                  {t('Your courage can save lives. In our society, silence only enables injustice. When you witness violence, murder, theft, fighting, corruption, extortion, robbery, drug abuse, sexual harassment, or youth gang activities, do not look away. Your anonymous report becomes a vital shield for the vulnerable and a powerful weapon for justice.',
                     'আপনার সাহস জীবন বাঁচাতে পারে। আমাদের সমাজে, নীরবতা কেবল অন্যায়কে সক্ষম করে। যখন আপনি সহিংসতা, হত্যা, চুরি, মারামারি, দুর্নীতি, চাঁদাবাজি, ডাকাতি, মাদকের অপব্যবহার, যৌন হয়রানি, বা যুব গ্যাং কার্যক্রম দেখেন, তখন চোখ ফেরিয়ে নিবেন না। আপনার বেনামী রিপোর্ট দুর্বলদের জন্য একটি গুরুত্বপূর্ণ ঢাল এবং ন্যায়বিচারের জন্য একটি শক্তিশালী অস্ত্র হয়ে ওঠে।')}
                </p>
                
                <p className="text-lg md:text-xl font-semibold text-yellow-300">
                  {t('Remember: every crime unreported is an opportunity stolen from justice. Every act of violence ignored is a wound on our community\'s soul.',
                     'মনে রাখবেন: প্রতিটি রিপোর্ট না করা অপরাধ হলো ন্যায়বিচার থেকে চুরি করা একটি সুযোগ। প্রতিটি উপেক্ষিত সহিংসতার ঘটনা আমাদের সমাজের আত্মায় একটি ক্ষত।')}
                </p>
                
                <p className="text-lg md:text-xl">
                  {t('But when you choose to speak up—anonymously and safely—you become the guardian our society needs. You are the one who breaks the cycle of fear.',
                     'কিন্তু যখন আপনি কথা বলতে পছন্দ করেন—বেনামীভাবে এবং নিরাপদে—আপনি আমাদের সমাজের প্রয়োজনীয় অভিভাবক হয়ে ওঠেন। আপনিই সেই ব্যক্তি যিনি ভয়ের চক্র ভাঙেন।')}
                </p>
                
                <p className="text-xl md:text-2xl font-bold text-yellow-400 mt-6">
                  {t('Be the Change. Report Confidentially.', 'পরিবর্তন হন। গোপনীয়তার সাথে রিপোর্ট করুন।')}
                </p>
                
                <p className="text-lg md:text-xl">
                  {t('Your identity will always be protected, but your impact will echo for generations. Together, we can build a Bangladesh free from fear, where safety is not a privilege but a fundamental right for all.',
                     'আপনার পরিচয় সর্বদা সুরক্ষিত থাকবে, কিন্তু আপনার প্রভাব প্রজন্মের পর প্রজন্ম প্রতিধ্বনিত হবে। একসাথে, আমরা ভয়মুক্ত একটি বাংলাদেশ গড়তে পারি, যেখানে নিরাপত্তা একটি বিশেষাধিকার নয় বরং সবার জন্য একটি মৌলিক অধিকার।')}
                </p>
                
                <p className="text-lg md:text-xl font-semibold text-purple-200">
                  {t('Don\'t stay silent. Your action today creates a safer tomorrow.',
                     'নীরব থাকবেন না। আপনার আজকের কর্ম একটি নিরাপদ আগামীকাল তৈরি করে।')}
                </p>
              </div>
              
              <div className="mt-10">
                <Link
                  to="/social-crime"
                  className="inline-flex items-center px-10 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-lg font-bold rounded-2xl hover:from-purple-700 hover:to-purple-800 transition-all transform hover:scale-105 shadow-2xl border-2 border-purple-400 hover:border-purple-300"
                >
                  <Shield className="w-6 h-6 mr-3" />
                  {t('Report Social Crime Anonymously', 'সামাজিক অপরাধ বেনামে রিপোর্ট করুন')}
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        

        {/* Emergency Contacts Section */}
        <div className="bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 py-12">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-6">
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">
                {t('Emergency Contacts', 'জরুরি যোগাযোগ')}
              </h3>
              <p className="text-sm text-gray-600">
                {t('Quick access to all Bangladesh emergency services', 'বাংলাদেশের সকল জরুরি সেবায় দ্রুত প্রবেশাধিকার')}
              </p>
            </div>
            <HierarchicalEmergencyContacts />
          </div>
        </div>

        </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-4 mb-4">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-2">
                <div className="bg-gradient-to-br from-indigo-600 to-blue-600 p-1.5 rounded-md">
                  <Eye className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="text-base font-bold">{t('Third Eye', 'তৃতীয় চোখ')}</h4>
                  <p className="text-gray-400 text-xs">{t('Making Roads Safer', 'রাস্তা নিরাপদ করা')}</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed max-w-md text-sm">
                {t(
                  'Empowering citizens to report traffic violations and earn rewards while making Bangladesh roads safer for everyone.',
                  'নাগরিকদের ট্রাফিক আইন লঙ্ঘন রিপোর্ট করতে এবং সবার জন্য বাংলাদেশের রাস্তা নিরাপদ করার সময় পুরস্কার অর্জন করতে ক্ষমতায়ন।'
                )}
              </p>
            </div>
            
            <div>
              <h5 className="font-semibold mb-2 text-sm">{t('Quick Links', 'দ্রুত লিঙ্ক')}</h5>
              <ul className="space-y-1 text-gray-400 text-sm">
                <li><Link to="/signup" className="hover:text-white transition-colors">{t('Get Started', 'শুরু করুন')}</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">{t('How it Works', 'কিভাবে কাজ করে')}</a></li>
                <li><a href="#" className="hover:text-white transition-colors">{t('Violations', 'আইন লঙ্ঘন')}</a></li>
                <li><a href="#" className="hover:text-white transition-colors">{t('Rewards', 'পুরস্কার')}</a></li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold mb-2 text-sm">{t('Emergency', 'জরুরি')}</h5>
              <ul className="space-y-1 text-gray-400 text-sm">
                <li className="flex items-center">
                  <Phone className="w-3 h-3 mr-1" />
                  <span>999 - {t('Police', 'পুলিশ')}</span>
                </li>
                <li className="flex items-center">
                  <Phone className="w-3 h-3 mr-1" />
                  <span>102 - {t('Fire Service', 'ফায়ার সার্ভিস')}</span>
                </li>
                <li className="flex items-center">
                  <Phone className="w-3 h-3 mr-1" />
                  <span>16263 - {t('Traffic Police', 'ট্রাফিক পুলিশ')}</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-4 text-center">
            <p className="text-gray-400 text-sm">
              {t(
                '© 2025 Third Eye. Making Bangladesh roads safer through community participation.',
                '© ২০২৫ তৃতীয় চোখ। কমিউনিটি অংশগ্রহণের মাধ্যমে বাংলাদেশের রাস্তা নিরাপদ করা।'
              )}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
