import { useState, useEffect } from 'react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { 
  User, 
  Lock, 
  Bell, 
  Shield, 
  LogOut,
  Camera,
  Edit3,
  Save,
  X,
  Mail,
  Phone,
  AlertCircle,
  CheckCircle,
  Trash2,
  UserX
} from 'lucide-react';
import BackButton from '@/react-app/components/BackButton';

export default function Settings() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'profile' | 'password' | 'notifications' | 'privacy' | 'account'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  // Profile form
  const [profileForm, setProfileForm] = useState({
    full_name: '',
    phone_number: '',
    profile_picture: '',
  });

  // Password change form
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: '',
    otp_code: '',
  });
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  // Notifications form
  const [notificationSettings, setNotificationSettings] = useState({
    case_updates: true,
    payment_alerts: true,
    security_alerts: true,
    marketing: false,
  });

  // Privacy form
  const [privacySettings, setPrivacySettings] = useState({
    profile_visibility: 'public',
    show_statistics: true,
    data_sharing: false,
  });

  useEffect(() => {
    if (user) {
      setProfileForm({
        full_name: user.full_name || '',
        phone_number: user.mobile_number || '',
        profile_picture: '',
      });
    }
  }, [user]);

  useEffect(() => {
    if (otpTimer > 0) {
      const timer = setTimeout(() => setOtpTimer(otpTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [otpTimer]);

  const handleProfileUpdate = async () => {
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await fetch('/api/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(profileForm),
      });

      if (response.ok) {
        setMessage({ type: 'success', text: t('Profile updated successfully', 'প্রোফাইল সফলভাবে আপডেট হয়েছে') });
        setIsEditing(false);
      } else {
        throw new Error('Update failed');
      }
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to update profile', 'প্রোফাইল আপডেট ব্যর্থ হয়েছে') });
    } finally {
      setLoading(false);
    }
  };

  const handleSendOTP = async () => {
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await fetch('/api/auth/send-password-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
      });

      if (response.ok) {
        setOtpSent(true);
        setOtpTimer(120); // 2 minutes
        setMessage({ type: 'success', text: t('OTP sent to your mobile/email', 'OTP আপনার মোবাইল/ইমেলে পাঠানো হয়েছে') });
      } else {
        throw new Error('Failed to send OTP');
      }
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to send OTP', 'OTP পাঠাতে ব্যর্থ') });
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      setMessage({ type: 'error', text: t('Passwords do not match', 'পাসওয়ার্ড মিলছে না') });
      return;
    }

    if (passwordForm.new_password.length < 8) {
      setMessage({ type: 'error', text: t('Password must be at least 8 characters', 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে') });
      return;
    }

    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          current_password: passwordForm.current_password,
          new_password: passwordForm.new_password,
          otp_code: passwordForm.otp_code,
        }),
      });

      if (response.ok) {
        setMessage({ type: 'success', text: t('Password changed successfully', 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে') });
        setPasswordForm({ current_password: '', new_password: '', confirm_password: '', otp_code: '' });
        setOtpSent(false);
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Password change failed');
      }
    } catch (error) {
      setMessage({ type: 'error', text: error instanceof Error ? error.message : t('Failed to change password', 'পাসওয়ার্ড পরিবর্তন ব্যর্থ') });
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivateAccount = async () => {
    if (!confirm(t('Are you sure you want to deactivate your account temporarily?', 'আপনি কি নিশ্চিত যে আপনি আপনার অ্যাকাউন্ট অস্থায়ীভাবে নিষ্ক্রিয় করতে চান?'))) {
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/account/deactivate', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        setMessage({ type: 'success', text: t('Account deactivated. You will be logged out.', 'অ্যাকাউন্ট নিষ্ক্রিয়। আপনি লগআউট হবেন।') });
        setTimeout(() => logout(), 2000);
      }
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to deactivate account', 'অ্যাকাউন্ট নিষ্ক্রিয় করতে ব্যর্থ') });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    const confirmText = prompt(t('Type "DELETE" to permanently delete your account', 'আপনার অ্যাকাউন্ট স্থায়ীভাবে মুছতে "DELETE" টাইপ করুন'));
    
    if (confirmText !== 'DELETE') {
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/account/delete', {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        setMessage({ type: 'success', text: t('Account deleted permanently', 'অ্যাকাউন্ট স্থায়ীভাবে মুছে ফেলা হয়েছে') });
        setTimeout(() => logout(), 2000);
      }
    } catch (error) {
      setMessage({ type: 'error', text: t('Failed to delete account', 'অ্যাকাউন্ট মুছতে ব্যর্থ') });
    } finally {
      setLoading(false);
    }
  };

  const handleProfilePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In production, upload to cloud storage
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileForm({ ...profileForm, profile_picture: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const tabs = [
    { id: 'profile', name: t('Edit Profile', 'প্রোফাইল সম্পাদনা'), icon: User },
    { id: 'password', name: t('Change Password', 'পাসওয়ার্ড পরিবর্তন'), icon: Lock },
    { id: 'notifications', name: t('Notification Settings', 'বিজ্ঞপ্তি সেটিংস'), icon: Bell },
    { id: 'privacy', name: t('Privacy & Security', 'গোপনীয়তা ও নিরাপত্তা'), icon: Shield },
    { id: 'account', name: t('Account Management', 'অ্যাকাউন্ট ব্যবস্থাপনা'), icon: AlertCircle },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center space-x-4">
            <BackButton to="/dashboard" className="p-2 hover:bg-gray-100 rounded-lg" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {t('Settings', 'সেটিংস')}
              </h1>
              <p className="text-sm text-gray-600">
                {t('Manage your account preferences', 'আপনার অ্যাকাউন্ট পছন্দসমূহ পরিচালনা করুন')}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Message Display */}
        {message.text && (
          <div className={`mb-6 p-4 rounded-xl ${
            message.type === 'success' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center">
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 mr-3" />
              )}
              <span className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
                {message.text}
              </span>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Sidebar Tabs */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                        activeTab === tab.id
                          ? 'bg-indigo-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium text-sm">{tab.name}</span>
                    </button>
                  );
                })}
              </nav>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={logout}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium text-sm">{t('Logout', 'লগআউট')}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
              {/* Edit Profile Tab */}
              {activeTab === 'profile' && (
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">
                      {t('Edit Profile', 'প্রোফাইল সম্পাদনা')}
                    </h2>
                    {!isEditing ? (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                      >
                        <Edit3 className="w-4 h-4" />
                        <span>{t('Edit', 'সম্পাদনা')}</span>
                      </button>
                    ) : (
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setIsEditing(false)}
                          className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
                        >
                          <X className="w-5 h-5" />
                        </button>
                        <button
                          onClick={handleProfileUpdate}
                          disabled={loading}
                          className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                        >
                          <Save className="w-4 h-4" />
                          <span>{t('Save', 'সংরক্ষণ')}</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Profile Picture */}
                  <div className="flex items-center space-x-6 mb-8">
                    <div className="relative">
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold overflow-hidden">
                        {profileForm.profile_picture ? (
                          <img src={profileForm.profile_picture} alt="Profile" className="w-full h-full object-cover" />
                        ) : (
                          user?.full_name?.charAt(0) || 'U'
                        )}
                      </div>
                      {isEditing && (
                        <label className="absolute bottom-0 right-0 bg-white p-2 rounded-full shadow-lg cursor-pointer hover:bg-gray-100">
                          <Camera className="w-4 h-4 text-gray-600" />
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleProfilePictureUpload}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{user?.full_name}</h3>
                      <p className="text-gray-600">{user?.email || user?.mobile_number}</p>
                    </div>
                  </div>

                  {/* Form Fields */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Full Name', 'পুরো নাম')}
                      </label>
                      <input
                        type="text"
                        value={profileForm.full_name}
                        onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                        disabled={!isEditing}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-gray-50"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Phone Number', 'ফোন নম্বর')}
                      </label>
                      <div className="flex items-center space-x-3 px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg">
                        <Phone className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-700">{profileForm.phone_number}</span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Email Address', 'ইমেল ঠিকানা')}
                      </label>
                      <div className="flex items-center space-x-3 px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg">
                        <Mail className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-700">{user?.email || t('Not provided', 'প্রদান করা হয়নি')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Change Password Tab */}
              {activeTab === 'password' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    {t('Change Password', 'পাসওয়ার্ড পরিবর্তন')}
                  </h2>

                  <form onSubmit={handlePasswordChange} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Current Password', 'বর্তমান পাসওয়ার্ড')}
                      </label>
                      <input
                        type="password"
                        value={passwordForm.current_password}
                        onChange={(e) => setPasswordForm({ ...passwordForm, current_password: e.target.value })}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('New Password', 'নতুন পাসওয়ার্ড')}
                      </label>
                      <input
                        type="password"
                        value={passwordForm.new_password}
                        onChange={(e) => setPasswordForm({ ...passwordForm, new_password: e.target.value })}
                        required
                        minLength={8}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        {t('Must be at least 8 characters with uppercase, lowercase, number and symbol', 'কমপক্ষে ৮ অক্ষর, বড় হাতের, ছোট হাতের, সংখ্যা এবং প্রতীক থাকতে হবে')}
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Confirm New Password', 'নতুন পাসওয়ার্ড নিশ্চিত করুন')}
                      </label>
                      <input
                        type="password"
                        value={passwordForm.confirm_password}
                        onChange={(e) => setPasswordForm({ ...passwordForm, confirm_password: e.target.value })}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>

                    {!otpSent ? (
                      <button
                        type="button"
                        onClick={handleSendOTP}
                        disabled={loading}
                        className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:opacity-50"
                      >
                        {loading ? t('Sending...', 'পাঠানো হচ্ছে...') : t('Send OTP', 'OTP পাঠান')}
                      </button>
                    ) : (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            {t('Enter OTP', 'OTP লিখুন')}
                          </label>
                          <input
                            type="text"
                            value={passwordForm.otp_code}
                            onChange={(e) => setPasswordForm({ ...passwordForm, otp_code: e.target.value })}
                            required
                            maxLength={6}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="000000"
                          />
                          <p className="mt-1 text-xs text-gray-500">
                            {otpTimer > 0 
                              ? t(`Code expires in ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')}`, 
                                  `কোডের মেয়াদ ${Math.floor(otpTimer / 60)}:${(otpTimer % 60).toString().padStart(2, '0')}`)
                              : t('Code expired', 'কোডের মেয়াদ শেষ')
                            }
                          </p>
                        </div>

                        <div className="flex space-x-4">
                          <button
                            type="button"
                            onClick={handleSendOTP}
                            disabled={loading || otpTimer > 0}
                            className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 disabled:opacity-50"
                          >
                            {t('Resend OTP', 'OTP পুনরায় পাঠান')}
                          </button>
                          <button
                            type="submit"
                            disabled={loading}
                            className="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:opacity-50"
                          >
                            {loading ? t('Changing...', 'পরিবর্তন করা হচ্ছে...') : t('Change Password', 'পাসওয়ার্ড পরিবর্তন করুন')}
                          </button>
                        </div>
                      </>
                    )}
                  </form>
                </div>
              )}

              {/* Notification Settings Tab */}
              {activeTab === 'notifications' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    {t('Notification Settings', 'বিজ্ঞপ্তি সেটিংস')}
                  </h2>

                  <div className="space-y-6">
                    {Object.entries(notificationSettings).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {t(
                              key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
                              key
                            )}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {t(`Receive notifications for ${key.replace('_', ' ')}`, `${key.replace('_', ' ')} এর জন্য বিজ্ঞপ্তি পান`)}
                          </p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={value}
                            onChange={(e) => setNotificationSettings({ ...notificationSettings, [key]: e.target.checked })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setMessage({ type: 'success', text: t('Notification settings saved', 'বিজ্ঞপ্তি সেটিংস সংরক্ষিত') })}
                    className="mt-6 w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
                  >
                    {t('Save Settings', 'সেটিংস সংরক্ষণ করুন')}
                  </button>
                </div>
              )}

              {/* Privacy & Security Tab */}
              {activeTab === 'privacy' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    {t('Privacy & Security', 'গোপনীয়তা ও নিরাপত্তা')}
                  </h2>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('Profile Visibility', 'প্রোফাইল দৃশ্যমানতা')}
                      </label>
                      <select
                        value={privacySettings.profile_visibility}
                        onChange={(e) => setPrivacySettings({ ...privacySettings, profile_visibility: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      >
                        <option value="public">{t('Public', 'সর্বজনীন')}</option>
                        <option value="private">{t('Private', 'ব্যক্তিগত')}</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {t('Show Statistics', 'পরিসংখ্যান দেখান')}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {t('Display your report statistics publicly', 'আপনার রিপোর্ট পরিসংখ্যান সর্বজনীনভাবে প্রদর্শন করুন')}
                        </p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={privacySettings.show_statistics}
                          onChange={(e) => setPrivacySettings({ ...privacySettings, show_statistics: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {t('Data Sharing', 'ডেটা শেয়ারিং')}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {t('Share anonymized data for research', 'গবেষণার জন্য বেনামী ডেটা শেয়ার করুন')}
                        </p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={privacySettings.data_sharing}
                          onChange={(e) => setPrivacySettings({ ...privacySettings, data_sharing: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </label>
                    </div>
                  </div>

                  <button
                    onClick={() => setMessage({ type: 'success', text: t('Privacy settings saved', 'গোপনীয়তা সেটিংস সংরক্ষিত') })}
                    className="mt-6 w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
                  >
                    {t('Save Settings', 'সেটিংস সংরক্ষণ করুন')}
                  </button>
                </div>
              )}

              {/* Account Management Tab */}
              {activeTab === 'account' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    {t('Account Management', 'অ্যাকাউন্ট ব্যবস্থাপনা')}
                  </h2>

                  <div className="space-y-6">
                    {/* Deactivate Account */}
                    <div className="border border-yellow-200 bg-yellow-50 rounded-lg p-6">
                      <div className="flex items-start space-x-4">
                        <UserX className="w-6 h-6 text-yellow-600 mt-1" />
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-gray-900 mb-2">
                            {t('Deactivate Account', 'অ্যাকাউন্ট নিষ্ক্রিয় করুন')}
                          </h3>
                          <p className="text-sm text-gray-700 mb-4">
                            {t('Temporarily deactivate your account. You can reactivate it anytime by logging in again.', 'আপনার অ্যাকাউন্ট অস্থায়ীভাবে নিষ্ক্রিয় করুন। আপনি যেকোনো সময় আবার লগইন করে এটি পুনরায় সক্রিয় করতে পারেন।')}
                          </p>
                          <button
                            onClick={handleDeactivateAccount}
                            disabled={loading}
                            className="bg-yellow-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-yellow-700 disabled:opacity-50"
                          >
                            {t('Deactivate', 'নিষ্ক্রিয় করুন')}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Delete Account */}
                    <div className="border border-red-200 bg-red-50 rounded-lg p-6">
                      <div className="flex items-start space-x-4">
                        <Trash2 className="w-6 h-6 text-red-600 mt-1" />
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-gray-900 mb-2">
                            {t('Delete Account Permanently', 'অ্যাকাউন্ট স্থায়ীভাবে মুছুন')}
                          </h3>
                          <p className="text-sm text-gray-700 mb-2">
                            {t('Permanently delete your account and all associated data. This action cannot be undone.', 'আপনার অ্যাকাউন্ট এবং সমস্ত সংশ্লিষ্ট ডেটা স্থায়ীভাবে মুছে ফেলুন। এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।')}
                          </p>
                          <div className="bg-white border border-red-200 rounded-lg p-4 mb-4">
                            <p className="text-sm font-semibold text-red-900 mb-2">
                              {t('What will be deleted:', 'যা মুছে ফেলা হবে:')}
                            </p>
                            <ul className="text-xs text-red-800 space-y-1">
                              <li>• {t('All your personal information', 'আপনার সমস্ত ব্যক্তিগত তথ্য')}</li>
                              <li>• {t('All submitted reports and cases', 'সমস্ত জমা দেওয়া রিপোর্ট এবং কেস')}</li>
                              <li>• {t('Earning history and statistics', 'উপার্জন ইতিহাস এবং পরিসংখ্যান')}</li>
                              <li>• {t('Account cannot be recovered', 'অ্যাকাউন্ট পুনরুদ্ধার করা যাবে না')}</li>
                            </ul>
                          </div>
                          <button
                            onClick={handleDeleteAccount}
                            disabled={loading}
                            className="bg-red-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-red-700 disabled:opacity-50"
                          >
                            {t('Delete Permanently', 'স্থায়ীভাবে মুছুন')}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Logout */}
                    <div className="border border-gray-200 bg-gray-50 rounded-lg p-6">
                      <div className="flex items-start space-x-4">
                        <LogOut className="w-6 h-6 text-gray-600 mt-1" />
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-gray-900 mb-2">
                            {t('Logout', 'লগআউট')}
                          </h3>
                          <p className="text-sm text-gray-700 mb-4">
                            {t('Sign out from your account on this device.', 'এই ডিভাইসে আপনার অ্যাকাউন্ট থেকে সাইন আউট করুন।')}
                          </p>
                          <button
                            onClick={logout}
                            className="bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-gray-700"
                          >
                            {t('Logout Now', 'এখনই লগআউট করুন')}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
