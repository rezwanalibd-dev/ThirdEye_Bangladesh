import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useLanguage } from '@/react-app/contexts/LanguageContext';

interface BackButtonProps {
  to?: string;
  label?: string;
  className?: string;
  onClick?: () => void;
}

export default function BackButton({ 
  to, 
  label, 
  className = "p-2 hover:bg-gray-100 rounded-lg transition-colors",
  onClick 
}: BackButtonProps) {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (to) {
      navigate(to);
    } else {
      navigate(-1);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={className}
      title={label || t('Go back', 'ফিরে যান')}
    >
      <ArrowLeft className="w-6 h-6" />
      {label && <span className="ml-2">{label}</span>}
    </button>
  );
}
