import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { EMERGENCY_CONTACTS } from '@/shared/constants';
import { Phone, ExternalLink } from 'lucide-react';

export default function EmergencyContactCard() {
  const { t } = useLanguage();

  const handleCall = (number: string) => {
    window.open(`tel:${number}`, '_self');
  };

  const getCategoryColor = (categoryType: string) => {
    switch (categoryType) {
      case 'urgent_emergency':
        return 'from-red-500 to-red-600';
      case 'law_enforcement':
        return 'from-blue-500 to-blue-600';
      case 'social_protection':
        return 'from-pink-500 to-pink-600';
      case 'health_medical':
        return 'from-green-500 to-green-600';
      case 'transport_utilities':
        return 'from-yellow-500 to-orange-500';
      case 'disaster_crisis':
        return 'from-purple-500 to-purple-600';
      case 'government_services':
        return 'from-gray-500 to-gray-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getCategoryIcon = (categoryType: string) => {
    switch (categoryType) {
      case 'urgent_emergency':
        return '🆘';
      case 'law_enforcement':
        return '👮';
      case 'social_protection':
        return '👩‍👧‍👦';
      case 'health_medical':
        return '🏥';
      case 'transport_utilities':
        return '🚗';
      case 'disaster_crisis':
        return '🌪️';
      case 'government_services':
        return '⚖️';
      default:
        return '📞';
    }
  };

  const getCategoryTitle = (categoryType: string) => {
    switch (categoryType) {
      case 'urgent_emergency':
        return t('Emergency 24/7', 'জরুরি ২৪/৭');
      case 'law_enforcement':
        return t('LAW ENFORCEMENT & SECURITY', 'আইন প্রয়োগকারী ও নিরাপত্তা');
      case 'social_protection':
        return t('SOCIAL PROTECTION', 'সামাজিক সুরক্ষা');
      case 'health_medical':
        return t('HEALTH & MEDICAL', 'স্বাস্থ্য ও চিকিৎসা');
      case 'transport_utilities':
        return t('TRANSPORT & UTILITIES', 'পরিবহন ও ইউটিলিটি');
      case 'disaster_crisis':
        return t('DISASTER & CRISIS', 'দুর্যোগ ও সংকট');
      case 'government_services':
        return t('GOVERNMENT SERVICES', 'সরকারি সেবা');
      default:
        return t('Emergency Services', 'জরুরি সেবা');
    }
  };

  const emergencyCategories = [
    { key: 'urgent_emergency', contacts: EMERGENCY_CONTACTS.urgent_emergency },
    { key: 'law_enforcement', contacts: EMERGENCY_CONTACTS.law_enforcement },
    { key: 'social_protection', contacts: EMERGENCY_CONTACTS.social_protection },
    { key: 'health_medical', contacts: EMERGENCY_CONTACTS.health_medical },
    { key: 'transport_utilities', contacts: EMERGENCY_CONTACTS.transport_utilities },
    { key: 'disaster_crisis', contacts: EMERGENCY_CONTACTS.disaster_crisis },
    { key: 'government_services', contacts: EMERGENCY_CONTACTS.government_services }
  ];

  return (
    <div className="card-base p-6 md:p-8">
      <div className="flex items-center space-x-4 mb-8">
        <div className="icon-danger">
          <Phone className="w-7 h-7 md:w-8 md:h-8" />
        </div>
        <div>
          <h3 className="text-display-3 text-gray-900 font-bold">
            <span className="text-xl mr-2">🚨</span>
            {t('OFFICIAL EMERGENCY CONTACT NUMBERS - BANGLADESH', 'অফিসিয়াল জরুরি যোগাযোগ নম্বর - বাংলাদেশ')}
          </h3>
          <p className="text-body text-gray-600 font-medium">
            {t('Tap to call instantly', 'তাৎক্ষণিক কল করতে ট্যাপ করুন')}
          </p>
        </div>
      </div>
      
      <div className="space-section">
        {emergencyCategories.map((category) => (
          <div key={category.key} className="space-content">
            {/* Category Header */}
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{getCategoryIcon(category.key)}</span>
              <h4 className="text-heading-1 text-gray-900 font-bold uppercase tracking-wide">
                {getCategoryTitle(category.key)}
              </h4>
            </div>
            
            {/* Category Contacts */}
            <div className={`grid ${
              category.key === 'urgent_emergency' || category.key === 'transport_utilities' 
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' 
                : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
            } gap-4 md:gap-6`}>
              {category.contacts.map((contact, index) => (
                <button
                  key={index}
                  onClick={() => handleCall(contact.number)}
                  className={`
                    w-full flex flex-col items-center justify-center p-5 md:p-6 rounded-2xl transition-all duration-200 
                    hover:shadow-strong active:scale-95 border-2 border-transparent touch-target
                    bg-gradient-to-r ${getCategoryColor(category.key)} text-white
                    hover:border-white/30 min-h-32 md:min-h-36 focus:outline-none focus:ring-4 focus:ring-white/50
                  `}
                >
                  <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm mb-4 border border-white/30">
                    <span className="text-xl md:text-2xl">{contact.icon}</span>
                  </div>
                  
                  <div className="text-center flex-1 space-y-2">
                    <p className="text-xl md:text-2xl font-bold text-white">
                      {contact.number}
                    </p>
                    <p className="text-base md:text-lg font-semibold text-white/95">
                      {t(contact.name_en, contact.name_bn)}
                    </p>
                    <p className="text-sm md:text-base text-white/85 leading-snug">
                      {t(contact.description_en, contact.description_bn)}
                    </p>
                  </div>
                  
                  <div className="mt-3 flex items-center justify-center">
                    <ExternalLink className="w-4 h-4 text-white/80" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Reference Card */}
      <div className="mt-10 p-6 bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 rounded-2xl">
        <div className="flex items-start space-x-4">
          <div className="icon-danger p-2">
            <span className="text-xl">🆘</span>
          </div>
          <div className="flex-1">
            <h4 className="text-heading-1 text-red-900 font-bold mb-4">
              {t('QUICK REFERENCE CARD', 'দ্রুত রেফারেন্স কার্ড')}
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
              {[
                { number: '999', label: t('MAIN EMERGENCY', 'মূল জরুরি'), color: 'bg-red-600 hover:bg-red-700' },
                { number: '199', label: t('FIRE & AMBULANCE', 'ফায়ার ও অ্যাম্বুলেন্স'), color: 'bg-orange-600 hover:bg-orange-700' },
                { number: '109', label: t('WOMEN & CHILDREN', 'নারী ও শিশু'), color: 'bg-pink-600 hover:bg-pink-700' },
                { number: '16263', label: t('HEALTH & BRTA', 'স্বাস্থ্য ও বিআরটিএ'), color: 'bg-blue-600 hover:bg-blue-700' },
                { number: '1090', label: t('DISASTER MGMT', 'দুর্যোগ ব্যবস্থাপনা'), color: 'bg-yellow-600 hover:bg-yellow-700' },
                { number: '01713090411', label: t('RAB EMERGENCY', 'র‍্যাব জরুরি'), color: 'bg-purple-600 hover:bg-purple-700' }
              ].map((item, index) => (
                <button
                  key={index}
                  onClick={() => handleCall(item.number)}
                  className={`${item.color} text-white p-3 md:p-4 rounded-xl transition-all duration-200 text-center touch-target active:scale-95 focus:outline-none focus:ring-2 focus:ring-white`}
                >
                  <div className="text-base md:text-lg font-bold">{item.number}</div>
                  <div className="text-xs md:text-sm mt-1">{item.label}</div>
                </button>
              ))}
            </div>
            <p className="text-body font-bold text-red-700 text-center bg-white/50 rounded-xl p-3">
              {t('SAVE THESE NUMBERS! CALL 999 FIRST!', 'এই নম্বরগুলো সেভ করুন! প্রথমে ৯৯৯ কল করুন!')}
            </p>
          </div>
        </div>
      </div>

      {/* Usage Instructions */}
      <div className="mt-8 p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl">
        <div className="flex items-start space-x-4">
          <div className="icon-primary p-2">
            <span className="text-xl">📱</span>
          </div>
          <div className="flex-1">
            <h4 className="text-heading-1 text-blue-900 font-bold mb-4">
              {t('HOW TO USE EMERGENCY NUMBERS', 'জরুরি নম্বর কীভাবে ব্যবহার করবেন')}
            </h4>
            <div className="space-content">
              <div className="bg-white/80 rounded-xl p-4 border border-blue-200">
                <h5 className="text-heading-2 text-red-600 font-bold mb-2">{t('For Life-Threatening Emergencies:', 'জীবন-মৃত্যুর জরুরি অবস্থায়:')}</h5>
                <p className="text-body text-gray-700 font-medium">{t('DIAL 999 FIRST - This is the integrated emergency number', '৯৯৯ প্রথমে ডায়াল করুন - এটি সমন্বিত জরুরি নম্বর')}</p>
              </div>
              <div className="bg-white/80 rounded-xl p-4 border border-blue-200">
                <h5 className="text-heading-2 text-blue-600 font-bold mb-3">{t('Important Tips:', 'গুরুত্বপূর্ণ টিপস:')}</h5>
                <ul className="space-y-2 text-body text-gray-700">
                  <li className="flex items-start space-x-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{t('Save these numbers in your phone contacts', 'এই নম্বরগুলো আপনার ফোন কন্টাক্টে সেভ করুন')}</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{t('Speak clearly and provide accurate location', 'স্পষ্টভাবে কথা বলুন এবং সঠিক অবস্থান প্রদান করুন')}</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{t('Don\'t hang up until operator has all information', 'অপারেটর সব তথ্য না পাওয়া পর্যন্ত ফোন কাটবেন না')}</span>
                  </li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 text-center">
                <p className="text-body-small text-gray-600 leading-relaxed">{t('All toll-free numbers work from any mobile or landline in Bangladesh at no cost.', 'সমস্ত টোল-ফ্রি নম্বর বাংলাদেশের যেকোনো মোবাইল বা ল্যান্ডলাইন থেকে বিনামূল্যে কাজ করে।')}</p>
                <p className="text-body-small font-semibold text-gray-700 mt-2">{t('Last Verified: November 2025 | Source: Bangladesh Government Official Directories', 'সর্বশেষ যাচাই: নভেম্বর ২০২৫ | সূত্র: বাংলাদেশ সরকারের অফিসিয়াল ডিরেক্টরি')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
