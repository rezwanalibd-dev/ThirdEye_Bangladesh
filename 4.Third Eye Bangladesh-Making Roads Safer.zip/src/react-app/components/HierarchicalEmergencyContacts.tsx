import { useState } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { Phone, ChevronDown, ChevronUp } from 'lucide-react';

interface EmergencyContact {
  number: string;
  name_en: string;
  name_bn: string;
  description_en: string;
  description_bn: string;
  icon?: string;
}

interface EmergencyCategory {
  key: string;
  icon: string;
  title_en: string;
  title_bn: string;
  contacts: EmergencyContact[];
}

export default function HierarchicalEmergencyContacts() {
  const { t } = useLanguage();
  const [isMainExpanded, setIsMainExpanded] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const handleCall = (number: string) => {
    window.open(`tel:${number}`, '_self');
  };

  const emergencyCategories: EmergencyCategory[] = [
    {
      key: 'emergency_24_7',
      icon: '🆘',
      title_en: 'Emergency 24/7',
      title_bn: 'জরুরি ২৪/৭',
      contacts: [
        {
          number: '999',
          name_en: 'Police/Fire/Ambulance',
          name_bn: 'পুলিশ/ফায়ার/অ্যাম্বুলেন্স',
          description_en: 'MAIN EMERGENCY',
          description_bn: 'মূল জরুরি',
        },
        {
          number: '199',
          name_en: 'Fire Service',
          name_bn: 'ফায়ার সার্ভিস',
          description_en: 'Fire & Rescue',
          description_bn: 'অগ্নিনির্বাপণ ও উদ্ধার',
        },
        {
          number: '199',
          name_en: 'Ambulance',
          name_bn: 'অ্যাম্বুলেন্স',
          description_en: 'Medical Emergency',
          description_bn: 'চিকিৎসা জরুরি',
        },
        {
          number: '16263',
          name_en: 'Health Helpline',
          name_bn: 'স্বাস্থ্য হেল্পলাইন',
          description_en: 'Alternative Medical',
          description_bn: 'বিকল্প চিকিৎসা',
        }
      ]
    },
    {
      key: 'law_enforcement',
      icon: '👮',
      title_en: 'LAW ENFORCEMENT & SECURITY',
      title_bn: 'আইন প্রয়োগকারী ও নিরাপত্তা',
      contacts: [
        {
          number: '01713-090411',
          name_en: 'RAB Emergency',
          name_bn: 'র‍্যাব জরুরি',
          description_en: 'Terrorism/Serious Crimes',
          description_bn: 'সন্ত্রাস/গুরুতর অপরাধ',
        },
        {
          number: '01320-040244',
          name_en: 'Traffic Police',
          name_bn: 'ট্রাফিক পুলিশ',
          description_en: 'Traffic Accidents',
          description_bn: 'ট্রাফিক দুর্ঘটনা',
        },
        {
          number: '01715-520520',
          name_en: 'Anti-Terrorism',
          name_bn: 'সন্ত্রাসবিরোধী',
          description_en: 'Terrorism Threats',
          description_bn: 'সন্ত্রাসী হুমকি',
        }
      ]
    },
    {
      key: 'social_protection',
      icon: '👩‍👧‍👦',
      title_en: 'SOCIAL PROTECTION',
      title_bn: 'সামাজিক সুরক্ষা',
      contacts: [
        {
          number: '109',
          name_en: 'Women & Children',
          name_bn: 'নারী ও শিশু',
          description_en: 'Violence/Harassment',
          description_bn: 'সহিংসতা/হয়রানি',
        },
        {
          number: '1098',
          name_en: 'Child Helpline',
          name_bn: 'শিশু হেল্পলাইন',
          description_en: 'Child Abuse/Missing',
          description_bn: 'শিশু নির্যাতন/নিখোঁজ',
        },
        {
          number: '16430',
          name_en: 'Legal Aid',
          name_bn: 'আইনি সহায়তা',
          description_en: 'Free Legal Help',
          description_bn: 'বিনামূল্যে আইনি সহায়তা',
        }
      ]
    },
    {
      key: 'health_medical',
      icon: '🏥',
      title_en: 'HEALTH & MEDICAL',
      title_bn: 'স্বাস্থ্য ও চিকিৎসা',
      contacts: [
        {
          number: '16263',
          name_en: 'COVID-19 Hotline',
          name_bn: 'কোভিড-১৯ হটলাইন',
          description_en: 'Testing/Vaccination',
          description_bn: 'পরীক্ষা/টিকাদান',
        },
        {
          number: '16263',
          name_en: 'Health Ministry',
          name_bn: 'স্বাস্থ্য মন্ত্রণালয়',
          description_en: 'General Health Info',
          description_bn: 'সাধারণ স্বাস্থ্য তথ্য',
        },
        {
          number: '09611-677777',
          name_en: 'Mental Health',
          name_bn: 'মানসিক স্বাস্থ্য',
          description_en: 'Crisis Support',
          description_bn: 'সংকট সহায়তা',
        }
      ]
    },
    {
      key: 'transport_utilities',
      icon: '🚗',
      title_en: 'TRANSPORT & UTILITIES',
      title_bn: 'পরিবহন ও ইউটিলিটি',
      contacts: [
        {
          number: '16263',
          name_en: 'BRTA Help Desk',
          name_bn: 'বিআরটিএ হেল্প ডেস্ক',
          description_en: 'License/Registration',
          description_bn: 'লাইসেন্স/নিবন্ধন',
        },
        {
          number: '16544',
          name_en: 'Dhaka Power',
          name_bn: 'ঢাকা পাওয়ার',
          description_en: 'Electricity Emergency',
          description_bn: 'বিদ্যুৎ জরুরি',
        },
        {
          number: '16462',
          name_en: 'Titas Gas',
          name_bn: 'তিতাস গ্যাস',
          description_en: 'Gas Leaks/Supply',
          description_bn: 'গ্যাস লিক/সরবরাহ',
        },
        {
          number: '16162',
          name_en: 'WASA',
          name_bn: 'ওয়াসা',
          description_en: 'Water Supply',
          description_bn: 'পানি সরবরাহ',
        }
      ]
    },
    {
      key: 'disaster_crisis',
      icon: '🌪️',
      title_en: 'DISASTER & CRISIS',
      title_bn: 'দুর্যোগ ও সংকট',
      contacts: [
        {
          number: '1090',
          name_en: 'Disaster Management',
          name_bn: 'দুর্যোগ ব্যবস্থাপনা',
          description_en: 'Natural Disasters',
          description_bn: 'প্রাকৃতিক দুর্যোগ',
        },
        {
          number: '1090',
          name_en: 'Cyclone Warning',
          name_bn: 'ঘূর্ণিঝড় সতর্কতা',
          description_en: 'Storm Alerts',
          description_bn: 'ঝড়ের সতর্কতা',
        },
        {
          number: '1090',
          name_en: 'Flood Warning',
          name_bn: 'বন্যা সতর্কতা',
          description_en: 'Flood Safety',
          description_bn: 'বন্যা নিরাপত্তা',
        }
      ]
    },
    {
      key: 'government_services',
      icon: '⚖️',
      title_en: 'GOVERNMENT SERVICES',
      title_bn: 'সরকারি সেবা',
      contacts: [
        {
          number: '106',
          name_en: 'Anti-Corruption',
          name_bn: 'দুর্নীতিবিরোধী',
          description_en: 'Corruption Reports',
          description_bn: 'দুর্নীতির রিপোর্ট',
        },
        {
          number: '333',
          name_en: 'National Helpline',
          name_bn: 'জাতীয় হেল্পলাইন',
          description_en: 'Government Info',
          description_bn: 'সরকারি তথ্য',
        },
        {
          number: '16157',
          name_en: 'Public Service',
          name_bn: 'সরকারি চাকরি',
          description_en: 'Job Exam Info',
          description_bn: 'চাকরি পরীক্ষার তথ্য',
        }
      ]
    }
  ];

  const toggleMainExpansion = () => {
    setIsMainExpanded(!isMainExpanded);
    if (!isMainExpanded) {
      setExpandedCategory(null); // Reset category expansion when main is opened
    }
  };

  const toggleCategoryExpansion = (categoryKey: string) => {
    setExpandedCategory(expandedCategory === categoryKey ? null : categoryKey);
  };

  const getCategoryColor = (categoryKey: string) => {
    switch (categoryKey) {
      case 'emergency_24_7':
        return 'from-red-500 to-red-600';
      case 'law_enforcement':
        return 'from-blue-500 to-blue-600';
      case 'social_protection':
        return 'from-pink-500 to-pink-600';
      case 'health_medical':
        return 'from-green-500 to-green-600';
      case 'transport_utilities':
        return 'from-yellow-500 to-orange-500';
      case 'disaster_crisis':
        return 'from-purple-500 to-purple-600';
      case 'government_services':
        return 'from-gray-500 to-gray-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      {/* Main Emergency Button */}
      <button
        onClick={toggleMainExpansion}
        className="w-full flex items-center justify-between p-6 bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-700 hover:to-red-800 transition-all duration-200"
      >
        <div className="flex items-center space-x-4">
          <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
            <span className="text-2xl">🚨</span>
          </div>
          <div className="text-left">
            <h3 className="text-xl font-bold">
              {t('OFFICIAL EMERGENCY CONTACT NUMBERS - BANGLADESH', 'অফিসিয়াল জরুরি যোগাযোগ নম্বর - বাংলাদেশ')}
            </h3>
            <p className="text-red-100 text-sm">
              {t('Tap to view emergency categories', 'জরুরি বিভাগ দেখতে ট্যাপ করুন')}
            </p>
          </div>
        </div>
        <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
          {isMainExpanded ? (
            <ChevronUp className="w-6 h-6 text-white" />
          ) : (
            <ChevronDown className="w-6 h-6 text-white" />
          )}
        </div>
      </button>

      {/* Categories Section */}
      {isMainExpanded && (
        <div className="border-t border-gray-200 bg-gray-50">
          <div className="p-6 space-y-4">
            {emergencyCategories.map((category) => (
              <div key={category.key} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                {/* Category Button */}
                <button
                  onClick={() => toggleCategoryExpansion(category.key)}
                  className={`w-full flex items-center justify-between p-4 bg-gradient-to-r ${getCategoryColor(category.key)} text-white hover:opacity-90 transition-all duration-200`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                      <span className="text-lg">{category.icon}</span>
                    </div>
                    <div className="text-left">
                      <h4 className="text-lg font-bold">
                        {t(category.title_en, category.title_bn)}
                      </h4>
                      <p className="text-white/80 text-xs">
                        {t(`${category.contacts.length} services available`, `${category.contacts.length}টি সেবা উপলব্ধ`)}
                      </p>
                    </div>
                  </div>
                  <div className="bg-white/20 p-1.5 rounded-lg backdrop-blur-sm">
                    {expandedCategory === category.key ? (
                      <ChevronUp className="w-5 h-5 text-white" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-white" />
                    )}
                  </div>
                </button>

                {/* Contact Numbers */}
                {expandedCategory === category.key && (
                  <div className="p-4 bg-gray-50">
                    <div className={`grid ${
                      category.key === 'emergency_24_7' || category.key === 'transport_utilities' 
                        ? 'grid-cols-2 lg:grid-cols-4' 
                        : 'grid-cols-1 lg:grid-cols-3'
                    } gap-3`}>
                      {category.contacts.map((contact, index) => (
                        <button
                          key={index}
                          onClick={() => handleCall(contact.number)}
                          className="w-full bg-white border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-md transition-all duration-200 active:scale-95 group"
                        >
                          <div className="flex items-center space-x-3 mb-3">
                            <div className="bg-blue-100 p-2 rounded-lg group-hover:bg-blue-200 transition-colors">
                              <Phone className="w-4 h-4 text-blue-600" />
                            </div>
                            <div className="text-left flex-1">
                              <p className="text-lg font-bold text-gray-900">
                                {contact.number}
                              </p>
                            </div>
                          </div>
                          
                          <div className="text-left space-y-1">
                            <p className="text-sm font-semibold text-gray-800">
                              {t(contact.name_en, contact.name_bn)}
                            </p>
                            <p className="text-xs text-gray-600">
                              {t(contact.description_en, contact.description_bn)}
                            </p>
                          </div>
                          
                          <div className="mt-3 text-center">
                            <span className="text-xs text-blue-600 font-medium group-hover:text-blue-700">
                              {t('Tap to call', 'কল করতে ট্যাপ করুন')}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Access Footer */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 p-4 text-center">
        <div className="flex items-center justify-center space-x-4 mb-2">
          <button
            onClick={() => handleCall('999')}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors font-bold text-sm"
          >
            {t('Call 999 Emergency', '৯৯৯ জরুরি কল')}
          </button>
          <button
            onClick={() => handleCall('199')}
            className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors font-bold text-sm"
          >
            {t('Call 199 Fire', '১৯৯ ফায়ার কল')}
          </button>
        </div>
        <p className="text-gray-300 text-xs">
          {t('For life-threatening emergencies, call 999 immediately', 'জীবন-মৃত্যুর জরুরি অবস্থায় অবিলম্বে ৯৯৯ কল করুন')}
        </p>
      </div>
    </div>
  );
}
