import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { TestTube, Info } from "lucide-react";

export default function DemoModeBanner() {
  const { isDemoMode } = useAuth();
  const { t } = useLanguage();

  if (!isDemoMode()) return null;

  return (
    <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 text-center relative overflow-hidden">
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white to-transparent transform -skew-x-12 animate-pulse"></div>
      </div>
      
      <div className="relative flex items-center justify-center space-x-2">
        <TestTube className="w-4 h-4 animate-bounce" />
        <span className="font-semibold text-sm">
          {t("🧪 TESTING MODE - All Features Available", "🧪 টেস্টিং মোড - সব ফিচার উপলব্ধ")}
        </span>
        <Info className="w-4 h-4" />
      </div>
      
      <div className="text-xs mt-1 opacity-90">
        {t("Test Account: 01712345678 | Sample data for testing", "টেস্ট অ্যাকাউন্ট: ০১৭১২৩৪৫৬৭৮ | নমুনা ডেটা")}
      </div>
    </div>
  );
}
