import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { AlertTriangle, Award } from 'lucide-react';
import { formatCurrency, calculateReward } from '@/shared/constants';

interface ViolationCardProps {
  violation: {
    id: string;
    name_en: string;
    name_bn: string;
    fine_amount: number;
    reward_percentage: number;
    applies_to: string | string[];
  };
  isSelected: boolean;
  onSelect: (violationId: string) => void;
  vehicleType?: string;
}

export default function ViolationCard({ 
  violation, 
  isSelected, 
  onSelect,
  vehicleType 
}: ViolationCardProps) {
  const { t } = useLanguage();

  const rewardAmount = calculateReward(violation.fine_amount, violation.reward_percentage);

  return (
    <label
      className={`
        relative p-6 border-2 rounded-2xl cursor-pointer transition-all duration-200 hover:shadow-lg
        ${isSelected 
          ? 'border-red-500 bg-red-50 shadow-md transform scale-[1.02]' 
          : 'border-gray-200 bg-white hover:border-red-300 hover:bg-red-50/30'
        }
      `}
    >
      <input
        type="radio"
        name="violation_type"
        value={violation.id}
        checked={isSelected}
        onChange={(e) => onSelect(e.target.value)}
        className="sr-only"
      />
      
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-3">
            <div className={`
              p-2 rounded-xl transition-colors
              ${isSelected ? 'bg-red-200 text-red-700' : 'bg-gray-100 text-gray-600'}
            `}>
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className={`font-bold text-lg transition-colors ${
                isSelected ? 'text-red-900' : 'text-gray-900'
              }`}>
                {t(violation.name_en, violation.name_bn)}
              </h4>
              {vehicleType && (
                <p className="text-sm text-gray-600">
                  {t('Applies to', 'প্রযোজ্য')}: {vehicleType}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-orange-50 border border-orange-200 rounded-xl p-3">
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-orange-600 font-bold text-xs">
                  {t('FINE AMOUNT', 'জরিমানার পরিমাণ')}
                </span>
              </div>
              <p className="text-2xl font-bold text-orange-700">
                {formatCurrency(violation.fine_amount)}
              </p>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Award className="w-4 h-4 text-green-600" />
                <span className="text-green-600 font-bold text-xs">
                  {t('YOUR REWARD', 'আপনার পুরস্কার')}
                </span>
              </div>
              <p className="text-2xl font-bold text-green-700">
                {formatCurrency(rewardAmount)}
              </p>
              <p className="text-xs text-green-600 mt-1">
                ({(violation.reward_percentage * 100).toFixed(0)}% {t('of fine', 'জরিমানার')})
              </p>
            </div>
          </div>
        </div>

        {/* Selection Indicator */}
        {isSelected && (
          <div className="absolute top-4 right-4">
            <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        )}
      </div>
    </label>
  );
}
