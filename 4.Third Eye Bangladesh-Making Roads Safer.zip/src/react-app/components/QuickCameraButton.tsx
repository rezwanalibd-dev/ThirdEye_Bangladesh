import React, { useRef, useState } from 'react';
import { Camera, Video, X, Check } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

interface QuickCameraButtonProps {
  className?: string;
}

export const QuickCameraButton: React.FC<QuickCameraButtonProps> = ({ className = '' }) => {
  const { user } = useAuth();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedFiles, setCapturedFiles] = useState<File[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const labels = {
    en: {
      quickReport: 'Quick Report',
      takePhoto: 'Take Photo',
      recordVideo: 'Record Video',
      cancel: 'Cancel',
      submit: 'Submit Report',
      loginRequired: 'Login Required',
      loginMessage: 'Please login to submit reports',
      captureSuccess: 'Media captured successfully',
      selectFiles: 'Select Files'
    },
    bn: {
      quickReport: 'তাৎক্ষণিক রিপোর্ট',
      takePhoto: 'ছবি তুলুন',
      recordVideo: 'ভিডিও রেকর্ড করুন',
      cancel: 'বাতিল',
      submit: 'রিপোর্ট জমা দিন',
      loginRequired: 'লগইন প্রয়োজন',
      loginMessage: 'রিপোর্ট জমা দিতে লগইন করুন',
      captureSuccess: 'মিডিয়া সফলভাবে ক্যাপচার হয়েছে',
      selectFiles: 'ফাইল নির্বাচন করুন'
    }
  };

  const t = labels[language];

  const handleCameraClick = () => {
    if (!user) {
      // Show login required message and redirect to signin
      alert(t.loginMessage);
      navigate('/signin');
      return;
    }
    setIsCapturing(true);
  };

  const handleFileCapture = (files: File[]) => {
    if (files.length > 0) {
      setCapturedFiles(prev => [...prev, ...Array.from(files)]);
      setShowPreview(true);
      alert(t.captureSuccess);
    }
  };

  const handlePhotoCapture = () => {
    fileInputRef.current?.click();
  };

  const handleVideoCapture = () => {
    videoInputRef.current?.click();
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      handleFileCapture(Array.from(files));
    }
    setIsCapturing(false);
  };

  const handleSubmitReport = () => {
    if (capturedFiles.length > 0) {
      // Navigate to report page with pre-filled media
      const fileUrls = capturedFiles.map(file => URL.createObjectURL(file));
      navigate('/report', { 
        state: { 
          prefilledMedia: fileUrls,
          quickCapture: true 
        } 
      });
    }
    setShowPreview(false);
    setCapturedFiles([]);
  };

  const handleCancel = () => {
    setIsCapturing(false);
    setShowPreview(false);
    setCapturedFiles([]);
  };

  return (
    <>
      {/* Main Camera Button */}
      <button
        onClick={handleCameraClick}
        className={`inline-flex items-center justify-center p-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 relative z-10 ${className}`}
        title={t.quickReport}
      >
        <Camera className="h-5 w-5" />
      </button>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        multiple
        className="hidden"
        onChange={handleFileInputChange}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        capture="environment"
        multiple
        className="hidden"
        onChange={handleFileInputChange}
      />

      {/* Capture Options Modal */}
      {isCapturing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">{t.quickReport}</h3>
              <button
                onClick={handleCancel}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-3">
              <button
                onClick={handlePhotoCapture}
                className="w-full flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
              >
                <Camera className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-gray-700">{t.takePhoto}</span>
              </button>
              
              <button
                onClick={handleVideoCapture}
                className="w-full flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all duration-200"
              >
                <Video className="h-5 w-5 text-red-600" />
                <span className="font-medium text-gray-700">{t.recordVideo}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preview and Submit Modal */}
      {showPreview && capturedFiles.length > 0 && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">{t.selectFiles}</h3>
              <button
                onClick={handleCancel}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="mb-6">
              <div className="flex items-center gap-2 text-sm text-green-600 mb-2">
                <Check className="h-4 w-4" />
                <span>{capturedFiles.length} file(s) captured</span>
              </div>
              
              <div className="space-y-2">
                {capturedFiles.map((file, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                    {file.type.startsWith('image/') ? (
                      <Camera className="h-4 w-4 text-blue-600" />
                    ) : (
                      <Video className="h-4 w-4 text-red-600" />
                    )}
                    <span className="text-sm text-gray-600 truncate">{file.name}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleCancel}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleSubmitReport}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200"
              >
                {t.submit}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
