import { Loader2 } from 'lucide-react';

export default function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50">
      <div className="relative">
        {/* Outer ring */}
        <div className="w-20 h-20 border-4 border-indigo-200 rounded-full animate-pulse"></div>
        {/* Inner spinner */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
        </div>
      </div>
      <div className="mt-8 text-center space-y-2">
        <p className="text-heading-2 text-gray-900 font-semibold">Loading...</p>
        <p className="text-body text-gray-600">Please wait while we prepare your experience</p>
      </div>
      
      {/* Loading dots animation */}
      <div className="flex space-x-2 mt-6">
        <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
        <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
      </div>
    </div>
  );
}
