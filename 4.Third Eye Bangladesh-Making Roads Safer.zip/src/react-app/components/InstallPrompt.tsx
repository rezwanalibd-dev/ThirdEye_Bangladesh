import { useState, useEffect } from 'react';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { Download, X, Smartphone, Apple } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function InstallPrompt() {
  const { t } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode
    const standalone = window.matchMedia('(display-mode: standalone)').matches;
    setIsStandalone(standalone);

    // Check if iOS
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream;
    setIsIOS(iOS);

    // Listen for the beforeinstallprompt event
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      
      // Show install prompt if not already installed
      if (!standalone) {
        setShowInstallPrompt(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setShowInstallPrompt(false);
    }
  };

  const handleDismiss = () => {
    setShowInstallPrompt(false);
    // Remember user dismissed the prompt
    localStorage.setItem('installPromptDismissed', 'true');
  };

  // Don't show if already installed or user dismissed
  if (isStandalone || !showInstallPrompt || localStorage.getItem('installPromptDismissed')) {
    return null;
  }

  // iOS Install Instructions
  if (isIOS) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 shadow-2xl z-50 safe-bottom">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3 flex-1">
              <div className="bg-white/20 p-2 rounded-lg flex-shrink-0">
                <Apple className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1">
                  {t('Install Third Eye App', 'থার্ড আই অ্যাপ ইনস্টল করুন')}
                </h4>
                <p className="text-sm text-blue-100 mb-2">
                  {t('Tap the Share button, then "Add to Home Screen"', 'শেয়ার বাটনে ট্যাপ করুন, তারপর "হোম স্ক্রিনে যোগ করুন"')}
                </p>
                <div className="flex items-center space-x-2 text-xs text-blue-200">
                  <span>1️⃣ Tap</span>
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M16 5l-1.42 1.42-1.59-1.59V16h-1.98V4.83L9.42 6.42 8 5l4-4 4 4zm4 5v11c0 1.1-.9 2-2 2H6c-1.11 0-2-.9-2-2V10c0-1.11.89-2 2-2h3v2H6v11h12V10h-3V8h3c1.1 0 2 .89 2 2z"/>
                  </svg>
                  <span>2️⃣ {t('Add to Home Screen', 'হোম স্ক্রিনে যোগ করুন')}</span>
                </div>
              </div>
            </div>
            <button
              onClick={handleDismiss}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors flex-shrink-0"
              aria-label="Dismiss"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Android/Chrome Install Prompt
  if (deferredPrompt) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4 shadow-2xl z-50 safe-bottom animate-slide-up">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 flex-1">
              <div className="bg-white/20 p-2 rounded-lg">
                <Smartphone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1">
                  {t('Install Third Eye App', 'থার্ড আই অ্যাপ ইনস্টল করুন')}
                </h4>
                <p className="text-sm text-green-100">
                  {t('Get faster access, offline support, and push notifications', 'দ্রুত অ্যাক্সেস, অফলাইন সাপোর্ট এবং পুশ নোটিফিকেশন পান')}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2 ml-4">
              <button
                onClick={handleDismiss}
                className="px-4 py-2 text-white hover:bg-white/20 rounded-lg transition-colors font-medium"
              >
                {t('Later', 'পরে')}
              </button>
              <button
                onClick={handleInstallClick}
                className="px-6 py-2 bg-white text-green-600 rounded-lg hover:bg-green-50 transition-colors font-bold flex items-center space-x-2 shadow-lg"
              >
                <Download className="w-5 h-5" />
                <span>{t('Install', 'ইনস্টল')}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
