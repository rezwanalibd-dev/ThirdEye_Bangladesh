import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { SAFETY_TIPS } from '@/shared/constants';
import { Lightbulb, Shield, AlertTriangle } from 'lucide-react';

export default function SafetyTipsCard() {
  const { t } = useLanguage();

  const getRandomTips = (count: number) => {
    const shuffled = [...SAFETY_TIPS].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };

  const randomTips = getRandomTips(3);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'protective_gear':
        return Shield;
      case 'road_rules':
        return AlertTriangle;
      default:
        return Lightbulb;
    }
  };

  return (
    <div className="card-gradient gradient-warning p-6 md:p-8 text-white">
      <div className="flex items-center space-x-4 mb-6">
        <div className="icon-container bg-white/20 backdrop-blur-sm border border-white/30">
          <AlertTriangle className="w-7 h-7 md:w-8 md:h-8 text-white" />
        </div>
        <div>
          <h3 className="text-display-3 text-white font-bold">
            {t('Daily Safety Tips', 'দৈনিক নিরাপত্তা টিপস')}
          </h3>
          <p className="text-body text-orange-100 font-medium">
            {t('Stay safe on the roads', 'রাস্তায় নিরাপদ থাকুন')}
          </p>
        </div>
      </div>

      <div className="space-content">
        {randomTips.map((tip) => {
          const IconComponent = getCategoryIcon(tip.category);
          return (
            <div key={tip.id} className="glass-effect rounded-xl p-4 md:p-5 border border-white/30 hover:bg-white/15 transition-all duration-300">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 mt-1">
                  <div className="icon-container bg-white/20 backdrop-blur-sm p-2.5">
                    <IconComponent className="w-5 h-5 text-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-heading-2 text-white font-semibold mb-2">
                    {t(tip.title_en, tip.title_bn)}
                  </h4>
                  <p className="text-body text-orange-100 leading-relaxed">
                    {t(tip.description_en, tip.description_bn)}
                  </p>
                </div>
                <span className="text-2xl md:text-3xl flex-shrink-0">{tip.icon}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 pt-6 border-t border-white/30">
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 md:p-5 border border-white/20">
          <p className="text-center text-body text-orange-100 font-medium leading-relaxed">
            💡 {t(
              'Following traffic rules saves lives and prevents accidents',
              'ট্রাফিক নিয়ম মেনে চলা জীবন বাঁচায় এবং দুর্ঘটনা প্রতিরোধ করে'
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
