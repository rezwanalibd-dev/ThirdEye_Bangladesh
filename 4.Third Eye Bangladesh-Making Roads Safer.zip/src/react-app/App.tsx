import { BrowserRouter as Router, Routes, Route, Link, useLocation } from "react-router";
import { useState } from "react";
import { AuthProvider } from "@/react-app/contexts/AuthContext";
import { LanguageProvider } from "@/react-app/contexts/LanguageContext";
import HomePage from "@/react-app/pages/Home";
import SignupPage from "@/react-app/pages/Signup";
import SigninPage from "@/react-app/pages/Signin";
import OTPVerificationPage from "@/react-app/pages/OTPVerification";
import IdentityVerificationPage from "@/react-app/pages/IdentityVerification";
import BiometricVerificationPage from "@/react-app/pages/BiometricVerification";
import DashboardPage from "@/react-app/pages/Dashboard";
import ReportPage from "@/react-app/pages/Report";
import SocialCrimePage from "@/react-app/pages/SocialCrime";
import CasesPage from "@/react-app/pages/Cases";
import ProfilePage from "@/react-app/pages/Profile";
import SetupPage from "@/react-app/pages/Setup";
import VehicleRulesPage from "@/react-app/pages/VehicleRules";
import TrafficFinesPage from "@/react-app/pages/TrafficFines";
import FeaturesPage from "@/react-app/pages/Features";
import SettingsPage from "@/react-app/pages/Settings";
import ProtectedRoute from "@/react-app/components/ProtectedRoute";
import { QuickCameraButton } from "@/react-app/components/QuickCameraButton";
import DemoModeBanner from "@/react-app/components/DemoModeBanner";
import InstallPrompt from "@/react-app/components/InstallPrompt";
import { useAuth } from "@/react-app/contexts/AuthContext";
import { useLanguage } from "@/react-app/contexts/LanguageContext";
import { Menu, X, Globe } from "lucide-react";

function AppHeader() {
  const { user } = useAuth();
  const { language, setLanguage } = useLanguage();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const t = (en: string, bn: string) => language === 'bn' ? bn : en;

  // Don't show header on auth pages
  const authPages = ['/signup', '/signin', '/verify-otp', '/verify-identity', '/verify-biometric', '/setup'];
  const shouldShowHeader = !authPages.includes(location.pathname);

  if (!shouldShowHeader) {
    return null;
  }

  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">👁️</span>
              </div>
              <span className="text-2xl font-bold text-gray-900">Third Eye</span>
            </Link>
            <div className="hidden sm:block">
              <QuickCameraButton />
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors"
              title={t('Switch Language', 'ভাষা পরিবর্তন করুন')}
            >
              <Globe className="h-4 w-4" />
              <span className="text-sm font-medium">{language.toUpperCase()}</span>
            </button>
            
            <div className="flex items-center space-x-4">
              <Link 
                to="/features" 
                className="px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t('Features', 'বৈশিষ্ট্য')}
              </Link>
            </div>

            {user ? (
              <div className="flex items-center space-x-4">
                <Link
                  to="/dashboard"
                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium"
                >
                  {t('Dashboard', 'ড্যাশবোর্ড')}
                </Link>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link
                  to="/signin"
                  className="px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors font-medium"
                >
                  {t('Sign In', 'সাইন ইন')}
                </Link>
                <Link
                  to="/signup"
                  className="px-4 py-2 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg hover:from-red-700 hover:to-red-800 transition-all font-medium"
                >
                  {t('Get Started', 'শুরু করুন')}
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center space-x-4 lg:hidden">
            <div className="block sm:hidden">
              <QuickCameraButton />
            </div>
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 lg:hidden">
          <div className="fixed right-0 top-0 h-full w-80 bg-white shadow-xl">
            <div className="flex items-center justify-between p-6 border-b">
              <span className="text-xl font-bold text-gray-900">Menu</span>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 text-gray-600 hover:text-red-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="py-6">
              <button
                onClick={() => {
                  setLanguage(language === 'en' ? 'bn' : 'en');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 w-full px-6 py-4 text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-all border-b border-gray-100"
              >
                <Globe className="h-5 w-5" />
                <span className="font-medium">{t('Switch to Bengali', 'ইংরেজিতে পরিবর্তন')}</span>
              </button>
              
              <Link 
                to="/features" 
                className="block px-6 py-4 text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-all border-b border-gray-100 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {t('Features', 'বৈশিষ্ট্য')}
              </Link>
              
              <div className="px-6 py-4 border-b border-gray-100">
                <QuickCameraButton className="w-full justify-center" />
              </div>

              {user ? (
                <div className="px-6 py-4 space-y-4">
                  <Link
                    to="/dashboard"
                    className="block w-full text-center px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {t('Dashboard', 'ড্যাশবোর্ড')}
                  </Link>
                </div>
              ) : (
                <div className="px-6 py-4 space-y-4">
                  <Link
                    to="/signin"
                    className="block w-full text-center px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all font-medium"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {t('Sign In', 'সাইন ইন')}
                  </Link>
                  <Link
                    to="/signup"
                    className="block w-full text-center px-4 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg hover:from-red-700 hover:to-red-800 transition-all font-medium"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {t('Get Started', 'শুরু করুন')}
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <div className="min-h-screen bg-white">
            <DemoModeBanner />
            <AppHeader />
            <InstallPrompt />
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/signin" element={<SigninPage />} />
              <Route path="/verify-otp" element={<OTPVerificationPage />} />
              <Route path="/verify-identity" element={<IdentityVerificationPage />} />
              <Route path="/verify-biometric" element={<BiometricVerificationPage />} />
              <Route 
                path="/setup" 
                element={
                  <ProtectedRoute>
                    <SetupPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/report" 
                element={
                  <ProtectedRoute>
                    <ReportPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/social-crime" 
                element={
                  <ProtectedRoute>
                    <SocialCrimePage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/cases" 
                element={
                  <ProtectedRoute>
                    <CasesPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/settings" 
                element={
                  <ProtectedRoute>
                    <SettingsPage />
                  </ProtectedRoute>
                } 
              />
              <Route path="/vehicle-rules" element={<VehicleRulesPage />} />
              <Route path="/traffic-fines" element={<TrafficFinesPage />} />
              <Route path="/features" element={<FeaturesPage />} />
            </Routes>
          </div>
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}
